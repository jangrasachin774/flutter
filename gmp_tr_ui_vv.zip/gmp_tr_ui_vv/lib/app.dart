import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/presentation/home_route.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:gmptr/utils/utils.dart';

import 'blocs/app_bloc.dart';
import 'blocs/bloc.dart';
import 'configs/config.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:io' show Platform;

class App extends StatefulWidget {
  const App({Key key}) : super(key: key);

  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {
  final route = Routes();
  var isMobile;
  @override
  void initState() {
    super.initState();
    AppBloc.applicationBloc.add(OnSetupApplication());
    if (kIsWeb) {
      isMobile = "no";
    } else if (Platform.isAndroid || Platform.isIOS) {
      isMobile = "yes";
    }
  }

  @override
  void dispose() {
    AppBloc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: AppBloc.providers,
      child: BlocBuilder<LanguageBloc, LanguageState>(builder: (context, lang) {
        return MaterialApp(
          title: StringConst.APP_NAME,
          debugShowCheckedModeBanner: false,
          theme: AppTheme.lightTheme,
          locale: AppLanguage.defaultLanguage,
          localizationsDelegates: [
            Translate.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          supportedLocales: AppLanguage.supportLanguage,
          builder: (context, child) => HomePage(child: child),
          onGenerateRoute: isMobile == "yes" ? route.generateMobileRoute : route.generateRoute,
          initialRoute: Routes.authPage,
        );
      }),
    );
  }
}
