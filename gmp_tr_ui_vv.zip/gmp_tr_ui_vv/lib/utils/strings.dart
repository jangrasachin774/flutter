class StringConst {
  //strings
  static const String APP_NAME = "Dataduoda";
}
