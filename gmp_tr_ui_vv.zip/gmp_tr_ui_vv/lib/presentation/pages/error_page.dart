import 'package:flutter/material.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/authentication/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class ErrorPage extends StatelessWidget {
  const ErrorPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.loose,
      children: [
        Container(
          decoration: BoxDecoration(
            color: const Color(0xff00439E),
            image: DecorationImage(
              image: AssetImage(Images.LoginBg),
              fit: BoxFit.cover,
            ),
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: Center(
            child: Container(
              width: 420,
              height: 600,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2.2),
                color: Colors.white,
              ),
              padding: EdgeInsets.symmetric(vertical: 30, horizontal: 40),
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image(image: AssetImage(Images.Logo)),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Translate.of(context).translate('student_only'),
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextButton(
                    child: Text(
                      Translate.of(context).translate('login'),
                      style: TextStyle(
                          color: Colors.blue,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      AppBloc.authBloc.add(OnClear());
                      Navigator.popAndPushNamed(context, Routes.signIn);
                    },
                  )
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
