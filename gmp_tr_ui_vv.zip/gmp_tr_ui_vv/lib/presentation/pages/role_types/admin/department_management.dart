import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class DepartmentManagementPage extends StatefulWidget {
  const DepartmentManagementPage({Key key}) : super(key: key);

  @override
  _DepartmentManagementPageState createState() =>
      _DepartmentManagementPageState();
}

class _DepartmentManagementPageState extends State<DepartmentManagementPage> {
  final _textIDController = TextEditingController();

  String _validID;
  var _focusID = FocusNode();

  @override
  void initState() {
    super.initState();
    AppBloc.departmentBlocs.add(OnLoadDepartments());
  }

  ///On create department Level
  _createDepartLevel1(parentId) async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text, min: 1);
    });
    if (_validID == null) {
      AppBloc.departmentBlocs.add(OnAddDepartment(
          name: _textIDController.text, parentId: parentId, level: 1));
      AppBloc.departmentBlocs.add(OnLoadDepartments());
    }
  }

  ///Create Department Form Level
  Future<void> _showFormLevel1(parentId) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  autoFocus: true,
                  hintText: Translate.of(context).translate('department_name'),
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textIDController,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      print(text);
                      _validID = UtilValidator.validate(
                        data: _textIDController.text,
                      );
                    });
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                    bloc: BlocProvider.of<DepartmentsListBloc>(context),
                    builder: (context, save) {
                      return BlocListener<DepartmentsListBloc,
                          DepartmentsListState>(
                        listener: (context, state) {
                          if (state is DepartmentsaveFail) {
                            Text(state.code);
                          }
                          if (state is DepartmentsaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text("Department Added Successfully"),
                            ));
                          }
                        },
                        child: AppButton(
                          Translate.of(context).translate('create'),
                          onPressed: () => _createDepartLevel1(parentId),
                          type: ButtonType.normal,
                          loading: save is Departmentsaving,
                          disabled: save is Departmentsaving,
                          color: Color(0xff787E8C),
                        ),
                      );
                    })
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);

    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Translate.of(context).translate('department_mngmt'),
                    style: TextStyle(
                        color: Color(0xff00439E),
                        fontSize: widthOfScreen(context) * 0.025,
                        fontWeight: FontWeight.bold),
                  ),
                  AppButton(
                    Translate.of(context).translate('create_department'),
                    onPressed: () {
                      setState(() {
                        _showFormLevel1(null);
                      });
                    },
                    type: ButtonType.normal,
                    color: Color(0xff787E8C),
                    icon: Icon(
                      Icons.person_add_outlined,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                child: BlocListener<DepartmentsListBloc, DepartmentsListState>(
                  listener: (context, state) {
                    if (state is DepartmentsaveFail) {
                      Text(state.code);
                    }
                    if (state is DepartmentsaveSuccess) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        backgroundColor: Colors.green,
                        content: Text("Child Department Added Successfully"),
                      ));
                    }
                    if (state is DepartmentUpdatingSuccess) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        backgroundColor: Colors.green,
                        content: Text("Department Updated Successfully"),
                      ));
                    }
                  },
                  child: BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                      bloc: BlocProvider.of<DepartmentsListBloc>(context),
                      builder: (context, departmentsList) {
                        if (departmentsList is DepartmentsLoading) {
                          return Center(child: CircularProgressIndicator());
                        } else if (departmentsList is DepartmentsSuccess) {
                          return Container(
                            decoration: BoxDecoration(
                              border: Border(
                                top: BorderSide(color: Color(0xffD4E5F9)),
                                left: BorderSide(color: Color(0xffD4E5F9)),
                                right: BorderSide(color: Color(0xffD4E5F9)),
                              ),
                            ),
                            child: MyDynamicTreeView(
                              actionVisible: true,
                              data: departmentsList.departments,
                              width: screenWidth * 0.7,
                              config: Config(
                                rootId: "null",
                              ),
                            ),
                          );
                        } else if (departmentsList is DepartmentsFail) {
                          return Container(
                            child: Text(departmentsList.code),
                          );
                        } else {
                          return Container(
                            child: Text(""),
                          );
                        }
                      }),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
