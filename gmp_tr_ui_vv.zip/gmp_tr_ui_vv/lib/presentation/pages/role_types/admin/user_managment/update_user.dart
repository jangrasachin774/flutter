import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/user_role_view_types/user_role_view_types_event.dart';
import 'package:gmptr/blocs/users/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/pages/role_types/admin/user_managment/user_authorities.dart';
import 'package:gmptr/presentation/pages/role_types/types.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/repository/repository.dart';
import 'package:gmptr/utils/utils.dart';

import 'package:responsive_builder/responsive_builder.dart';

class UpdateUser extends StatefulWidget {
  final UsersModel user;
  const UpdateUser({Key key, this.user}) : super(key: key);

  @override
  _UpdateUserState createState() => _UpdateUserState();
}

class _UpdateUserState extends State<UpdateUser> {
  int _chosenValue;
  int _choseGender;
  int _statusValue;
  int _currentStep = 0;
  int userRoleIdFk;

  // Default Radio Button Selected Item.
  String radioItemHolder;

  // Group Value for Radio Button.
  int id = 1;
  int widgetRoleId;
  int multiRoleId;
  int multiUserRoleIdFk;

  String roleName;
  int roleId;

  bool isCheckboxChecked;

  StepperType stepperType = StepperType.horizontal;

  final _textIDController = TextEditingController();
  final _textNameController = TextEditingController();
  final _textUsernameController = TextEditingController();
  final _textPassController = TextEditingController();
  final _textWorkNoController = TextEditingController();
  final _textContactController = TextEditingController();
  final _textRealCompanyController = TextEditingController();
  final _textRealDepoController = TextEditingController();

  String _validID;
  String _validName;
  String _validUsername;
  String _validPassword;
  String _validWorkNo;
  String _validContact;
  String _validRealCompany;
  String _validRealDept;
  final _textEmailController = TextEditingController();
  String _validEmail;
  List<DropdownMenuItem> items = [];
  List<DropdownMenuItem> docItems = [];

  List<int> selectedLeadersDocsItems = [];
  List<int> unSelectedLeadersDocsItems = [];

  List<String> selectedAdminDepartsItems = [];

  List<String> selectedAdminDepartMngmtItems = [];

  List<String> selectedViewDepartsItems = [];
  List<int> unSelectedViewDepartsItems = [];

  List<int> selectedItems = [];
  List<int> unSelectedItems = [];
  List<int> selectedDocItems = [];
  List<int> unSelectedDocItems = [];
  List<Departments> childList;
  List<DocumentsFeature> listItems;
  List<String> multiRolesId = [];

  List<String> selected = [];
  List<String> taskDeptselected = [];
  List<String> docSelected = [];

  int getId;

  @override
  void initState() {
    super.initState();
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.rolesBloc.add(OnLoadRoles());
    AppBloc.adminPagesBloc.add(OnLoadAdminPages());
    AppBloc.userRolesBloc.add(OnLoadUserRoles(userId: widget.user.id));
    _textIDController.text = widget.user.identifier.toString();
    _textNameController.text = widget.user.name;
    _textUsernameController.text = widget.user.username;
    _textPassController.text = widget.user.password;
    _textWorkNoController.text = widget.user.workNo;
    _textContactController.text = widget.user.contact;
    _textRealCompanyController.text = widget.user.realCompany;
    _textRealDepoController.text = widget.user.realDepartment;
    _textEmailController.text = widget.user.email;
    setState(() {
      id = 1;
    });
  }

  Future _update() async {
    setState(() {
      _validID = UtilValidator.validate(
        data: _textIDController.text,
        min: 1,
        max: 10,
      );
      _validName = UtilValidator.validate(
        data: _textNameController.text,
        min: 3,
        max: 50,
      );
      _validPassword = UtilValidator.validate(
        data: _textPassController.text,
        min: 6,
        max: 10,
      );
      _validWorkNo = UtilValidator.validate(
        data: _textWorkNoController.text,
        min: 1,
        max: 10,
      );
      _validContact = UtilValidator.validate(
        data: _textContactController.text,
        min: 9,
        max: 12,
      );
      _validUsername = UtilValidator.validate(
        data: _textUsernameController.text,
        type: ValidateType.normal,
        min: 4,
        max: 30,
      );
      _validEmail = UtilValidator.validate(
        data: _textEmailController.text,
        type: ValidateType.email,
      );
    });

    if (_validName == null && _validUsername == null && _validPassword == null && _validWorkNo == null && _validEmail == null) {
      AppBloc.usersBloc.add(OnUpdateUser(
        id: widget.user.id,
        name: _textNameController.text,
        email: _textEmailController.text,
        username: _textUsernameController.text,
        password: _textPassController.text,
        workNo: _textWorkNoController.text,
        contact: _textContactController.text,
        realCompany: _textRealCompanyController.text,
        realDepartment: _textRealDepoController.text,
        userStatusIdFk: _statusValue ?? widget.user.userStatusIdFk,
        gender: _choseGender ?? widget.user.gender,
        departmentIdFk: _chosenValue ?? widget.user.departmentIdFk,
      ));
      // AppBloc.usersBloc.add(OnLoadUsers());
      AppBloc.userRolesBloc.add(OnLoadUserRoles(userId: widget.user.id));
    }
  }

  tapped(int step) {
    setState(() => _currentStep = step);
  }

  continued() {
    UtilPreferences.setStringList(
      Preferences.singleUserRoleId,
      [],
    );
    UtilPreferences.setStringList(
      Preferences.multipleUserRoleId,
      [],
    );
    UtilPreferences.setStringList(
      Preferences.userAdminPage,
      [],
    );
    UtilPreferences.setStringList(
      "multiRoleIdChecked",
      [],
    );
    if (_validName == null && _validUsername == null && _validPassword == null && _validWorkNo == null && _validEmail == null) {
      Application.userRoleId = null;
      // ignore: unnecessary_statements
      _currentStep < 1 ? setState(() => _currentStep += 1) : null;
    }
  }

  cancel() {
    return UserManagementPage();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);
    double contentAreaWidthSm = screenWidth * 1.0;
    double contentAreaWidthLg = screenWidth * 0.6;
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: ResponsiveBuilder(
          refinedBreakpoints: RefinedBreakpoints(),
          builder: (context, sizingInformation) {
            double screenWidth = sizingInformation.screenSize.width;
            //Desktop
            if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
              return SingleChildScrollView(
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                            icon: Icon(Icons.close_outlined),
                            onPressed: () {
                              Navigator.of(context).pop();
                              AppBloc.usersBloc.add(OnLoadFilteredUsers(departmentIdFk: null));
                              // AppBloc.usersBloc.add(OnLoadUsers());
                            })
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: contentAreaWidthSm,
                      height: 720,
                      child: Theme(
                        data: ThemeData(canvasColor: Colors.transparent, shadowColor: Colors.transparent),
                        child: Stepper(
                         /* controlsBuilder: (context, details) {
                            return Container(
                              margin: EdgeInsets.only(top: 20),
                              child: Row(
                                children: <Widget>[
                                  _currentStep == 0
                                      ? BlocBuilder<UsersListBloc, UsersListState>(
                                          bloc: BlocProvider.of<UsersListBloc>(context),
                                          builder: (context, save) {
                                            return BlocListener<UsersListBloc, UsersListState>(
                                              listener: (context, state) {
                                                if (state is UserSaveFail) {
                                                  Text(state.error.toString());
                                                }
                                                if (state is UserSaveSuccess) {
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                    backgroundColor: Colors.green,
                                                    content: Text("Saved User Basic Details Successfully"),
                                                  ));
                                                }
                                              },
                                              child: AppButton(
                                                Translate.of(context).translate('next'),
                                                onPressed: () async {
                                                  _update();
                                                  details.onStepContinue();
                                                },
                                                loading: save is UserUpdating,
                                                disabled: save is UserUpdating,
                                                type: ButtonType.normal,
                                                color: Color(0xff787E8C),
                                                icon: Icon(
                                                  Icons.navigate_next_outlined,
                                                ),
                                              ),
                                            );
                                          })
                                      : Container(),
                                  SizedBox(
                                    width: 20,
                                  ),
                                ],
                              ),
                            );
                          },*/

                          // controlsBuilder: (BuildContext context,
                          //     {VoidCallback onStepContinue,
                          //     VoidCallback onStepCancel}) {
                          //   return Container(
                          //     margin: EdgeInsets.only(top: 20),
                          //     child: Row(
                          //       children: <Widget>[
                          //         _currentStep == 0
                          //             ? BlocBuilder<UsersListBloc,
                          //                     UsersListState>(
                          //                 bloc: BlocProvider.of<UsersListBloc>(
                          //                     context),
                          //                 builder: (context, save) {
                          //                   return BlocListener<UsersListBloc,
                          //                       UsersListState>(
                          //                     listener: (context, state) {
                          //                       if (state is UserSaveFail) {
                          //                         Text(state.error.toString());
                          //                       }
                          //                       if (state is UserSaveSuccess) {
                          //                         ScaffoldMessenger.of(context)
                          //                             .showSnackBar(SnackBar(
                          //                           backgroundColor:
                          //                               Colors.green,
                          //                           content: Text(
                          //                               "Saved User Basic Details Successfully"),
                          //                         ));
                          //                       }
                          //                     },
                          //                     child: AppButton(
                          //                       Translate.of(context)
                          //                           .translate('next'),
                          //                       onPressed: () async {
                          //                         _update();
                          //                         onStepContinue();
                          //                       },
                          //                       loading: save is UserUpdating,
                          //                       disabled: save is UserUpdating,
                          //                       type: ButtonType.normal,
                          //                       color: Color(0xff787E8C),
                          //                       icon: Icon(
                          //                         Icons.navigate_next_outlined,
                          //                       ),
                          //                     ),
                          //                   );
                          //                 })
                          //             : Container(),
                          //         SizedBox(
                          //           width: 20,
                          //         ),
                          //       ],
                          //     ),
                          //   );
                          // },
                          type: stepperType,
                          physics: ScrollPhysics(),
                          currentStep: _currentStep,
                          onStepTapped: (step) => tapped(step),
                          onStepContinue: continued,
                          onStepCancel: cancel,
                          steps: <Step>[
                            Step(
                              title: new Text(Translate.of(context).translate('basic_details')),
                              isActive: _currentStep >= 0,
                              state: _currentStep >= 0 ? StepState.complete : StepState.disabled,
                              content: Theme(
                                data: ThemeData(canvasColor: Colors.white, shadowColor: Colors.black54),
                                child: Container(
                                  width: contentAreaWidthLg,
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(
                                                    Translate.of(context).translate('user_status'),
                                                    style: TextStyle(fontSize: 14),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: Container(
                                                    height: 40,
                                                    padding: EdgeInsets.symmetric(
                                                      horizontal: 10,
                                                      vertical: 0,
                                                    ),
                                                    decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                                    child: DropdownButton(
                                                      isExpanded: true,
                                                      value: _statusValue ?? widget.user.userStatusIdFk,
                                                      underline: SizedBox(),
                                                      icon: Icon(Icons.keyboard_arrow_down_outlined),
                                                      items: [
                                                        DropdownMenuItem(
                                                          child: Text(
                                                            Translate.of(context).translate("normal"),
                                                            style: TextStyle(fontSize: 12),
                                                          ),
                                                          value: 1,
                                                        ),
                                                        DropdownMenuItem(
                                                          child: Text(
                                                            Translate.of(context).translate("leave"),
                                                            style: TextStyle(fontSize: 12),
                                                          ),
                                                          value: 2,
                                                        ),
                                                        DropdownMenuItem(
                                                          child: Text(
                                                            Translate.of(context).translate("disabled"),
                                                            style: TextStyle(fontSize: 12),
                                                          ),
                                                          value: 3,
                                                        )
                                                      ],
                                                      hint: Text(
                                                        Translate.of(context).translate("choose_status"),
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 12,
                                                        ),
                                                      ),
                                                      onChanged: (int value) {
                                                        setState(() {
                                                          _statusValue = value;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Container(),
                                                ),
                                                Expanded(
                                                  flex: 4,
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        flex: 1,
                                                        child: Text(
                                                          Translate.of(context).translate('department_for_training'),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 3,
                                                        child: Container(
                                                          height: 40,
                                                          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                                                          decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                                          child: BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                                                            bloc: BlocProvider.of<DepartmentsListBloc>(context),
                                                            builder: (context, departmentsList) {
                                                              if (departmentsList is DepartmentsLoading) {
                                                                return Text(
                                                                  Translate.of(context).translate("choose_department"),
                                                                  style: TextStyle(
                                                                    color: Colors.black,
                                                                    fontSize: 12,
                                                                  ),
                                                                );
                                                              } else if (departmentsList is DepartmentsSuccess) {
                                                                return DropdownButton(
                                                                  isExpanded: true,
                                                                  value: _chosenValue ?? widget.user.departmentIdFk,
                                                                  underline: SizedBox(),
                                                                  icon: Icon(Icons.keyboard_arrow_down_outlined),
                                                                  items: getDepartmentsList(departmentsList.departments),
                                                                  hint: Text(
                                                                    Translate.of(context).translate("choose_department"),
                                                                    style: TextStyle(
                                                                      color: Colors.black,
                                                                      fontSize: 12,
                                                                    ),
                                                                  ),
                                                                  onChanged: (int value) {
                                                                    setState(() {
                                                                      _chosenValue = value;
                                                                    });
                                                                  },
                                                                );
                                                              } else {
                                                                return Container();
                                                              }
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Expanded(flex: 1, child: Container()),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(Translate.of(context).translate("name")),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textNameController,
                                                    errorText: Translate.of(context).translate(_validName),
                                                    onTapIcon: () async {
                                                      _textNameController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      _validName = UtilValidator.validate(
                                                        data: _textNameController.text,
                                                      );
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(Translate.of(context).translate("id")),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textIDController,
                                                    errorText: Translate.of(context).translate(_validID),
                                                    onTapIcon: () async {
                                                      _textIDController.clear();
                                                    },
                                                    keyboardType: TextInputType.number,
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validID = UtilValidator.validate(
                                                          data: _textIDController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(Translate.of(context).translate("gender")),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: Container(
                                                    height: 40,
                                                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                                                    decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                                    child: DropdownButton(
                                                      isExpanded: true,
                                                      value: _choseGender ?? widget.user.gender,
                                                      underline: SizedBox(),
                                                      icon: Icon(Icons.keyboard_arrow_down_outlined),
                                                      items: [
                                                        DropdownMenuItem(
                                                          child: Text(
                                                            Translate.of(context).translate("male"),
                                                            style: TextStyle(fontSize: 12),
                                                          ),
                                                          value: 1,
                                                        ),
                                                        DropdownMenuItem(
                                                          child: Text(
                                                            Translate.of(context).translate("female"),
                                                            style: TextStyle(fontSize: 12),
                                                          ),
                                                          value: 0,
                                                        )
                                                      ],
                                                      hint: Text(
                                                        Translate.of(context).translate("choose_gender"),
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 12,
                                                        ),
                                                      ),
                                                      onChanged: (int value) {
                                                        setState(() {
                                                          _choseGender = value;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Container(),
                                                ),
                                                Expanded(
                                                  flex: 4,
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        flex: 1,
                                                        child: Text(Translate.of(context).translate("work_no")),
                                                      ),
                                                      Expanded(
                                                        flex: 3,
                                                        child: AppTextInput(
                                                          controller: _textWorkNoController,
                                                          errorText: Translate.of(context).translate(_validWorkNo),
                                                          onTapIcon: () async {
                                                            _textWorkNoController.clear();
                                                          },
                                                          icon: Icon(
                                                            Icons.clear,
                                                            size: 14,
                                                          ),
                                                          onChanged: (text) {
                                                            setState(() {
                                                              _validWorkNo = UtilValidator.validate(
                                                                data: _textWorkNoController.text,
                                                              );
                                                            });
                                                          },
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Container(),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(Translate.of(context).translate("contact")),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textContactController,
                                                    errorText: Translate.of(context).translate(_validContact),
                                                    onTapIcon: () async {
                                                      _textContactController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validContact = UtilValidator.validate(
                                                          data: _textContactController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(Translate.of(context).translate("email")),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textEmailController,
                                                    errorText: Translate.of(context).translate(_validEmail),
                                                    onTapIcon: () async {
                                                      _textEmailController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validEmail = UtilValidator.validate(
                                                          data: _textEmailController.text,
                                                          type: ValidateType.email,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(
                                                    Translate.of(context).translate('real_company'),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textRealCompanyController,
                                                    errorText: Translate.of(context).translate(_validRealCompany),
                                                    onTapIcon: () async {
                                                      _textRealCompanyController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validRealCompany = UtilValidator.validate(
                                                          data: _textRealCompanyController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(
                                                    Translate.of(context).translate('real_department'),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textRealDepoController,
                                                    errorText: Translate.of(context).translate(_validRealDept),
                                                    onTapIcon: () async {
                                                      _textRealDepoController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validRealDept = UtilValidator.validate(
                                                          data: _textRealDepoController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(
                                                    Translate.of(context).translate('username'),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textUsernameController,
                                                    errorText: Translate.of(context).translate(_validUsername),
                                                    onTapIcon: () async {
                                                      _textUsernameController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validUsername = UtilValidator.validate(
                                                          data: _textUsernameController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(
                                                    Translate.of(context).translate('password'),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textPassController,
                                                    errorText: Translate.of(context).translate(_validPassword),
                                                    onTapIcon: () async {
                                                      _textPassController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validPassword = UtilValidator.validate(
                                                          data: _textPassController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Step(
                              title: new Text(Translate.of(context).translate("role_details")),
                              content: Theme(
                                data: ThemeData(canvasColor: Colors.white, shadowColor: Colors.black54),
                                child: BlocListener<UserRolesListBloc, UserRolesListState>(
                                  listener: (context, state) {
                                    if (state is SingleUserRoleSaveSuccess) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        backgroundColor: Colors.green,
                                        content: Text(Translate.of(context).translate("assign_role_success")),
                                      ));
                                    }
                                    if (state is UserRoleSaveSuccess) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        backgroundColor: Colors.green,
                                        content: Text(Translate.of(context).translate("assign_role_success")),
                                      ));
                                    }
                                    if (state is UserRoleDeleteSuccess) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        backgroundColor: Colors.red,
                                        content: Text(Translate.of(context).translate("delete_role_success")),
                                      ));
                                    }
                                    if (state is SingleUserRoleDeleteSuccess) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        backgroundColor: Colors.red,
                                        content: Text(Translate.of(context).translate("delete_role_success")),
                                      ));
                                    }
                                  },
                                  child: BlocBuilder<UserRolesListBloc, UserRolesListState>(
                                    bloc: BlocProvider.of<UserRolesListBloc>(context),
                                    builder: (context, userRolesList) {
                                      if (userRolesList is UserRolesLoading) {
                                        return Container();
                                      } else if (userRolesList is UserRolesSuccess) {
                                        return Container(
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    Translate.of(context).translate("role"),
                                                    style: TextStyle(fontWeight: FontWeight.bold),
                                                  ),
                                                  SizedBox(
                                                    height: 18,
                                                  ),
                                                  Container(
                                                    width: 220,
                                                    decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                                                    padding: EdgeInsets.all(20),
                                                    child: BlocBuilder<RolesListBloc, RolesListState>(
                                                      bloc: BlocProvider.of<RolesListBloc>(context),
                                                      builder: (context, rolesList) {
                                                        if (rolesList is RolesSuccess) {
                                                          return ListView.builder(
                                                            shrinkWrap: true,
                                                            itemCount: rolesList.roles.length,
                                                            itemBuilder: (context, i) {
                                                              final roles = rolesList.roles[i];
                                                              return Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Text(
                                                                    roles.name,
                                                                    style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                                                                  ),
                                                                  roles != null && roles.roles.length > 0
                                                                      ? ListView.builder(
                                                                          shrinkWrap: true,
                                                                          itemCount: roles.roles.length,
                                                                          itemBuilder: (context, index) {
                                                                            final userRolesRepository = UserRolesRepository();
                                                                            userRolesList.userroles.map((element) {
                                                                              if (element.roleIdFk == roles.roles[index].id) {
                                                                                if (roles.multiSelect == false) {
                                                                                  id = element.roleIdFk;
                                                                                  userRoleIdFk = element.id;
                                                                                }
                                                                                if (roles.multiSelect == true) {
                                                                                  roles.roles[index].isCheck = true;
                                                                                  multiUserRoleIdFk = element.id;

                                                                                  roleName = roles.roles[index].name;

                                                                                  roleId = roles.roles[index].id;
                                                                                  userRolesRepository.saveUserRoleId(multiUserRoleIdFk, widget.user.id, roleId, roleName);
                                                                                }
                                                                              }
                                                                            }).toList();

                                                                            userRolesRepository.saveSingleUserRoleId(userRoleIdFk);
                                                                            AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                                                                            AppBloc.userRoleDepartmentsBloc.add(OnLoadUserRoleDepartments(userRoleIdFk: Application.userRoleId));

                                                                            AppBloc.userRoleDocTypesBloc.add(OnLoadUserRoleDocTypes(userRoleIdFk: Application.userRoleId));

                                                                            AppBloc.userRoleTrainingTypes.add(OnLoadUserRoleTrainingTypes(userRoleIdFk: Application.userRoleId));
                                                                            AppBloc.userRoleViewTypesBloc.add(OnLoadUserRoleViewTypes(userRoleIdFk: Application.userRoleId));

                                                                            return roles.multiSelect == false
                                                                                ? MyRadioListTile<int>(
                                                                                    value: roles.roles[index].id,
                                                                                    groupValue: id,
                                                                                    title: Text(
                                                                                      "${roles.roles[index].name}",
                                                                                      style: TextStyle(
                                                                                        fontSize: 12,
                                                                                      ),
                                                                                    ),
                                                                                    onChanged: (value) {
                                                                                      setState(
                                                                                        () {
                                                                                          id = value;
                                                                                          var userRoleId = Application.userRoleId;
                                                                                          if (userRoleId != null) {
                                                                                            AppBloc.userRolesBloc.add(OnRemoveUserRoleId(id: userRoleId));

                                                                                            AppBloc.userRolesBloc.add(OnCreateSingleUserRole(roleId: id));
                                                                                          } else {
                                                                                            AppBloc.userRolesBloc.add(OnCreateSingleUserRole(roleId: id));
                                                                                          }
                                                                                          AppBloc.userRolesBloc.add(OnLoadUserRoles(userId: widget.user.id));
                                                                                        },
                                                                                      );
                                                                                    },
                                                                                  )
                                                                                : Theme(
                                                                                    data: ThemeData(hoverColor: Colors.transparent, unselectedWidgetColor: Color(0xff9B9B9B)),
                                                                                    child: Container(
                                                                                      height: 30,
                                                                                      child: CheckboxListTile(
                                                                                        activeColor: Color(0xff00A4E3),
                                                                                        dense: true,
                                                                                        //font change
                                                                                        contentPadding: EdgeInsets.zero,
                                                                                        title: new Text(
                                                                                          roles.roles[index].name,
                                                                                          style: TextStyle(
                                                                                            fontSize: 12,
                                                                                          ),
                                                                                        ),
                                                                                        value: roles.roles[index].isCheck,
                                                                                        onChanged: roles.roles[index].name == "学生"
                                                                                            ? null
                                                                                            : (value) {
                                                                                                setState(
                                                                                                  () {
                                                                                                    roles.roles[index].isCheck = value;
                                                                                                    // isCheckboxChecked = value;
                                                                                                    multiRoleId = roles.roles[index].id;

                                                                                                    if (value == true) {
                                                                                                      List<String> rolesIdSelected = UtilPreferences.getStringList(
                                                                                                        "multiRoleIdChecked",
                                                                                                      );
                                                                                                      if (rolesIdSelected != null) {
                                                                                                        rolesIdSelected.add(multiRoleId.toString());
                                                                                                        UtilPreferences.setStringList(
                                                                                                          "multiRoleIdChecked",
                                                                                                          rolesIdSelected,
                                                                                                        );
                                                                                                      } else {
                                                                                                        UtilPreferences.setStringList("multiRoleIdChecked", [
                                                                                                          jsonEncode(multiRoleId)
                                                                                                        ]);
                                                                                                      }
                                                                                                    } else {
                                                                                                      List<String> rolesIdSelected = UtilPreferences.getStringList(
                                                                                                        "multiRoleIdChecked",
                                                                                                      );
                                                                                                      if (rolesIdSelected != null) {
                                                                                                        rolesIdSelected.remove(multiRoleId.toString());
                                                                                                        UtilPreferences.setStringList(
                                                                                                          "multiRoleIdChecked",
                                                                                                          rolesIdSelected,
                                                                                                        );
                                                                                                      }
                                                                                                    }
                                                                                                    multiRolesId = UtilPreferences.getStringList(
                                                                                                      "multiRoleIdChecked",
                                                                                                    );
                                                                                                    // if (roles.roles[index].isCheck == true) {
                                                                                                    //   if (value == false) {
                                                                                                    //     AppBloc.userRolesBloc.add(OnRemoveUserRole(roleId: multiRoleId, rolename: roles.roles[index].name));
                                                                                                    //     AppBloc.userRolesBloc.add(OnCreateUserRole(userRoles: multiRoleId, roleName: roles.roles[index].name));
                                                                                                    //   }
                                                                                                    // } else {
                                                                                                    //   if (value == true) AppBloc.userRolesBloc.add(OnCreateUserRole(userRoles: multiRoleId, roleName: roles.roles[index].name));
                                                                                                    // }
                                                                                                    if (value == true) AppBloc.userRolesBloc.add(OnCreateUserRole(userRoles: multiRoleId, roleName: roles.roles[index].name));

                                                                                                    if (value == false) AppBloc.userRolesBloc.add(OnRemoveUserRole(roleId: multiRoleId, rolename: roles.roles[index].name));
                                                                                                    AppBloc.userRolesBloc.add(OnLoadUserRoles(userId: widget.user.id));
                                                                                                  },
                                                                                                );
                                                                                              },
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                          },
                                                                        )
                                                                      : Container(),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  )
                                                                ],
                                                              );
                                                            },
                                                          );
                                                        } else {
                                                          return Container();
                                                        }
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                width: 12,
                                              ),
                                              UserAuthorities(
                                                userRolesList: userRolesList.userroles,
                                                roleId: id,
                                                multiRolesId: multiRolesId,
                                              ),
                                            ],
                                          ),
                                        );
                                      } else if (userRolesList is UserRolesFail) {
                                        return Container(
                                          child: Text(userRolesList.code),
                                        );
                                      } else {
                                        return Center(
                                          child: Container(width: 30, child: CircularProgressIndicator()),
                                          // child: Row(
                                          //   mainAxisAlignment: MainAxisAlignment.start,
                                          //   crossAxisAlignment:
                                          //       CrossAxisAlignment.start,
                                          //   children: [
                                          //     Column(
                                          //       mainAxisAlignment:
                                          //           MainAxisAlignment.start,
                                          //       crossAxisAlignment:
                                          //           CrossAxisAlignment.start,
                                          //       children: [
                                          //         Text(
                                          //           "Role",
                                          //           style: TextStyle(
                                          //               fontWeight: FontWeight.bold),
                                          //         ),
                                          //         SizedBox(
                                          //           height: 18,
                                          //         ),
                                          //         Container(
                                          //           width: 220,
                                          //           decoration: BoxDecoration(
                                          //               border: Border.all(
                                          //                   width: 1,
                                          //                   color: Color(0xffeeeeee))),
                                          //           padding: EdgeInsets.all(20),
                                          //           child: BlocBuilder<RolesListBloc,
                                          //               RolesListState>(
                                          //             bloc: BlocProvider.of<
                                          //                 RolesListBloc>(context),
                                          //             builder: (context, rolesList) {
                                          //               if (rolesList is RolesSuccess) {
                                          //                 return ListView.builder(
                                          //                   shrinkWrap: true,
                                          //                   itemCount:
                                          //                       rolesList.roles.length,
                                          //                   itemBuilder: (context, i) {
                                          //                     final roles =
                                          //                         rolesList.roles[i];
                                          //                     return Column(
                                          //                       mainAxisAlignment:
                                          //                           MainAxisAlignment
                                          //                               .start,
                                          //                       crossAxisAlignment:
                                          //                           CrossAxisAlignment
                                          //                               .start,
                                          //                       children: [
                                          //                         Text(
                                          //                           roles.name,
                                          //                           style: TextStyle(
                                          //                               color: Colors
                                          //                                   .black,
                                          //                               fontWeight:
                                          //                                   FontWeight
                                          //                                       .bold),
                                          //                         ),
                                          //                         roles != null &&
                                          //                                 roles.roles
                                          //                                         .length >
                                          //                                     0
                                          //                             ? ListView
                                          //                                 .builder(
                                          //                                 shrinkWrap:
                                          //                                     true,
                                          //                                 itemCount: roles
                                          //                                     .roles
                                          //                                     .length,
                                          //                                 itemBuilder:
                                          //                                     (context,
                                          //                                         index) {
                                          //                                   return roles.multiSelect ==
                                          //                                           false
                                          //                                       ? MyRadioListTile<
                                          //                                           int>(
                                          //                                           value:
                                          //                                               roles.roles[index].id,
                                          //                                           groupValue:
                                          //                                               id,
                                          //                                           title:
                                          //                                               Text(
                                          //                                             "${roles.roles[index].name}",
                                          //                                             style: TextStyle(
                                          //                                               fontSize: 12,
                                          //                                             ),
                                          //                                           ),
                                          //                                           onChanged:
                                          //                                               (value) {
                                          //                                             setState(
                                          //                                               () {
                                          //                                                 id = value;
                                          //                                                 var userRoleId = Application.userRoleId;
                                          //                                                 print("//////////// $userRoleId");
                                          //                                                 if (userRoleId != null) {
                                          //                                                   AppBloc.userRolesBloc.add(OnRemoveUserRoleId(id: userRoleId));

                                          //                                                   AppBloc.userRolesBloc.add(OnCreateSingleUserRole(roleId: id));
                                          //                                                 } else {
                                          //                                                   AppBloc.userRolesBloc.add(OnCreateSingleUserRole(roleId: id));
                                          //                                                 }
                                          //                                                 AppBloc.userRolesBloc.add(OnLoadUserRoles(userId: widget.user.id));
                                          //                                               },
                                          //                                             );
                                          //                                           },
                                          //                                         )
                                          //                                       : Theme(
                                          //                                           data:
                                          //                                               ThemeData(hoverColor: Colors.transparent, unselectedWidgetColor: Color(0xff9B9B9B)),
                                          //                                           child:
                                          //                                               Container(
                                          //                                             height: 30,
                                          //                                             child: CheckboxListTile(
                                          //                                               activeColor: Color(0xff00A4E3),
                                          //                                               dense: true,
                                          //                                               //font change
                                          //                                               contentPadding: EdgeInsets.zero,
                                          //                                               title: new Text(
                                          //                                                 roles.roles[index].name,
                                          //                                                 style: TextStyle(
                                          //                                                   fontSize: 12,
                                          //                                                 ),
                                          //                                               ),
                                          //                                               value: roles.roles[index].isCheck,
                                          //                                               onChanged: (value) {
                                          //                                                 setState(
                                          //                                                   () {
                                          //                                                     roles.roles[index].isCheck = value;
                                          //                                                     // isCheckboxChecked = value;
                                          //                                                     multiRoleId = roles.roles[index].id;

                                          //                                                     if (value == true) {
                                          //                                                       List<String> rolesIdSelected = UtilPreferences.getStringList(
                                          //                                                         "multiRoleIdChecked",
                                          //                                                       );
                                          //                                                       if (rolesIdSelected != null) {
                                          //                                                         rolesIdSelected.add(multiRoleId.toString());
                                          //                                                         UtilPreferences.setStringList(
                                          //                                                           "multiRoleIdChecked",
                                          //                                                           rolesIdSelected,
                                          //                                                         );
                                          //                                                       } else {
                                          //                                                         UtilPreferences.setStringList("multiRoleIdChecked", [
                                          //                                                           jsonEncode(multiRoleId)
                                          //                                                         ]);
                                          //                                                       }
                                          //                                                     } else {
                                          //                                                       List<String> rolesIdSelected = UtilPreferences.getStringList(
                                          //                                                         "multiRoleIdChecked",
                                          //                                                       );
                                          //                                                       if (rolesIdSelected != null) {
                                          //                                                         rolesIdSelected.remove(multiRoleId.toString());
                                          //                                                         UtilPreferences.setStringList(
                                          //                                                           "multiRoleIdChecked",
                                          //                                                           rolesIdSelected,
                                          //                                                         );
                                          //                                                       }
                                          //                                                     }
                                          //                                                     multiRolesId = UtilPreferences.getStringList(
                                          //                                                       "multiRoleIdChecked",
                                          //                                                     );

                                          //                                                     if (value == true) AppBloc.userRolesBloc.add(OnCreateUserRole(userRoles: multiRoleId, roleName: roles.roles[index].name));
                                          //                                                     if (value == false) AppBloc.userRolesBloc.add(OnRemoveUserRole(roleId: multiRoleId, rolename: roles.roles[index].name));
                                          //                                                     AppBloc.userRolesBloc.add(OnLoadUserRoles(userId: widget.user.id));
                                          //                                                   },
                                          //                                                 );
                                          //                                               },
                                          //                                             ),
                                          //                                           ),
                                          //                                         );
                                          //                                 },
                                          //                               )
                                          //                             : Container(),
                                          //                         SizedBox(
                                          //                           height: 10,
                                          //                         ),
                                          //                       ],
                                          //                     );
                                          //                   },
                                          //                 );
                                          //               } else {
                                          //                 return Container();
                                          //               }
                                          //             },
                                          //           ),
                                          //         ),
                                          //       ],
                                          //     ),
                                          //     SizedBox(
                                          //       width: 12,
                                          //     ),
                                          //     UserAuthorities(
                                          //       roleId: id,
                                          //       multiRolesId: multiRolesId,
                                          //     ),
                                          //   ],
                                          // ),
                                        );
                                      }
                                    },
                                  ),
                                ),
                              ),
                              isActive: _currentStep >= 0,
                              state: _currentStep >= 1 ? StepState.complete : StepState.disabled,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            } else {
              return Container(
                width: contentAreaWidthSm,
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Text(Translate.of(context).translate("name")),
                        ),
                        Expanded(
                          flex: 3,
                          child: AppTextInput(
                            icon: Icon(
                              Icons.clear,
                              size: 14,
                            ),
                            onChanged: (text) {},
                            onSubmitted: (text) {},
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }
          }),
    );
  }

  List<DropdownMenuItem<int>> getDepartmentsList(List<Departments> childList) {
    List<DropdownMenuItem<int>> childs = [];
    for (var list in childList) {
      childs.add(
        DropdownMenuItem(
          child: Text(
            list.name,
            style: TextStyle(fontSize: 12),
          ),
          value: list.id,
        ),
      );
    }
    return childs;
  }
}
