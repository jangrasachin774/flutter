import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/users/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/pages/role_types/types.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

import 'package:responsive_builder/responsive_builder.dart';

class CreateForm extends StatefulWidget {
  const CreateForm({Key key}) : super(key: key);

  @override
  _CreateFormState createState() => _CreateFormState();
}

class _CreateFormState extends State<CreateForm> {
  int _chosenValue;
  int _choseGender;
  int _statusValue;
  int _currentStep = 0;

  // Default Radio Button Selected Item.
  String radioItemHolder;

  // Group Value for Radio Button.
  int id = 1;
  int multiId;

  bool isCheckboxChecked;

  StepperType stepperType = StepperType.horizontal;

  final _textIDController = TextEditingController();
  final _textNameController = TextEditingController();
  final _textUsernameController = TextEditingController();
  final _textPassController = TextEditingController();
  final _textWorkNoController = TextEditingController();
  final _textContactController = TextEditingController();
  final _textRealCompanyController = TextEditingController();
  final _textRealDepoController = TextEditingController();

  String _validID;
  String _validName;
  String _validUsername;
  String _validPassword;
  String _validWorkNo;
  String _validContact;
  String _validRealCompany;
  String _validRealDept;
  final _textEmailController = TextEditingController();
  String _validEmail;
  List<DropdownMenuItem> items = [];
  List<DropdownMenuItem> docItems = [];

  List<int> selectedLeadersDocsItems = [];
  List<int> unSelectedLeadersDocsItems = [];

  List<String> selectedAdminDepartsItems = [];

  List<String> selectedAdminDepartMngmtItems = [];

  List<String> selectedViewDepartsItems = [];
  List<int> unSelectedViewDepartsItems = [];

  List<int> selectedItems = [];
  List<int> unSelectedItems = [];
  List<int> selectedDocItems = [];
  List<int> unSelectedDocItems = [];
  List<Departments> childList;
  List<DocumentsFeature> listItems;
  List<String> multiRolesId = [];

  List<String> selected = [];
  List<String> taskDeptselected = [];
  List<String> docSelected = [];

  @override
  void initState() {
    super.initState();
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.rolesBloc.add(OnLoadRoles());
    AppBloc.adminPagesBloc.add(OnLoadAdminPages());
  }

  getDepartList(childList) {
    childList.forEach((item) {
      items.add(DropdownMenuItem(
        child: Text(item.name),
        value: item.id,
      ));
    });
    return items;
  }

  getMultiDepartmentsList(childList, itemsLength) {
    childList.forEach((item) {
      if (items.length < itemsLength)
        items.add(DropdownMenuItem(
          child: Text(item.name),
          value: item.id,
        ));
    });
    return items;
  }

  getDocumentsList(listItems) {
    listItems.forEach((item) {
      docItems.add(DropdownMenuItem(
        child: Text(item.name),
        value: item.id,
      ));
    });
    return docItems;
  }

  void _save() {
    setState(() {
      _validID = UtilValidator.validate(
        data: _textIDController.text,
        min: 1,
        max: 10,
      );
      _validName = UtilValidator.validate(
        data: _textNameController.text,
        min: 3,
        max: 50,
      );
      _validPassword = UtilValidator.validate(
        data: _textPassController.text,
        min: 6,
        max: 10,
      );
      _validWorkNo = UtilValidator.validate(
        data: _textWorkNoController.text,
        min: 1,
        max: 10,
      );
      _validContact = UtilValidator.validate(
        data: _textContactController.text,
        min: 9,
        max: 12,
      );
      _validUsername = UtilValidator.validate(
        data: _textUsernameController.text,
        type: ValidateType.normal,
        min: 4,
        max: 30,
      );
      _validEmail = UtilValidator.validate(
        data: _textEmailController.text,
        type: ValidateType.email,
      );
    });

    if (_validName == null && _validUsername == null && _validPassword == null && _validWorkNo == null && _validEmail == null) {
      AppBloc.usersBloc.add(OnAddUser(
        name: _textNameController.text,
        email: _textEmailController.text,
        username: _textUsernameController.text,
        password: _textPassController.text,
        workNo: _textWorkNoController.text,
        contact: _textContactController.text,
        realCompany: _textRealCompanyController.text,
        realDepartment: _textRealDepoController.text,
        userStatusIdFk: _statusValue,
        gender: _choseGender,
        departmentIdFk: _chosenValue,
      ));
      // AppBloc.usersBloc.add(OnLoadUsers());
    }
  }

  tapped(int step) {
    setState(() => _currentStep = step);
  }

  continued() {
    UtilPreferences.setStringList(
      Preferences.singleUserRoleId,
      [],
    );
    UtilPreferences.setStringList(
      Preferences.multipleUserRoleId,
      [],
    );
    UtilPreferences.setStringList(
      Preferences.userAdminPage,
      [],
    );
    UtilPreferences.setStringList(
      "multiIdChecked",
      [],
    );
    if (_validName == null && _validUsername == null && _validPassword == null && _validWorkNo == null && _validEmail == null) {
      Application.userRoleId = null;
      // ignore: unnecessary_statements
      _currentStep < 1 ? setState(() => _currentStep += 1) : null;
    }
  }

  cancel() {
    print("usermanag");
    return UserManagementPage();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);
    double contentAreaWidthSm = screenWidth * 1.0;
    double contentAreaWidthLg = screenWidth * 0.6;
    return ResponsiveBuilder(
        refinedBreakpoints: RefinedBreakpoints(),
        builder: (context, sizingInformation) {
          double screenWidth = sizingInformation.screenSize.width;
          //Desktop
          if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
            return SingleChildScrollView(
              child: Container(
                width: contentAreaWidthSm,
                height: 600,
                child: Theme(
                  data: ThemeData(canvasColor: Colors.transparent, shadowColor: Colors.transparent),
                  child: Stepper(
                    /*controlsBuilder: (context, details) {
                      return Container(
                        margin: EdgeInsets.only(top: 20),
                        child: Row(
                          children: <Widget>[
                            _currentStep == 0
                                ? BlocBuilder<UsersListBloc, UsersListState>(
                                    bloc: BlocProvider.of<UsersListBloc>(context),
                                    builder: (context, save) {
                                      return BlocListener<UsersListBloc, UsersListState>(
                                        listener: (context, state) {
                                          if (state is UserSaveFail) {
                                            Text(state.error.toString());
                                          }
                                          if (state is UserSaveSuccess) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              SnackBar(
                                                backgroundColor: Colors.green,
                                                content: Text("Saved User Basic Details Successfully"),
                                              ),
                                            );
                                          }
                                        },
                                        child: AppButton(
                                          Translate.of(context).translate('next'),
                                          onPressed: () {
                                            _save();
                                            details.onStepContinue();
                                          },
                                          type: ButtonType.normal,
                                          color: Color(0xff787E8C),
                                          icon: Icon(
                                            Icons.navigate_next_outlined,
                                          ),
                                        ),
                                      );
                                    })
                                : Container(),
                            SizedBox(
                              width: 20,
                            ),
                          ],
                        ),
                      );
                    },*/
                    // controlsBuilder: (BuildContext context,
                    //     {VoidCallback onStepContinue,
                    //     VoidCallback onStepCancel}) {
                    //   return Container(
                    //     margin: EdgeInsets.only(top: 20),
                    //     child: Row(
                    //       children: <Widget>[
                    //         _currentStep == 0
                    //             ? BlocBuilder<UsersListBloc, UsersListState>(
                    //                 bloc:
                    //                     BlocProvider.of<UsersListBloc>(context),
                    //                 builder: (context, save) {
                    //                   return BlocListener<UsersListBloc,
                    //                       UsersListState>(
                    //                     listener: (context, state) {
                    //                       if (state is UserSaveFail) {
                    //                         Text(state.error.toString());
                    //                       }
                    //                       if (state is UserSaveSuccess) {
                    //                         ScaffoldMessenger.of(context)
                    //                             .showSnackBar(
                    //                           SnackBar(
                    //                             backgroundColor: Colors.green,
                    //                             content: Text(
                    //                                 "Saved User Basic Details Successfully"),
                    //                           ),
                    //                         );
                    //                       }
                    //                     },
                    //                     child: AppButton(
                    //                       Translate.of(context)
                    //                           .translate('next'),
                    //                       onPressed: () {
                    //                         _save();
                    //                         onStepContinue();
                    //                       },
                    //                       type: ButtonType.normal,
                    //                       color: Color(0xff787E8C),
                    //                       icon: Icon(
                    //                         Icons.navigate_next_outlined,
                    //                       ),
                    //                     ),
                    //                   );
                    //                 })
                    //             : Container(),
                    //         SizedBox(
                    //           width: 20,
                    //         ),
                    //       ],
                    //     ),
                    //   );
                    // },
                    type: stepperType,
                    physics: ScrollPhysics(),
                    currentStep: _currentStep,
                    onStepTapped: (step) => tapped(step),
                    onStepContinue: continued,
                    onStepCancel: cancel,
                    steps: <Step>[
                      Step(
                        title: new Text(Translate.of(context).translate('basic_details')),
                        isActive: _currentStep >= 0,
                        state: _currentStep >= 0 ? StepState.complete : StepState.disabled,
                        content: Theme(
                          data: ThemeData(canvasColor: Colors.white, shadowColor: Colors.black54),
                          child: Container(
                            width: contentAreaWidthLg,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(
                                              Translate.of(context).translate('user_status'),
                                              style: TextStyle(fontSize: 14),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: Container(
                                              height: 40,
                                              padding: EdgeInsets.symmetric(
                                                horizontal: 10,
                                                vertical: 0,
                                              ),
                                              decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                              child: DropdownButton(
                                                isExpanded: true,
                                                value: _statusValue,
                                                underline: SizedBox(),
                                                icon: Icon(Icons.keyboard_arrow_down_outlined),
                                                items: [
                                                  DropdownMenuItem(
                                                    child: Text(
                                                      Translate.of(context).translate("normal"),
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                    value: 1,
                                                  ),
                                                  DropdownMenuItem(
                                                    child: Text(
                                                      Translate.of(context).translate("leave"),
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                    value: 2,
                                                  ),
                                                  DropdownMenuItem(
                                                    child: Text(
                                                      Translate.of(context).translate("disabled"),
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                    value: 3,
                                                  )
                                                ],
                                                hint: Text(
                                                  Translate.of(context).translate("choose_status"),
                                                  style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                onChanged: (int value) {
                                                  setState(() {
                                                    _statusValue = value;
                                                  });
                                                },
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                          Expanded(
                                            flex: 5,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(
                                                    Translate.of(context).translate('department_for_training'),
                                                  ),
                                                ),
                                                Expanded(
                                                  // width: 228,
                                                  // color: Colors.white,
                                                  flex: 3,
                                                  child: Container(
                                                      height: 40,
                                                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                                                      decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                                      child: BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                                                          bloc: BlocProvider.of<DepartmentsListBloc>(context),
                                                          builder: (context, departmentsList) {
                                                            if (departmentsList is DepartmentsLoading) {
                                                              return Text(
                                                                "Please choose a Department",
                                                                style: TextStyle(
                                                                  color: Colors.black,
                                                                  fontSize: 12,
                                                                ),
                                                              );
                                                            } else if (departmentsList is DepartmentsSuccess) {
                                                              return DropdownButton(
                                                                isExpanded: true,
                                                                value: _chosenValue,
                                                                underline: SizedBox(),
                                                                icon: Icon(Icons.keyboard_arrow_down_outlined),
                                                                items: getDepartmentsList(departmentsList.departments),
                                                                hint: Text(
                                                                  "Please choose a Department",
                                                                  style: TextStyle(
                                                                    color: Colors.black,
                                                                    fontSize: 12,
                                                                  ),
                                                                ),
                                                                onChanged: (int value) {
                                                                  setState(() {
                                                                    _chosenValue = value;
                                                                  });
                                                                },
                                                              );
                                                            } else {
                                                              return Container();
                                                            }
                                                          })),
                                                ),
                                                Expanded(flex: 1, child: Container()),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(Translate.of(context).translate('name')),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textNameController,
                                              errorText: Translate.of(context).translate(_validName),
                                              onTapIcon: () async {
                                                _textNameController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                _validName = UtilValidator.validate(
                                                  data: _textNameController.text,
                                                );
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(Translate.of(context).translate('id')),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textIDController,
                                              errorText: Translate.of(context).translate(_validID),
                                              onTapIcon: () async {
                                                _textIDController.clear();
                                              },
                                              keyboardType: TextInputType.number,
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validID = UtilValidator.validate(
                                                    data: _textIDController.text,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(),
                                      flex: 1,
                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(Translate.of(context).translate('gender')),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: Container(
                                              height: 40,
                                              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                                              decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                              child: DropdownButton(
                                                isExpanded: true,
                                                value: _choseGender,
                                                underline: SizedBox(),
                                                icon: Icon(Icons.keyboard_arrow_down_outlined),
                                                items: [
                                                  DropdownMenuItem(
                                                    child: Text(
                                                      Translate.of(context).translate('male'),
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                    value: 1,
                                                  ),
                                                  DropdownMenuItem(
                                                    child: Text(
                                                      Translate.of(context).translate('female'),
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                    value: 0,
                                                  )
                                                ],
                                                hint: Text(
                                                  "Please choose a gender",
                                                  style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                onChanged: (int value) {
                                                  setState(() {
                                                    _choseGender = value;
                                                  });
                                                },
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Container(),
                                          ),
                                          Expanded(
                                            flex: 4,
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  flex: 1,
                                                  child: Text(Translate.of(context).translate('work_number')),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: AppTextInput(
                                                    controller: _textWorkNoController,
                                                    errorText: Translate.of(context).translate(_validWorkNo),
                                                    onTapIcon: () async {
                                                      _textWorkNoController.clear();
                                                    },
                                                    icon: Icon(
                                                      Icons.clear,
                                                      size: 14,
                                                    ),
                                                    onChanged: (text) {
                                                      setState(() {
                                                        _validWorkNo = UtilValidator.validate(
                                                          data: _textWorkNoController.text,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            child: Container(),
                                            flex: 1,
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(Translate.of(context).translate('contact')),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textContactController,
                                              errorText: Translate.of(context).translate(_validContact),
                                              onTapIcon: () async {
                                                _textContactController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validContact = UtilValidator.validate(
                                                    data: _textContactController.text,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(Translate.of(context).translate('email')),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textEmailController,
                                              errorText: Translate.of(context).translate(_validEmail),
                                              onTapIcon: () async {
                                                _textEmailController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validEmail = UtilValidator.validate(
                                                    data: _textEmailController.text,
                                                    type: ValidateType.email,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(),
                                      flex: 1,
                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(
                                              Translate.of(context).translate('real_company'),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textRealCompanyController,
                                              errorText: Translate.of(context).translate(_validRealCompany),
                                              onTapIcon: () async {
                                                _textRealCompanyController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validRealCompany = UtilValidator.validate(
                                                    data: _textRealCompanyController.text,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(
                                              Translate.of(context).translate('real_department'),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textRealDepoController,
                                              errorText: Translate.of(context).translate(_validRealDept),
                                              onTapIcon: () async {
                                                _textRealDepoController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validRealDept = UtilValidator.validate(
                                                    data: _textRealDepoController.text,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(),
                                      flex: 1,
                                    )
                                  ],
                                ),
                                // SizedBox(
                                //   height: 20,
                                // ),
                                // Row(
                                //   children: [
                                //     Expanded(
                                //       flex: 4,
                                //       child: Row(
                                //         children: [
                                //           Expanded(
                                //             flex: 1,
                                //             child: Text(
                                //               Translate.of(context).translate('department_for_training'),
                                //             ),
                                //           ),
                                //           Expanded(
                                //             // width: 228,
                                //             // color: Colors.white,
                                //             flex: 3,
                                //             child: Container(
                                //                 height: 40,
                                //                 padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                                //                 decoration: BoxDecoration(color: Colors.white, border: Border.all(width: 1, color: Colors.grey), borderRadius: BorderRadius.circular(2.2)),
                                //                 child: BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                                //                     bloc: BlocProvider.of<DepartmentsListBloc>(context),
                                //                     builder: (context, departmentsList) {
                                //                       if (departmentsList is DepartmentsLoading) {
                                //                         return Text(
                                //                           "Please choose a Department",
                                //                           style: TextStyle(
                                //                             color: Colors.black,
                                //                             fontSize: 12,
                                //                           ),
                                //                         );
                                //                       } else if (departmentsList is DepartmentsSuccess) {
                                //                         return DropdownButton(
                                //                           isExpanded: true,
                                //                           value: _chosenValue,
                                //                           underline: SizedBox(),
                                //                           icon: Icon(Icons.keyboard_arrow_down_outlined),
                                //                           items: getDepartmentsList(departmentsList.departments),
                                //                           hint: Text(
                                //                             "Please choose a Department",
                                //                             style: TextStyle(
                                //                               color: Colors.black,
                                //                               fontSize: 12,
                                //                             ),
                                //                           ),
                                //                           onChanged: (int value) {
                                //                             setState(() {
                                //                               _chosenValue = value;
                                //                             });
                                //                           },
                                //                         );
                                //                       } else {
                                //                         return Container();
                                //                       }
                                //                     })),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //     Expanded(
                                //       flex: 1,
                                //       child: Container(),
                                //     ),
                                //     Expanded(
                                //       flex: 4,
                                //       child: Container(),
                                //     ),
                                //     Expanded(
                                //       child: Container(),
                                //       flex: 1,
                                //     )
                                //   ],
                                // ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(
                                              Translate.of(context).translate('username'),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textUsernameController,
                                              errorText: Translate.of(context).translate(_validUsername),
                                              onTapIcon: () async {
                                                _textUsernameController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validUsername = UtilValidator.validate(
                                                    data: _textUsernameController.text,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 1,
                                            child: Text(
                                              Translate.of(context).translate('password'),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: AppTextInput(
                                              controller: _textPassController,
                                              errorText: Translate.of(context).translate(_validPassword),
                                              onTapIcon: () async {
                                                _textPassController.clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                size: 14,
                                              ),
                                              onChanged: (text) {
                                                setState(() {
                                                  _validPassword = UtilValidator.validate(
                                                    data: _textPassController.text,
                                                  );
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(),
                                      flex: 1,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Step(
                        title: new Text(Translate.of(context).translate('role_details')),
                        content: Theme(
                          data: ThemeData(canvasColor: Colors.white, shadowColor: Colors.black54),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    Translate.of(context).translate('role'),
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    height: 18,
                                  ),
                                  Container(
                                    width: 220,
                                    decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                                    padding: EdgeInsets.all(20),
                                    child: BlocListener<UserRolesListBloc, UserRolesListState>(
                                      listener: (context, state) {
                                        if (state is SingleUserRoleSaveSuccess) {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            backgroundColor: Colors.green,
                                            content: Text("Assigned Trainer Role to User Successfully"),
                                          ));
                                        }
                                        if (state is UserRoleSaveSuccess) {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            backgroundColor: Colors.green,
                                            content: Text("Assigned Role to User Successfully"),
                                          ));
                                        }
                                        if (state is UserRoleDeleteSuccess) {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            backgroundColor: Colors.red,
                                            content: Text("Deleted Assigned Role of User Successfully"),
                                          ));
                                        }
                                        if (state is SingleUserRoleDeleteSuccess) {
                                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            backgroundColor: Colors.red,
                                            content: Text("Deleted Assigned Role of User Successfully"),
                                          ));
                                        }
                                      },
                                      child: BlocBuilder<RolesListBloc, RolesListState>(
                                        bloc: BlocProvider.of<RolesListBloc>(context),
                                        builder: (context, rolesList) {
                                          if (rolesList is RolesSuccess) {
                                            return ListView.builder(
                                              shrinkWrap: true,
                                              itemCount: rolesList.roles.length,
                                              itemBuilder: (context, i) {
                                                final roles = rolesList.roles[i];
                                                return Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      roles.name,
                                                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                                                    ),
                                                    roles != null && roles.roles.length > 0
                                                        ? ListView.builder(
                                                            shrinkWrap: true,
                                                            itemCount: roles.roles.length,
                                                            itemBuilder: (context, index) {
                                                              return roles.multiSelect == false
                                                                  ? MyRadioListTile<int>(
                                                                      value: roles.roles[index].id,
                                                                      groupValue: id,
                                                                      title: Text(
                                                                        "${roles.roles[index].name}",
                                                                        style: TextStyle(fontSize: 12),
                                                                      ),
                                                                      onChanged: (value) {
                                                                        setState(() => id = value);

                                                                        var userRoleId = Application.userRoleId;
                                                                        if (userRoleId != null) {
                                                                          AppBloc.userRolesBloc.add(OnRemoveUserRoleId(id: userRoleId));
                                                                          AppBloc.userRolesBloc.add(OnCreateSingleUserRole(roleId: id));
                                                                        } else {
                                                                          AppBloc.userRolesBloc.add(OnCreateSingleUserRole(roleId: id));
                                                                        }
                                                                      })
                                                                  : Theme(
                                                                      data: ThemeData(hoverColor: Colors.transparent, unselectedWidgetColor: Color(0xff9B9B9B)),
                                                                      child: Container(
                                                                        height: 30,
                                                                        child: CheckboxListTile(
                                                                          activeColor: Color(0xff00A4E3),
                                                                          dense: true,
                                                                          //font change
                                                                          contentPadding: EdgeInsets.zero,
                                                                          title: new Text(
                                                                            roles.roles[index].name,
                                                                            style: TextStyle(
                                                                              fontSize: 12,
                                                                            ),
                                                                          ),
                                                                          value: roles.roles[index].isCheck,
                                                                          onChanged: roles.roles[index].name == "学生"
                                                                              ? null
                                                                              : (value) {
                                                                                  print(value);
                                                                                  setState(
                                                                                    () {
                                                                                      roles.roles[index].isCheck = value;
                                                                                      isCheckboxChecked = value;
                                                                                      multiId = roles.roles[index].id;

                                                                                      if (value == true) {
                                                                                        List<String> rolesIdSelected = UtilPreferences.getStringList(
                                                                                          "multiIdChecked",
                                                                                        );
                                                                                        if (rolesIdSelected != null) {
                                                                                          rolesIdSelected.add(multiId.toString());
                                                                                          UtilPreferences.setStringList(
                                                                                            "multiIdChecked",
                                                                                            rolesIdSelected,
                                                                                          );
                                                                                        } else {
                                                                                          UtilPreferences.setStringList("multiIdChecked", [
                                                                                            jsonEncode(multiId)
                                                                                          ]);
                                                                                        }
                                                                                      } else {
                                                                                        List<String> rolesIdSelected = UtilPreferences.getStringList(
                                                                                          "multiIdChecked",
                                                                                        );
                                                                                        if (rolesIdSelected != null) {
                                                                                          rolesIdSelected.remove(multiId.toString());
                                                                                          UtilPreferences.setStringList(
                                                                                            "multiIdChecked",
                                                                                            rolesIdSelected,
                                                                                          );
                                                                                        }
                                                                                      }
                                                                                      multiRolesId = UtilPreferences.getStringList(
                                                                                        "multiIdChecked",
                                                                                      );

                                                                                      if (value == true) AppBloc.userRolesBloc.add(OnCreateUserRole(userRoles: multiId, roleName: roles.roles[index].name));
                                                                                      if (value == false) AppBloc.userRolesBloc.add(OnRemoveUserRole(roleId: multiId, rolename: roles.roles[index].name));
                                                                                    },
                                                                                  );
                                                                                },
                                                                        ),
                                                                      ),
                                                                    );
                                                            },
                                                          )
                                                        : Container(),
                                                    SizedBox(
                                                      height: 10,
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                          } else {
                                            return Container();
                                          }
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Visibility(
                                visible: id == 2,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      Translate.of(context).translate('authorities_for_task_creator'),
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 18,
                                    ),
                                    Container(
                                      width: 240,
                                      decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                                      padding: EdgeInsets.all(20),
                                      child: Container(
                                        width: 230,
                                        color: Colors.white,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Translate.of(context).translate('department'),
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            BlocListener<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                                              listener: (context, state) {
                                                if (state is UserRoleDepartmentSaveSuccess) {
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                    backgroundColor: Colors.green,
                                                    content: Text("Assigned User Role Department to Task Creator User Successfully"),
                                                  ));
                                                }
                                                if (state is UserRoleDepartmentDeleteSuccess) {
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                    backgroundColor: Colors.red,
                                                    content: Text("Deleted User Role Department to Task Creator User Successfully"),
                                                  ));
                                                }
                                              },
                                              child: MyDropDownMultiSelect(
                                                onChanged: (List<String> x) {
                                                  setState(() {
                                                    taskDeptselected = x;
                                                  });
                                                },
                                                selectedValues: taskDeptselected,
                                                whenEmpty: 'Select Something',
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Text(
                                              Translate.of(context).translate('documents'),
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            MyDocDropDownMultiSelect(
                                              onChanged: (List<String> x) {
                                                setState(() {
                                                  docSelected = x;
                                                });
                                              },
                                              selectedValues: docSelected,
                                              whenEmpty: 'Select Something',
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Visibility(
                                visible: id == 3 || id == 4,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      id == 3 ? "Authorities for Small Leader" : "Authorities for Big Leader",
                                      style: TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      height: 18,
                                    ),
                                    Container(
                                      width: 240,
                                      decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                                      padding: EdgeInsets.all(20),
                                      child: Container(
                                        width: 230,
                                        color: Colors.white,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Translate.of(context).translate('department'),
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            BlocListener<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                                              listener: (context, state) {
                                                if (state is UserRoleDepartmentSaveSuccess) {
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                    backgroundColor: Colors.green,
                                                    content: Text("Assigned User Role Department to User Successfully"),
                                                  ));
                                                }
                                                if (state is UserRoleDepartmentDeleteSuccess) {
                                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                    backgroundColor: Colors.red,
                                                    content: Text("Deleted User Role Department to User Successfully"),
                                                  ));
                                                }
                                              },
                                              child: MyDropDownMultiSelect(
                                                onChanged: (List<String> x) {
                                                  setState(() {
                                                    selected = x;
                                                  });
                                                },
                                                selectedValues: selected,
                                                whenEmpty: 'Select Something',
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Visibility(
                                visible: multiRolesId.contains("6"),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      Translate.of(context).translate('authorities_for_admin'),
                                      style: TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      height: 18,
                                    ),
                                    Container(
                                        width: 240,
                                        decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                                        padding: EdgeInsets.all(20),
                                        child: BlocListener<UserAdminPageDepartmentsBloc, UserAdminPageDepartmentsState>(
                                          listener: (context, state) {
                                            if (state is UserAdminPageDepartmentSaveSuccess) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                backgroundColor: Colors.green,
                                                content: Text("Added User Admin Page Department Successfully"),
                                              ));
                                            }
                                            if (state is UserAdminPageDepartmentDeleteSuccess) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                backgroundColor: Colors.red,
                                                content: Text("Deleted User Admin Page Department Successfully"),
                                              ));
                                            }
                                          },
                                          child: BlocListener<UserAdminPagesBloc, UserAdminPagesState>(
                                            listener: (context, state) {
                                              if (state is UserAdminPageSaveSuccess) {
                                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                  backgroundColor: Colors.green,
                                                  content: Text("Added User Admin Page Successfully"),
                                                ));
                                              }
                                              if (state is UserAdminPageDeleteSuccess) {
                                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                  backgroundColor: Colors.red,
                                                  content: Text("Deleted User Admin Page Successfully"),
                                                ));
                                              }
                                            },
                                            child: BlocBuilder<AdminPagesBloc, AdminPagesState>(
                                                bloc: BlocProvider.of<AdminPagesBloc>(context),
                                                builder: (context, adminPages) {
                                                  if (adminPages is AdminPagesLoading) {
                                                    return Container();
                                                  } else if (adminPages is AdminPagesSuccess) {
                                                    return ListView.builder(
                                                        shrinkWrap: true,
                                                        itemCount: adminPages.adminPages.length,
                                                        itemBuilder: (context, i) {
                                                          return adminPages.adminPages[i].parentAdminPageIdFk == 1
                                                              ? Column(
                                                                  children: [
                                                                    CheckboxListTile(
                                                                      activeColor: Color(0xff00A4E3),
                                                                      dense: true,
                                                                      contentPadding: EdgeInsets.zero,
                                                                      title: new Text(
                                                                        adminPages.adminPages[i].name,
                                                                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                                                      ),
                                                                      value: adminPages.adminPages[i].isChecked,
                                                                      onChanged: (value) {
                                                                        setState(
                                                                          () {
                                                                            adminPages.adminPages[i].isChecked = value;
                                                                            if (value == true) {
                                                                              AppBloc.userAdminPageBloc.add(
                                                                                OnCreateUserAdminPage(
                                                                                  adminPageId: adminPages.adminPages[i].id,
                                                                                  adminPageName: adminPages.adminPages[i].name,
                                                                                  roleName: Translate.of(context).translate('admin'),
                                                                                ),
                                                                              );
                                                                            } else {
                                                                              AppBloc.userAdminPageBloc.add(
                                                                                OnRemoveUserAdminPage(
                                                                                  adminPageName: adminPages.adminPages[i].name,
                                                                                ),
                                                                              );
                                                                            }
                                                                          },
                                                                        );
                                                                      },
                                                                    ),
                                                                    if (adminPages.adminPages[i].departments == true && adminPages.adminPages[i].id == 6 && adminPages.adminPages[i].isChecked)
                                                                      MyAdminViewDropDownMultiSelect(
                                                                        onChanged: (List<String> x) {
                                                                          setState(() {
                                                                            selectedAdminDepartsItems = x;
                                                                          });
                                                                        },
                                                                        selectedValues: selectedAdminDepartsItems,
                                                                        whenEmpty: 'Select Something',
                                                                        adminPageName: adminPages.adminPages[i].name,
                                                                      ),
                                                                    if (adminPages.adminPages[i].departments == true && adminPages.adminPages[i].id == 7 && adminPages.adminPages[i].isChecked)
                                                                      MyAdminViewDropDownMultiSelect(
                                                                        onChanged: (List<String> x) {
                                                                          setState(() {
                                                                            selectedAdminDepartMngmtItems = x;
                                                                          });
                                                                        },
                                                                        selectedValues: selectedAdminDepartMngmtItems,
                                                                        whenEmpty: 'Select Something',
                                                                        adminPageName: adminPages.adminPages[i].name,
                                                                      ),
                                                                  ],
                                                                )
                                                              : Container();
                                                        });
                                                  } else {
                                                    return Container();
                                                  }
                                                }),
                                          ),
                                        ))
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Visibility(
                                visible: multiRolesId.contains("7"),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      Translate.of(context).translate('authorities_for_view'),
                                      style: TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      height: 18,
                                    ),
                                    Container(
                                      width: 240,
                                      decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                                      padding: EdgeInsets.all(20),
                                      child: BlocListener<UserAdminPageDepartmentsBloc, UserAdminPageDepartmentsState>(
                                        listener: (context, state) {
                                          if (state is UserAdminPageDepartmentSaveSuccess) {
                                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                              backgroundColor: Colors.green,
                                              content: Text("Added User View Page Department Successfully"),
                                            ));
                                          }
                                          if (state is UserAdminPageDepartmentDeleteSuccess) {
                                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                              backgroundColor: Colors.red,
                                              content: Text("Deleted User View Page Department Successfully"),
                                            ));
                                          }
                                        },
                                        child: BlocListener<UserAdminPagesBloc, UserAdminPagesState>(
                                          listener: (context, state) {
                                            if (state is UserAdminPageSaveSuccess) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                backgroundColor: Colors.green,
                                                content: Text("Added User View Page Successfully"),
                                              ));
                                            }
                                            if (state is UserAdminPageDeleteSuccess) {
                                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                backgroundColor: Colors.red,
                                                content: Text("Deleted User View Page Successfully"),
                                              ));
                                            }
                                          },
                                          child: BlocBuilder<AdminPagesBloc, AdminPagesState>(
                                              bloc: BlocProvider.of<AdminPagesBloc>(context),
                                              builder: (context, adminPages) {
                                                if (adminPages is AdminPagesLoading) {
                                                  return Container();
                                                } else if (adminPages is AdminPagesSuccess) {
                                                  return ListView.builder(
                                                    shrinkWrap: true,
                                                    itemCount: adminPages.adminPages.length,
                                                    itemBuilder: (context, i) {
                                                      return adminPages.adminPages[i].parentAdminPageIdFk == 2 || adminPages.adminPages[i].parentAdminPageIdFk == 13
                                                          ? Column(
                                                              children: [
                                                                CheckboxListTile(
                                                                  activeColor: Color(0xff00A4E3),
                                                                  dense: true,
                                                                  contentPadding: EdgeInsets.zero,
                                                                  title: new Text(
                                                                    adminPages.adminPages[i].name,
                                                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                                                  ),
                                                                  value: adminPages.adminPages[i].isChecked,
                                                                  onChanged: (value) {
                                                                    setState(
                                                                      () {
                                                                        adminPages.adminPages[i].isChecked = value;
                                                                        AppBloc.userAdminPageBloc.add(OnCreateUserAdminPage(
                                                                          adminPageId: adminPages.adminPages[i].id,
                                                                          roleName: Translate.of(context).translate('viewer'),
                                                                        ));
                                                                      },
                                                                    );
                                                                  },
                                                                ),
                                                                if (adminPages.adminPages[i].departments == true && adminPages.adminPages[i].isChecked)
                                                                  MyAdminViewDropDownMultiSelect(
                                                                    onChanged: (List<String> x) {
                                                                      setState(() {
                                                                        selectedViewDepartsItems = x;
                                                                      });
                                                                    },
                                                                    selectedValues: selectedViewDepartsItems,
                                                                    whenEmpty: 'Select Something',
                                                                    adminPageName: adminPages.adminPages[i].name,
                                                                  ),
                                                              ],
                                                            )
                                                          : Container();
                                                    },
                                                  );
                                                } else {
                                                  return Container();
                                                }
                                              }),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        isActive: _currentStep >= 0,
                        state: _currentStep >= 1 ? StepState.complete : StepState.disabled,
                      ),
                    ],
                  ),
                ),
              ),
            );
          } else {
            return Container(
              width: contentAreaWidthSm,
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: Text(Translate.of(context).translate('name')),
                      ),
                      Expanded(
                        flex: 3,
                        child: AppTextInput(
                          icon: Icon(
                            Icons.clear,
                            size: 14,
                          ),
                          onChanged: (text) {},
                          onSubmitted: (text) {},
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }
        });
  }

  List<DropdownMenuItem<int>> getDepartmentsList(List<Departments> childList) {
    List<DropdownMenuItem<int>> childs = [];
    for (var list in childList) {
      childs.add(
        DropdownMenuItem(
          child: Text(
            list.name,
            style: TextStyle(fontSize: 12),
          ),
          value: list.id,
        ),
      );
    }
    return childs;
  }
}
