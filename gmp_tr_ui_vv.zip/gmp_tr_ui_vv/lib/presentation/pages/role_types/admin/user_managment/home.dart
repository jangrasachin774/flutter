import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/users/bloc.dart';
import 'package:gmptr/models/model_leaves.dart';
import 'package:gmptr/models/model_users.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/pages/role_types/admin/user_managment/update_user.dart';
import 'package:gmptr/presentation/pages/role_types/admin/user_managment/widgets/filterbox.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/user_disable_comment_dialog.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'create_user.dart';

enum WidgetChange { userslist, create, update, history }

class UserManagementPage extends StatefulWidget {
  const UserManagementPage({Key key}) : super(key: key);

  @override
  _UserManagementPageState createState() => _UserManagementPageState();
}

List<UsersModel> paginatedUsers = [];
final int rowsPerPage = 10;

class _UserManagementPageState extends State<UserManagementPage> {
  WidgetChange selectedWidgetPage = WidgetChange.userslist;
  UsersModel user;

  @override
  void initState() {
    super.initState();

    AppBloc.usersBloc.add(OnLoadFilteredUsers(departmentIdFk: null));
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case WidgetChange.create:
        return createUserWidget(context);

      case WidgetChange.userslist:
        return usersListWidget(context);

      case WidgetChange.update:
        return updateUser(context);

      case WidgetChange.history:
        return userHistory(context);
    }
    return usersListWidget(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == WidgetChange.userslist)
                    Text(
                      Translate.of(context).translate('user_management'),
                      style: TextStyle(color: Color(0xff00439E), fontSize: widthOfScreen(context) * 0.025, fontWeight: FontWeight.bold),
                    ),
                  if (selectedWidgetPage == WidgetChange.create)
                    Text(
                      Translate.of(context).translate('create_user'),
                      style: TextStyle(color: Color(0xff00439E), fontSize: widthOfScreen(context) * 0.025, fontWeight: FontWeight.bold),
                    ),
                  if (selectedWidgetPage == WidgetChange.update)
                    Text(
                      Translate.of(context).translate('update_user'),
                      style: TextStyle(color: Color(0xff00439E), fontSize: widthOfScreen(context) * 0.025, fontWeight: FontWeight.bold),
                    ),
                  Row(
                    children: [
                      if (selectedWidgetPage == WidgetChange.userslist)
                        AppButton(
                          Translate.of(context).translate('create_user'),
                          onPressed: () {
                            setState(() {
                              selectedWidgetPage = WidgetChange.create;
                            });
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.person_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage == WidgetChange.create)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: AppButton(
                            Translate.of(context).translate('cancel'),
                            onPressed: () {
                              setState(() {
                                selectedWidgetPage = WidgetChange.userslist;
                              });
                            },
                            type: ButtonType.outline,
                            color: Color(0xff787E8C),
                            icon: Icon(
                              Icons.close_outlined,
                            ),
                          ),
                        ),
                      if (selectedWidgetPage == WidgetChange.update)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: AppButton(
                            Translate.of(context).translate('back'),
                            onPressed: () {
                              setState(() {
                                selectedWidgetPage = WidgetChange.userslist;
                                // AppBloc.usersBloc.add(OnLoadUsers());
                              });
                            },
                            type: ButtonType.outline,
                            color: Color(0xff787E8C),
                          ),
                        ),
                    ],
                  )
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Container(child: getCustomContainer(context))
            ],
          ),
        ),
      ],
    );
  }

  ///CREATE USER WIDGET
  Widget createUserWidget(context) {
    return CreateForm();
  }

  ///UPDATE USER WIDGET
  Widget updateUser(context) {
    return UpdateUser(user: user);
  }

  ///USER HISTORY
  Widget userHistory(context) {
    return UserInfoCard(user: user);
  }

  ///USER LISTS
  Widget usersListWidget(context) {
    return Column(
      children: [
        UsersFilterBox(),
        SizedBox(
          height: 20,
        ),
        Container(
          child: BlocListener<UsersListBloc, UsersListState>(
            listener: (context, state) {
              if (state is StatusUpdateSuccess) {
                String status;
                Color color;
                if (state.userStatusIdFk == 1) {
                  status = "Normal Mode Enabled";
                  color = Colors.green;
                } else if (state.userStatusIdFk == 2) {
                  status = "Vacation Mode Enabled";
                  color = Colors.orange;
                } else if (state.userStatusIdFk == 3) {
                  status = "User Disabled";
                  color = Colors.red;
                }
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  backgroundColor: color,
                  content: Text(status),
                ));
              }
            },
            child: BlocBuilder<UsersListBloc, UsersListState>(
                bloc: BlocProvider.of<UsersListBloc>(context),
                builder: (context, usersList) {
                  if (usersList is FilteredUsersSuccess) {
                    UsersDataSource usersDataSource;
                    usersDataSource = new UsersDataSource(usersList.users, context);

                    List<UsersModel> userCount = usersList.users;

                    return LayoutBuilder(builder: (context, constraints) {
                      return Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 360,
                                width: constraints.maxWidth,
                                child: SfDataGrid(
                                  allowSorting: true,
                                  source: usersDataSource,
                                  columnWidthMode: ColumnWidthMode.fill,
                                  footerFrozenColumnsCount: 1,
                                  isScrollbarAlwaysShown: true,
                                  columns: [
                                    GridColumn(
                                      columnName: 'name',
                                      width: 150,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('name'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'company',
                                      width: 150,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('company'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'department',
                                      width: 150,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('department'),
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'id',
                                      width: 130,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('id'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'gender',
                                      width: 100,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('gender'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'workNo',
                                      width: 180,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('work_no'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'mobile',
                                      width: 160,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('mobile'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'role',
                                      width: 200,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('role'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'username',
                                      width: 150,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('username'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'password',
                                      width: 120,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('password'),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    GridColumn(
                                      columnName: 'actions',
                                      width: 180,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          "",
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 52,
                                width: constraints.maxWidth,
                                child: SfDataPager(
                                  delegate: usersDataSource,
                                  pageCount: (userCount.length / rowsPerPage).ceilToDouble(),
                                  direction: Axis.horizontal,
                                ),
                              )
                            ],
                          ),
                        ],
                      );
                    });
                  } else if (usersList is FilteredUsersLoading) {
                    return LoadingBox(
                      height: 20,
                    );
                  } else if (usersList is FilteredUsersEmpty) {
                    return Container(
                      child: Text("No users"),
                    );
                  } else if (usersList is FilteredUsersFail) {
                    return Container(
                      child: Text(usersList.code),
                    );
                  } else {
                    return Container();
                  }
                }),
          ),
        ),
      ],
    );
  }
}

class UsersDataSource extends DataGridSource {
  BuildContext contxt;
  int taskStatusId;
  User user;
  final Completer _completer = new Completer();
  UsersDataSource(List<UsersModel> tasksData, context) {
    users = tasksData;
    contxt = context;
    try {
      if (users.length < rowsPerPage) {
        paginatedUsers = users.toList();
      } else {
        paginatedUsers = users.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.users.length) {
      endIndex = this.users.length;
    }
    paginatedUsers = List.from(
      this.users.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  Future<void> _showDisableForDialog(int userId) async {
    showDialog(
      context: contxt,
      barrierDismissible: true,
      builder: (context) => DialogForDisableComment(
        userId: userId,
      ),
    );
  }

  List<DataGridRow> _users = [];
  List<UsersModel> users = [];

  @override
  List<DataGridRow> get rows => _users;

  void buildPaginatedDataGridRows() {
    _users = paginatedUsers
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'name', value: e.name),
              DataGridCell<String>(columnName: 'company', value: e.realCompany),
              DataGridCell<String>(
                columnName: 'department',
                value: e.department.name,
              ),
              DataGridCell(
                columnName: 'id',
                value: e.identifier,
              ),
              DataGridCell(
                columnName: 'gender',
                value: e.gender,
              ),
              DataGridCell<String>(columnName: 'workNo', value: e.workNo),
              DataGridCell<String>(columnName: 'mobile', value: e.contact),
              DataGridCell(columnName: 'role', value: e.userRoles),
              DataGridCell(columnName: 'username', value: e.username),
              DataGridCell<String>(columnName: 'username', value: e.password),
              DataGridCell(columnName: 'actions', value: e),
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    var roles = row.getCells()[7].value.map((e) => e.role.name).toList();

    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[0].value.toString(),
              child: Text(
                row.getCells()[0].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[1].value.toString(),
              child: Text(
                row.getCells()[1].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Text(
              row.getCells()[2].value != null ? row.getCells()[2].value : "",
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[3].value.toString(),
            child: Text(
              row.getCells()[3].value != null ? row.getCells()[3].value : "",
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            row.getCells()[4].value == 1 ? Translate.of(contxt).translate('male') : Translate.of(contxt).translate('female'),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[5].value.toString(),
            child: Text(
              row.getCells()[5].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[6].value.toString(),
            child: Text(
              row.getCells()[6].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          width: 190,
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(vertical: 15),
          child: row.getCells()[7].value != null && row.getCells()[7].value.length > 0
              ? Tooltip(
                  message: roles.join(', '),
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: row.getCells()[7].value.length,
                    itemBuilder: (context, i) {
                      final userRoles = row.getCells()[7].value[i].role.name;
                      return Text(
                        userRoles + ', \n',
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        softWrap: true,
                        style: TextStyle(fontSize: 12),
                      );
                    },
                  ),
                )
              : Container(),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            row.getCells()[8].value.toString(),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            row.getCells()[9].value.toString(),
          ),
        ),
        Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                InkWell(
                  onTap: () {
                    showDialog(
                      context: contxt,
                      // FIXME: use correct datasource
                      builder: (context) {
                        return UserInfoCard(user: row.getCells()[10].value);
                      },
                    );
                  },
                  child: Icon(
                    Icons.history_outlined,
                    color: Color(0xff00A4E3),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                InkWell(
                  onTap: () {
                    if (row.getCells()[10].value.userStatusIdFk == 3) {
                      /// send status 1 - normal
                      AppBloc.usersBloc.add(ChangeStatus(userId: row.getCells()[10].value.id, userStatusIdFk: 1));
                      // AppBloc.usersBloc.add(OnLoadUsers());
                    } else {
                      if (row.getCells()[10].value.userStatusIdFk == 2) {
                        /// send status  - disabled
                        _showDisableForDialog(row.getCells()[10].value.id);
                      } else if (row.getCells()[10].value.userStatusIdFk == 1) {
                        /// send status  - disabled
                        _showDisableForDialog(row.getCells()[10].value.id);
                      }
                    }
                  },
                  child: Icon(
                    Icons.pan_tool_outlined,
                    color: row.getCells()[10].value.userStatusIdFk == 3 ? Color(0xffFF2800) : Color(0xff00A4E3),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                InkWell(
                  onTap: () {
                    if (row.getCells()[10].value.userStatusIdFk == 2) {
                      /// send status 1
                      AppBloc.usersBloc.add(ChangeStatus(userId: row.getCells()[10].value.id, userStatusIdFk: 1));
                      // AppBloc.usersBloc.add(OnLoadUsers());
                    } else {
                      if (row.getCells()[10].value.userStatusIdFk == 3) {
                        /// send status 2
                        AppBloc.usersBloc.add(ChangeStatus(userId: row.getCells()[10].value.id, userStatusIdFk: 2));
                        // AppBloc.usersBloc.add(OnLoadUsers());
                      } else if (row.getCells()[10].value.userStatusIdFk == 1) {
                        /// send status 1
                        AppBloc.usersBloc.add(ChangeStatus(userId: row.getCells()[10].value.id, userStatusIdFk: 2));
                        // AppBloc.usersBloc.add(OnLoadUsers());
                      }
                    }
                  },
                  child: Icon(
                    Icons.houseboat_outlined,
                    color: row.getCells()[10].value.userStatusIdFk == 2 ? Colors.orange : Color(0xff00A4E3),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                InkWell(
                  onTap: () {
                    showDialog(
                      context: contxt,
                      // FIXME: use correct datasource
                      builder: (context) {
                        return UpdateUser(user: row.getCells()[10].value);
                      },
                    );
                  },
                  child: Icon(
                    Icons.edit_outlined,
                    color: Color(0xff00A4E3),
                  ),
                ),
                SizedBox(
                  width: 8,
                ),
                row.getCells()[10].value.userStatusIdFk == 1
                    ? Container(
                        width: 12.0,
                        height: 12.0,
                        decoration: new BoxDecoration(
                          color: Color(0xff5AC91D),
                          shape: BoxShape.circle,
                        ),
                      )
                    : row.getCells()[10].value.userStatusIdFk == 2
                        ? Container(
                            width: 12.0,
                            height: 12.0,
                            decoration: new BoxDecoration(
                              color: Color(0xffF7D403),
                              shape: BoxShape.circle,
                            ),
                          )
                        : Container(
                            width: 12.0,
                            height: 12.0,
                            decoration: new BoxDecoration(
                              color: Color(0xffFF2800),
                              shape: BoxShape.circle,
                            ),
                          ),
              ],
            )),
      ],
    );
  }
}
