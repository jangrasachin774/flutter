import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/algorithm/filter_strategy.dart';

class FilterStrategyFactory {
  Map<FilterEnum, FilterStrategy> _strategies = {};

  FilterStrategy getStrategy(FilterEnum type) {
    print(type);
    return _strategies[type];
  }

  void register(FilterEnum type, FilterStrategy strategy) {
    if (type == null || strategy == null) {
      throw Error();
    }
    _strategies[type] = strategy;
  }

  static final FilterStrategyFactory _instance =
      FilterStrategyFactory._internal();

  factory FilterStrategyFactory() {
    return _instance;
  }

  FilterStrategyFactory._internal() {
    // register filter strategy here
    register(FilterEnum.NONE, FilterByNothing());

    register(FilterEnum.DocumentFeature, FilterByDocumentFeature());
    register(FilterEnum.TrainingType, FilterByTrainingType());

    register(FilterEnum.Department, FilterByDepartment());

    register(FilterEnum.Time, FilterByTime());
  }
}
