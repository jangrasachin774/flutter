import 'package:flutter/cupertino.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/algorithm/filter_strategy.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/algorithm/filter_strategy_factory.dart';

class DocumentsListController extends ChangeNotifier {
  FilterStrategy strategy =
      FilterStrategyFactory().getStrategy(FilterEnum.NONE);
  List<DocumentsModel> _documents = [];

  set documents(List<DocumentsModel> _documents) => _documents = documents;

  get documents => strategy.doFilter(_documents);

  get original => _documents;

  void trigger() {
    // 发生筛选器状态变化前清除元素的选中状态，避免因为筛选器的改变而使处于选中中的元素没有显示
    resetSelectionStatus();
    notifyListeners();
  }

  void resetSelectionStatus() =>
      _documents.forEach((element) => element.selected = false);
}
