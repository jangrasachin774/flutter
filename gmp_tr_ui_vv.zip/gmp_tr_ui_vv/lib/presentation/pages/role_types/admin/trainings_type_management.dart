import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class TrainingTypeManagementPage extends StatefulWidget {
  const TrainingTypeManagementPage({Key key}) : super(key: key);

  @override
  _TrainingTypeManagementPageState createState() =>
      _TrainingTypeManagementPageState();
}

class _TrainingTypeManagementPageState
    extends State<TrainingTypeManagementPage> {
  final _textIDController = TextEditingController();

  String _validID;
  var _focusID = FocusNode();

  @override
  void initState() {
    super.initState();
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
  }

  ///On create department Level
  _createDocFeature(parentId) async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text, min: 1);
    });
    if (_validID == null) {
      AppBloc.trainingsTypeBlocs.add(OnAddTrainingType(
          name: _textIDController.text, parentId: parentId, level: 1));
      AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    }
  }

  ///Create Document Form Level
  Future<void> _showForm(parentId) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_trainings_type'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  autoFocus: true,
                  hintText:
                      Translate.of(context).translate('training_type_name'),
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textIDController,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      print(text);
                      _validID = UtilValidator.validate(
                        data: _textIDController.text,
                      );
                    });
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                  bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                  builder: (context, save) {
                    return BlocListener<TrainingsTypeListBloc,
                        TrainingsTypeListState>(
                      listener: (context, state) {
                        if (state is TrainingsTypsaveFail) {
                          Text(state.code);
                        }
                        if (state is TrainingsTypsaveSuccess) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            backgroundColor: Colors.green,
                            content: Text("Training Type Created Successfully"),
                          ));
                        }
                      },
                      child: AppButton(
                        Translate.of(context).translate('create'),
                        onPressed: () => _createDocFeature(parentId),
                        type: ButtonType.normal,
                        loading: save is TrainingsTypsaving,
                        disabled: save is TrainingsTypsaving,
                        color: Color(0xff787E8C),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Translate.of(context)
                        .translate('trainings_type_page_heading'),
                    style: TextStyle(
                        color: Color(0xff00439E),
                        fontSize: widthOfScreen(context) * 0.025,
                        fontWeight: FontWeight.bold),
                  ),
                  AppButton(
                    Translate.of(context).translate('create_trainings_type'),
                    onPressed: () {
                      setState(() {
                        _showForm(null);
                      });
                    },
                    type: ButtonType.normal,
                    color: Color(0xff787E8C),
                    icon: Icon(
                      Icons.person_add_outlined,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                child:
                    BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                        bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                        builder: (context, trainingsTypeList) {
                          if (trainingsTypeList is TrainingsTypeLoading) {
                            return Center(child: CircularProgressIndicator());
                          } else if (trainingsTypeList
                              is TrainingsTypeSuccess) {
                            return Container(
                              decoration: BoxDecoration(
                                border: Border(
                                  top: BorderSide(color: Color(0xffD4E5F9)),
                                  left: BorderSide(color: Color(0xffD4E5F9)),
                                  right: BorderSide(color: Color(0xffD4E5F9)),
                                ),
                              ),
                              child: MyTrainingsTypeDynamicTreeView(
                                actionVisible: true,
                                data: trainingsTypeList.trainingTypes,
                                width: screenWidth * 0.7,
                                config: TrainingsConfig(
                                    rootId: "null",
                                    parentPaddingEdgeInsets: EdgeInsets.only(
                                        left: 16, top: 0, bottom: 0)),
                              ),
                            );
                          } else if (trainingsTypeList is TrainingsTypeFail) {
                            return Container(
                              child: Text(trainingsTypeList.code),
                            );
                          } else {
                            return Container(
                              child: Text(""),
                            );
                          }
                        }),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
