import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_document.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/document_detail.dart';
import 'package:gmptr/presentation/pages/role_types/creator/create_new_document.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'create_new_task.dart';
import 'widgets/snack_bar_util.dart';
import 'widgets/task_info.dart';

class FinishedByStudentPage extends StatefulWidget {
  const FinishedByStudentPage({Key key}) : super(key: key);

  @override
  _FinishedByStudentPageState createState() => _FinishedByStudentPageState();
}

List<int> selectedTaskIds = [];
List<int> selectedDocIds = [];
List<Task> paginatedTask = [];
final int rowsPerPage = 10;
List<DocumentsModel> paginatedDocuments = [];

class _FinishedByStudentPageState extends State<FinishedByStudentPage> {
  WidgetChange selectedWidgetPage = WidgetChange.dashboard;
  int taskStatusId = 9;
  List<int> taskStatusIds = [
    2,
    3,
    4,
    6,
    8,
    9
  ];

  Task task;
  DocumentsModel document;

  /// CREATE TASK VARIABLES
  bool isRegularTask = false;
  final _dateController = TextEditingController();
  final _textTitleController = TextEditingController();
  final trainingTypeSelection = SelectionBoxController();
  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentVersionController = MyTextEditingController();

  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final studentsSelection = SelectionBoxController();
  final departmentSelection = SelectionBoxController();
  DocumentsModel selectedDocument;
  int departmentIdFk;
  int documentFeatureIdFk;
  int trainingTypeId;
  GlobalKey key = new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
  final List<SingleTaskTestController> testControllers = [];
  List<DocumentTests> selectedDocumentTests = [];

  final List<PlatformFile> choseDocuments = [];

  List<DocumentFiles> selectedDocuments = [];

  List<DocumentTests> selectedDocumentTest = [];

  final int smallLeaderRoleId = 3;

  final int studentsRoleId = 5;

  int documentIdFk;
  String selectedPath;
  String selectedName;
  String selectedIdentifier;
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  int studentIdFk;
  List<String> selectedStudents = [];
  List<int> selectedStudentsIds = [];

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  ///CREATE DOCUMENT VARIABLE
  final List<SingleTestController> doctestControllers = [];

  @override
  void initState() {
    super.initState();
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      selectedViewTypeCommon
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());

    AppBloc.documentsBloc.add(OnLoadDocuments());

    AppBloc.studentsBloc.add(OnLoadStudents());
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case WidgetChange.dashboard:
        return dashboard(context);
      case WidgetChange.taskInfo:
        return taskInfo(context);
      case WidgetChange.docInfo:
        return docInfo(context);
      case WidgetChange.createDoc:
        return createDoc(context);
      case WidgetChange.createTask:
        return createTask(context);
    }

    return dashboard(context);
  }

  /// SHOW CALENDER
  void _showCalender() {
    showDialog<void>(
        context: context,
        builder: (BuildContext buildContext) {
          return AlertDialog(
            content: Container(
              width: 280,
              height: 400,
              child: SfDateRangePicker(
                onSelectionChanged: _onSelectionChanged,
                selectionMode: DateRangePickerSelectionMode.range,
                enablePastDates: false,
              ),
            ),
            actions: <Widget>[
              AppButton(
                Translate.of(context).translate('ok'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
                type: ButtonType.normal,
              ),
            ],
          );
        });
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    setState(() {
      if (args.value is PickerDateRange) {
        _startDate = formatter.format(args.value.startDate).toString();
        _endDate = formatter.format(args.value.endDate).toString();
        _dateController.text = _startDate + "-" + _endDate;
      } else if (args.value is DateTime) {
        _selectedDate = args.value.toString();
      } else if (args.value is List<DateTime>) {
        _dateCount = args.value.length.toString();
      } else {
        _rangeCount = args.value.length.toString();
      }
    });
  }

  /// CREATE TASK
  Future<void> doSave() async {
    print("save >>>> ");
    // check if all test been confirmed.
    if (selectedDocuments == null)
      for (var controller in testControllers) {
        if (controller.onFocus) {
          if (controller.changeFocus(context)) {
            setState(() {});
          } else {
            // save failed. suspend create task
            return;
          }
          return;
        }

        if (controller.totalAnswers == [] || controller.correctAnswers == []) {
          return;
        }
      }

    // check task title
    if (documentTitleController.text == null || documentTitleController.text.isEmpty) {
      SnackBarUtil.warn(context, "document title empty");
      return;
    }

    // check training type
    if (trainingTypeSelection.value == null) {
      SnackBarUtil.warn(context, "training type not select");
      return;
    }

    // check document feature
    if (documentFeatureSelection.value == null) {
      SnackBarUtil.warn(context, "document feature not select");
      return;
    }

    // check department id
    if (departmentSelection.value == null) {
      SnackBarUtil.warn(context, "department not select");
      return;
    }

    // check small leader id
    if (smallLeaderSelection.value == null) {
      SnackBarUtil.warn(context, "small leader not select");
      return;
    }

    String title = documentTitleController.text;
    String description = documentDescriptionController.text;
    int trainingTypeIdFk = trainingTypeSelection.value.id;
    int documentTypeIdFk = documentFeatureSelection.value.id;
    int smallLeaderIdFk = smallLeaderSelection.value.id;

    final task = TaskModel.create(
      isReadonly: isRegularTask,
      departmentIdFk: departmentIdFk,
      title: title,
      description: description,
      trainingTypeIdFk: trainingTypeIdFk,
      documentTypeIdFk: documentTypeIdFk,
      creatorIdFk: Application.user.id,
      smallLeaderIdFk: smallLeaderIdFk,
      startDate: _startDate,
      endDate: _endDate,
      taskStatusIdFk: 1,
    );
    try {
      var response = await Api.createTask(task);
      int taskId = response.id;

      // do create task tests

      testControllers.forEach((e) => Api.createTaskTest(
            e.genTaskTest(taskId),
          ));

      selectedStudentsIds.forEach((element) => Api.saveTaskToUsers(
            taskId,
            element,
          ));

      // do upload new files
      if (choseDocuments.isNotEmpty || choseDocuments.length > 0) {
        await Api.uploadTaskDocumentFiles(taskId, choseDocuments);
      }

      /// DO UPLOAD EXISTS FILES
      if (documentIdFk != null) {
        selectedDocuments.forEach((element) => Api.uploadExistsTaskDocumentFiles(
              taskId,
              element.path,
              element.name,
              documentIdFk,
              selectedIdentifier,
            ));
      }

      SnackBarUtil.info(context, "Create Task Success.");
    } catch (e) {
      SnackBarUtil.error(context, "Some thing went wrong");
    }
    // reset fields
    _resetFields();
  }

  void _resetFields() async {
    setState(() {
      selectedDocuments = [];
      testControllers.clear();
      departmentIdFk = null;
      trainingTypeId = null;
      documentIdFk = null;
      departmentSelection.value = null;
      trainingTypeSelection.value = null;
      documentFeatureSelection.value = null;
      smallLeaderSelection.value = null;
      selectedStudentsIds.clear();
    });

    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentsBloc.add(OnLoadDocuments());
    AppBloc.studentsBloc.add(OnLoadStudents());
    documentTitleController.text = "";
    documentDescriptionController.text = "";
    _dateController.text = "";
  }

  Future<void> uploadFile() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;

      DocumentFiles documentFiles = new DocumentFiles.fromJson({
        "id": null,
        "name": file.name,
        "path": ""
      });
      setState(() {
        documentIdFk = null;
        choseDocuments.add(file);
        selectedDocuments.clear();
        selectedDocuments.add(documentFiles);
      });
    } else {
      // User canceled the picker
    }
  }

  /// DOCUMENTS METHODS
  Future<void> doSaveDoc() async {
    // check if all test been confirmed.
    for (var controller in testControllers) {
      if (controller.onFocus) {
        // try save test controller changes
        if (controller.changeFocus(context)) {
          setState(() {});
        } else {
          // save failed. suspend create document
          return;
        }
      }
    }

    // check document title
    if (documentTitleController.text == null || documentTitleController.text.isEmpty) {
      SnackBarUtil.warn(context, "document title empty");
      return;
    }

    // check description
    // if (documentDescriptionController.text == null ||
    //     documentDescriptionController.text.isEmpty) {
    //   SnackBarUtil.warn(context, "document description empty");
    //   return;
    // }

    // check training type
    if (trainingTypeSelection.value == null) {
      SnackBarUtil.warn(context, "training type not select");
      return;
    }

    // check document feature
    if (documentFeatureSelection.value == null) {
      SnackBarUtil.warn(context, "document feature not select");
      return;
    }

    // check department id
    if (departmentSelection.value == null) {
      SnackBarUtil.warn(context, "department not select");
      return;
    }

    // check small leader id
    if (departmentSelection.value == null) {
      SnackBarUtil.warn(context, "small leader not select");
      return;
    }

    String title = documentTitleController.text;
    String description = documentDescriptionController.text;
    String fileVersion = documentVersionController.text;

    int trainingTypeIdFk = trainingTypeSelection.value.id;
    int documentTypeIdFk = documentFeatureSelection.value.id;
    int creatorIdFk = Application.user.id;
    int departmentIdFk = departmentSelection.value.id;
    int smallLeaderIdFk = smallLeaderSelection.value.id;

    final document = DocumentModel.create(
      title: title,
      description: description,
      fileVersion: fileVersion,
      trainingTypeIdFk: trainingTypeIdFk,
      documentTypeIdFk: documentTypeIdFk,
      creatorIdFk: creatorIdFk,
      smallLeaderIdFk: smallLeaderIdFk,
      departmentIdFk: departmentIdFk,
    );

    // do create document
    var response = await Api.createDocument(document);
    int documentId = response.id;
    print("documentId >>>>> $documentId");

    // do create document tests
    doctestControllers.forEach((e) => Api.createDocumentTest(e.genDocumentTest(documentId)));

    // do upload files
    await Api.uploadDocumentFiles(documentId, choseDocuments);

    SnackBarUtil.info(context, "create document success.");

    // ignore: todo
    // TODO: back to dashboard page.
    _resetDocFields();
  }

  void _resetDocFields() async {
    setState(() {
      selectedDocuments = [];
      doctestControllers.clear();
      departmentIdFk = null;
      trainingTypeId = null;
      documentIdFk = null;
      departmentSelection.value = null;
      trainingTypeSelection.value = null;
      documentFeatureSelection.value = null;
      smallLeaderSelection.value = null;
      selectedStudentsIds.clear();
    });

    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentsBloc.add(OnLoadDocuments());
    AppBloc.studentsBloc.add(OnLoadStudents());
    documentTitleController.text = "";
    documentDescriptionController.text = "";
    _dateController.text = "";
  }

  void doCancel() {}

  Future<void> uploadDocFile() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;
      setState(() => choseDocuments.add(file));

      // print(file.name);
      // print(file.bytes);
      // print(file.size);
      // print(file.extension);
      // print(file.path);
    } else {
      // User canceled the picker
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == WidgetChange.dashboard) HeadingText(Translate.of(context).translate("finished_by_student")),
                  if (selectedWidgetPage == WidgetChange.createDoc || selectedWidgetPage == WidgetChange.createTask || selectedWidgetPage == WidgetChange.taskInfo || selectedWidgetPage == WidgetChange.docInfo) Container(),
                  Row(
                    children: [
                      if (selectedWidgetPage == WidgetChange.dashboard)
                        AppButton(
                          Translate.of(context).translate('create_new_document'),
                          onPressed: () => {
                            setState(() {
                              showDialog(context: context, builder: (context) => CreateDocument(taskStatusId: taskStatusId));
                              // selectedWidgetPage = WidgetChange.createDoc;
                            })
                          },
                          // Navigator.pushNamed(context, Routes.createDocument),
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage == WidgetChange.dashboard) SizedBox(width: 10),
                      if (selectedWidgetPage == WidgetChange.dashboard)
                        AppButton(
                          Translate.of(context).translate('create_new_task'),
                          onPressed: () {
                            setState(() {
                              showDialog(context: context, builder: (context) => CreateNewTask(taskStatusId: taskStatusId));
                              // selectedWidgetPage = WidgetChange.createTask;
                            });
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      // Wrap(
                      //   runSpacing: 20,
                      //   spacing: 40,
                      //   children: [
                      //     if (selectedWidgetPage == WidgetChange.createTask)
                      //       AppButton(
                      //         Translate.of(context).translate('save'),
                      //         onPressed: () {
                      //           doSave();
                      //           selectedWidgetPage = WidgetChange.dashboard;
                      //           AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                      //               viewType: [ViewType.regularTask],
                      //               creatorIdFk: Application.user.id,
                      //               taskDocStatusId: taskStatusId));
                      //         },
                      //         type: ButtonType.normal,
                      //         color: Color(0xff787E8C),
                      //         icon: Icon(Icons.save_outlined),
                      //       ),
                      //     if (selectedWidgetPage == WidgetChange.createDoc)
                      //       AppButton(
                      //         Translate.of(context).translate('save'),
                      //         onPressed: () {
                      //           doSaveDoc();
                      //           selectedWidgetPage = WidgetChange.dashboard;
                      //           AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                      //               viewType: [ViewType.documents],
                      //               creatorIdFk: Application.user.id,
                      //               taskDocStatusId: taskStatusId));
                      //         },
                      //         type: ButtonType.normal,
                      //         color: Color(0xff787E8C),
                      //         icon: Icon(Icons.save_outlined),
                      //       ),
                      //     if (selectedWidgetPage == WidgetChange.createTask ||
                      //         selectedWidgetPage == WidgetChange.taskInfo)
                      //       Tooltip(
                      //         message: Translate.of(context).translate('close'),
                      //         child: InkWell(
                      //           onTap: () {
                      //             setState(() {
                      //               selectedWidgetPage = WidgetChange.dashboard;
                      //               AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                      //                   viewType: [ViewType.regularTask],
                      //                   creatorIdFk: Application.user.id,
                      //                   taskDocStatusId: taskStatusId));
                      //             });
                      //           },
                      //           child: Padding(
                      //             padding: const EdgeInsets.all(8.0),
                      //             child: Icon(
                      //               Icons.close,
                      //               color: Color(0xff00A4E3),
                      //               size: 24,
                      //             ),
                      //           ),
                      //         ),
                      //       ),
                      //     if (selectedWidgetPage == WidgetChange.docInfo ||
                      //         selectedWidgetPage == WidgetChange.createDoc)
                      //       Tooltip(
                      //         message: Translate.of(context).translate('close'),
                      //         child: InkWell(
                      //           onTap: () {
                      //             setState(() {
                      //               selectedWidgetPage = WidgetChange.dashboard;
                      //               AppBloc.tasksDocBloc.add(
                      //                 OnLoadTaskDocEvent(
                      //                     viewType: [ViewType.documents],
                      //                     creatorIdFk: Application.user.id,
                      //                     taskDocStatusId: taskStatusId),
                      //               );
                      //             });
                      //           },
                      //           child: Padding(
                      //             padding: const EdgeInsets.all(8.0),
                      //             child: Icon(
                      //               Icons.close,
                      //               color: Color(0xff00A4E3),
                      //               size: 24,
                      //             ),
                      //           ),
                      //         ),
                      //       ),
                      //   ],
                      // ),
                      if (selectedWidgetPage == WidgetChange.createTask) const SizedBox(width: 10),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Container(child: getCustomContainer(context))
            ],
          ),
        ),
      ],
    );
  }

  Widget dashboard(context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BlocBuilder<TaskDocBloc, TaskDocState>(
          bloc: BlocProvider.of<TaskDocBloc>(context),
          builder: (context, state) {
            if (state is TaskDocSuccess) {
              StudentsTaskDataSource taskDataSource;
              StudentsDocDataSource docDataSource;
              taskDataSource = new StudentsTaskDataSource(
                state.tasks,
                context,
                taskStatusId,
              );

              List<Task> taskCount = state.tasks;
              List<DocumentsModel> docCount = state.documents;

              docDataSource = new StudentsDocDataSource(
                state.documents,
                context,
                taskStatusId,
              );

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FiltersBox(
                    taskStatusId: taskStatusId,
                    viewType: [
                      selectedViewTypeCommon
                    ],
                  ),
                  const SizedBox(height: 20),
                  LayoutBuilder(builder: (context, constraints) {
                    return Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.5,
                              width: constraints.maxWidth,
                              child: SfDataGrid(
                                allowSorting: true,
                                source: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                                columnWidthMode: ColumnWidthMode.fill,
                                columns: [
                                  GridColumn(
                                    columnName: 'title',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('title'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'description',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('description'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'version',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('version'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'beginTime',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('begin_time'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                      columnName: 'endTime',
                                      label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('end_time'),
                                          ))),
                                  GridColumn(
                                    columnName: 'createdDepWorker',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('created_dep_worker'),
                                      ),
                                    ),
                                  ),
                                  if (taskDataSource.rows.length > 0)
                                    GridColumn(
                                      columnName: 'students',
                                      minimumWidth: 150,
                                      label: Container(
                                        height: 50,
                                        color: Color(0xffEFF5FC),
                                        padding: EdgeInsets.all(16.0),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate('students'),
                                        ),
                                      ),
                                    ),
                                ],
                                selectionMode: SelectionMode.single,
                                onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                  if (taskDataSource.rows.length > 0) {
                                    final index = taskDataSource.rows.indexOf(addedRows.last);
                                    print("task >>> $index");
                                  } else {
                                    final index = docDataSource.rows.indexOf(addedRows.last);
                                    print("document >>>> $index");
                                  }
                                  return true;
                                },
                                onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) async {
                                  if (taskDataSource.rows.length > 0) {
                                    final index = taskDataSource.rows.indexOf(addedRows.last);
                                    await showDialog(
                                        context: context,
                                        builder: (context) => CreatorTaskInfoWidget(
                                              taskInfo: paginatedTask[index],
                                            ));
                                    // setState(() {
                                    //   selectedWidgetPage =
                                    //       WidgetChange.taskInfo;
                                    //   task = taskCount[index];
                                    // });
                                  } else {
                                    final index = docDataSource.rows.indexOf(addedRows.first);
                                    print("document >>>> $index");
                                    await showDialog(
                                      context: context,
                                      builder: (context) => DocumentDetailPage(documentInfo: paginatedDocuments[index]),
                                    );
                                    // setState(() {
                                    //   selectedWidgetPage = WidgetChange.docInfo;
                                    //   document = docCount[index];
                                    // });
                                  }
                                },
                              ),
                            ),
                            Container(
                              height: 52,
                              width: constraints.maxWidth,
                              child: SfDataPager(
                                delegate: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                                pageCount: taskDataSource.rows.length > 0 ? (taskCount.length / 10).ceilToDouble() : docCount.length / 10,
                                direction: Axis.horizontal,
                              ),
                            )
                          ],
                        ),
                      ],
                    );
                  }),
                ],
              );
            } else if (state is TaskDocLoading) {
              return LoadingBox(
                height: 20,
              );
            } else if (state is TaskDocEmpty) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FiltersBox(
                    taskStatusId: taskStatusId,
                    viewType: [
                      selectedViewTypeCommon
                    ],
                  ),
                  const SizedBox(height: 20),
                  Center(child: Text("No Records")),
                ],
              );
            } else {
              return Text("load failed.");
            }
          },
        ),
      ],
    );
  }

  void onDelete(int index) => setState(() {
        testControllers.removeAt(index);
      });

  Widget createDoc(context) {
    // return ListView(
    //   shrinkWrap: true,
    //   children: [
    //     Padding(
    //       padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
    //       child: Column(
    //         crossAxisAlignment: CrossAxisAlignment.start,
    //         children: [
    //           // header and two button

    //           Wrap(
    //             runSpacing: 12,
    //             spacing: 40,
    //             children: [
    //               // selection box, choose dept
    //               BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
    //                 bloc: BlocProvider.of<DepartmentsListBloc>(context),
    //                 builder: (context, state) {
    //                   if (state is DepartmentsSuccess) {
    //                     List<Departments> departments = state.departments;
    //                     return SelectionBox<Departments>(
    //                       leading: Translate.of(context).translate("choose_department"),
    //                       hint: "choose_department",
    //                       controller: departmentSelection,
    //                       items: departments,
    //                       getText: (department) => department.name,
    //                       onChanged: (value) => AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: value.id, roleId: smallLeaderRoleId)),
    //                     );
    //                   } else if (state is DepartmentsLoading) {
    //                     return Text("loading");
    //                   } else {
    //                     return Text("load department data failed.");
    //                   }
    //                 },
    //               ),

    //               // selection box, choose small leader
    //               BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
    //                 bloc: BlocProvider.of<DepartmentUsersBloc>(context),
    //                 builder: (context, state) {
    //                   if (state is DepartmentUsersSuccess) {
    //                     return SelectionBox<ReadUsersByIdModel>(
    //                       leading: Translate.of(context).translate("choose_small_leader"),
    //                       hint: "choose small leader",
    //                       controller: smallLeaderSelection,
    //                       items: state.departmentsUser,
    //                       getText: (e) => e.name,
    //                     );
    //                   } else if (state is DepartmentUsersLoading) {
    //                     return LoadingBox(height: 20, width: 20);
    //                   } else {
    //                     return SelectionBox(
    //                       leading: Translate.of(context).translate("choose_small_leader"),
    //                       items: [],
    //                       getText: (e) => "",
    //                       controller: smallLeaderSelection,
    //                       hint: "Please choose a small leader",
    //                     );
    //                   }
    //                 },
    //               ),
    //               SizedBox(
    //                 width: 40,
    //               ),
    //             ],
    //           ),
    //           const SizedBox(height: 12),

    //           // two selection box, train type and document feature
    //           Wrap(
    //             runSpacing: 12,
    //             spacing: 40,
    //             children: [
    //               // selection box of training types
    //               BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
    //                 bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
    //                 builder: (context, state) {
    //                   if (state is TrainingsTypeSuccess) {
    //                     return SelectionBox<TrainingsType>(
    //                       leading: Translate.of(context).translate("training_type"),
    //                       hint: "choose training type",
    //                       controller: trainingTypeSelection,
    //                       items: state.trainingTypes,
    //                       getText: (e) => e.name,
    //                     );
    //                   } else if (state is TrainingsTypeLoading) {
    //                     return Text("loading");
    //                   } else {
    //                     return Text("load trainings type failed.");
    //                   }
    //                 },
    //               ),

    //               // selection box of training types
    //               BlocBuilder<DocumentsFeatureListBloc, DocumentsFeatureListState>(
    //                 bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
    //                 builder: (context, state) {
    //                   if (state is DocumentsFeatureSuccess) {
    //                     return SelectionBox<DocumentsFeature>(
    //                       leading: Translate.of(context).translate("document_feature"),
    //                       hint: "choose document feature",
    //                       controller: documentFeatureSelection,
    //                       items: state.documentsFeature,
    //                       getText: (e) => e.name,
    //                     );
    //                   } else if (state is DocumentsFeatureLoading) {
    //                     return Text("loading");
    //                   } else {
    //                     return Text("load document features failed.");
    //                   }
    //                 },
    //               ),
    //             ],
    //           ),
    //           const SizedBox(height: 12),

    //           // two input box, document title and document description
    //           Wrap(runSpacing: 12, spacing: 40, children: [
    //             InputBox(
    //               label: Translate.of(context).translate("document_title"),
    //               controller: documentTitleController,
    //             ),
    //             InputBox(
    //               label: Translate.of(context).translate("document_description"),
    //               controller: documentDescriptionController,
    //             )
    //           ]),
    //           const SizedBox(height: 12),

    //           // button, upload file;
    //           Row(
    //             children: [
    //               UploadFileButton(uploadDocFile),
    //               SizedBox(width: 60),
    //               InputBox(
    //                 label: Translate.of(context).translate("file_version"),
    //                 controller: documentVersionController,
    //                 keyBoardType: TextInputType.number,
    //                 inputFormatters: <TextInputFormatter>[
    //                   FilteringTextInputFormatter.digitsOnly
    //                 ], // Only numbers can be entered
    //               ),
    //             ],
    //           ),
    //           const SizedBox(height: 23),

    //           // data table, files
    //           UploadedFileTable(choseDocuments),
    //           const SizedBox(height: 20),

    //           // tests table
    //           TestsTable(doctestControllers),
    //           const SizedBox(height: 30),
    //         ],
    //       ),
    //     ),
    //   ],
    // );
  }

  Widget createTask(context) {
    // return ListView(
    //   shrinkWrap: true,
    //   children: [
    //     Padding(
    //       padding: const EdgeInsets.fromLTRB(8, 12, 12, 25),
    //       child: Column(
    //         crossAxisAlignment: CrossAxisAlignment.start,
    //         children: [
    //           // two radio, regular or read only
    //           Column(
    //             crossAxisAlignment: CrossAxisAlignment.start,
    //             children: [
    //               SizedBox(
    //                 width: 162,
    //                 height: 40,
    //                 child: Container(
    //                   alignment: Alignment.centerLeft,
    //                   child: Text(
    //                     Translate.of(context).translate("task_type"),
    //                     style: TextStyle(fontSize: 14),
    //                   ),
    //                 ),
    //               ),
    //               Wrap(
    //                 runSpacing: 10,
    //                 spacing: 210,
    //                 children: [
    //                   Wrap(
    //                     runSpacing: 10,
    //                     spacing: 5,
    //                     children: [
    //                       Radio(
    //                         value: false,
    //                         groupValue: isRegularTask,
    //                         onChanged: (newValue) => setState(() => isRegularTask = newValue),
    //                         activeColor: Colors.lightBlueAccent,
    //                       ),
    //                       Text(Translate.of(context).translate("regular_task")),
    //                       SizedBox(
    //                         width: 15,
    //                       ),
    //                       Radio(
    //                         value: true,
    //                         groupValue: isRegularTask,
    //                         onChanged: (newValue) => setState(() => isRegularTask = newValue),
    //                         activeColor: Colors.lightBlueAccent,
    //                       ),
    //                       Text(Translate.of(context).translate("read_only_task")),
    //                     ],
    //                   ),

    //                   // selection box, choose dept
    //                   BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
    //                     bloc: BlocProvider.of<DepartmentsListBloc>(context),
    //                     builder: (context, state) {
    //                       if (state is DepartmentsSuccess) {
    //                         List<Departments> departments = state.departments;
    //                         return SelectionBox<Departments>(
    //                           leading: Translate.of(context).translate("choose_department"),
    //                           hint: Translate.of(context).translate("choose_department"),
    //                           controller: departmentSelection,
    //                           items: departments,
    //                           getText: (department) => department.name,
    //                           onChanged: (value) {
    //                             setState(() {
    //                               departmentIdFk = value.id;
    //                               AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: value.id, roleId: smallLeaderRoleId));
    //                               AppBloc.studentsBloc.add(OnLoadStudents(departmentIdFk: value.id, roleIdFk: studentsRoleId));
    //                             });
    //                           },
    //                         );
    //                       } else if (state is DepartmentsLoading) {
    //                         return Text("loading");
    //                       } else {
    //                         return Text("load department data failed.");
    //                       }
    //                     },
    //                   ),
    //                 ],
    //               ),
    //             ],
    //           ),
    //           const SizedBox(height: 12),

    //           // two selection box, train type and document feature
    //           Wrap(
    //             runSpacing: 12,
    //             spacing: 40,
    //             children: [
    //               // selection box of training types
    //               BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
    //                 bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
    //                 builder: (context, state) {
    //                   if (state is TrainingsTypeSuccess) {
    //                     return SelectionBox<TrainingsType>(
    //                       leading: Translate.of(context).translate("train_type"),
    //                       hint: Translate.of(context).translate("train_type"),
    //                       controller: trainingTypeSelection,
    //                       items: state.trainingTypes,
    //                       getText: (e) => e.name,
    //                       onChanged: (value) {
    //                         setState(() {
    //                           trainingTypeId = value.id;
    //                           AppBloc.documentsBloc.add(OnLoadDocuments(trainingTypeIdFk: trainingTypeId, departmentIdFk: departmentIdFk, documentFeature: documentFeatureIdFk));
    //                         });
    //                       },
    //                     );
    //                   } else if (state is TrainingsTypeLoading) {
    //                     return Text("loading");
    //                   } else {
    //                     return Text("load trainings type failed.");
    //                   }
    //                 },
    //               ),

    //               // selection box of training types
    //               BlocBuilder<DocumentsFeatureListBloc, DocumentsFeatureListState>(
    //                 bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
    //                 builder: (context, state) {
    //                   if (state is DocumentsFeatureSuccess) {
    //                     return SelectionBox<DocumentsFeature>(
    //                       leading: Translate.of(context).translate("document_feature"),
    //                       hint: Translate.of(context).translate("document_feature"),
    //                       controller: documentFeatureSelection,
    //                       items: state.documentsFeature,
    //                       getText: (e) => e.name,
    //                       onChanged: (value) {
    //                         setState(() {
    //                           documentFeatureIdFk = value.id;
    //                           AppBloc.documentsBloc.add(OnLoadDocuments(trainingTypeIdFk: trainingTypeId, departmentIdFk: departmentIdFk, documentFeature: documentFeatureIdFk));
    //                         });
    //                       },
    //                     );
    //                   } else if (state is DocumentsFeatureLoading) {
    //                     return Text("loading");
    //                   } else {
    //                     return Text("load document features failed.");
    //                   }
    //                 },
    //               ),
    //             ],
    //           ),
    //           const SizedBox(height: 12),

    //           // two input box, document title and document description
    //           Wrap(
    //             runSpacing: 12,
    //             spacing: 40,
    //             children: [
    //               Row(
    //                 mainAxisSize: MainAxisSize.min,
    //                 children: [
    //                   SizedBox(
    //                     width: 162,
    //                     height: 40,
    //                     child: Container(
    //                       alignment: Alignment.centerLeft,
    //                       child: Text(
    //                         Translate.of(context).translate("document_title"),
    //                         style: TextStyle(fontSize: 14),
    //                       ),
    //                     ),
    //                   ),
    //                   BlocBuilder<DocumentsBloc, DocumentsState>(
    //                     bloc: BlocProvider.of<DocumentsBloc>(context),
    //                     builder: (context, documentsList) {
    //                       if (documentsList is DocumentsLoading) {
    //                         return Container(
    //                           child: LoadingBox(
    //                             height: 30,
    //                           ),
    //                         );
    //                       } else if (documentsList is DocumentsSuccess) {
    //                         return Container(
    //                           width: 200,
    //                           height: 38,
    //                           child: CustomAutoCompleteTextField<DocumentsModel>(
    //                             controller: documentTitleController,
    //                             suggestions: documentsList.documents,
    //                             key: key,
    //                             style: TextStyle(
    //                               color: Colors.black,
    //                               fontSize: 12,
    //                             ),
    //                             onFocusChanged: (focus) {
    //                               if (focus == true) {
    //                                 print(documentsList.documents.length);
    //                               }
    //                             },
    //                             decoration: InputDecoration(
    //                               border: OutlineInputBorder(
    //                                 borderRadius: BorderRadius.all(Radius.circular(3)),
    //                                 borderSide: BorderSide(color: Colors.red, width: 1.0),
    //                               ),
    //                               contentPadding: EdgeInsets.fromLTRB(10, 4, 10, 4),
    //                               hintText: Translate.of(context).translate("document_title"),
    //                               hintStyle: TextStyle(color: Colors.black),
    //                             ),
    //                             itemBuilder: (context, query) {
    //                               return new Padding(
    //                                   child: new ListTile(
    //                                     title: new Text(query.title),
    //                                   ),
    //                                   padding: EdgeInsets.all(2.0));
    //                             },
    //                             textChanged: (text) {
    //                               print(text);
    //                             },
    //                             itemSorter: (a, b) => a.title.compareTo(b.title),
    //                             itemFilter: (suggestion, input) => suggestion.title.toLowerCase().startsWith(input.toLowerCase()),
    //                             itemSubmitted: (item) {
    //                               setState(
    //                                 () {
    //                                   selectedDocument = item;
    //                                   documentTitleController.text = item.title;
    //                                   documentIdFk = item.id;
    //                                   selectedIdentifier = item.identifier;
    //                                   selectedName = item.documentFiles[0].name;
    //                                   selectedPath = item.documentFiles[0].path;
    //                                   selectedDocuments = item.documentFiles;
    //                                   selectedDocumentTest = item.documentTests;
    //                                   var documentTestIdFk = item.documentTests.first.id;
    //                                   item.documentTests.forEach(
    //                                     (e) => testControllers.add(
    //                                       new SingleTaskTestController(doRemove: onDelete, correctAnswers: e.rightAnswers, questionInputController: TextEditingController(text: e.question), selectedAnswers: e.totalAnswers, documentIdFk: documentIdFk, documentTestIdFk: documentTestIdFk),
    //                                     ),
    //                                   );
    //                                 },
    //                               );
    //                             },
    //                             clearOnSubmit: false,
    //                           ),
    //                         );
    //                       } else {
    //                         return Container();
    //                       }
    //                     },
    //                   ),
    //                 ],
    //               ),
    //               InputBox(
    //                 label: Translate.of(context).translate("document_description"),
    //                 controller: documentDescriptionController,
    //               ),
    //             ],
    //           ),
    //           const SizedBox(height: 12),

    //           // button, upload file;

    //           UploadTaskFileButton(uploadFile),
    //           const SizedBox(height: 23),

    //           // data table, files

    //           UploadedTaskFileTable(selectedDocuments: selectedDocuments),
    //           const SizedBox(height: 20),

    //           // tests table
    //           TaskTestsTable(controllers: testControllers),
    //           const SizedBox(height: 30),

    //           // selection box, choose small leader
    //           Wrap(
    //             runSpacing: 12,
    //             spacing: 20,
    //             children: [
    //               Column(
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //                 children: [
    //                   Text(
    //                     Translate.of(context).translate("choose_small_leader"),
    //                     style: TextStyle(fontSize: 12),
    //                   ),
    //                   SizedBox(
    //                     height: 5,
    //                   ),
    //                   BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
    //                     bloc: BlocProvider.of<DepartmentUsersBloc>(context),
    //                     builder: (context, state) {
    //                       if (state is DepartmentUsersSuccess) {
    //                         return SelectionBox<ReadUsersByIdModel>(
    //                           items: state.departmentsUser,
    //                           getText: (e) => e.name,
    //                           controller: smallLeaderSelection,
    //                           hint: Translate.of(context).translate("choose_small_leader"),
    //                         );
    //                       } else if (state is DepartmentUsersLoading) {
    //                         return LoadingBox(height: 20, width: 20);
    //                       } else {
    //                         return SelectionBox(
    //                           items: [],
    //                           getText: (e) => "",
    //                           controller: smallLeaderSelection,
    //                           hint: Translate.of(context).translate("choose_small_leader"),
    //                         );
    //                       }
    //                     },
    //                   ),
    //                 ],
    //               ),
    //               // selection box, choose STUDENT
    //               Column(
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //                 children: [
    //                   Text(
    //                     Translate.of(context).translate("choose_student"),
    //                     style: TextStyle(fontSize: 12),
    //                   ),
    //                   SizedBox(
    //                     height: 5,
    //                   ),
    //                   SizedBox(
    //                     width: 162,
    //                     height: 40,
    //                     child: StudentsDropDownMultiSelect(
    //                         onChanged: (List<String> names, List<int> ids) {
    //                           print(selectedStudentsIds);
    //                           setState(() {
    //                             selectedStudents = names;
    //                             selectedStudentsIds = ids;
    //                           });
    //                         },
    //                         selectedValues: selectedStudents,
    //                         selectedIds: selectedStudentsIds,
    //                         whenEmpty: Translate.of(context).translate("choose_student"),
    //                         departmentIdFk: departmentIdFk,
    //                         studentsRoleId: studentsRoleId),
    //                   ),
    //                   // BlocBuilder<StudentsBloc, StudentsState>(
    //                   //   bloc: BlocProvider.of<StudentsBloc>(context),
    //                   //   builder: (context, state) {
    //                   //     if (state is StudentsSuccess) {
    //                   //       // return SelectionBox<ReadUsersByIdModel>(
    //                   //       //   items: state.students,
    //                   //       //   getText: (e) => e.name,
    //                   //       //   controller: studentsSelection,
    //                   //       //   hint: Translate.of(context)
    //                   //       //       .translate("choose_student"),
    //                   //       //   onChanged: (value) {
    //                   //       //     setState(() {
    //                   //       //       studentIdFk = value.id;
    //                   //       //     });
    //                   //       //   },
    //                   //       // );
    //                   //       return SizedBox(
    //                   //         width: 162,
    //                   //         height: 40,
    //                   //         child: StudentsDropDownMultiSelect(
    //                   //             onChanged: (List<String> x) {
    //                   //               setState(() {
    //                   //                 selectedStudents = x;
    //                   //               });
    //                   //             },
    //                   //             selectedValues: selectedStudents,
    //                   //             whenEmpty: 'Select Students',
    //                   //             departmentIdFk: departmentIdFk,
    //                   //             studentsRoleId: studentsRoleId),
    //                   //       );
    //                   //     } else if (state is StudentsLoading) {
    //                   //       return LoadingBox(height: 20, width: 20);
    //                   //     } else {
    //                   //       return SelectionBox(
    //                   //         items: [],
    //                   //         getText: (e) => "",
    //                   //         controller: studentsSelection,
    //                   //         hint: Translate.of(context)
    //                   //             .translate("choose_student"),
    //                   //       );
    //                   //     }
    //                   //   },
    //                   // ),
    //                 ],
    //               ),
    //               Container(
    //                 width: 400,
    //                 child: Column(
    //                   crossAxisAlignment: CrossAxisAlignment.start,
    //                   children: [
    //                     Text(
    //                       Translate.of(context).translate("choose_duration"),
    //                       style: TextStyle(fontSize: 12),
    //                     ),
    //                     SizedBox(
    //                       height: 5,
    //                     ),
    //                     Container(
    //                       width: 300,
    //                       child: GestureDetector(
    //                         onTap: () {
    //                           setState(() {
    //                             _showCalender();
    //                           });
    //                         },
    //                         child: AbsorbPointer(
    //                           child: AppTextInput(
    //                             controller: _dateController,
    //                             hintText: Translate.of(context).translate("from_to_date"),
    //                             keyboardType: TextInputType.datetime,
    //                             icon: Icon(
    //                               Icons.calendar_today_outlined,
    //                               color: Colors.blue,
    //                               size: 13,
    //                             ),
    //                           ),
    //                         ),
    //                       ),
    //                     ),
    //                   ],
    //                 ),
    //               )
    //             ],
    //           )
    //         ],
    //       ),
    //     )
    //   ],
    // );
  }

  Widget taskInfo(context) {
    return TaskInfoWidget(taskInfo: task);
  }

  Widget docInfo(context) {
    return DocumentDetailPage(documentInfo: document);
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }
}

class StudentsTaskDataSource extends DataGridSource {
  BuildContext contxt;

  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  StudentsTaskDataSource(List<Task> tasksData, context, int statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    try {
      if (tasks.length < 10) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.taskDocuments.first.document.version),
              DataGridCell<String>(columnName: 'beginTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.startDate)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'students',
                value: e.taskStudents.fold<String>("", (previousValue, element) => previousValue + element.taskUser.username + ', '),
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[0].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[0].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[1].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[2].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[3].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[3].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[4].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[4].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[5].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[5].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[6].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[6].value.toString()),
            ),
          ),
        ),
      ],
    );
  }
}

class StudentsDocDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int statusId;
  Task task;
  final Completer _completer = new Completer();
  StudentsDocDataSource(
    List<DocumentsModel> documentsData,
    context,
    int docStatusId,
  ) {
    try {
      documents = documentsData;
      contxt = context;
      statusId = docStatusId;

      if (documents.length < rowsPerPage) {
        paginatedDocuments = documents.toList();
      } else {
        paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.version),
              DataGridCell<String>(columnName: 'beginTime', value: ""),
              DataGridCell<String>(columnName: 'endTime', value: ""),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.docCreator.creatorDepartment.name + ", " + e.docCreator.name,
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[0].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[0].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[1].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[2].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[5].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[5].value.toString()),
            ),
          ),
        ),
      ],
    );
  }
}
