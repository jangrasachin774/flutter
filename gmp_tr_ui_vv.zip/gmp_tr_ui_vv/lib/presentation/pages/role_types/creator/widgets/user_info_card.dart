import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/app_button.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:intl/intl.dart';

class UserInfoCard extends StatefulWidget {
  final UsersModel user;

  const UserInfoCard({Key key, this.user}) : super(key: key);

  @override
  _UserInfoCardState createState() => _UserInfoCardState();
}

class _UserInfoCardState extends State<UserInfoCard> {
  bool viewHistory = false;

  @override
  void initState() {
    super.initState();
    AppBloc.usersHistoryBloc.add(UserHistory(userId: widget.user.id));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          _studentNameAndStatus(),
          const SizedBox(height: 20),
          ConstrainedBox(constraints: BoxConstraints(maxWidth: 1100), child: Divider()),
          const SizedBox(height: 20),
          Wrap(
            spacing: 30,
            runSpacing: 20,
            children: [
              _keyValueText(Translate.of(context).translate("work_no"), widget.user.workNo),
              _keyValueText(Translate.of(context).translate("gender"), _getGenderText(widget.user.gender)),
              _keyValueText(Translate.of(context).translate("contact"), widget.user.contact),
              _keyValueText(Translate.of(context).translate("email"), widget.user.email),
              _keyValueText(Translate.of(context).translate("real_company"), widget.user.realCompany),
              _keyValueText(Translate.of(context).translate("real_department"), widget.user.realDepartment)
            ],
          ),
          // const SizedBox(height: 20),
          // Wrap(
          //   spacing: 20,
          //   runSpacing: 20,
          //   children: [
          //     // _keyValueText(Translate.of(context).translate("contact"),
          //     //     widget.user.contact),
          //     // _keyValueText(Translate.of(context).translate("email"),
          //     //     widget.user.email)
          //   ],
          // ),
          // const SizedBox(height: 20),
          // Wrap(
          //   spacing: 20,
          //   runSpacing: 20,
          //   children: [
          //     _keyValueText(Translate.of(context).translate("real_company"),
          //         widget.user.realCompany),
          //     _keyValueText(
          //         Translate.of(context).translate("real_department"),
          //         widget.user.realDepartment)
          //   ],
          // ),
          const SizedBox(height: 20),
          widget.user.department != null ? _keyValueText(Translate.of(context).translate("department_for_training"), widget.user.department.name) : Container(),
          const SizedBox(height: 20),
          _keyValueList(
              Translate.of(context).translate("role"),
              // FIXME: where to get the Role?
              widget.user.userRoles),
          const SizedBox(height: 20),
          _keyValueText(Translate.of(context).translate("username"), widget.user.username),
          const SizedBox(height: 40),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: 600),
            child: Container(
              alignment: Alignment.centerRight,
              child: AppButton(
                Translate.of(context).translate("view_history"),
                color: Color(0xff787E8C),
                type: ButtonType.outline,
                onPressed: () => setState(() {
                  viewHistory = !viewHistory;
                }),
                icon: Icon(Icons.history_outlined),
              ),
            ),
          ),
          const SizedBox(height: 20),
          if (viewHistory) _historyInfoCard()
        ]),
      ),
    );
  }

  _studentNameAndStatus() {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.user.name, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(width: 20),
          Container(
            height: 20,
            width: 20,
            decoration: BoxDecoration(color: _getStatusColor(widget.user.userStatusIdFk), shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Text(_getStatusName(widget.user.userStatusIdFk))
        ],
      ),
    );
  }

  _keyValueText(String key, String value) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      // Container(width: 150, child: Text(key)),
      // Container(
      //     width: 150,
      //     child: Text(value, style: TextStyle(fontWeight: FontWeight.bold)))
      Text(key),
      SizedBox(width: 5),
      Text(value, style: TextStyle(fontWeight: FontWeight.bold))
    ]);
  }

  _keyValueList(String key, List<UserRole> roles) {
    return Row(mainAxisSize: MainAxisSize.min, verticalDirection: VerticalDirection.down, crossAxisAlignment: CrossAxisAlignment.center, mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(key),
      SizedBox(width: 5),
      Container(
        width: 400,
        height: 20,
        child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: roles.length,
            itemBuilder: (context, index) {
              return _getUserRoles(roles[index], index);
            }),
      )
    ]);
  }

  _getUserRoles(UserRole roles, int index) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: Text(roles.role.name + ","),
    );
  }

  // FIXME: check if the status to color is right?
  _getStatusColor(int status) {
    if (status == 3)
      return Colors.redAccent;
    else if (status == 2)
      return Colors.yellowAccent;
    else
      return Colors.greenAccent;
  }

  String _getStatusName(int status) {
    if (status == 3)
      return Translate.of(context).translate("disable");
    else if (status == 2)
      return Translate.of(context).translate("leave");
    else
      return Translate.of(context).translate("normal");
  }

  String _getGenderText(int gender) {
    return Translate.of(context).translate(gender == 0 ? "male" : "female");
  }

  Widget _historyInfoCard() {
    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: 1100),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              alignment: Alignment.centerLeft,
              color: Colors.grey.withOpacity(.2),
              child: Text(
                Translate.of(context).translate("view_history"),
                style: _bold14,
              ),
            ),
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: 146),
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: BlocBuilder<UsersHistoryBloc, UsersHistoryState>(
                        bloc: BlocProvider.of<UsersHistoryBloc>(context),
                        builder: (context, userHistory) {
                          if (userHistory is UserHistoryLoading) {
                            return LoadingBox();
                          } else if (userHistory is UserHistoryLoadedSuccess) {
                            return DataTable(
                              headingRowHeight: 40,
                              columnSpacing: 20,
                              dataRowHeight: 40,
                              dividerThickness: 0,
                              columns: [
                                DataColumn(label: Text(Translate.of(context).translate("username"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("gender"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("work_no"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("contact"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("email"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("name"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("real_company"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("real_department"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("user_status"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("department"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("updated_at"), style: _bold14)),
                                DataColumn(label: Text(Translate.of(context).translate("type"), style: _bold14)),
                              ],
                              rows: List.generate(userHistory.userHistory.length, (index) => _singleHistoryRecord(userHistory.userHistory[index])),
                            );
                          } else {
                            return Container();
                          }
                        })),
              ),
            )
          ],
        ),
      ),
    );
  }

  // FIXME: use correct datasource
  DataRow _singleHistoryRecord(UserHistoryModel userHistory) {
    return DataRow(cells: [
      DataCell(Text(userHistory.username)),
      DataCell(Text(userHistory.gender.toString())),
      DataCell(Text(userHistory.workNo.toString())),
      DataCell(Text(userHistory.contact)),
      DataCell(Text(userHistory.email)),
      DataCell(Text(userHistory.name)),
      DataCell(Text(userHistory.realCompany)),
      DataCell(Text(userHistory.realDepartment)),
      DataCell(Text(userHistory.userStatus.name)),
      DataCell(Text(userHistory?.department?.name ?? '')),
      DataCell(Text(DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(userHistory.updatedAt)).toString())),
      DataCell(Text(userHistory.type)),
    ]);
  }

  get _bold14 => const TextStyle(fontSize: 14, fontWeight: FontWeight.bold);
}
