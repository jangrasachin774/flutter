import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:gmptr/utils/translate.dart';

/// for create document/task page
class UploadedFileTable extends StatefulWidget {
  final List<PlatformFile> choseDocuments;

  const UploadedFileTable(this.choseDocuments, {Key key}) : super(key: key);

  @override
  _UploadedFileTableState createState() => _UploadedFileTableState();
}

class _UploadedFileTableState extends State<UploadedFileTable> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          Translate.of(context).translate("files"),
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          child: DataTable(
            headingRowColor: MaterialStateColor.resolveWith(
              (states) => Color(0xffEFF5FC),
            ),
            headingRowHeight: 50,
            decoration: BoxDecoration(
              border: Border.all(width: 1, color: Color(0xffD4E5F9)),
            ),
            columns: [
              DataColumn(
                label: Text(Translate.of(context).translate("s.no")),
              ),
              DataColumn(
                label: Text(Translate.of(context).translate("file_name")),
              ),
              DataColumn(
                label: Text(Translate.of(context).translate("actions")),
              )
            ],
            rows: List.generate(
                widget.choseDocuments.length,
                (index) => DataRow(cells: [
                      DataCell(Text("${index + 1}")),
                      DataCell(Text("${widget.choseDocuments[index].name}")),
                      DataCell(Row(
                        children: [
                          IconButton(
                            onPressed: () => setState(
                                () => widget.choseDocuments.removeAt(index)),
                            icon: Icon(
                              Icons.delete_outlined,
                              color: Colors.lightBlueAccent,
                            ),
                          ),
                        ],
                      ))
                    ])),
          ),
        )
      ],
    );
  }
}

class UploadFileButton extends StatefulWidget {
  final void Function() onUpload;

  const UploadFileButton(this.onUpload, {Key key}) : super(key: key);

  @override
  _UploadFileButtonState createState() => _UploadFileButtonState();
}

class _UploadFileButtonState extends State<UploadFileButton> {
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      SizedBox(
        width: 162,
        height: 40,
        child: Container(
          alignment: Alignment.centerLeft,
          child: Text(
            Translate.of(context).translate("upload_file"),
            style: TextStyle(fontSize: 14),
          ),
        ),
      ),
      SizedBox(
        height: 40,
        width: 157,
        child: OutlinedButton(
          onPressed: widget.onUpload,
          child: Container(
            alignment: Alignment.center,
            child: Row(children: [
              Icon(Icons.file_upload_outlined),
              SizedBox(width: 7),
              Text(
                Translate.of(context).translate("choose_file"),
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
              )
            ]),
          ),
          style: OutlinedButton.styleFrom(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
            side: BorderSide(color: Colors.lightBlueAccent),
          ),
        ),
      ),
    ]);
  }
}
