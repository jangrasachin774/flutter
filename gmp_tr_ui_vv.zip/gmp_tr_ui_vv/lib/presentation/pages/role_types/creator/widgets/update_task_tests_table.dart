import 'package:flutter/material.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/responsive.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/translate.dart';

import 'multiselect_widget.dart';

class UpdateTaskTestsTable extends StatefulWidget {
  final List<UpdateSingleTaskTestController> controllers;

  const UpdateTaskTestsTable({Key key, this.controllers}) : super(key: key);

  @override
  _UpdateTaskTestsTableState createState() => _UpdateTaskTestsTableState();
}

class _UpdateTaskTestsTableState extends State<UpdateTaskTestsTable> {
  @override
  Widget build(BuildContext context) {
    print("Question first id >>>>>> ${widget.controllers.first.id}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // editable table, tests
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            Translate.of(context).translate("tests"),
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            // FIXME: text will overflow in mobile size
            child: Row(children: [
              // S.NO
              textOfUpdateTaskTestsTable(
                  1, Translate.of(context).translate("s_no")),
              const SizedBox(width: 10),

              // Question
              textOfUpdateTaskTestsTable(
                  12, Translate.of(context).translate("question")),
              const SizedBox(width: 10),

              // Total Answers
              textOfUpdateTaskTestsTable(
                  3, Translate.of(context).translate("total_answers")),
              const SizedBox(width: 10),

              // Correct Answer
              textOfUpdateTaskTestsTable(
                  2, Translate.of(context).translate("correct_answer")),
              const SizedBox(width: 10),

              Spacer(flex: 2),
            ]),
          ),
          const SizedBox(height: 20),
          Column(
            children: List.generate(
              widget.controllers.length,
              (i) => UpdateTaskSingleTest(
                  controller: widget.controllers[i], index: i),
            ),
          )
        ]),
        const SizedBox(height: 10),

        // add new question button
        AppButton(
          Translate.of(context).translate("add_new_question_and_answer"),
          icon: Icon(Icons.question_answer_outlined),
          type: ButtonType.outline,
          color: Color(0xff787E8C),
          onPressed: () => setState(() => widget.controllers.add(
              new UpdateSingleTaskTestController(
                  doRemove: onDelete,
                  questionInputController: TextEditingController(text: ""),
                  correctAnswers: [],
                  selectedAnswers: []))),
        ),
      ],
    );
  }

  Widget textOfUpdateTaskTestsTable(int flex, String key) => Expanded(
        flex: flex,
        child: Container(
          child: Text(
            Translate.of(context).translate(key),
            style: TextStyle(
                fontSize: Responsive.isMobile(context) ? 10 : 14,
                fontWeight: FontWeight.bold),
          ),
        ),
      );

  void onDelete(int index) => setState(
        () => widget.controllers.removeAt(index),
      );
}

class UpdateSingleTaskTestController {
  var questionInputController = TextEditingController();
  final int documentIdFk;
  final int documentTestIdFk;
  final int id;
  List<String> selectedAnswers = [];
  List<String> correctAnswers = [];

  final void Function(int) doRemove;

  UpdateSingleTaskTestController({
    this.doRemove,
    this.correctAnswers,
    this.selectedAnswers,
    this.questionInputController,
    this.documentIdFk,
    this.documentTestIdFk,
    this.id,
  });
  bool onFocus = true;
  bool changeFocus(BuildContext context) {
    if (onFocus == true) {
      // check user input here.

      if (selectedAnswers.isEmpty || correctAnswers.isEmpty) {
        SnackBarUtil.warn(context, "total answer or correct answer not select");
        return false;
      }

      if (questionInputController.text == "") {
        SnackBarUtil.warn(context, "question can't be empty");
        return false;
      }
    }
    onFocus = !onFocus;

    return true;
  }

  TaskTestModel genTaskTest(int taskId) {
    return TaskTestModel.create(
      question: questionInputController.text,
      documentIdFk: documentIdFk,
      id: id,
      taskIdFk: taskId,
      documentTestIdFk: documentTestIdFk,
      totalAnswers: selectedAnswers,
      rightAnswers: correctAnswers,
    );
  }

  get question => questionInputController.text;

  get totalAnswers => selectedAnswers;

  get correctAnswer => correctAnswers;
}

class UpdateTaskSingleTest extends StatefulWidget {
  final int index;
  final UpdateSingleTaskTestController controller;

  const UpdateTaskSingleTest({Key key, this.controller, this.index})
      : super(key: key);

  @override
  _UpdateTaskSingleTestState createState() => _UpdateTaskSingleTestState();
}

class _UpdateTaskSingleTestState extends State<UpdateTaskSingleTest> {
  String _question;

  @override
  void initState() {
    super.initState();
    widget.controller.questionInputController.text = _question;
    print("QUESTION ID >>>>> ${widget.controller.id}");
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xffd4d4d4),
        border: Border.all(
          color: Colors.grey.withOpacity(.12),
          width: 1,
        ),
      ),
      constraints: BoxConstraints(minHeight: 50),
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
      // generated by a test recorde
      child: Row(children: [
        // S.NO.
        Expanded(
          flex: 1,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            alignment: Alignment.center,
            child: SizedBox(
              height: 45,
              child: Center(
                child: Text(
                  (widget.index + 1).toString(),
                  style: TextStyle(fontSize: 14),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),

        // question
        Expanded(
          flex: 12,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            padding: EdgeInsets.symmetric(vertical: 10),
            alignment: Alignment.center,
            child: TextField(
              maxLines: null,
              keyboardType: TextInputType.multiline,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                border: OutlineInputBorder(borderSide: BorderSide.none),
                hintText: "Enter Questions here",
              ),
              style: TextStyle(fontSize: 12),
              enabled: widget.controller.onFocus,
              controller: widget.controller.questionInputController,
              onChanged: (text) {
                setState(() {
                  _question = text;
                });
              },
            ),
          ),
        ),
        const SizedBox(width: 10),

        // total answers
        Expanded(
          flex: 3,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            alignment: Alignment.center,
            // FIXME: will overflow while choosing dropdown item in mobile size
            child: createDropdownMultiSelect(
              onChanged: (List<String> newValues) =>
                  setState(() => widget.controller.selectedAnswers = newValues),
              options:
                  List.generate(26, (index) => String.fromCharCode(65 + index)),
              selectedValues: widget.controller.selectedAnswers,
              hint: "A ~ Z",
            ),
          ),
        ),
        const SizedBox(width: 10),

        // correct answer
        Expanded(
          flex: 2,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            alignment: Alignment.center,
            child: createDropdownMultiSelect(
              hint: "answers",
              selectedValues: widget.controller.correctAnswers,
              options: widget.controller.selectedAnswers,
              onChanged: (newValues) =>
                  setState(() => widget.controller.correctAnswers = newValues),
            ),
          ),
        ),
        const SizedBox(width: 10),

        // edit/save & delete
        // FIXME: right side icon will overflow in mobile size
        Expanded(
            flex: 2,
            child: Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    InkWell(
                      child: focusIcon,
                      onTap: () => setState(() {
                        widget.controller.changeFocus(context);
                      }),
                    ),
                    InkWell(
                        child: Icon(Icons.delete_outlined, color: Colors.grey),
                        onTap: () {
                          setState(() {
                            print('clickeedddd....');
                            // try {
                            //   Api.deleteTaskQuestion(widget.controller.id);
                            // } catch (e) {
                            //   print("QUESTION >>>>> $e");
                            //   throw e;
                            // }
                            // widget.controller.doRemove(widget.index);
                          });
                        }),
                  ]),
            ))
      ]),
    );
  }

  Widget createDropdownMultiSelect({
    String hint,
    List<String> selectedValues,
    List<String> options,
    ValueChanged<List<String>> onChanged,
  }) {
    return IgnorePointer(
      ignoring: !widget.controller.onFocus,
      child: Container(
        width: double.infinity,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: 50, minHeight: 50),
          child: CustomDropDownMultiSelect(
            onChanged: onChanged,
            options: options,
            selectedValues: selectedValues,
            whenEmpty: hint,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 10, vertical: 12),
              hintStyle: TextStyle(fontSize: 13),
            ),
          ),
        ),
      ),
    );
  }

  Color get focusColor =>
      widget.controller.onFocus ? Colors.white : Color(0xffe6e6e6);

  Icon get focusIcon => widget.controller.onFocus
      ? Icon(Icons.done_outlined, color: Colors.lightBlueAccent)
      : Icon(Icons.edit_outlined, color: Colors.lightBlueAccent);
}
