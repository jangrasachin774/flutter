import 'package:flutter/material.dart';

class DismissiblePopupDialog extends StatelessWidget {
  final Text child;
  final String info;

  const DismissiblePopupDialog({Key key, this.child, this.info = ""})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
            child: child == null ? Text(info) : child,
          ),
          Positioned(
            right: 0,
            child: IconButton(
              icon: Icon(Icons.close_outlined),
              onPressed: () => Navigator.of(context).pop(),
            ),
          )
        ],
      ),
    );
  }

  static Future<void> pop(
      {BuildContext context, Text child, String info}) async {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) => DismissiblePopupDialog(child: child, info: info));
  }
}
