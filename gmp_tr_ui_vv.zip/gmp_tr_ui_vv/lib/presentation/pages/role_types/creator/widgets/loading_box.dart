import 'package:flutter/material.dart';

class LoadingBox extends StatelessWidget {
  final double width;
  final double height;

  const LoadingBox({Key key, this.width = double.infinity, this.height = 500})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      alignment: Alignment.center,
      child: CircularProgressIndicator(),
    );
  }
}
