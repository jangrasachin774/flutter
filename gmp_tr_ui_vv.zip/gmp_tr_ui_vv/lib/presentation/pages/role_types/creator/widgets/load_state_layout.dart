import 'package:flutter/material.dart';

///四种视图状态
enum LoadState { StateSuccess, StateError, StateLoading, StateEmpty }

///根据不同状态来展示不同的视图
class LoadStateLayout<T> extends StatefulWidget {
  final Future<T> Function() loadData;
  final Widget Function(BuildContext context, LoadState state, T data) builder;

  LoadStateLayout({Key key, this.loadData, this.builder}) : super(key: key);

  @override
  _LoadStateLayoutState<T> createState() => _LoadStateLayoutState<T>();
}

class _LoadStateLayoutState<T> extends State<LoadStateLayout<T>> {
  T data;
  LoadState state = LoadState.StateLoading;

  void changeTo(LoadState newState) {
    setState(() => state = newState);
  }

  @override
  void initState() {
    super.initState();
    widget.loadData()
      ..then((val) {
        if (val == null) {
          changeTo(LoadState.StateEmpty);
        } else {
          data = val;
          changeTo(LoadState.StateSuccess);
        }
      })
      ..onError((error, stackTrace) {
        changeTo(LoadState.StateError);
        return null;
      });
  }

  @override
  Widget build(BuildContext context) {
    return widget.builder(context, state, data);
  }
}
