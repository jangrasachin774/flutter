import 'package:flutter/material.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class CreatorApproveLeaveDialog extends StatefulWidget {
  /// true: approve
  /// false: deny
  final bool isApprove;
  final int recordId;

  const CreatorApproveLeaveDialog(this.isApprove, this.recordId, {Key key})
      : super(key: key);

  @override
  _CreatorApproveLeaveDialogState createState() =>
      _CreatorApproveLeaveDialogState();
}

class _CreatorApproveLeaveDialogState extends State<CreatorApproveLeaveDialog> {
  final commentInputController = TextEditingController();
  final int maxLines = 5;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(25, 60, 25, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                Translate.of(context)
                    .translate(widget.isApprove ? "approve" : "deny"),
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlueAccent),
              ),
              const SizedBox(height: 20),
              Container(
                width: 350,
                height: maxLines * 24.0,
                child: TextField(
                  maxLines: maxLines,
                  controller: commentInputController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: Translate.of(context).translate("comment"),
                      contentPadding: const EdgeInsets.all(20)),
                  onChanged: (val) => setState(() {}),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: 350,
                height: 45,
                child: ElevatedButton(
                    onPressed: () => _submit(context),
                    child: Text(Translate.of(context).translate("submit"))),
              )
            ],
          ),
        ),
        Positioned(
          right: 0,
          child: IconButton(
              onPressed: () => _close(context),
              icon: Icon(Icons.close_outlined, size: 20)),
        )
      ]),
    );
  }

  _close(BuildContext context) {
    Navigator.of(context).pop();
  }

  Future<void> _submit(BuildContext context) async {
    Api.approveLeave(
      widget.recordId,
      widget.isApprove,
      commentInputController.text,
      Application.user.id,
    ).then((value) {
      Navigator.of(context).pop();
    });
  }
}
