import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_document.dart';

import 'package:gmptr/presentation/pages/role_types/creator/widgets/input_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/selection_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/uploaded_files_table.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class UpdateDocument extends StatefulWidget {
  final DocumentsModel document;
  UpdateDocument({Key key, this.document}) : super(key: key);

  @override
  _UpdateDocumentState createState() => _UpdateDocumentState();
}

class _UpdateDocumentState extends State<UpdateDocument> {
  final trainingTypeSelection = SelectionBoxController();
  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final departmentSelection = DynamicSelectionBoxController();
  List<DocumentFiles> selectedDocuments = [];
  int departmentIdFk;
  int smallLeaderIdFk;
  int trainingTypeIdFk;
  int traininTypeIdFk;
  int documentFeatureIdFk;

  List<DocumentTests> selectedDocumentTest = [];
  final List<SingleDocumentTestController> testControllers = [];
  final List<PlatformFile> choseDocuments = [];

  final int smallLeaderRoleId = 3;

  @override
  void initState() {
    super.initState();
    // AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.userRoleDocTypesBloc.add(OnLoadUserRoleDocTypes());
    AppBloc.userRoleTrainingTypes.add(OnLoadUserRoleTrainingTypes());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentsBloc.add(OnLoadDocuments(documentId: widget.document.id));

    AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: widget.document.departmentIdFk, roleId: smallLeaderRoleId));
  }

  @protected
  @mustCallSuper
  void didChangeDependencies() {
    setState(() {
      AppBloc.documentsBloc.add(OnLoadDocuments(documentId: widget.document.id));
      documentTitleController.text = widget.document.title;
      documentDescriptionController.text = widget.document.description;
      departmentIdFk = widget.document.departmentIdFk;
      traininTypeIdFk = widget.document.trainingTypeIdFk;
      documentFeatureIdFk = widget.document.documentTypeIdFk;
      smallLeaderIdFk = widget.document.smallLeaderIdFk;
      selectedDocuments = widget.document.documentFiles;
      // selectedDocumentTest = widget.document.documentTests;
      widget.document.documentTests.forEach(
        (e) => testControllers.add(
          new SingleDocumentTestController(
            doRemove: onDelete,
            correctAnswers: e.rightAnswers,
            questionInputController: TextEditingController(text: e.question),
            selectedAnswers: e.totalAnswers,
            documentIdFk: widget.document.id,
            documentTestIdFk: e.id,
          ),
        ),
      );
    });

    super.didChangeDependencies();
  }

  void onDelete(int index) => setState(() {
        testControllers.removeAt(index);
      });

  Future<void> doUpdate() async {
    // check if all test been confirmed.
    for (var controller in testControllers) {
      if (controller.onFocus) {
        // try save test controller changes
        if (controller.changeFocus(context)) {
          setState(() {});
        } else {
          // save failed. suspend create document
          return;
        }
      }
    }

    // check document title
    if (documentTitleController.text == null || documentTitleController.text.isEmpty) {
      SnackBarUtil.warn(context, "document title empty");
      return;
    }

    // check description
    if (documentDescriptionController.text == null || documentDescriptionController.text.isEmpty) {
      SnackBarUtil.warn(context, "document description empty");
      return;
    }

    // check training type
    if (traininTypeIdFk == null) {
      SnackBarUtil.warn(context, "training type not select");
      return;
    }

    // check document feature
    if (documentFeatureIdFk == null) {
      SnackBarUtil.warn(context, "document feature not select");
      return;
    }

    // check department id
    if (departmentIdFk == null) {
      SnackBarUtil.warn(context, "department not select");
      return;
    }

    // check small leader id
    if (smallLeaderIdFk == null) {
      SnackBarUtil.warn(context, "small leader not select");
      return;
    }

    String title = documentTitleController.text;
    String description = documentDescriptionController.text;

    int creatorIdFk = Application.user.id;

    final document = DocumentModel.create(
      title: title,
      description: description,
      trainingTypeIdFk: trainingTypeIdFk ?? widget.document.trainingTypeIdFk,
      documentTypeIdFk: documentFeatureIdFk ?? widget.document.documentTypeIdFk,
      creatorIdFk: creatorIdFk,
      smallLeaderIdFk: smallLeaderIdFk ?? widget.document.smallLeaderIdFk,
      departmentIdFk: departmentIdFk ?? widget.document.departmentIdFk,
    );
    try {
      // do update document
      await Api.updateDocument(document, widget.document.id);

      // do update exists document tests
      testControllers.forEach((e) {
        if (e.documentTestIdFk != null) {
          Api.updateDocumentTest(
            e.genUpdateDocumentTest(widget.document.id),
          );
        } else {
          Api.createDocumentTest(
            e.genUpdateDocumentTest(widget.document.id),
          );
        }
      });

      reloadPage();

      // do upload files
      Api.uploadDocumentFiles(widget.document.id, choseDocuments);

      SnackBarUtil.info(context, "updated document success.");
    } catch (e) {
      SnackBarUtil.info(context, e);
    }
  }

  reloadPage() {
    print("reload");
    return AppBloc.documentsBloc.add(OnLoadDocuments(documentId: widget.document.id));
  }

  void doCancel() {}

  Future<void> uploadFile() async {
    if (widget.document.documentFiles.isNotEmpty || widget.document.documentFiles == []) {
      widget.document.documentFiles.forEach((element) => Api.deleteDocumentFile(element.id));
    }
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;

      DocumentFiles documentFiles = new DocumentFiles.fromJson({
        "id": null,
        "name": file.name,
        "path": ""
      });
      setState(() {
        choseDocuments.add(file);
        selectedDocuments.clear();
        selectedDocuments.add(documentFiles);
      });
      // print(file.name);
      // print(file.bytes);
      // print(file.size);
      // print(file.extension);
      // print(file.path);
    } else {
      // User canceled the picker
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      child: ListView(
        shrinkWrap: true,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(width: 10),
                    AppButton(
                      Translate.of(context).translate('update'),
                      onPressed: () {
                        doUpdate().then((value) => Navigator.of(context).pop());
                      },
                      type: ButtonType.normal,
                      color: Color(0xff787E8C),
                      icon: Icon(Icons.save_outlined),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    IconButton(
                      icon: Icon(Icons.close_outlined),
                      onPressed: () => Navigator.of(context).pop(),
                    )
                  ],
                ),
                // header and two button
                Wrap(
                  runSpacing: 12,
                  spacing: 40,
                  children: [
                    // selection box, choose dept
                    BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                      bloc: BlocProvider.of<DepartmentsListBloc>(context),
                      builder: (context, state) {
                        if (state is DepartmentsSuccess) {
                          return Wrap(
                            children: [
                              SizedBox(
                                width: 162,
                                height: 40,
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate("choose_department"),
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 40,
                                width: 200,
                                child: Container(
                                  alignment: Alignment.center,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 0,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(width: 1, color: Colors.grey),
                                    borderRadius: BorderRadius.circular(2.2),
                                  ),
                                  child: DropdownButton(
                                    value: departmentIdFk,
                                    underline: SizedBox(),
                                    icon: Icon(Icons.keyboard_arrow_down_outlined),
                                    items: state.departments
                                        .map((e) => DropdownMenuItem(
                                              child: Text(e.name, style: TextStyle(fontSize: 12)),
                                              value: e.id,
                                            ))
                                        .toList(),
                                    hint: Text(
                                      Translate.of(context).translate("choose_department"),
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                      ),
                                    ),
                                    onChanged: (int value) {
                                      setState(() {
                                        departmentIdFk = value;
                                        AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: value, roleId: smallLeaderRoleId));
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          );
                        } else if (state is DepartmentsLoading) {
                          return Text("loading");
                        } else {
                          return Text("load department data failed.");
                        }
                      },
                    ),

                    // selection box, choose small leader
                    BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
                      bloc: BlocProvider.of<DepartmentUsersBloc>(context),
                      builder: (context, state) {
                        if (state is DepartmentUsersSuccess) {
                          return Wrap(
                            children: [
                              SizedBox(
                                width: 162,
                                height: 40,
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate("choose_small_leader"),
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 40,
                                width: 200,
                                child: Container(
                                  alignment: Alignment.center,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 0,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(width: 1, color: Colors.grey),
                                    borderRadius: BorderRadius.circular(2.2),
                                  ),
                                  child: DropdownButton(
                                    value: smallLeaderIdFk ?? widget.document.smallLeaderIdFk,
                                    underline: SizedBox(),
                                    icon: Icon(Icons.keyboard_arrow_down_outlined),
                                    items: state.departmentsUser
                                        .map((e) => DropdownMenuItem(
                                              child: Text(e.name, style: TextStyle(fontSize: 12)),
                                              value: e.id,
                                            ))
                                        .toList(),
                                    hint: Text(
                                      Translate.of(context).translate("choose_small_leader"),
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                      ),
                                    ),
                                    onChanged: (int value) {
                                      setState(() {
                                        smallLeaderIdFk = value;
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          );
                        } else if (state is DepartmentUsersLoading) {
                          return LoadingBox(height: 20, width: 20);
                        } else {
                          return SelectionBox(
                            leading: Translate.of(context).translate("choose_small_leader"),
                            items: [],
                            getText: (e) => "",
                            controller: smallLeaderSelection,
                            hint: "Please choose a small leader",
                          );
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // two selection box, train type and document feature
                Wrap(
                  runSpacing: 12,
                  spacing: 40,
                  children: [
                    // selection box of training types
                    BlocBuilder<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                      bloc: BlocProvider.of<UserRoleTrainingTypesListBloc>(context),
                      builder: (context, state) {
                        if (state is UserRoleTrainingTypesSuccess) {
                          return Wrap(
                            children: [
                              SizedBox(
                                width: 162,
                                height: 40,
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate("training_type"),
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 40,
                                width: 200,
                                child: Container(
                                  alignment: Alignment.center,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 0,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(width: 1, color: Colors.grey),
                                    borderRadius: BorderRadius.circular(2.2),
                                  ),
                                  child: DropdownButton(
                                    value: traininTypeIdFk ?? widget.document.trainingTypeIdFk,
                                    underline: SizedBox(),
                                    icon: Icon(Icons.keyboard_arrow_down_outlined),
                                    items: state.userRoleTrainingType
                                        .map((e) => e.trainingType)
                                        .map((e) => DropdownMenuItem(
                                              child: Text(e.name, style: TextStyle(fontSize: 12)),
                                              value: e.id,
                                            ))
                                        .toList(),
                                    hint: Text(
                                      "Please choose a status",
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                      ),
                                    ),
                                    onChanged: (int value) {
                                      setState(() {
                                        traininTypeIdFk = value;
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          );
                        } else if (state is UserRoleTrainingTypesLoading) {
                          return Text("loading");
                        } else {
                          return Text("load trainings type failed.");
                        }
                      },
                    ),

                    // selection box of document feature
                    BlocBuilder<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                      bloc: BlocProvider.of<UserRoleDocTypesListBloc>(context),
                      builder: (context, state) {
                        if (state is UserRoleDocTypesSuccess) {
                          return Wrap(
                            children: [
                              SizedBox(
                                width: 162,
                                height: 40,
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate("document_feature"),
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 40,
                                width: 200,
                                child: Container(
                                  alignment: Alignment.center,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 0,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(width: 1, color: Colors.grey),
                                    borderRadius: BorderRadius.circular(2.2),
                                  ),
                                  child: DropdownButton(
                                    value: documentFeatureIdFk ?? widget.document.trainingTypeIdFk,
                                    underline: SizedBox(),
                                    icon: Icon(Icons.keyboard_arrow_down_outlined),
                                    items: state.userroleDocType
                                        .map((e) => e.documentType)
                                        .map((e) => DropdownMenuItem(
                                              child: Text(e.name, style: TextStyle(fontSize: 12)),
                                              value: e.id,
                                            ))
                                        .toList(),
                                    hint: Text(
                                      Translate.of(context).translate("document_feature"),
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                      ),
                                    ),
                                    onChanged: (int value) {
                                      setState(() {
                                        documentFeatureIdFk = value;
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          );
                        } else if (state is UserRoleDocTypesLoading) {
                          return Text("loading");
                        } else {
                          return Text("load document features failed.");
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // two input box, document title and document description
                Wrap(runSpacing: 12, spacing: 40, children: [
                  InputBox(
                    label: Translate.of(context).translate("document_title"),
                    controller: documentTitleController,
                  ),
                  InputBox(
                    label: Translate.of(context).translate("document_description"),
                    controller: documentDescriptionController,
                  )
                ]),
                const SizedBox(height: 12),

                // button, upload file;
                UploadFileButton(uploadFile),
                const SizedBox(height: 23),

                // data table, files
                UpdateUploadedDocFileTable(selectedDocuments: selectedDocuments),
                const SizedBox(height: 20),

                // tests table
                DocumentTestsTable(controllers: testControllers),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
