import 'dart:async';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/document_detail.dart';
import 'package:gmptr/presentation/pages/role_types/creator/update_document.dart';
import 'package:gmptr/presentation/pages/role_types/creator/update_task.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/heading_text.dart';
import 'package:gmptr/presentation/widgets/app_autocomplete_textfiled.dart';
import 'package:gmptr/presentation/widgets/app_doc_status.dart';
import 'package:gmptr/presentation/widgets/app_task_status.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import '../../../../global.dart';
import 'create_new_document.dart';
import 'create_new_task.dart';
import 'update_task_dialog.dart';
import 'widgets/creator_sign_dialog.dart';
import 'widgets/widgets.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:collection/collection.dart';

class CreatorHomePage extends StatefulWidget {
  const CreatorHomePage({Key key}) : super(key: key);

  @override
  _CreatorHomePageState createState() => _CreatorHomePageState();
}

///DATA TABLE VARIABLE DECLARATION
bool checkedBox = false;
List<int> taskIds = [];
List<int> docIds = [];
List<int> selectedTaskIds = [];
List<int> selectedDocIds = [];
List<Task> paginatedTask = [];
int _rowsPerPage = 10;
List<DocumentsModel> paginatedDocuments = [];

class _CreatorHomePageState extends State<CreatorHomePage> {
  HomeWidgetChange selectedWidgetPage = HomeWidgetChange.taskDocController;

  Task task;
  int taskId;
  DocumentsModel document;
  int taskStatusId;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];

  FocusNode _focus = FocusNode();

  /// CREATE TASK VARIABLES
  bool isRegularTask = false;
  final _dateController = TextEditingController();
  final _textTitleController = TextEditingController();
  final trainingTypeSelection = SelectionBoxController();
  final viewTypeSelection = SelectionBoxController();

  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentVersionController = MyTextEditingController();
  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final studentsSelection = SelectionBoxController();
  final departmentSelection = SelectionBoxController();
  DocumentsModel selectedDocument;
  int departmentIdFk;
  int documentFeatureIdFk;
  int trainingTypeId;
  int viewTypeIdFk;
  int taskTypeView;
  // List<int> taskDocuments = [];
  List<ViewTypeModel> views = [];
  List<ViewTypeModel> documentType = [];

  GlobalKey key = new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
  final List<SingleTaskTestController> testControllers = [];
  List<DocumentTests> selectedDocumentTests = [];

  final List<PlatformFile> choseDocuments = [];

  List<DocumentFiles> selectedDocuments = [];

  List<DocumentTests> selectedDocumentTest = [];

  final int smallLeaderRoleId = 3;

  final int studentsRoleId = 5;

  int documentIdFk;
  String selectedPath;
  String selectedName;
  String selectedIdentifier;
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  int studentIdFk;
  List<String> selectedStudents = [];
  List<int> selectedStudentsIds = [];

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  ///CREATE DOCUMENT VARIABLES
  final List<SingleTestController> doctestControllers = [];
  // List<int> viewType = [];

  @override
  void initState() {
    super.initState();
    AppBloc.tasksDocBloc.add(
      OnLoadTaskDocEvent(viewType: [
        selectedViewTypeCommon
      ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId),
    );
    // print("taskInfo taskDocuments ${task.taskDocuments}");

    // AppBloc.viewTypesBloc.add(OnLoadViewType());
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    // if (taskDocuments.isNotEmpty)
    //   AppBloc.documentsBloc.add(OnLoadDocuments(taskDocuments: taskDocuments));
    // AppBloc.documentsBloc.add(OnLoadDocuments());
    // AppBloc.studentsBloc.add(OnLoadStudents());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
  }

  ///CANCEL DOC
  _cancelDoc(List<int> docIds) async {
    AppBloc.documentsBloc.add(OnUpdateDocumentStatus(docIds: docIds, status: 3));
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      3
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  ///CANCEL TASK
  _cancelTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: context, builder: (context) => CreatorSignDialog(text: "Confirm to Cancel"));

    if (confirm) {
      AppBloc.tasksDocBloc.add(CancelCreatedTask(taskStatusId: 3, taskIds: taskIds));
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  ///SIGN DOC
  _signDoc(List<int> docIds) async {
    bool confirm = await showDialog(context: context, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignDoc(docIds);
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      3
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  ///SIGN TASK
  _signTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: context, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignTask(taskIds);
      AppBloc.tasksDocBloc.add(
        OnLoadTaskDocEvent(viewType: [
          ViewType.regularTask
        ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId),
      );
    }
  }

  ///SWITCH WIDGET
  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case HomeWidgetChange.taskDocController:
        return taskController(context);
      // case HomeWidgetChange.createDoc:
      //   return createDoc(context);
      // case HomeWidgetChange.createTask:
      //   return createTask(context);

      case HomeWidgetChange.taskInfo:
        return taskInfo(context);
      case HomeWidgetChange.docInfo:
        return docInfo(context);

      // case HomeWidgetChange.updateTask:
      //   return updateTask(context);
      case HomeWidgetChange.updateDoc:
        return updateDoc(context);
    }

    return taskController(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == HomeWidgetChange.taskDocController) HeadingText(Translate.of(context).translate("create_by_me_page_heading")),
                  if (selectedWidgetPage == HomeWidgetChange.taskInfo || selectedWidgetPage == HomeWidgetChange.docInfo || selectedWidgetPage == HomeWidgetChange.updateDoc) Container(),
                  Row(
                    children: [
                      if (selectedWidgetPage == HomeWidgetChange.taskDocController)
                        AppButton(
                          Translate.of(context).translate('create_new_document'),
                          onPressed: () => {
                            setState(() {
                              showDialog(context: context, builder: (context) => CreateDocument());
                              // selectedWidgetPage = HomeWidgetChange.createDoc;
                            })
                          },
                          // Navigator.pushNamed(context, Routes.createDocument),
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage == HomeWidgetChange.taskDocController) SizedBox(width: 10),
                      if (selectedWidgetPage == HomeWidgetChange.taskDocController)
                        AppButton(
                          Translate.of(context).translate('create_new_task'),
                          onPressed: () {
                            setState(() {
                              showDialog(context: context, builder: (context) => CreateNewTask());
                              // selectedWidgetPage = HomeWidgetChange.createTask;
                            });
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage == HomeWidgetChange.taskInfo)
                        Tooltip(
                          message: Translate.of(context).translate('close'),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                selectedWidgetPage = HomeWidgetChange.taskDocController;
                              });
                            },
                            child: Icon(
                              Icons.close,
                              color: Color(0xff00A4E3),
                              size: 20,
                            ),
                          ),
                        ),
                      if (selectedWidgetPage == HomeWidgetChange.docInfo)
                        Tooltip(
                          message: Translate.of(context).translate('close'),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                selectedWidgetPage = HomeWidgetChange.taskDocController;
                              });
                            },
                            child: Icon(
                              Icons.close,
                              color: Color(0xff00A4E3),
                              size: 20,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 0),
              Container(child: getCustomContainer(context))
              // TaskTable(tasksController),
            ],
          ),
        ),
      ],
    );
  }

  void onDelete(int index) => setState(() {
        testControllers.removeAt(index);
      });
  Widget createDropdownButton({
    String hint,
    dynamic value,
    List<DropdownMenuItem<dynamic>> items,
    Function(dynamic) onChanged,
  }) {
    return Container(
      height: 36,
      padding: const EdgeInsets.fromLTRB(7, 10, 7, 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black.withOpacity(.06), width: 1),
      ),
      child: DropdownButton(
        hint: Text(
          hint,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
        ),
        // FIXME: 视觉效果上这个icon偏下了
        icon: const Icon(
          Icons.expand_more_outlined,
          color: Colors.blueAccent,
        ),
        elevation: 8,
        underline: Container(color: Colors.white),
        iconSize: 18,
        value: value,
        items: items,
        onChanged: onChanged,
      ),
    );
  }

  Widget taskController(context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BlocBuilder<TaskDocBloc, TaskDocState>(
              bloc: BlocProvider.of<TaskDocBloc>(context),
              buildWhen: (previousState, currentState) {
                return previousState != currentState;
              },
              builder: (ctxt, state) {
                if (state is TaskDocSuccess) {
                  TaskDataSource taskDataSource;
                  DocDataSource docDataSource;
                  taskDataSource = new TaskDataSource(
                    state.tasks,
                    context,
                    taskStatusId,
                  );

                  List<Task> taskCount = state.tasks;
                  List<DocumentsModel> docCount = state.documents;

                  docDataSource = new DocDataSource(
                    state.documents,
                    context,
                    taskStatusId,
                    onChanged: (List<int> x) {
                      setState(() {
                        selectedDocIds = x;
                      });
                    },
                    selectedIds: selectedDocIds,
                  );

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FiltersBox(taskStatusId: taskStatusId, viewType: [
                        selectedViewTypeCommon
                      ]),
                      const SizedBox(height: 10),
                      LayoutBuilder(builder: (context, constraints) {
                        return Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: MediaQuery.of(context).size.height * 0.5,
                                  width: constraints.maxWidth,
                                  child: SfDataGrid(
                                    allowSorting: true,
                                    source: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                                    columnWidthMode: ColumnWidthMode.fill,
                                    footerFrozenColumnsCount: 1,
                                    columns: [
                                      GridColumn(
                                        columnName: 'id',
                                        width: 34,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.center,
                                          child: Checkbox(
                                            value: checkedBox,
                                            onChanged: (value) {
                                              setState(() {
                                                checkedBox = value;
                                                if (value == true) {
                                                  if (taskDataSource.rows.length > 0) {
                                                    state.tasks.forEach((e) {
                                                      if (taskIds.length < taskDataSource.rows.length) {
                                                        taskIds.add(e.id);
                                                      }
                                                    });
                                                  } else {
                                                    state.documents.forEach((e) {
                                                      if (docIds.length < docDataSource.rows.length) {
                                                        docIds.add(e.id);
                                                      }
                                                    });
                                                  }
                                                } else {
                                                  if (taskDataSource.rows.length > 0) {
                                                    taskIds.clear();
                                                  } else {
                                                    docIds.clear();
                                                  }
                                                }
                                              });
                                            },
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'title',
                                        width: 100,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('title'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'description',
                                        width: 200,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('description'),
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'version',
                                        minimumWidth: 150,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('version'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'beginTime',
                                        minimumWidth: 150,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('begin_time'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                          columnName: 'endTime',
                                          minimumWidth: 150,
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('end_time'),
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                softWrap: true,
                                              ))),
                                      GridColumn(
                                        columnName: 'createdDepWorker',
                                        minimumWidth: 150,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('created_dep_worker'),
                                          ),
                                        ),
                                      ),
                                      if (taskDataSource.rows.length > 0)
                                        GridColumn(
                                          columnName: 'students',
                                          minimumWidth: 150,
                                          label: Container(
                                            height: 50,
                                            color: Color(0xffEFF5FC),
                                            padding: EdgeInsets.all(16.0),
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              Translate.of(context).translate('students'),
                                            ),
                                          ),
                                        ),
                                      GridColumn(
                                        columnName: 'filters',
                                        minimumWidth: 200,
                                        label: Container(
                                          height: 26,
                                          constraints: BoxConstraints(maxHeight: 30),
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Colors.black12, width: 1),
                                            borderRadius: BorderRadius.all(Radius.circular(4)),
                                          ),
                                          child: DropdownButton(
                                            onChanged: (val) {
                                              if (val == 1) {
                                                selectedTaskIds.isNotEmpty ? _cancelTask(selectedTaskIds) : null;
                                                selectedDocIds.isNotEmpty ? _cancelDoc(selectedDocIds) : null;
                                              } else if (val == 2) {
                                                selectedTaskIds.isNotEmpty ? _cancelTask(selectedTaskIds) : null;
                                                selectedDocIds.isNotEmpty ? _cancelDoc(selectedDocIds) : null;
                                              }
                                            },
                                            icon: const Icon(Icons.expand_more_outlined),
                                            underline: Container(color: Colors.white),
                                            hint: Text(Translate.of(context).translate("bulk_actions"), style: TextStyle(fontSize: 12)),
                                            items: [
                                              DropdownMenuItem(
                                                value: 1,
                                                child: Text(Translate.of(context).translate('cancel'), style: TextStyle(fontSize: 12)),
                                              ),
                                              DropdownMenuItem(
                                                value: 2,
                                                child: Text(Translate.of(context).translate('sign'), style: TextStyle(fontSize: 12)),
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                    selectionMode: SelectionMode.single,
                                    onSelectionChanged: (addedRows, removedRows) async {
                                      if (taskDataSource.rows.length > 0) {
                                        final index = taskDataSource.rows.indexOf(addedRows.last);
                                        await showDialog(
                                            context: context,
                                            builder: (context) => CreatorTaskInfoWidget(
                                                  taskInfo: paginatedTask[index],
                                                ));
                                        // setState(() {
                                        //   selectedWidgetPage =
                                        //       WidgetChange.taskInfo;
                                        //   task = taskCount[index];
                                        // });
                                      } else {
                                        final index = docDataSource.rows.indexOf(addedRows.first);
                                        print("document >>>> $index");
                                        await showDialog(
                                          context: context,
                                          builder: (context) => DocumentDetailPage(documentInfo: paginatedDocuments[index]),
                                        );
                                        // setState(() {
                                        //   selectedWidgetPage = WidgetChange.docInfo;
                                        //   document = docCount[index];
                                        // });
                                      }
                                    },
                                  ),
                                ),
                                Container(
                                  height: 52,
                                  width: constraints.maxWidth,
                                  child: SfDataPager(
                                    delegate: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                                    availableRowsPerPage: [
                                      10,
                                      20,
                                      30
                                    ],
                                    onRowsPerPageChanged: (int rowsPerPage) {
                                      setState(() {
                                        _rowsPerPage = rowsPerPage;
                                        taskDataSource.updateDataGriDataSource();
                                      });
                                    },
                                    pageCount: taskDataSource.rows.length > 0 ? (taskCount.length / _rowsPerPage).ceilToDouble() : docCount.length / _rowsPerPage,
                                    direction: Axis.horizontal,
                                  ),
                                )
                              ],
                            ),
                          ],
                        );
                      }),
                    ],
                  );
                } else if (state is TaskDocLoading) {
                  return LoadingBox(
                    height: 20,
                  );
                } else if (state is TaskDocEmpty) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FiltersBox(
                        taskStatusId: taskStatusId,
                        viewType: [
                          selectedViewTypeCommon
                        ],
                      ),
                      const SizedBox(height: 20),
                      Center(child: Text("No Records")),
                    ],
                  );
                } else {
                  return Text("load failed.");
                }
              },
            ),
          ],
        ),
      );

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }

  Widget taskInfo(context) {
    return CreatorTaskInfoWidget(taskInfo: task);
  }

  Widget docInfo(context) {
    return DocumentDetailPage(documentInfo: document);
  }

  // Widget updateTask(context) {
  //   return UpdateTask(
  //     task: task,
  //   );
  // }

   Widget createTask(context) {
     return CreateNewTask();
   }

  Widget updateDoc(context) {
    return UpdateDocument(document: document);
  }
}

class TaskDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int taskStatusId;
  Task task;
  List<Task> tasks = [];

  final Completer _completer = new Completer();
  TaskDataSource(List<Task> tasksData, context, int statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    try {
      if (tasks != null) {
        if (tasks.length < _rowsPerPage) {
          paginatedTask = tasks.toList();
        } else {
          paginatedTask = tasks.getRange(0, _rowsPerPage).toList();
          print("paginatedTask >>>> ${paginatedTask.length}");
        }
        buildPaginatedDataGridRows();
      }
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * _rowsPerPage;
    int endIndex = startIndex + _rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    // if (_rowsPerPage == endIndex) {
    //   endIndex = endIndex;
    // }
    // if (_rowsPerPage < endIndex) {
    //   startIndex += 1;
    // }
    if (startIndex < this.tasks.length && endIndex <= this.tasks.length) {
      paginatedTask = List.from(
        this.tasks.getRange(startIndex, endIndex).toList(growable: false),
      );
    } else {
      paginatedTask = [];
    }
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  void updateDataGriDataSource() {
    notifyListeners();
  }

  List<DataGridRow> _tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  _cancelTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: contxt, builder: (context) => CreatorSignDialog(text: "Confirm to Cancel"));

    if (confirm) {
      AppBloc.tasksDocBloc.add(CancelCreatedTask(taskStatusId: 3, taskIds: taskIds));
    }
    AppBloc.tasksDocBloc.add(
      OnLoadTaskDocEvent(viewType: [
        ViewType.regularTask
      ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId),
    );
  }

  _updateTask(Task task) async {
    bool confirm = await showDialog(
        context: contxt,
        builder: (context) => UpdateTaskDialog(
              task: task,
            ));

    if (confirm) {}
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
      viewType: [
        ViewType.regularTask
      ],
      creatorIdFk: Application.user.id,
      taskDocStatusId: taskStatusId,
    ));
    notifyListeners();
  }

  // _viewDoc(Task task) async {
  //   await showDialog(
  //       context: contxt,
  //       builder: (contxt) => CreatorTaskInfoWidget(
  //             taskInfo: task,
  //           ));
  // }

  _signTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: contxt, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignTask(taskIds);
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    notifyListeners();
  }

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell(columnName: 'id', value: e.selected),
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              DataGridCell<String>(columnName: 'version', value: e.taskDocuments.first.document.version),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'beginTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.startDate)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'students',
                value: e.taskStudents.fold<String>("", (previousValue, element) => previousValue + element.taskUser.username + ', '),
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
            alignment: Alignment.center,
            child: showCancelSignButtonWhen.contains(row.getCells()[8].value.taskStatusIdFk)
                ? Checkbox(
                    value: taskIds.contains(row.getCells()[8].value.id),
                    onChanged: (value) {
                      var index;
                      if (value) {
                        selectedTaskIds = taskIds;
                        selectedTaskIds.add(row.getCells()[8].value.id);
                        index = _tasks.indexOf(row);
                      } else {
                        selectedTaskIds = taskIds;
                        index = _tasks.indexOf(row);
                        selectedTaskIds.remove(row.getCells()[8].value.id);
                      }

                      row.getCells()[0] = DataGridCell(value: taskIds.contains(row.getCells()[8].value.id), columnName: 'id');
                      notifyDataSourceListeners(rowColumnIndex: RowColumnIndex(index, 0));
                    })
                : Checkbox(value: false, onChanged: null)),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[1].value.toString(),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[2].value,
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[2].value,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[3].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[3].value.toString(),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[4].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[4].value.toString(),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[5].value,
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[5].value,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[6].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[6].value.toString(),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[7].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[7].value.toString(),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              TaskStatusWidget(taskStatusId: row.getCells()[8].value.taskStatusIdFk),
              SizedBox(width: 10),
              if (showCancelSignButtonWhen.contains(row.getCells()[8].value.taskStatusIdFk))
                Tooltip(
                  message: "Cancel Task",
                  child: InkWell(
                    onTap: () {
                      _cancelTask([
                        row.getCells()[8].value.id
                      ]);
                    },
                    child: Icon(
                      Icons.cancel_presentation,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              if (showCancelSignButtonWhen.contains(row.getCells()[8].value.taskStatusIdFk)) SizedBox(width: 10),
              if (showChangeButtonWhen.contains(row.getCells()[8].value.taskStatusIdFk))
                Tooltip(
                  message: "Edit Task",
                  child: InkWell(
                    autofocus: true,
                    onTap: () {
                      _updateTask(row.getCells()[8].value);
                    },
                    child: Icon(
                      Icons.edit_outlined,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              SizedBox(width: 10),
              if (showChangeButtonWhen.contains(row.getCells()[8].value.taskStatusIdFk))
                Tooltip(
                  message: "Create New Task",
                  child: InkWell(
                    autofocus: true,
                    onTap: () {
                      showDialog(context: contxt, builder: (context) => CreateNewTask());
                    },
                    child: Icon(
                      Icons.post_add_outlined,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              SizedBox(width: 10),
              if (showCancelSignButtonWhen.contains(row.getCells()[8].value.taskStatusIdFk))
                Tooltip(
                  message: "Sign Task",
                  child: InkWell(
                    onTap: () => _signTask([
                      row.getCells()[8].value.id
                    ]),
                    child: Icon(
                      Icons.check_outlined,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              // SizedBox(width: 10),
              // Tooltip(
              //   message: "View Document",
              //   child: InkWell(
              //     onTap: () {
              //       _viewDoc(row.getCells()[8].value);
              //     },
              //     child: Icon(
              //       Icons.info_outline,
              //       color: Color(0xff00A4E3),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ],
    );
  }
}

class DocDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int statusId;
  final Function(List<int>) onChanged;
  Task task;
  final Completer _completer = new Completer();
  DocDataSource(
    List<DocumentsModel> documentsData,
    context,
    int docStatusId, {
    selectedIds,
    this.onChanged,
  }) {
    try {
      documents = documentsData;
      contxt = context;
      statusId = docStatusId;
      docIds = selectedIds;

      if (documents != null) {
        if (documents.length < _rowsPerPage) {
          paginatedDocuments = documents.toList();
        } else {
          paginatedDocuments = documents.getRange(0, _rowsPerPage).toList();
        }
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * _rowsPerPage;
    int endIndex = startIndex + _rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  _cancelDoc(List<int> docIds) async {
    AppBloc.documentsBloc.add(OnUpdateDocumentStatus(docIds: docIds, status: 3));
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.documents
    ], creatorIdFk: Application.user.id, taskDocStatusId: statusId));
  }

  _updateDoc(DocumentsModel document, int statusId) async {
    bool confirm = await showDialog(
        context: contxt,
        builder: (context) => UpdateDocument(
              document: document,
            ));

    if (confirm) {}
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.documents
    ], creatorIdFk: Application.user.id, taskDocStatusId: statusId));
  }

  // _viewDoc(DocumentsModel document, int statusId) async {
  //   showDialog(
  //       context: contxt,
  //       builder: (BuildContext context) =>
  //           DocumentDetailPage(documentInfo: document));
  // }

  _signDoc(List<int> docIds) async {
    bool confirm = await showDialog(context: contxt, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignDoc(docIds);
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.documents
    ], creatorIdFk: Application.user.id, taskDocStatusId: statusId));
  }

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell(columnName: 'id', value: e.selected),
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              DataGridCell<String>(columnName: 'version', value: e.version),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'beginTime', value: ""),
              DataGridCell<String>(columnName: 'endTime', value: ""),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.docCreator.creatorDepartment.name + ", " + e.docCreator.name,
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.center,
          child: showCancelSignButtonWhen.contains(row.getCells()[7].value.status)
              ? Checkbox(
                  value: docIds.contains(row.getCells()[7].value.id),
                  onChanged: (value) {
                    int index = _documents.indexOf(row);
                    if (value) {
                      selectedDocIds = docIds;
                      selectedDocIds.add(row.getCells()[7].value.id);
                    } else {
                      selectedDocIds = docIds;
                      selectedDocIds.remove(row.getCells()[7].value.id);
                    }
                    row.getCells()[0] = DataGridCell(value: docIds.contains(row.getCells()[7].value.id), columnName: 'id');
                    notifyDataSourceListeners(rowColumnIndex: RowColumnIndex(index, 0));
                  },
                )
              : Checkbox(value: false, onChanged: null),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[1].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[2].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[3].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[3].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[6].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[6].value.toString()),
            ),
          ),
        ),
        // Tooltip(
        //   message: row.getCells()[7].value.toString(),
        //   child: Container(
        //     alignment: Alignment.centerLeft,
        //     padding: EdgeInsets.symmetric(horizontal: 16),
        //     child: Text(row.getCells()[7].value.toString()),
        //   ),
        // ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              DocStatusWidget(docStatusId: row.getCells()[7].value.status),
              SizedBox(width: 10),
              if (showCancelSignButtonWhen.contains(row.getCells()[7].value.status))
                Tooltip(
                  message: "Cancel Document",
                  child: InkWell(
                    onTap: () {
                      _cancelDoc([
                        row.getCells()[7].value.id
                      ]);
                    },
                    child: Icon(
                      Icons.cancel_presentation,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              if (showCancelSignButtonWhen.contains(row.getCells()[7].value.status)) SizedBox(width: 10),
              if (showChangeButtonWhen.contains(row.getCells()[7].value.status))
                Tooltip(
                  message: "Edit Document",
                  child: InkWell(
                    autofocus: true,
                    onTap: () {
                      _updateDoc(row.getCells()[7].value, statusId);
                    },
                    child: Icon(
                      Icons.edit_outlined,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              SizedBox(width: 10),
              if (showCancelSignButtonWhen.contains(row.getCells()[7].value.status))
                Tooltip(
                  message: "Sign Document",
                  child: InkWell(
                    onTap: () => _signDoc([
                      row.getCells()[7].value.id
                    ]),
                    child: Icon(
                      Icons.check_outlined,
                      color: Color(0xff00A4E3),
                    ),
                  ),
                ),
              // Tooltip(
              //   message: "View Document",
              //   child: InkWell(
              //     onTap: () {
              //       _viewDoc(row.getCells()[7].value, statusId);
              //     },
              //     child: Icon(
              //       Icons.check_outlined,
              //       color: Color(0xff00A4E3),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ],
    );
  }
}
