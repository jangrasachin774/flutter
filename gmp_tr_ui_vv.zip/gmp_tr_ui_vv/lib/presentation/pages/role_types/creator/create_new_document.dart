import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_document.dart';

import 'package:gmptr/presentation/pages/role_types/creator/widgets/input_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/selection_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/tests_table.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/uploaded_files_table.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

import '../../../../global.dart';
import 'widgets/heading_text.dart';

class CreateDocument extends StatefulWidget {
  final int taskStatusId;
  CreateDocument({Key key, this.taskStatusId}) : super(key: key);

  @override
  _CreateDocumentState createState() => _CreateDocumentState();
}

class _CreateDocumentState extends State<CreateDocument> {
  final trainingTypeSelection = SelectionBoxController();
  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final departmentSelection = SelectionBoxController();
  final viewTypeSelection = SelectionBoxController();
  final documentVersionController = MyTextEditingController();
  List<DocumentTests> selectedDocuments = [];
  List<DocVersionsModel> docVersions = [];

  final List<SingleTestController> testControllers = [];
  final List<PlatformFile> choseDocuments = [];
  int departmentIdFk;
  int trainingTypeId;
  int documentIdFk;
  String docTitle;
  String versionValidation;

  final int smallLeaderRoleId = 3;
  final List<SingleTestController> doctestControllers = [];
  List<int> viewType = [];
  List<ViewTypeModel> views = [];
  List<int> selectedStudentsIds = [];

  int viewTypeIdFk;

  @override
  void initState() {
    super.initState();
    // AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.userRoleDocTypesBloc.add(OnLoadUserRoleDocTypes());
    AppBloc.userRoleTrainingTypes.add(OnLoadUserRoleTrainingTypes());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentVersionsBloc.add(ValidatingDocVersion());
  }

  /// DOCUMENTS METHODS
  Future<void> doSaveDoc() async {
    // check if all test been confirmed.
    for (var controller in testControllers) {
      if (controller.onFocus) {
        // try save test controller changes
        if (controller.changeFocus(context)) {
          setState(() {});
        } else {
          // save failed. suspend create document
          return;
        }
      }
    }

    // check document title
    if (documentTitleController.text == null || documentTitleController.text.isEmpty) {
      SnackBarUtil.warn(context, "document title empty");
      return;
    }
    //check view type selection
    if (viewTypeSelection.value == null) {
      SnackBarUtil.warn(context, "view type not select");
      return;
    }

    // check training type
    if (trainingTypeSelection.value == null) {
      SnackBarUtil.warn(context, "training type not select");
      return;
    }

    // check document feature
    if (documentFeatureSelection.value == null) {
      SnackBarUtil.warn(context, "document feature not select");
      return;
    }

    // check department id
    if (departmentSelection.value == null) {
      SnackBarUtil.warn(context, "department not select");
      return;
    }

    // check small leader id
    if (departmentSelection.value == null) {
      SnackBarUtil.warn(context, "small leader not select");
      return;
    }

    String title = documentTitleController.text;
    String description = documentDescriptionController.text;
    // int fileVersion = int.parse(documentVersionController.text);
    String fileVersion = documentVersionController.text;
    int trainingTypeIdFk = trainingTypeSelection.value.id;
    int documentTypeIdFk = documentFeatureSelection.value.id;
    int viewTypeIdFk = viewTypeSelection.value.id;
    int creatorIdFk = Application.user.id;
    int departmentIdFk = departmentSelection.value.id;
    int smallLeaderIdFk = smallLeaderSelection.value.id;

    final document = DocumentModel.create(
      title: title,
      description: description,
      fileVersion: fileVersion,
      trainingTypeIdFk: trainingTypeIdFk,
      viewTypeIdFk: viewTypeIdFk,
      documentTypeIdFk: documentTypeIdFk,
      creatorIdFk: creatorIdFk,
      smallLeaderIdFk: smallLeaderIdFk,
      departmentIdFk: departmentIdFk,
    );

    // do create document
    var response = await Api.createDocument(document);
    int documentId = response.id;

    // do create document tests
    doctestControllers.forEach((e) => Api.createDocumentTest(e.genDocumentTest(documentId)));

    // do upload files
    await Api.uploadDocumentFiles(documentId, choseDocuments);

    SnackBarUtil.info(context, "create document success.");

    _resetDocFields();
  }

  void _resetDocFields() async {
    setState(() {
      selectedDocuments = [];
      doctestControllers.clear();
      departmentIdFk = null;
      trainingTypeId = null;
      documentIdFk = null;
      departmentSelection.value = null;
      trainingTypeSelection.value = null;
      documentFeatureSelection.value = null;
      smallLeaderSelection.value = null;
      selectedStudentsIds.clear();
    });

    // AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.userRoleDocTypesBloc.add(OnLoadUserRoleDocTypes());
    AppBloc.userRoleTrainingTypes.add(OnLoadUserRoleTrainingTypes());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentsBloc.add(OnLoadDocuments());
    AppBloc.studentsBloc.add(OnLoadStudents());
    documentTitleController.text = "";
    documentDescriptionController.text = "";
  }

  void doCancel() {}

  Future<void> uploadFile() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;
      setState(() => choseDocuments.add(file));
    } else {
      // User canceled the picker
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 0,
      child: ListView(
        shrinkWrap: true,
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    HeadingText(Translate.of(context).translate("create_new_document")),
                    Tooltip(
                      message: Translate.of(context).translate('close'),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            _resetDocFields();
                            Navigator.of(context).pop();
                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
                              selectedViewTypeCommon
                            ], creatorIdFk: Application.user.id, taskDocStatusId: widget.taskStatusId));
                          });
                          viewType = [
                            ViewType.regularTask
                          ];
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.close,
                            color: Color(0xff00A4E3),
                            size: 24,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 30,
                ),
                // header and two button
                Wrap(
                  runSpacing: 12,
                  spacing: 40,
                  children: [
                    // selection box, choose dept
                    BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                      bloc: BlocProvider.of<DepartmentsListBloc>(context),
                      builder: (context, state) {
                        if (state is DepartmentsSuccess) {
                          return SelectionBox<Departments>(
                            leading: Translate.of(context).translate("choose_department"),
                            hint: "choose_department",
                            controller: departmentSelection,
                            items: state.departments,
                            getText: (department) => department.name,
                            onChanged: (value) => AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: value.id, roleId: smallLeaderRoleId)),
                          );
                        } else if (state is DepartmentsLoading) {
                          return LoadingBox(
                            width: 10,
                            height: 10,
                          );
                        } else {
                          return Text("load department data failed.");
                        }
                      },
                    ),

                    // selection box, choose small leader
                    BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
                      bloc: BlocProvider.of<DepartmentUsersBloc>(context),
                      builder: (context, state) {
                        if (state is DepartmentUsersSuccess) {
                          return SelectionBox<ReadUsersByIdModel>(
                            leading: Translate.of(context).translate("choose_small_leader"),
                            hint: "choose small leader",
                            controller: smallLeaderSelection,
                            items: state.departmentsUser,
                            getText: (e) => e.name,
                          );
                        } else if (state is DepartmentUsersLoading) {
                          return LoadingBox(height: 20, width: 20);
                        } else {
                          return SelectionBox(
                            leading: Translate.of(context).translate("choose_small_leader"),
                            items: [],
                            getText: (e) => "",
                            controller: smallLeaderSelection,
                            hint: "Please choose a small leader",
                          );
                        }
                      },
                    ),
                    SizedBox(
                      width: 40,
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // two selection box, train type and document feature
                Wrap(
                  runSpacing: 12,
                  spacing: 40,
                  children: [
                    // selection box of training types
                    BlocBuilder<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                      bloc: BlocProvider.of<UserRoleTrainingTypesListBloc>(context),
                      builder: (context, state) {
                        if (state is UserRoleTrainingTypesSuccess) {
                          return SelectionBox<TrainingType>(
                            leading: Translate.of(context).translate("training_type"),
                            hint: "choose training type",
                            controller: trainingTypeSelection,
                            items: state.userRoleTrainingType.map((e) => e.trainingType).toList(),
                            getText: (e) => e.name,
                          );
                        } else if (state is UserRoleTrainingTypesLoading) {
                          return Text("loading");
                        } else {
                          return Text("");
                        }
                      },
                    ),

                    // selection box of training types
                    BlocBuilder<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                      bloc: BlocProvider.of<UserRoleDocTypesListBloc>(context),
                      builder: (context, state) {
                        if (state is UserRoleDocTypesSuccess) {
                          return SelectionBox<DocumentType>(
                            leading: Translate.of(context).translate("document_feature"),
                            hint: "choose document feature",
                            controller: documentFeatureSelection,
                            items: state.userroleDocType.map((e) => e.documentType).toList(),
                            getText: (e) => e.name,
                          );
                        } else if (state is UserRoleDocTypesLoading) {
                          return Text("loading");
                        } else {
                          return Text("load document features failed.");
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // two input box, document title and document description
                Wrap(
                  runSpacing: 12,
                  spacing: 40,
                  children: [
                    BlocBuilder<ViewTypeListBloc, ViewTypeListState>(
                      bloc: BlocProvider.of<ViewTypeListBloc>(context),
                      builder: (context, state) {
                        if (state is ViewTypeSuccess) {
                          views.clear();
                          if (views.isEmpty) {
                            for (var v in state.views) {
                              if (v.type == "D") {
                                views.add(v);
                              }
                            }
                          }

                          return SelectionBox<ViewTypeModel>(
                              leading: Translate.of(context).translate("view_type"),
                              hint: "choose view type",
                              controller: viewTypeSelection,
                              items: views,
                              getText: (e) => e.name,
                              onChanged: (value) {
                                setState(() {
                                  viewTypeIdFk = value.id;
                                });
                              });
                        } else if (state is ViewTypeLoading) {
                          return LoadingBox(
                            width: 10,
                            height: 10,
                          );
                        } else if (state is ViewTypeFail) {
                          return Text(state.code);
                        } else {
                          return Text("load training types failed.");
                        }
                      },
                    ),
                    InputBox(
                      label: Translate.of(context).translate("document_title"),
                      controller: documentTitleController,
                      onChange: (val) {
                        docTitle = val;
                        AppBloc.documentVersionsBloc.add(ValidatingDocVersion(title: docTitle, viewIdFk: viewTypeIdFk));
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                ///DOCUMENT VERSION
                Wrap(
                  runSpacing: 12,
                  spacing: 40,
                  children: [
                    BlocBuilder<DocumentVersionsBloc, DocumentVersionsState>(
                      bloc: BlocProvider.of<DocumentVersionsBloc>(context),
                      builder: (context, state) {
                        if (state is DocumentVersionFetchSuccess) {
                          String versionGet;
                          for (var version in state.versions) {
                            versionGet = version.version;
                          }
                          return Column(
                            children: [
                              InputBox(
                                label: Translate.of(context).translate("file_version"),
                                controller: documentVersionController,
                                keyBoardType: TextInputType.text,
                                // inputFormatters: <TextInputFormatter>[
                                //   FilteringTextInputFormatter.digitsOnly
                                // ],
                                onChange: (val) {
                                  // int versionInput = int.parse(val);
                                  setState(() {
                                    if (val == versionGet) {
                                      versionValidation = Translate.of(context).translate("version_exist");
                                    } else {
                                      versionValidation = "";
                                    }
                                  });
                                }, // Only numbers can be entered
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 60),
                                child: Text(
                                  versionValidation != null ? versionValidation : "",
                                  style: TextStyle(color: Colors.red, fontSize: 10),
                                ),
                              ),
                            ],
                          );
                        } else {
                          return InputBox(
                            label: Translate.of(context).translate("file_version"),
                            controller: documentVersionController,
                            keyBoardType: TextInputType.text,
                            // inputFormatters: <TextInputFormatter>[
                            //   FilteringTextInputFormatter.digitsOnly
                            // ],
                            onChange: (val) {
                              print(val);
                            }, // Only numbers can be entered
                          );
                        }
                      },
                    ),
                    InputBox(
                      label: Translate.of(context).translate("document_description"),
                      controller: documentDescriptionController,
                    ),
                  ],
                ),
                const SizedBox(height: 23),
                // button, upload file;
                if (viewTypeIdFk == 3) ...[
                  UploadFileButton(uploadFile),
                  SizedBox(height: 23)
                ],
                // data table, files
                if (viewTypeIdFk == 3) ...[
                  UploadedFileTable(choseDocuments),
                  const SizedBox(height: 20),
                ],

                // tests table
                if (viewTypeIdFk == 4) ...[
                  TestsTable(doctestControllers),
                  const SizedBox(height: 30),
                ],
                SizedBox(
                  height: 30,
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    AppButton(
                      Translate.of(context).translate('save'),
                      onPressed: () {
                        doSaveDoc().then((value) => Navigator.of(context).pop());
                        selectedViewTypeCommon = viewTypeSelection.value.id;
                        AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
                          selectedViewTypeCommon
                        ], creatorIdFk: Application.user.id, taskDocStatusId: widget.taskStatusId));
                        setState(() {});
                      },
                      type: ButtonType.normal,
                      color: Color(0xff787E8C),
                      icon: Icon(Icons.save_outlined),
                    ),
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
