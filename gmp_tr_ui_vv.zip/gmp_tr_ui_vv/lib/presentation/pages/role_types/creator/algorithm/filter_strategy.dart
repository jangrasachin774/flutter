import 'package:flutter/material.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filterable.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/date_picker.dart';

enum FilterEnum {
  NONE,
  DocumentFeature,
  TrainingType,
  RoleType,
  Department,
  Worker,
  Result,
  Time,
}

class AfterFilterNotification extends Notification {}

abstract class FilterStrategy {
  dynamic value;

  List<Filterable> doFilter(List<Filterable> source) {
    return source;
  }
}

class FilterByDocumentFeature extends FilterStrategy {
  @override
  List<Filterable> doFilter(List<Filterable> source) {
    return source.where((e) => e.documentFeatureId == value).toList();
  }
}

class FilterByTrainingType extends FilterStrategy {
  @override
  List<Filterable> doFilter(List<Filterable> source) {
    return source.where((e) => e.trainingTypeId == value).toList();
  }
}

class FilterByRoleType extends FilterStrategy {
  @override
  List<Filterable> doFilter(List<Filterable> source) {
    // FIXME: do correct filter
    return source;
  }
}

class FilterByDepartment extends FilterStrategy {
  @override
  List<Filterable> doFilter(List<Filterable> source) {
    // FIXME: can not find department reference in task model.
    return source;
  }
}

class FilterByWorker extends FilterStrategy {
  @override
  List<Filterable> doFilter(List<Filterable> source) {
    // FIXME: can not find worker reference in task model.
    return source;
  }
}

class FilterByResult extends FilterStrategy {
  final Map<String, int> kv = {"Fail": 1, "Pass": 2};

  @override
  List<Filterable> doFilter(List<Filterable> source) {
    // FIXME
    switch (value) {
      // Fail
      case 1:
        break;
      // Pass
      case 2:
        break;
      default:
        return source;
    }
    return source;
  }
}

class FilterByTime extends FilterStrategy {
  final startTimeController = DatePickerController();
  final endTimeController = DatePickerController();

  final Map<String, int> kv = {
    "创建时间": 1,
    "审核时间": 2,
    "审批时间": 3,
    "结束时间": 4,
    "完成时间": 5,
  };

  @override
  List<Filterable> doFilter(List<Filterable> source) {
    DateTime startTime = startTimeController.selectedDate;
    DateTime endTime = endTimeController.selectedDate;

    // FIXME
    switch (value) {
      // Creator Sign Time
      case 1:
        break;
      // Small Leader Sign Time
      case 2:
        break;
      // Big Leader Sign Time
      case 3:
        break;
      // End Time
      case 4:
        break;
      // Finish Time
      case 5:
        break;
      default:
        return source;
    }
    return source;
  }
}

class FilterByNothing extends FilterStrategy {}
