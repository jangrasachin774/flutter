import 'package:flutter/cupertino.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filter_strategy.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filter_strategy_factory.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filterable.dart';

class TaskListController extends ChangeNotifier {
  FilterStrategy strategy =
      FilterStrategyFactory().getStrategy(FilterEnum.NONE);

  bool isTask = true;
  bool isReadOnly = true;
  List<Task> _tasks = [];
  List<DocumentsModel> _documents = [];

  set tasks(list) => _tasks = list;

  set documents(list) => _documents = list;

  List<Filterable> get filtered => _doFilter(isTask ? _tasks : _documents);

  List<Task> get tasks => _doFilter(_tasks);

  List<DocumentsModel> get documents => _doFilter(_documents);

  dynamic _doFilter(List<Filterable> list) {
    try {
      return strategy.doFilter(list);
    } on UnimplementedError catch (e) {
      print(e.message);
      return list;
    }
  }

  void trigger() {
    // 发生筛选器状态变化前清除元素的选中状态，避免因为筛选器的改变而使处于选中中的元素没有显示
    resetSelectionStatus();
    notifyListeners();
  }

  void resetSelectionStatus() => (isTask ? _tasks : _documents)
      .forEach((element) => element.selected = false);

  void fill(List<Task> tasks, List<DocumentsModel> docs) {
    this.tasks = tasks;
    this.documents = docs;
  }
}
