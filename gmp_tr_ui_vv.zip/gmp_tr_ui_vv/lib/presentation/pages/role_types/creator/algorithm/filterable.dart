abstract class Filterable {
  bool selected;
  int get id;
  int get documentFeatureId;
  int get trainingTypeId;
  int get roleTypeId;
  int get departmentId;
  int get workerId;
  int get resultId;

  DateTime get creatorSignTime;
  DateTime get smallLeaderSignTime;
  DateTime get bigLeaderSignTime;
  DateTime get endTime;
  DateTime get finishTime;
}