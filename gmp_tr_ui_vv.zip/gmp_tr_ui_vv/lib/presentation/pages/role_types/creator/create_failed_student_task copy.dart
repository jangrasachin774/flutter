import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/input_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/selection_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/task_tests_table.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/task_uploaded_files_table.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/students_multi_select_dropdown.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class CreateFailedStudTask extends StatefulWidget {
  final TaskStudents studentInfo;
  const CreateFailedStudTask({Key key, this.studentInfo}) : super(key: key);

  @override
  _CreateNewTaskState createState() => _CreateNewTaskState();
}

class _CreateNewTaskState extends State<CreateFailedStudTask> {
  bool isRegularTask = false;
  final _dateController = TextEditingController();
  final _textTitleController = TextEditingController();
  final trainingTypeSelection = SelectionBoxController();
  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final studentsSelection = SelectionBoxController();
  final departmentSelection = SelectionBoxController();
  DocumentsModel selectedDocument;
  int departmentIdFk;
  int documentFeatureIdFk;
  int trainingTypeId;
  GlobalKey key = new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
  final List<SingleTaskTestController> testControllers = [];
  List<DocumentTests> selectedDocumentTests = [];

  final List<PlatformFile> choseDocuments = [];

  List<DocumentFiles> selectedDocuments = [];

  List<DocumentTests> selectedDocumentTest = [];

  final int smallLeaderRoleId = 3;

  final int studentsRoleId = 5;

  bool saveButtonEnabled = false;

  int documentIdFk;
  String selectedPath;
  String selectedName;
  String selectedIdentifier;
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  int studentIdFk;
  List<String> selectedStudents = [];
  List<int> selectedStudentsIds = [];

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  @override
  void initState() {
    super.initState();
    // AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.userRoleDocTypesBloc.add(OnLoadUserRoleDocTypes());
    AppBloc.userRoleTrainingTypes.add(OnLoadUserRoleTrainingTypes());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentsBloc.add(OnLoadDocuments());
    AppBloc.studentsBloc.add(OnLoadStudents());
    if (selectedDocument != null) _textTitleController.text = selectedDocument.title;

    selectedStudentsIds.add(widget.studentInfo.id);
    selectedStudents.add(widget.studentInfo.taskUser.username);
  }

  void _showCalender() {
    showDialog<void>(
        context: context,
        builder: (BuildContext buildContext) {
          return AlertDialog(
            content: Container(
              width: 280,
              height: 400,
              child: SfDateRangePicker(
                onSelectionChanged: _onSelectionChanged,
                selectionMode: DateRangePickerSelectionMode.range,
                enablePastDates: false,
              ),
            ),
            actions: <Widget>[
              AppButton(
                Translate.of(context).translate('ok'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
                type: ButtonType.normal,
              ),
            ],
          );
        });
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    setState(() {
      if (args.value is PickerDateRange) {
        _startDate = formatter.format(args.value.startDate).toString();
        _endDate = formatter.format(args.value.endDate).toString();
        _dateController.text = _startDate + "-" + _endDate;
      } else if (args.value is DateTime) {
        _selectedDate = args.value.toString();
      } else if (args.value is List<DateTime>) {
        _dateCount = args.value.length.toString();
      } else {
        _rangeCount = args.value.length.toString();
      }
    });
  }

  Future<void> doSave() async {
    print("save >>>> ");
    // check if all test been confirmed.
    if (selectedDocuments == null)
      for (var controller in testControllers) {
        if (controller.onFocus) {
          if (controller.changeFocus(context)) {
            setState(() {});
          } else {
            // save failed. suspend create task
            return;
          }
          return;
        }

        if (controller.totalAnswers == [] || controller.correctAnswers == []) {
          return;
        }
      }

    // check task title
    if (documentTitleController.text == null || documentTitleController.text.isEmpty) {
      SnackBarUtil.warn(context, "document title empty");
      return;
    }

    // check training type
    if (trainingTypeSelection.value == null) {
      SnackBarUtil.warn(context, "training type not select");
      return;
    }

    // check document feature
    if (documentFeatureSelection.value == null) {
      SnackBarUtil.warn(context, "document feature not select");
      return;
    }

    // check department id
    if (departmentSelection.value == null) {
      SnackBarUtil.warn(context, "department not select");
      return;
    }

    // check small leader id
    if (smallLeaderSelection.value == null) {
      SnackBarUtil.warn(context, "small leader not select");
      return;
    }

    String title = documentTitleController.text;
    String description = documentDescriptionController.text;
    int trainingTypeIdFk = trainingTypeSelection.value.id;
    int documentTypeIdFk = documentFeatureSelection.value.id;
    int smallLeaderIdFk = smallLeaderSelection.value.id;

    // String selectedQuestion;
    // List<String> selectedTotalAnswers;
    // List<String> selectedCorrectAnswers;
    // List<TaskTestModel> taskTests;
    // int selectedTestId;
    // if (selectedDocuments == [] ||
    //     selectedDocuments.length > 0 ||
    //     selectedDocumentTest.length > 0 ||
    //     selectedDocuments == null ||
    //     selectedDocuments.isEmpty) {
    //   AppBloc.tasksBloc.add(
    //     OnAddTask(
    //       readOnly: isRegularTask,
    //       title: title,
    //       description: description,
    //       trainingTypeIdFk: trainingTypeIdFk,
    //       documentTypeIdFk: documentTypeIdFk,
    //       creatorIdFk: creatorIdFk,
    //       departmentIdFk: departmentIdFk,
    //       smallLeaderIdFk: smallLeaderIdFk,
    //       documentIdFk: documentIdFk,
    //       documentFiles: choseDocuments,
    //       taskTests: taskTests,
    //     ),
    //   );

    //   for (var tests in testControllers) {
    //     selectedQuestion = tests.questionInputController.text;
    //     selectedTotalAnswers = tests.selectedAnswers;
    //     selectedCorrectAnswers = tests.correctAnswers;

    //     AppBloc.tasksBloc.add(
    //       OnAddTask(
    //         selectedQuestion: selectedQuestion,
    //         selectedTotalAnswers: selectedTotalAnswers,
    //         selectedCorrectAnswers: selectedCorrectAnswers,
    //       ),
    //     );
    //   }
    // } else {
    //   for (var tests in selectedDocumentTest) {
    //     selectedQuestion = tests.question;
    //     selectedTotalAnswers = tests.totalAnswers;
    //     selectedCorrectAnswers = tests.rightAnswers;
    //     selectedTestId = tests.id;
    //   }

    //   AppBloc.tasksBloc.add(
    //     OnAddTask(
    //       readOnly: isRegularTask,
    //       title: title,
    //       description: description,
    //       trainingTypeIdFk: trainingTypeIdFk,
    //       documentTypeIdFk: documentTypeIdFk,
    //       creatorIdFk: creatorIdFk,
    //       departmentIdFk: departmentIdFk,
    //       smallLeaderIdFk: smallLeaderIdFk,
    //       documentIdFk: documentIdFk,
    //       documentIdentifier: identifier,
    //       path: path,
    //       name: name,
    //       selectedTestId: selectedTestId,
    //       selectedQuestion: selectedQuestion,
    //       selectedTotalAnswers: selectedTotalAnswers,
    //       selectedCorrectAnswers: selectedCorrectAnswers,
    //     ),
    //   );
    // }
    print(departmentIdFk);
    final task = TaskModel.create(
      isReadonly: isRegularTask,
      departmentIdFk: departmentIdFk,
      title: title,
      description: description,
      trainingTypeIdFk: trainingTypeIdFk,
      documentTypeIdFk: documentTypeIdFk,
      creatorIdFk: Application.user.id,
      smallLeaderIdFk: smallLeaderIdFk,
      startDate: _startDate,
      endDate: _endDate,
      taskStatusIdFk: 1,
    );
    try {
      var response = await Api.createTask(task);
      int taskId = response.id;

      // do create task tests

      testControllers.forEach((e) => Api.createTaskTest(
            e.genTaskTest(taskId),
          ));

      selectedStudentsIds.forEach((element) => Api.saveTaskToUsers(
            taskId,
            element,
          ));

      // do upload new files
      if (choseDocuments.isNotEmpty || choseDocuments.length > 0) {
        await Api.uploadTaskDocumentFiles(taskId, choseDocuments);
      }

      /// DO UPLOAD EXISTS FILES
      if (documentIdFk != null) {
        selectedDocuments.forEach((element) => Api.uploadExistsTaskDocumentFiles(
              taskId,
              element.path,
              element.name,
              documentIdFk,
              selectedIdentifier,
            ));
      }

      SnackBarUtil.info(context, "Create Task Success.");
    } catch (e) {
      SnackBarUtil.error(context, "Some thing went wrong");
    }
    // do create task
  }

  Future<void> uploadFile() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;

      print(choseDocuments);
      DocumentFiles documentFiles = new DocumentFiles.fromJson({
        "id": null,
        "name": file.name,
        "path": ""
      });
      setState(() {
        documentIdFk = null;
        choseDocuments.add(file);
        selectedDocuments.clear();
        selectedDocuments.add(documentFiles);
      });
      // print(file.name);
      // print(file.bytes);
      // print(file.size);
      // print(file.extension);
      // print(file.path);
    } else {
      // User canceled the picker
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      child: SizedBox(
        height: 720,
        child: ListView(
          shrinkWrap: true,
          children: [
            // Stack(
            //   children: [
            //     Container(
            //       height: 120,
            //       alignment: Alignment.centerLeft,
            //       margin: const EdgeInsets.all(15),
            //       child: Text(
            //         "",
            //         style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            //       ),
            //     ),
            //     Positioned(
            //       right: 0,
            //       child: Container(
            //         margin: EdgeInsets.all(12),
            //         child: Row(
            //           children: [
            //             AppButton(
            //               Translate.of(context).translate('save'),
            //               onPressed: () {
            //                 doSave();
            //                 setState(() {
            //                   saveButtonEnabled = true;
            //                 });
            //               },
            //               type: ButtonType.normal,
            //               color: Color(0xff787E8C),
            //               icon: Icon(Icons.save_outlined),
            //               disabled: saveButtonEnabled,
            //             ),
            //             SizedBox(
            //               width: 30,
            //             ),
            //             IconButton(
            //               icon: Icon(Icons.close_outlined),
            //               onPressed: () => Navigator.of(context).pop(),
            //             ),
            //           ],
            //         ),
            //       ),
            //     )
            //   ],
            // ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 12, 12, 25),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      AppButton(
                        Translate.of(context).translate('save'),
                        onPressed: () {
                          doSave();
                          setState(() {
                            saveButtonEnabled = true;
                          });
                        },
                        type: ButtonType.normal,
                        color: Color(0xff787E8C),
                        icon: Icon(Icons.save_outlined),
                        disabled: saveButtonEnabled,
                      ),
                      SizedBox(
                        width: 30,
                      ),
                      IconButton(
                        icon: Icon(Icons.close_outlined),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  // two radio, regular or read only
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 162,
                        height: 40,
                        child: Container(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            Translate.of(context).translate("task_type"),
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                      ),
                      Wrap(
                        runSpacing: 10,
                        spacing: 210,
                        children: [
                          Wrap(
                            runSpacing: 10,
                            spacing: 5,
                            children: [
                              Radio(
                                value: false,
                                groupValue: isRegularTask,
                                onChanged: (newValue) => setState(() => isRegularTask = newValue),
                                activeColor: Colors.lightBlueAccent,
                              ),
                              Text(Translate.of(context).translate("regular_task")),
                              SizedBox(
                                width: 15,
                              ),
                              Radio(
                                value: true,
                                groupValue: isRegularTask,
                                onChanged: (newValue) => setState(() => isRegularTask = newValue),
                                activeColor: Colors.lightBlueAccent,
                              ),
                              Text(Translate.of(context).translate("read_only_task")),
                            ],
                          ),
                          // SizedBox(
                          //   width: 50,
                          // ),
                          // selection box, choose dept
                          BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                            bloc: BlocProvider.of<DepartmentsListBloc>(context),
                            builder: (context, state) {
                              if (state is DepartmentsSuccess) {
                                List<Departments> departments = state.departments;
                                return SelectionBox<Departments>(
                                  leading: Translate.of(context).translate("choose_department"),
                                  hint: Translate.of(context).translate("choose_department"),
                                  controller: departmentSelection,
                                  items: departments,
                                  getText: (department) => department.name,
                                  onChanged: (value) {
                                    setState(() {
                                      departmentIdFk = value.id;
                                      AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: value.id, roleId: smallLeaderRoleId));
                                      AppBloc.studentsBloc.add(OnLoadStudents(departmentIdFk: value.id, roleIdFk: studentsRoleId));
                                    });
                                  },
                                );
                              } else if (state is DepartmentsLoading) {
                                return Text("loading");
                              } else {
                                return Text("load department data failed.");
                              }
                            },
                          ),
                          // AppButton(
                          //   Translate.of(context).translate('save'),
                          //   onPressed: () {
                          //     doSave();
                          //     setState(() {
                          //       saveButtonEnabled = true;
                          //     });
                          //   },
                          //   type: ButtonType.normal,
                          //   color: Color(0xff787E8C),
                          //   icon: Icon(Icons.save_outlined),
                          //   disabled: saveButtonEnabled,
                          // )
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // two selection box, train type and document feature
                  Wrap(
                    runSpacing: 12,
                    spacing: 40,
                    children: [
                      // selection box of training types
                      BlocBuilder<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                        bloc: BlocProvider.of<UserRoleTrainingTypesListBloc>(context),
                        builder: (context, state) {
                          if (state is UserRoleTrainingTypesSuccess) {
                            return SelectionBox<TrainingType>(
                              leading: Translate.of(context).translate("train_type"),
                              hint: Translate.of(context).translate("train_type"),
                              controller: trainingTypeSelection,
                              items: state.userRoleTrainingType.map((e) => e.trainingType).toList(),
                              getText: (e) => e.name,
                              onChanged: (value) {
                                setState(() {
                                  trainingTypeId = value.id;
                                  AppBloc.documentsBloc.add(OnLoadDocuments(trainingTypeIdFk: trainingTypeId, departmentIdFk: departmentIdFk, documentFeature: documentFeatureIdFk));
                                });
                              },
                            );
                          } else if (state is UserRoleTrainingTypesLoading) {
                            return Text("loading");
                          } else {
                            return Text("load trainings type failed.");
                          }
                        },
                      ),

                      // selection box of training types
                      BlocBuilder<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                        bloc: BlocProvider.of<UserRoleDocTypesListBloc>(context),
                        builder: (context, state) {
                          if (state is UserRoleDocTypesSuccess) {
                            return SelectionBox<DocumentType>(
                              leading: Translate.of(context).translate("document_feature"),
                              hint: Translate.of(context).translate("document_feature"),
                              controller: documentFeatureSelection,
                              items: state.userroleDocType.map((e) => e.documentType).toList(),
                              getText: (e) => e.name,
                              onChanged: (value) {
                                setState(() {
                                  documentFeatureIdFk = value.id;
                                  AppBloc.documentsBloc.add(OnLoadDocuments(trainingTypeIdFk: trainingTypeId, departmentIdFk: departmentIdFk, documentFeature: documentFeatureIdFk));
                                });
                              },
                            );
                          } else if (state is UserRoleDocTypesLoading) {
                            return Text("loading");
                          } else {
                            return Text("load document features failed.");
                          }
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // two input box, document title and document description
                  Wrap(
                    runSpacing: 12,
                    spacing: 40,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: 162,
                            height: 40,
                            child: Container(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate("document_title"),
                                style: TextStyle(fontSize: 14),
                              ),
                            ),
                          ),
                          BlocBuilder<DocumentsBloc, DocumentsState>(
                            bloc: BlocProvider.of<DocumentsBloc>(context),
                            builder: (context, documentsList) {
                              if (documentsList is DocumentsLoading) {
                                return Container(
                                  child: LoadingBox(
                                    height: 30,
                                  ),
                                );
                              } else if (documentsList is DocumentsSuccess) {
                                return Container(
                                  width: 200,
                                  height: 38,
                                  child: CustomAutoCompleteTextField<DocumentsModel>(
                                    controller: documentTitleController,
                                    suggestions: documentsList.documents,
                                    key: key,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                    ),
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(3)),
                                        borderSide: BorderSide(color: Colors.red, width: 1.0),
                                      ),
                                      contentPadding: EdgeInsets.fromLTRB(10, 4, 10, 4),
                                      hintText: Translate.of(context).translate("document_title"),
                                      hintStyle: TextStyle(color: Colors.black),
                                    ),
                                    itemBuilder: (context, query) {
                                      return new Padding(
                                          child: new ListTile(
                                            title: new Text(query.title),
                                          ),
                                          padding: EdgeInsets.all(2.0));
                                    },
                                    textChanged: (text) {
                                      print(text);
                                    },
                                    itemSorter: (a, b) => a.title.compareTo(b.title),
                                    itemFilter: (suggestion, input) => suggestion.title.toLowerCase().startsWith(input.toLowerCase()),
                                    itemSubmitted: (item) {
                                      setState(
                                        () {
                                          selectedDocument = item;
                                          documentTitleController.text = item.title;
                                          documentIdFk = item.id;
                                          selectedIdentifier = item.identifier;
                                          selectedName = item.documentFiles[0].name;
                                          selectedPath = item.documentFiles[0].path;
                                          selectedDocuments = item.documentFiles;
                                          selectedDocumentTest = item.documentTests;
                                          var documentTestIdFk = item.documentTests.first.id;
                                          item.documentTests.forEach(
                                            (e) => testControllers.add(
                                              new SingleTaskTestController(doRemove: onDelete, correctAnswers: e.rightAnswers, questionInputController: TextEditingController(text: e.question), selectedAnswers: e.totalAnswers, documentIdFk: documentIdFk, documentTestIdFk: documentTestIdFk),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                    clearOnSubmit: false,
                                  ),
                                );
                              } else {
                                return Container();
                              }
                            },
                          ),
                        ],
                      ),
                      InputBox(
                        label: Translate.of(context).translate("document_description"),
                        controller: documentDescriptionController,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // button, upload file;

                  UploadTaskFileButton(uploadFile),
                  const SizedBox(height: 23),

                  // data table, files

                  UploadedTaskFileTable(selectedDocuments: selectedDocuments),
                  const SizedBox(height: 20),

                  // tests table
                  TaskTestsTable(controllers: testControllers),
                  const SizedBox(height: 30),

                  // selection box, choose small leader
                  Wrap(
                    runSpacing: 12,
                    spacing: 20,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Translate.of(context).translate("choose_small_leader"),
                            style: TextStyle(fontSize: 12),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
                            bloc: BlocProvider.of<DepartmentUsersBloc>(context),
                            builder: (context, state) {
                              if (state is DepartmentUsersSuccess) {
                                return SelectionBox<ReadUsersByIdModel>(
                                  items: state.departmentsUser,
                                  getText: (e) => e.name,
                                  controller: smallLeaderSelection,
                                  hint: Translate.of(context).translate("choose_small_leader"),
                                );
                              } else if (state is DepartmentUsersLoading) {
                                return LoadingBox(height: 20, width: 20);
                              } else {
                                return SelectionBox(
                                  items: [],
                                  getText: (e) => "",
                                  controller: smallLeaderSelection,
                                  hint: Translate.of(context).translate("choose_small_leader"),
                                );
                              }
                            },
                          ),
                        ],
                      ),
                      // selection box, choose STUDENT
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Translate.of(context).translate("choose_student"),
                            style: TextStyle(fontSize: 12),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          SizedBox(
                            width: 162,
                            height: 40,
                            child: StudentsDropDownMultiSelect(
                                onChanged: (List<String> names, List<int> ids) {
                                  print(selectedStudentsIds);
                                  setState(() {
                                    selectedStudents = names;
                                    selectedStudentsIds = ids;
                                  });
                                },
                                selectedValues: selectedStudents,
                                selectedIds: selectedStudentsIds,
                                whenEmpty: Translate.of(context).translate("choose_student"),
                                departmentIdFk: departmentIdFk,
                                studentsRoleId: studentsRoleId),
                          ),
                          // BlocBuilder<StudentsBloc, StudentsState>(
                          //   bloc: BlocProvider.of<StudentsBloc>(context),
                          //   builder: (context, state) {
                          //     if (state is StudentsSuccess) {
                          //       // return SelectionBox<ReadUsersByIdModel>(
                          //       //   items: state.students,
                          //       //   getText: (e) => e.name,
                          //       //   controller: studentsSelection,
                          //       //   hint: Translate.of(context)
                          //       //       .translate("choose_student"),
                          //       //   onChanged: (value) {
                          //       //     setState(() {
                          //       //       studentIdFk = value.id;
                          //       //     });
                          //       //   },
                          //       // );
                          //       return SizedBox(
                          //         width: 162,
                          //         height: 40,
                          //         child: StudentsDropDownMultiSelect(
                          //             onChanged: (List<String> x) {
                          //               setState(() {
                          //                 selectedStudents = x;
                          //               });
                          //             },
                          //             selectedValues: selectedStudents,
                          //             whenEmpty: 'Select Students',
                          //             departmentIdFk: departmentIdFk,
                          //             studentsRoleId: studentsRoleId),
                          //       );
                          //     } else if (state is StudentsLoading) {
                          //       return LoadingBox(height: 20, width: 20);
                          //     } else {
                          //       return SelectionBox(
                          //         items: [],
                          //         getText: (e) => "",
                          //         controller: studentsSelection,
                          //         hint: Translate.of(context)
                          //             .translate("choose_student"),
                          //       );
                          //     }
                          //   },
                          // ),
                        ],
                      ),
                      Container(
                        width: 400,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Translate.of(context).translate("choose_duration"),
                              style: TextStyle(fontSize: 12),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Container(
                              width: 300,
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _showCalender();
                                  });
                                },
                                child: AbsorbPointer(
                                  child: AppTextInput(
                                    controller: _dateController,
                                    hintText: Translate.of(context).translate("from_to_date"),
                                    keyboardType: TextInputType.datetime,
                                    icon: Icon(
                                      Icons.calendar_today_outlined,
                                      color: Colors.blue,
                                      size: 13,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  void onDelete(int index) => setState(() {
        testControllers.removeAt(index);
      });
}
