import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/tasks/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'student_take_test_page.dart';
import 'student_task_detail_page.dart';
import 'widgets/bottom_filters_box.dart';
import 'widgets/filters_box.dart';
import 'widgets/key_value_text_horizontal.dart';
import 'widgets/key_value_text_vertical.dart';

class SignedBySLDashboardPage extends StatefulWidget {
  const SignedBySLDashboardPage({Key key}) : super(key: key);

  @override
  _SignedBySLDashboardPageState createState() => _SignedBySLDashboardPageState();
}

List<int> selectedTaskIds = [];
List<Task> paginatedTask = [];
final int rowsPerPage = 10;

class _SignedBySLDashboardPageState extends State<SignedBySLDashboardPage> {
  StudentsWidgets selectedWidgetPage = StudentsWidgets.dashboard;
  Task task;
  List<DocumentTests> tests;
  int taskStatusId = 4;
  @override
  void initState() {
    super.initState();
    AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
      ViewType.regularTask
    ], studentIdFk: Application.user.id, taskStatusId: taskStatusId));
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case StudentsWidgets.dashboard:
        return dashboardController(context);
      case StudentsWidgets.openTest:
        return openTest(context);
      case StudentsWidgets.taskDetails:
        return taskDetails(context);
    }

    return dashboardController(context);
  }

  @override
  Widget build(BuildContext context) {
    return ResponsiveBuilder(
        refinedBreakpoints: RefinedBreakpoints(),
        builder: (context, sizingInformation) {
          double screenWidth = sizingInformation.screenSize.width;
          //Desktop
          if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
            return ListView(
              shrinkWrap: true,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // heading text and two button, create new document/task
                      Container(
                        width: double.infinity,
                        child: Wrap(
                          runSpacing: 10,
                          alignment: WrapAlignment.spaceBetween,
                          children: [
                            if (selectedWidgetPage == StudentsWidgets.dashboard) HeadingText(Translate.of(context).translate("signed_by_small_leader")),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails) HeadingText(Translate.of(context).translate("company_policy_training")),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails)
                              Tooltip(
                                message: Translate.of(context).translate('close'),
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      selectedWidgetPage = StudentsWidgets.dashboard;
                                      AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
                                        ViewType.regularTask
                                      ], studentIdFk: Application.user.id, taskStatusId: taskStatusId));
                                    });
                                  },
                                  child: Icon(
                                    Icons.close,
                                    color: Color(0xff00A4E3),
                                    size: 20,
                                  ),
                                ),
                              ),
                            Container(
                              child: getCustomContainer(context),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          } else {
            return ListView(
              shrinkWrap: true,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          if (selectedWidgetPage == StudentsWidgets.dashboard) HeadingText(Translate.of(context).translate("signed_by_small_leader")),
                          if (selectedWidgetPage == StudentsWidgets.taskDetails) Container(),
                          if (selectedWidgetPage == StudentsWidgets.dashboard)
                            Row(
                              children: [
                                AppButton(
                                  Translate.of(context).translate('filter'),
                                  onPressed: () {
                                    showModalBottomSheet<void>(
                                      shape: RoundedRectangleBorder(
                                        //setting a new shape
                                        borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(0),
                                        ),
                                      ),
                                      isScrollControlled: true,
                                      backgroundColor: Colors.white,
                                      context: context,
                                      builder: (BuildContext context) {
                                        return FractionallySizedBox(
                                          heightFactor: 0.8,
                                          child: BottomSheetFilters(taskStatusId: taskStatusId),
                                        );
                                      },
                                    );
                                  },
                                  type: ButtonType.outline,
                                  color: Color(0xff787E8C),
                                  icon: Icon(
                                    Icons.filter_alt,
                                  ),
                                ),
                              ],
                            ),
                          if (selectedWidgetPage == StudentsWidgets.taskDetails)
                            Tooltip(
                              message: Translate.of(context).translate('close'),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    selectedWidgetPage = StudentsWidgets.dashboard;
                                    AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
                                      ViewType.regularTask
                                    ], studentIdFk: Application.user.id, taskStatusId: taskStatusId));
                                  });
                                },
                                child: Icon(
                                  Icons.close,
                                  color: Color(0xff00A4E3),
                                  size: 20,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Container(
                        child: getCustomContainer(context),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }
        });
  }

  Widget dashboardController(context) {
    return ResponsiveBuilder(
        refinedBreakpoints: RefinedBreakpoints(),
        builder: (context, sizingInformation) {
          double screenWidth = sizingInformation.screenSize.width;
          //Desktop
          if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
            return Column(
              children: [
                StudentsFiltersBox(taskStatusId: taskStatusId),
                const SizedBox(height: 20),
                BlocBuilder<TasksListBloc, TasksListState>(
                  bloc: BlocProvider.of<TasksListBloc>(context),
                  builder: (context, state) {
                    if (state is TasksSuccess) {
                      TaskDataSource taskDataSource;
                      taskDataSource = new TaskDataSource(
                        state.tasks,
                        context,
                        taskStatusId,
                      );

                      List<Task> taskCount = state.tasks;

                      return LayoutBuilder(builder: (context, constraints) {
                        return Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: MediaQuery.of(context).size.height * 0.5,
                                  width: constraints.maxWidth,
                                  child: SfDataGrid(
                                    allowSorting: true,
                                    source: taskDataSource,
                                    columnWidthMode: ColumnWidthMode.fill,
                                    columns: [
                                      GridColumn(
                                        columnName: 'title',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('title'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'description',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('description'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'createdAt',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('created_time'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'beginTime',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('begin_time'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                          columnName: 'endTime',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('end_time'),
                                              ))),
                                      GridColumn(
                                        columnName: 'createdDepWorker',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('created_dep_worker'),
                                          ),
                                        ),
                                      ),
                                    ],
                                    selectionMode: SelectionMode.single,
                                    onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                      if (taskDataSource.rows.length > 0) {
                                        final index = taskDataSource.rows.indexOf(addedRows.last);
                                        print("task >>> $index");
                                      }
                                      return true;
                                    },
                                    onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                      if (taskDataSource.rows.length > 0) {
                                        final index = taskDataSource.rows.indexOf(addedRows.last);
                                        setState(() {
                                          selectedWidgetPage = StudentsWidgets.taskDetails;
                                          task = taskCount[index];
                                        });
                                      }
                                    },
                                  ),
                                ),
                                Container(
                                  height: 51,
                                  width: constraints.maxWidth,
                                  child: SfDataPager(
                                    delegate: taskDataSource,
                                    pageCount: (taskCount.length / rowsPerPage).ceilToDouble(),
                                    direction: Axis.horizontal,
                                  ),
                                )
                              ],
                            ),
                          ],
                        );
                      });
                    } else if (state is TasksLoading) {
                      return LoadingBox(
                        height: 20,
                      );
                    } else if (state is TasksEmpty) {
                      return Center(child: Text("No Records"));
                    } else {
                      return Text("load failed.");
                    }
                  },
                ),
              ],
            );
          } else {
            return BlocBuilder<TasksListBloc, TasksListState>(
                bloc: BlocProvider.of<TasksListBloc>(context),
                builder: (context, state) {
                  if (state is TasksSuccess) {
                    return ListView.builder(
                        shrinkWrap: true,
                        itemCount: state.tasks.length,
                        itemBuilder: (BuildContext context, index) {
                          return Container(
                            padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                            margin: EdgeInsets.only(bottom: 12),
                            decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xFFD1D1D1))),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                KeyValueTextHorizontal(field: Translate.of(context).translate('title'), value: state.tasks[index].title),
                                SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    KeyValueTextVertical(field: Translate.of(context).translate("created_time"), value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(state.tasks[index].createdAt)).toString()),
                                    KeyValueTextVertical(field: Translate.of(context).translate("begin_time"), value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(state.tasks[index].endDate)).toString()),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    KeyValueTextVertical(field: Translate.of(context).translate("created_dep_worker"), value: state.tasks[index].taskCreator.department.name + ", " + state.tasks[index].taskCreator.name),
                                    KeyValueTextVertical(field: Translate.of(context).translate("finish_dep_worker"), value: state.tasks[index].dept.name),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                KeyValueTextHorizontal(field: Translate.of(context).translate('description'), value: state.tasks[index].description),
                                SizedBox(
                                  height: 15,
                                ),
                                AppButton(
                                  Translate.of(context).translate('view_details'),
                                  onPressed: () {
                                    setState(() {
                                      selectedWidgetPage = StudentsWidgets.taskDetails;
                                      task = state.tasks[index];
                                    });
                                  },
                                  type: ButtonType.normal,
                                  color: Color(0xff787E8C),
                                ),
                              ],
                            ),
                          );
                        });
                  } else if (state is TasksLoading) {
                    return LoadingBox(
                      height: 20,
                    );
                  } else if (state is TasksEmpty) {
                    return Center(child: Text("No Records"));
                  } else {
                    return Text("load failed.");
                  }
                });
          }
        });
  }

  Widget openTest(context) {
    return StudentTakeTestPage(tests: tests);
  }

  Widget taskDetails(context) {
    return StudentTaskDetailPage(task);
  }
}

class TaskDataSource extends DataGridSource {
  BuildContext contxt;
  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  TaskDataSource(List<Task> tasksData, context, int statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    try {
      if (tasks.length < rowsPerPage) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'training_type', value: e.taskTrainingType.name),
              DataGridCell<String>(columnName: 'createdAt', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.createdAt)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'finish_dep_worker',
                value: e.dept.name,
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[0].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[1].value),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[2].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[3].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[4].value),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[5].value.toString(),
            ),
          ),
        ),
      ],
    );
  }
}
