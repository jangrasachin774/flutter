import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

class KeyValueTextVertical extends StatelessWidget {
  final String field;

  final String value;
  KeyValueTextVertical({Key key, this.field, this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 148,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              width: 130,
              child: AutoSizeText(
                field,
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                maxLines: 1,
              )),
          SizedBox(
            width: 130,
            child: AutoSizeText(
              value,
              style: TextStyle(fontSize: 12),
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }
}
