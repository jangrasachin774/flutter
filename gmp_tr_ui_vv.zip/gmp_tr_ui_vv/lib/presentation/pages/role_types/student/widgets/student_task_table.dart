import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:gmptr/models/model_tasks.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/task_list_controller.dart';
import 'package:gmptr/utils/utils.dart';

/// for creator dashboard
class StudentTaskTable extends StatefulWidget {
  final TaskListController controller;

  const StudentTaskTable(this.controller, {Key key}) : super(key: key);

  @override
  _StudentTaskTableState createState() => _StudentTaskTableState();
}

class _StudentTaskTableState extends State<StudentTaskTable> {
  VoidCallback listener;

  @override
  void initState() {
    super.initState();
    listener = () => setState(() {});
    widget.controller.addListener(listener);
  }

  @override
  void dispose() {
    widget.controller.removeListener(listener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        child: buildDataTable(context, buildDataRow(widget.controller.tasks)));
  }

  Widget buildDataTable(BuildContext context, List<DataRow> rows) {
    // makes DataTable full width
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: BoxConstraints(minWidth: constraints.minWidth),
          child: DataTable(
            headingRowHeight: 50,
            columnSpacing: 25,
            decoration: BoxDecoration(
              border: Border.all(width: 1, color: Color(0xffD4E5F9)),
            ),
            headingRowColor: MaterialStateColor.resolveWith(
              (states) => Color(0xffEFF5FC),
            ),
            headingTextStyle: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
            columns: buildTasksTableHeader(context),
            rows: rows,
          ),
        ),
      ),
    );
  }

  dynamic buildTasksTableHeader(BuildContext context) {
    return <DataColumn>[
      DataColumn(
        label: Text(
          Translate.of(context).translate('s_no'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('training_type'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('created_time'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('end_time'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('created_dep_worker'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('finish_dep_worker'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('title'),
        ),
      ),
      DataColumn(label: Container()),
    ];
  }

  List<DataRow> buildDataRow(List<Task> tasks) {
    return tasks
        .map((e) => DataRow(
              color: MaterialStateProperty.resolveWith<Color>(
                  (Set<MaterialState> states) => states
                          .contains(MaterialState.selected)
                      ? Theme.of(context).colorScheme.primary.withOpacity(0.08)
                      : null),
              selected: e.selected,
              onSelectChanged: (bool value) =>
                  setState(() => e.selected = value),
              cells: [
                // DataCell(Text(e.id.toString())),
                // DataCell(Text(e.trainingType.name)),
                // DataCell(Text(e.startDate)),
                // DataCell(Text(e.endDate)),
                // DataCell(Text(
                //     "${e.creators?.department?.name}, ${e.creators?.username}")),
                // DataCell(Text("${e.department?.name}, ")),
                // DataCell(Text(e.title)),
                // DataCell(OutlinedButton(
                //   onPressed: () async => _open(),
                //   child: Text("Open"),
                //   style: outlinedButtonStyle(),
                // ))
              ],
            ))
        .toList();
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
        side: BorderSide(color: Colors.lightBlueAccent));
  }
}
