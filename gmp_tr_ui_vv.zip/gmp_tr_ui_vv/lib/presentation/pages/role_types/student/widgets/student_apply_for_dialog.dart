import 'package:flutter/material.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class StudentApplyForDialog extends StatefulWidget {
  /// true: apply for leave
  /// false: apply for back
  final bool isApplyForLeave;

  const StudentApplyForDialog(this.isApplyForLeave, {Key key})
      : super(key: key);

  @override
  _StudentApplyForDialogState createState() => _StudentApplyForDialogState();
}

class _StudentApplyForDialogState extends State<StudentApplyForDialog> {
  final commentInputController = TextEditingController();
  final int maxLines = 5;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(25, 60, 25, 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  Translate.of(context).translate(widget.isApplyForLeave
                      ? "apply_for_leave"
                      : "apply_for_back"),
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.lightBlueAccent),
                ),
                const SizedBox(height: 20),
                Container(
                  width: 350,
                  height: maxLines * 24.0,
                  child: TextField(
                    maxLines: maxLines,
                    controller: commentInputController,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: Translate.of(context).translate("comment"),
                        contentPadding: const EdgeInsets.all(20)),
                    onChanged: (val) => setState(() {}),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: 350,
                  height: 45,
                  child: ElevatedButton(
                      onPressed: () => _submit(context),
                      child: Text(Translate.of(context).translate("submit"))),
                )
              ],
            ),
          ),
          Positioned(
            right: 0,
            child: IconButton(
                onPressed: () => _close(context),
                icon: Icon(Icons.close_outlined, size: 20)),
          )
        ],
      ),
    );
  }

  _close(BuildContext context) {
    Navigator.of(context).pop();
  }

  Future<void> _submit(BuildContext context) async {
    widget.isApplyForLeave
        ? Api.applyLeave(commentInputController.text, Application.user.id,
                Application.user.departmentIdFk)
            .then((value) {
            Navigator.of(context).pop();
            AppBloc.userLeavesBloc
                .add(OnLoadMyLeaves(studentId: Application.user.id));
          })
        : Api.applyBack(commentInputController.text, Application.user.id,
                Application.user.departmentIdFk)
            .then((value) {
            Navigator.of(context).pop();
            AppBloc.userLeavesBloc
                .add(OnLoadMyLeaves(studentId: Application.user.id));
          });
  }
}
