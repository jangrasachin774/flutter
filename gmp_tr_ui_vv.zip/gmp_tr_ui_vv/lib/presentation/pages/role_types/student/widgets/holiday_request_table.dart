import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/models/model_leaves.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'apply_again_dialog.dart';

class MyRequestTable extends StatefulWidget {
  const MyRequestTable({Key key}) : super(key: key);

  @override
  _MyRequestTableState createState() => _MyRequestTableState();
}

List<UserLeavesModel> paginatedUserLeaves = [];
final int rowsPerPage = 15;

class _MyRequestTableState extends State<MyRequestTable> {
  @override
  void initState() {
    super.initState();
    AppBloc.userLeavesBloc.add(OnLoadMyLeaves(studentId: Application.user.id));
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<UserLeavesBloc, UserLeavesState>(
      bloc: BlocProvider.of<UserLeavesBloc>(context),
      builder: (contxt, state) {
        if (state is MyLeavesLoadedSuccess) {
          HolidayDataSource userLeavesDataSource;
          userLeavesDataSource = new HolidayDataSource(
            state.userLeaves,
            context,
          );

          List<UserLeavesModel> userLeavesCount = state.userLeaves;

          return LayoutBuilder(builder: (context, constraints) {
            return Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 450,
                      width: constraints.maxWidth,
                      child: SfDataGrid(
                        allowSorting: true,
                        source: userLeavesDataSource,
                        columnWidthMode: ColumnWidthMode.fill,
                        isScrollbarAlwaysShown: true,
                        columns: [
                          GridColumn(
                            columnName: 'sNo',
                            width: 80,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('s_no'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'applyTime',
                            width: 180,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('apply_time'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'confirmTime',
                            width: 180,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context)
                                    .translate('approve_reject_time'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'confirmPerson',
                            width: 180,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context)
                                    .translate('approve_reject_person'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'status',
                            width: 150,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('status'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'reason',
                            width: 150,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('reason'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'actions',
                            columnWidthMode: ColumnWidthMode.lastColumnFill,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                '',
                              ),
                            ),
                          ),
                        ],
                        selectionMode: SelectionMode.none,
                      ),
                    ),
                    Container(
                      height: 52,
                      width: constraints.maxWidth,
                      child: SfDataPager(
                        delegate: userLeavesDataSource,
                        pageCount: (userLeavesCount.length / rowsPerPage)
                            .ceilToDouble(),
                        direction: Axis.horizontal,
                      ),
                    )
                  ],
                ),
              ],
            );
          });
        } else if (state is MyLeavesLoading) {
          return LoadingBox(
                    height: 20,
                  );
        } else if (state is MyLeavesLoadEmpty) {
          return Center(child: Text("No Records"));
        } else {
          return Container(child: Text("Network err."));
        }
      },
    );
  }
}

class HolidayDataSource extends DataGridSource {
  BuildContext contxt;

  final Completer _completer = new Completer();
  HolidayDataSource(
    List<UserLeavesModel> userLeave,
    context,
  ) {
    try {
      userLeaves = userLeave;
      contxt = context;

      if (userLeaves.length < rowsPerPage) {
        paginatedUserLeaves = userLeaves.toList().reversed;
      } else {
        paginatedUserLeaves =
            userLeaves.getRange(0, rowsPerPage).toList().reversed;
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.userLeaves.length) {
      endIndex = this.userLeaves.length;
    }
    paginatedUserLeaves = List.from(
      this
          .userLeaves
          .getRange(startIndex, endIndex)
          .toList(growable: false)
          .reversed,
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _userLeaves = [];
  List<UserLeavesModel> userLeaves = [];
  @override
  List<DataGridRow> get rows => _userLeaves;

  void buildPaginatedDataGridRows() {
    int rowCount = 1;
    _userLeaves = paginatedUserLeaves
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell(columnName: 'sNo', value: rowCount++),
              DataGridCell(
                  columnName: 'applyTime',
                  value: DateFormat('yyyy/MM/dd hh:mm:ss')
                      .format(DateTime.parse(e.createdAt))
                      .toString()),
              DataGridCell(
                  columnName: 'confirmTime',
                  value: e.confirmedDate != null
                      ? DateFormat('yyyy/MM/dd hh:mm:ss')
                          .format(DateTime.parse(e.confirmedDate))
                          .toString()
                      : ""),
              DataGridCell<String>(
                  columnName: 'confirmPerson',
                  value: e.confirmedBy?.username ?? ""),
              DataGridCell(
                  columnName: 'status',
                  value: e.status != null ? e.status : null),
              DataGridCell<String>(
                columnName: 'reason',
                value: e.approverDescription ?? "",
              ),
              DataGridCell(
                columnName: 'actions',
                value: e,
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  Future<void> _showApplyForDialog(String description) async {
    showDialog(
        context: contxt,
        barrierDismissible: true,
        builder: (context) => ApplyAgainForDialog(description));
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[0].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[1].value.toString(),
              child: Text(
                row.getCells()[1].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[2].value.toString(),
              child: Text(
                row.getCells()[2].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[3].value.toString(),
              child: Text(
                row.getCells()[3].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: row.getCells()[4].value == null
              ? Text(
                  "Pending",
                  style: TextStyle(color: Colors.orange),
                )
              : row.getCells()[4].value == 0
                  ? Text(
                      "Rejected",
                      style: TextStyle(color: Colors.red),
                    )
                  : Text(
                      "Approved",
                      style: TextStyle(color: Colors.green),
                    ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[5].value.toString(),
              child: Text(
                row.getCells()[5].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
            alignment: Alignment.centerLeft,
            child: row.getCells()[6].value.status == null
                ? Text("Pending")
                : row.getCells()[6].value.status == 0
                    ? OutlinedButton(
                        onPressed: () {
                          _showApplyForDialog(
                              row.getCells()[6].value.userDescription);
                        },
                        child:
                            Text(Translate.of(contxt).translate("apply_again")),
                        style: outlinedButtonStyle(),
                      )
                    : Container()),
      ],
    );
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
        side: BorderSide(color: Colors.lightBlueAccent));
  }
}
