import 'dart:async';
import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/translate.dart';
// import 'package:pdftron_flutter/pdftron_flutter.dart' as configg;
import 'dart:ui' as ui;

import '../student_take_test_page.dart';

// ignore: must_be_immutable
class StudentViewDocumentDialog extends StatefulWidget {
  final bool isNeedConfirm;
  final String path;
  final String name;
  // final List<TaskTestModel> tests;
  final List<DocumentTests> tests;
  final Task task;
  StudentViewDocumentDialog(
      {Key key,
      this.isNeedConfirm = true,
      this.path,
      this.name,
      this.task,
      this.tests})
      : super(key: key);

  @override
  _ViewDocumentDialogState createState() => _ViewDocumentDialogState();
}

class _ViewDocumentDialogState extends State<StudentViewDocumentDialog>
    with AutomaticKeepAliveClientMixin {
  String src;
  final IFrameElement _iframeElement = IFrameElement();
  final ImageElement img = ImageElement();
  Duration time = Duration(seconds: 120);
  Timer timer;

  @override
  void initState() {
    super.initState();

    if (time <= Duration()) {
      setState(() {
        time = Duration();
      });
    } else {
      setState(() {
        time -= Duration(seconds: 1);
      });
    }
    timer = Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
    // initPlatformState();

    src =
        "http://139.9.146.31:3333${this.widget.path}#toolbar=0&navpanes=0&scrollbar=0";

    var splits = src.split('.');
    var parts = splits.last.split('#');
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'bmp'].contains(parts.first)) {
      img
        ..style.display = 'block'
        ..style.marginLeft = 'auto'
        ..style.marginRight = 'auto'
        ..style.objectFit = 'contain'
        // ..style.overflow = 'scroll'
        ..src = src;
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        src,
        (int viewId) => img,
      );
    } else {
      _iframeElement
        ..src = src
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.border = 'none';
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        src,
        (int viewId) => _iframeElement,
      );
    }
  }

  // String _version = 'Unknown';

  // bool _showViewer = true;

  // Future<void> launchWithPermission() async {
  //  PermissionStatus permission = await Permission.storage.request();
  //  if (permission.isGranted) {
  //    showViewer();
  //  }
  // }

  // Platform messages are asynchronous, so initialize in an async method.
  // Future<void> initPlatformState() async {
  //   String version;
  //   // Platform messages may fail, so use a try/catch PlatformException.
  //   try {
  //     // Initializes the PDFTron SDK, it must be called before you can use any functionality.
  //     configg.PdftronFlutter.initialize("your_pdftron_license_key");

  //     version = await configg.PdftronFlutter.version;
  //   } on PlatformException {
  //     version = 'Failed to get platform version.';
  //   }

  //   // If the widget was removed from the tree while the asynchronous platform
  //   // message was in flight, you want to discard the reply rather than calling
  //   // setState to update our non-existent appearance.
  //   if (!mounted) return;

  //   setState(() {
  //     _version = version;
  //   });
  // }

  void resetTimer(Duration reStartTime) {
    setState(() {
      time = reStartTime;
    });
  }

  String _printDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "$twoDigitMinutes:$twoDigitSeconds";
  }

  void _getTime() {
    if (mounted) {
      setState(() {
        if (time <= Duration()) {
          setState(() {
            time = Duration();
          });
        } else {
          setState(() {
            time -= Duration(seconds: 1);
          });
        }
      });
    }
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
      return Dialog(
        backgroundColor: Colors.white,
        child: Container(
          height: heightOfScreen(context) * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                children: [
                  Container(
                    height: 40,
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.only(left: 20),
                    child: Text(
                      "This is document title",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    color: Colors.grey.withOpacity(.25),
                  ),
                  if (!widget.isNeedConfirm)
                    Positioned(
                      right: 0,
                      child: IconButton(
                        icon: Icon(Icons.close_outlined),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    )
                ],
              ),
              SingleChildScrollView(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.65,
                  padding: const EdgeInsets.all(20),
                  child: HtmlElementView(
                    viewType: src,
                  ),
                  // child: _showViewer
                  //     ? configg.DocumentView(
                  //         onCreated: _onDocumentViewCreated,
                  //       )
                  //     : Container(),
                ),
              ),
              _confirmOrNot(context, time, widget.tests, widget.task),
            ],
          ),
        ),
      );
    });
  }

  Widget _confirmOrNot(BuildContext context, Duration time,
      List<DocumentTests> exam, Task task) {
    return Container(
      height: 120,
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (widget.isNeedConfirm)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "Go through the documents thoroughly, your go to test is enable after 2 Minutes ${_printDuration(time)}",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12),
              ),
            ),
          SizedBox(
            height: 20,
          ),
          if (widget.isNeedConfirm)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 36,
                  width: 150,
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() {
                        resetTimer(
                          Duration(seconds: 0),
                        );
                      });
                      Navigator.of(context).pop(false);
                    },
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.close_outlined),
                      const SizedBox(width: 6),
                      Text(Translate.of(context).translate('cancel'))
                    ]),
                    style: _outlinedButtonStyle(),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  height: 36,
                  child: exam != null && exam.length > 0
                      ? AppButton(
                          Translate.of(context).translate('go_to_test_page'),
                          onPressed: () {
                            // if we show StudentTakeTestPage over view document dialog,
                            // user is unable to click checkbox because of iFrameElement
                            // therefore, poping that screen
                            Navigator.of(context).pop();
                            showDialog<bool>(
                                context: context,
                                barrierDismissible:
                                    false, // user must tap button!
                                builder: (context) => StudentTakeTestPage(
                                    tests: exam, task: task));
                          },
                          disabled: time == Duration() ? false : true,
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(Icons.done_outlined),
                        )
                      : AppButton(
                          Translate.of(context).translate('submit'),
                          onPressed: () {
                            AppBloc.testsBloc.add(OnSaveTest(
                              testIdFk: widget.task.id,
                              studentIdFk: Application.user.id,
                              selectedAnswers: [],
                            ));
                          },
                          disabled: time == Duration() ? false : true,
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(Icons.done_outlined),
                        ),
                )
              ],
            ),
        ],
      ),
    );
  }

  // This function is used to control the DocumentView widget after it has been created.
  // The widget will not work without a void Function(DocumentViewController controller) being passed to it.
  // void _onDocumentViewCreated(configg.DocumentViewController controller) async {
  //   print("On document viewer");
  //   configg.Config config = new configg.Config();
  //   String _document = "http://139.9.146.31:3333${this.widget.path}";
  //   var leadingNavCancel = configg.startLeadingNavButtonPressedListener(() {
  //     // Uncomment this to quit the viewer when leading navigation button is pressed.
  //     this.setState(() {
  //       _showViewer = !_showViewer;
  //     });

  //     // Show a dialog when leading navigation button is pressed.
  //     _showMyDialog();
  //   });

  //   config.hideTopAppNavBar = true;
  //   config.hideTopToolbars = true;
  //   config.hideDefaultAnnotationToolbars = [];
  //   config.hideAnnotationMenu = [
  //     configg.Buttons.shareButton,
  //     configg.Buttons.searchButton,
  //     configg.Buttons.annotationListButton,
  //     configg.Buttons.moreItemsButton,
  //     configg.Buttons.toolsButton,
  //     configg.Buttons.viewControlsButton,
  //   ];
  //   config.disabledElements = [
  //     configg.Buttons.shareButton,
  //     configg.Buttons.searchButton,
  //     configg.Buttons.annotationListButton,
  //     configg.Buttons.moreItemsButton,
  //     configg.Buttons.toolsButton,
  //     configg.Buttons.viewControlsButton
  //   ];
  //   config.disabledTools = [
  //     configg.Tools.annotationCreateLine,
  //     configg.Tools.pencilKitDrawing,
  //     configg.Tools.annotationCreateRectangle
  //   ];
  //   config.multiTabEnabled = true;
  //   config.customHeaders = {'headerName': 'headerValue'};

  //   controller.openDocument(_document, config: config);
  //   //   // An event listener for document loading
  //   //   var documentLoadedCancel = configg.startDocumentLoadedListener((filePath) {
  //   //     print("document loaded: $filePath");
  //   //   });
  // }

  // Future<void> _showMyDialog() async {
  //   print('hello');
  //   return showDialog<void>(
  //     context: context,
  //     barrierDismissible: false, // User must tap button!
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: Text('AlertDialog'),
  //         content: SingleChildScrollView(
  //           child: Text('Leading navigation button has been pressed.'),
  //         ),
  //         actions: <Widget>[
  //           TextButton(
  //             child: Text('OK'),
  //             onPressed: () {
  //               Navigator.of(context).pop();
  //             },
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  ButtonStyle _outlinedButtonStyle() {
    return OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        side: BorderSide(color: Colors.lightBlueAccent));
  }
}
