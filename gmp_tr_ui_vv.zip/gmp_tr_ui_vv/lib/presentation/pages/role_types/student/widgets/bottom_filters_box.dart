import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class BottomSheetFilters extends StatefulWidget {
  final int taskStatusId;
  const BottomSheetFilters({Key key, this.taskStatusId}) : super(key: key);

  @override
  _BottomSheetFiltersState createState() => _BottomSheetFiltersState();
}

class _BottomSheetFiltersState extends State<BottomSheetFilters> {
  int viewType = 0;
  var documentFeatureIdFk;
  var trainingTypeIdFk;
  var roleTypeIdFk;
  var departmentIdFk;
  int criteriaId;

  var workerIdFk;

  final _dateController = TextEditingController();

  ///Sticky header controller
  ScrollController _mainScrollController = ScrollController();
  double _removableWidgetSize = 100;
  bool _isStickyOnTop = false;

  /// stored filter variables
  String getDepartmentIdFk = 'null';
  String getTrainingTypeIdFk = 'null';
  String getDocumentFeatureIdFk = 'null';

  /// calender
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  @override
  void initState() {
    super.initState();
    // UtilPreferences.remove(Preferences.filterDepartmentIdFk);
    // UtilPreferences.remove(Preferences.filterTrainingTypeIdFk);
    // UtilPreferences.remove(Preferences.filterDocFeatureIdFk);
    getDepartmentIdFk =
        UtilPreferences.getString(Preferences.filterDepartmentIdFk) ?? 'null';
    getTrainingTypeIdFk =
        UtilPreferences.getString(Preferences.filterTrainingTypeIdFk) ?? 'null';
    getDocumentFeatureIdFk =
        UtilPreferences.getString(Preferences.filterDocFeatureIdFk) ?? 'null';
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.rolesBloc.add(OnLoadRoles());
    _mainScrollController.addListener(() {
      if (_mainScrollController.offset >= _removableWidgetSize &&
          !_isStickyOnTop) {
        _isStickyOnTop = true;
        setState(() {});
      } else if (_mainScrollController.offset < _removableWidgetSize &&
          _isStickyOnTop) {
        _isStickyOnTop = false;
        setState(() {});
      }
    });
  }

  ///SHOW CALENDER
  void _showCalender() {
    showDialog<void>(
      context: context,
      builder: (BuildContext buildContext) {
        return AlertDialog(
          content: Container(
            width: 280,
            height: 400,
            child: SfDateRangePicker(
              onSelectionChanged: _onSelectionChanged,
              selectionMode: DateRangePickerSelectionMode.range,
              enablePastDates: false,
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.normal,
            ),
          ],
        );
      },
    );
  }

  ///ON SELECT CHANGE
  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    setState(() {
      if (args.value is PickerDateRange) {
        _startDate = formatter.format(args.value.startDate).toString();
        _endDate = formatter.format(args.value.endDate).toString();
        _dateController.text = _startDate + "-" + _endDate;
      } else if (args.value is DateTime) {
        _selectedDate = args.value.toString();
      } else if (args.value is List<DateTime>) {
        _dateCount = args.value.length.toString();
      } else {
        _rangeCount = args.value.length.toString();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ListView(
          controller: _mainScrollController,
          shrinkWrap: true,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _getStickyWidget(),

                ///VIEW TYPE
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: HeadingText(
                      Translate.of(context).translate("view_type"),
                      textColor: Color(0xff000000)),
                ),
                Container(
                  height: 40.0,
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    children: [
                      TextButton(
                        style: TextButton.styleFrom(
                          primary: Colors.blue,
                          backgroundColor: viewType == 0
                              ? Color(0xffCFD6DF)
                              : Color(0xffEFF5FC),
                        ),
                        onPressed: () {
                          setState(() {
                            viewType = 0;
                          });
                        },
                        child: Text(
                          Translate.of(context).translate('task'),
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      TextButton(
                        style: TextButton.styleFrom(
                          backgroundColor: viewType == 1
                              ? Color(0xffCFD6DF)
                              : Color(0xffEFF5FC),
                        ),
                        onPressed: () {
                          setState(() {
                            viewType = 1;
                          });
                        },
                        child: Text(
                          Translate.of(context).translate('read_only_task'),
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),

                ///DEPARTMENT SELECTION
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: HeadingText(
                      Translate.of(context).translate("department"),
                      textColor: Color(0xff000000)),
                ),
                BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                  bloc: BlocProvider.of<DepartmentsListBloc>(context),
                  builder: (context, state) {
                    if (state is DepartmentsSuccess) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: state.departments.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    childAspectRatio: 2, crossAxisCount: 3),
                            itemBuilder: (context, index) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    width: 100,
                                    child: TextButton(
                                      style: TextButton.styleFrom(
                                        backgroundColor: getDepartmentIdFk !=
                                                    "null" &&
                                                getDepartmentIdFk.isNotEmpty
                                            ? int.parse(getDepartmentIdFk) ==
                                                    state.departments[index].id
                                                ? Color(0xffCFD6DF)
                                                : Color(0xffEFF5FC)
                                            : departmentIdFk ==
                                                    state.departments[index].id
                                                ? Color(0xffCFD6DF)
                                                : Color(0xffEFF5FC),
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          departmentIdFk =
                                              state.departments[index].id;
                                          getDepartmentIdFk = "null";
                                        });
                                      },
                                      child: Text(
                                        state.departments[index].name,
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }),
                      );
                    } else if (state is DepartmentsLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load departments failed.");
                    }
                  },
                ),
                const SizedBox(width: 10),

                ///TRAINING TYPE SELECTION
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: HeadingText(
                      Translate.of(context).translate("training_type"),
                      textColor: Color(0xff000000)),
                ),
                BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                  bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                  builder: (context, state) {
                    if (state is TrainingsTypeSuccess) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        // height: 200,
                        child: GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: state.trainingTypes.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    childAspectRatio: 2.2, crossAxisCount: 3),
                            itemBuilder: (context, index) {
                              return Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    width: 120,
                                    child: TextButton(
                                      style: TextButton.styleFrom(
                                        backgroundColor: getTrainingTypeIdFk !=
                                                    'null' &&
                                                getTrainingTypeIdFk.isNotEmpty
                                            ? int.parse(getTrainingTypeIdFk) ==
                                                    state
                                                        .trainingTypes[index].id
                                                ? Color(0xffCFD6DF)
                                                : Color(0xffEFF5FC)
                                            : trainingTypeIdFk ==
                                                    state
                                                        .trainingTypes[index].id
                                                ? Color(0xffCFD6DF)
                                                : Color(0xffEFF5FC),
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          trainingTypeIdFk =
                                              state.trainingTypes[index].id;
                                          getTrainingTypeIdFk = "null";
                                        });
                                      },
                                      child: Text(
                                        state.trainingTypes[index].name,
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }),
                      );
                    } else if (state is TrainingsTypeLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load training types failed.");
                    }
                  },
                ),
                const SizedBox(width: 10),

                ///TRAINING TYPE SELECTION
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: HeadingText(
                      Translate.of(context).translate("document_feature"),
                      textColor: Color(0xff000000)),
                ),
                BlocBuilder<DocumentsFeatureListBloc,
                    DocumentsFeatureListState>(
                  bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
                  builder: (context, state) {
                    if (state is DocumentsFeatureSuccess) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        // height: 200,
                        child: GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: state.documentsFeature.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    childAspectRatio: 2.2, crossAxisCount: 3),
                            itemBuilder: (context, index) {
                              return Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    width: 120,
                                    child: TextButton(
                                      style: TextButton.styleFrom(
                                        backgroundColor: getDocumentFeatureIdFk !=
                                                    "null" &&
                                                getDocumentFeatureIdFk
                                                    .isNotEmpty
                                            ? int.parse(getDocumentFeatureIdFk) ==
                                                    state
                                                        .documentsFeature[index]
                                                        .id
                                                ? Color(0xffCFD6DF)
                                                : Color(0xffEFF5FC)
                                            : documentFeatureIdFk ==
                                                    state
                                                        .documentsFeature[index]
                                                        .id
                                                ? Color(0xffCFD6DF)
                                                : Color(0xffEFF5FC),
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          documentFeatureIdFk =
                                              state.documentsFeature[index].id;
                                          getDocumentFeatureIdFk = "null";
                                        });
                                      },
                                      child: Text(
                                        state.documentsFeature[index].name,
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }),
                      );
                    } else if (state is DocumentsFeatureLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load document features failed.");
                    }
                  },
                ),

                ///TIME DATE - CRITERIA SELECTION
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: HeadingText(Translate.of(context).translate("time"),
                      textColor: Color(0xff000000)),
                ),

                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Translate.of(context).translate("choose_duration"),
                        style: TextStyle(fontSize: 12),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Container(
                        width: 320,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _showCalender();
                            });
                          },
                          child: AbsorbPointer(
                            child: AppTextInput(
                              controller: _dateController,
                              hintText: Translate.of(context)
                                  .translate("from_to_date"),
                              keyboardType: TextInputType.datetime,
                              icon: Icon(
                                Icons.calendar_today_outlined,
                                color: Colors.blue,
                                size: 13,
                              ),
                            ),
                          ),
                        ),
                      ),
                      GridView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: criteria.length,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                  childAspectRatio: 2, crossAxisCount: 3),
                          itemBuilder: (context, index) {
                            return Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                SizedBox(
                                  width: 120,
                                  child: TextButton(
                                    style: TextButton.styleFrom(
                                      backgroundColor: Color(0xffEFF5FC),
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        criteriaId = criteria[index].id;
                                      });
                                    },
                                    child: Text(
                                      criteria[index].name,
                                      style: TextStyle(fontSize: 12),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          })
                    ],
                  ),
                ),

                ///Clear , Save filter Options
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      AppButton(
                        Translate.of(context).translate('clear'),
                        fontSize: 12,
                        onPressed: () {
                          ///Reset start time & end time
                          _startDate = '';
                          _endDate = '';

                          ///SAVE FILTER OPTION DEPARTMENT ID FK
                          UtilPreferences.remove(
                            Preferences.filterDepartmentIdFk,
                          );

                          ///SAVE FILTER OPTION TRAINING TYPE ID FK
                          UtilPreferences.remove(
                            Preferences.filterTrainingTypeIdFk,
                          );

                          ///SAVE FILTER OPTION DOCUMENT FEATURE ID FK
                          UtilPreferences.remove(
                            Preferences.filterDocFeatureIdFk,
                          );
                          AppBloc.tasksBloc.add(OnLoadTasksEvent(
                            viewType: [viewType],
                            departmentIdFk: departmentIdFk,
                            documentFeatureIdFk: documentFeatureIdFk,
                            trainingTypeIdFk: trainingTypeIdFk,
                            roleTypeIdFk: roleTypeIdFk,
                            workerIdFk: workerIdFk,
                            studentIdFk: Application.user.id,
                            taskStatusId: widget.taskStatusId,
                          ));
                          Navigator.pop(context);
                        },
                        type: ButtonType.outline,
                        color: Color(0xff787E8C),
                      ),
                      AppButton(
                        Translate.of(context).translate('save'),
                        onPressed: () {
                          ///SAVE FILTER OPTION DEPARTMENT ID FK
                          UtilPreferences.setString(
                            Preferences.filterDepartmentIdFk,
                            jsonEncode(
                              departmentIdFk ?? int.parse(getDepartmentIdFk),
                            ),
                          );

                          ///SAVE FILTER OPTION TRAINING TYPE ID FK
                          UtilPreferences.setString(
                            Preferences.filterTrainingTypeIdFk,
                            jsonEncode(
                              trainingTypeIdFk ??
                                  int.parse(getTrainingTypeIdFk),
                            ),
                          );

                          ///SAVE FILTER OPTION DOCUMENT FEATURE ID FK
                          UtilPreferences.setString(
                            Preferences.filterDocFeatureIdFk,
                            jsonEncode(
                              documentFeatureIdFk ??
                                  int.parse(getDocumentFeatureIdFk),
                            ),
                          );
                          AppBloc.tasksBloc.add(OnLoadTasksEvent(
                            viewType: [viewType],
                            departmentIdFk: departmentIdFk,
                            documentFeatureIdFk: documentFeatureIdFk,
                            trainingTypeIdFk: trainingTypeIdFk,
                            roleTypeIdFk: roleTypeIdFk,
                            workerIdFk: workerIdFk,
                            studentIdFk: Application.user.id,
                            taskStatusId: widget.taskStatusId,
                            criteria: criteriaId,
                            startDate: _startDate,
                            endDate: _endDate,
                          ));
                          Navigator.pop(context);
                        },
                        type: ButtonType.outline,
                        color: Color(0xff787E8C),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        if (_isStickyOnTop) _getStickyWidget()
      ],
    );
  }

  Container _getStickyWidget() {
    return Container(
      color: Color(0xffD0D0D0),
      padding: EdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(Translate.of(context).translate('filter')),
          InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Color(0xff000000),
              size: 20,
            ),
          ),
        ],
      ),
    );
  }
}
