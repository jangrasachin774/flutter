import 'package:flutter/material.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

import '../../../../../global.dart';
import '../signed_by_big_leader.dart';

class StudentTestPassDialog extends StatelessWidget {
  const StudentTestPassDialog({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  Translate.of(context).translate("well_done"),
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green),
                ),
                Text(
                  Translate.of(context).translate("you_have_passed_your_exam"),
                  style: TextStyle(fontSize: 14, color: Colors.black.withOpacity(.54), fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 50),
                SizedBox(
                  width: 300,
                  height: 45,
                  child: ElevatedButton(onPressed: () => _close(context), child: Text(Translate.of(context).translate("go_to_dashboard"))),
                )
              ],
            ),
          ),
          Positioned(
            right: 0,
            child: IconButton(onPressed: () => _close(context), icon: Icon(Icons.close_outlined, size: 20)),
          )
        ],
      ),
    );
  }

  void _close(BuildContext context) {
    // ignore: todo
    // TODO: should navigate to dashboard page.
    Navigator.of(context)
      ..pop()
      ..pop()
      ..pop();
    // SignedByBLDashboardPage();
    AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
      ViewType.regularTask
    ], studentIdFk: Application.user.id, taskStatusId: 6));
  }
}
