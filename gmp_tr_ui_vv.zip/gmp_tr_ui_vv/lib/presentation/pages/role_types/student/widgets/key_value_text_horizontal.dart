import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

class KeyValueTextHorizontal extends StatelessWidget {
  final String field;

  final String value;
  KeyValueTextHorizontal({Key key, this.field, this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Wrap(
      runSpacing: 20,
      spacing: 20,
      children: [
        SizedBox(
            width: 100,
            child: AutoSizeText(
              this.field,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            )),
        SizedBox(
          width: 100,
          child: AutoSizeText(
            this.value,
            style: TextStyle(fontSize: 12),
          ),
        ),
      ],
    );
  }
}
