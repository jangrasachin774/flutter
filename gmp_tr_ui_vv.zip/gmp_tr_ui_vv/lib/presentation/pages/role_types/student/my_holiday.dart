import 'package:flutter/material.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/heading_text.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:responsive_builder/responsive_builder.dart';

import 'widgets/holiday_request_table.dart';
import 'widgets/student_apply_for_dialog.dart';

class MyHolidayPage extends StatefulWidget {
  const MyHolidayPage({Key key}) : super(key: key);

  @override
  _MyHolidayPageState createState() => _MyHolidayPageState();
}

class _MyHolidayPageState extends State<MyHolidayPage> {
  Future<void> _showApplyForDialog(bool isApplyForLeave) async {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) => StudentApplyForDialog(isApplyForLeave));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                child: Wrap(
                  runSpacing: 10,
                  alignment: WrapAlignment.spaceBetween,
                  children: [
                    // heading text
                    HeadingText(Translate.of(context).translate("my_holiday")),
                    ResponsiveBuilder(
                        refinedBreakpoints: RefinedBreakpoints(),
                        builder: (context, sizingInformation) {
                          double screenWidth =
                              sizingInformation.screenSize.width;
                          //Desktop
                          if (screenWidth >
                              (RefinedBreakpoints().mobileExtraLarge)) {
                            return Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                AppButton(
                                  Translate.of(context)
                                      .translate('back_from_leave'),
                                  onPressed: () => _showApplyForDialog(false),
                                  type: ButtonType.outline,
                                  color: Color(0xff787E8C),
                                  icon: Icon(
                                    Icons.perm_identity_outlined,
                                  ),
                                ),
                                SizedBox(width: 10),
                                AppButton(
                                  Translate.of(context)
                                      .translate('apply_for_leave'),
                                  onPressed: () => _showApplyForDialog(true),
                                  type: ButtonType.normal,
                                  color: Color(0xff787E8C),
                                  icon: Icon(
                                    Icons.drafts_outlined,
                                  ),
                                ),
                              ],
                            );
                          } else {
                            return PopupMenuButton(
                              onSelected: (value) {
                                if (value == 1) {
                                  _showApplyForDialog(false);
                                }
                                if (value == 2) {
                                  _showApplyForDialog(true);
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Icon(
                                  Icons.more_vert,
                                  color: Color(0xff00A4E3),
                                ),
                              ),
                              itemBuilder: (context) => [
                                PopupMenuItem(
                                  child: Text(
                                    Translate.of(context)
                                        .translate('back_from_leave'),
                                    style: TextStyle(
                                        color: Color(0xff00A4E3), fontSize: 11),
                                  ),
                                  value: 1,
                                ),
                                PopupMenuItem(
                                  child: Text(
                                    Translate.of(context)
                                        .translate('apply_for_leave'),
                                    style: TextStyle(
                                        color: Color(0xff00A4E3), fontSize: 11),
                                  ),
                                  value: 2,
                                ),
                              ],
                            );
                          }
                        })
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // holiday request table
              MyRequestTable(),
            ],
          ),
        ),
      ],
    );
  }
}
