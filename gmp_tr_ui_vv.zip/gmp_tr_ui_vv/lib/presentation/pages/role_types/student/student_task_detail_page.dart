import 'package:flutter/material.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:responsive_builder/responsive_builder.dart';

import 'student_take_test_page.dart';
import 'widgets/view_document_dialog.dart';

class StudentTaskDetailPage extends StatefulWidget {
  final Task task;

  const StudentTaskDetailPage(this.task, {Key key})
      : assert(task != null),
        super(key: key);

  @override
  _StudentTaskDetailPageState createState() => _StudentTaskDetailPageState();
}

class _StudentTaskDetailPageState extends State<StudentTaskDetailPage> {
  StudentsWidgets selectedWidgetPage = StudentsWidgets.taskDetails;
  // FIXME: if single task has multi docs, one doc confirm will work to others.
  bool isConfirmed = false;
  DateTime enterTime;

  Future<void> _go2TestPage() async {
    if (DateTime.now().difference(enterTime).abs().inMinutes < 2) {
      SnackBarUtil.warn(context, "please read at least 2 minutes.");

      return;
    }
  }

  @override
  void initState() {
    super.initState();
    enterTime = DateTime.now();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ResponsiveBuilder(
                refinedBreakpoints: RefinedBreakpoints(),
                builder: (context, sizingInformation) {
                  double screenWidth = sizingInformation.screenSize.width;
                  //Desktop
                  if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
                    return const SizedBox(height: 30);
                  } else {
                    return const SizedBox(height: 0);
                  }
                }),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: Icon(Icons.close_outlined),
                  onPressed: () => Navigator.of(context).pop(),
                )
              ],
            ),

            // training type and training title
            Wrap(spacing: 100, runSpacing: 20, children: [
              _keyValueText(
                Translate.of(context).translate("training_type"),
                widget.task.taskTrainingType.name,
              ),
              _keyValueText(
                Translate.of(context).translate("training_title"),
                widget.task.title,
              ),
              // document feature type
              _keyValueText(
                Translate.of(context).translate("document_feature_type"),
                widget.task.taskDocumentType.name,
              ),
              // training description
              _trainingDescription(),
            ]),
            // const SizedBox(height: 20),

            // const SizedBox(height: 20),

            const SizedBox(height: 20),

            // training documents buttons
            _trainingDocuments(),
            const SizedBox(height: 20),

            // create info card
            _createAndSignInfoCard(
              isSign: widget.task.creatorConfirmDate == null ? false : true,
              title: Translate.of(context).translate("create_task_person"),
              dept: widget.task.taskCreator.department.name,
              worker: widget.task.taskCreator.name,
              time: DateFormat('yyyy/MM/dd hh:mm:ss')
                  .format(DateTime.parse(widget.task.createdAt))
                  .toString(),
              isSigned: widget.task.creatorConfirmDate == null ? false : true,
            ),
            const SizedBox(height: 20),
            // small leader sign info card
            _createAndSignInfoCard(
              isSign: true,
              title: Translate.of(context).translate("small_leader"),
              dept: widget.task.smallLeader == null
                  ? ""
                  : widget.task.smallLeader.department.name,
              worker: widget.task.smallLeader == null
                  ? ""
                  : widget.task.smallLeader.username,
              time: widget.task.smallLeaderConfirmDate == null
                  ? ""
                  : DateFormat('yyyy/MM/dd hh:mm:ss')
                      .format(
                          DateTime.parse(widget.task.smallLeaderConfirmDate))
                      .toString(),
              isSigned:
                  widget.task.smallLeaderConfirmDate == null ? false : true,
            ),
            const SizedBox(height: 20),
            // big leader sign info card
            _createAndSignInfoCard(
              isSign: true,
              title: Translate.of(context).translate("big_leader"),
              dept: widget.task.bigLeader != null
                  ? widget.task.bigLeader.department.name
                  : "",
              worker: widget.task.bigLeader != null
                  ? widget.task.bigLeader.username
                  : "",
              time: widget.task.bigLeaderConfirmDate != null
                  ? DateFormat('yyyy/MM/dd hh:mm:ss')
                      .format(DateTime.parse(widget.task.bigLeaderConfirmDate))
                      .toString()
                  : "",
              isSigned: widget.task.bigLeaderConfirmDate == null ? false : true,
            ),
            const SizedBox(height: 20),
            // students info card
            _studentInfoCard(
              name: _fakeWorker,
              department: _fakeDept,
              beginTime: _fakeTime,
              endTime: _fakeTime,
              result: "Pending",
            )
          ],
        ),
      ),
    );
  }

  // Widget _header() {
  //   return Container(
  //     width: double.infinity,
  //     child: Wrap(
  //       alignment: WrapAlignment.spaceBetween,
  //       children: [
  //         SizedBox(
  //           width: 1,
  //         ),
  //         Row(
  //           mainAxisSize: MainAxisSize.min,
  //           children: [
  //             SizedBox(width: 10),
  //             AppButton(
  //               Translate.of(context).translate('go_to_test_page'),
  //               onPressed: () {
  //                 setState(() {
  //                   // _go2TestPage();
  //                   selectedWidgetPage = StudentsWidgets.openTest;
  //                   StudentTakeTestPage(widget.task.taskDocumentTests);
  //                 });
  //               },
  //               type: ButtonType.normal,
  //               color: Color(0xff787E8C),
  //               icon: Icon(Icons.history_edu_outlined),
  //             ),
  //           ],
  //         )
  //       ],
  //     ),
  //   );
  // }

  Widget _keyValueText(String key, String value) {
    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.end,
      children: [
        // Container(width: 200, child: Text(key, style: _bold14)),
        Text(key, style: _bold14),
        SizedBox(width: 8.0),
        Text(value, style: _text12),
      ],
    );
  }

  Widget _trainingDescription() {
    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.end,
      children: [
        Text(Translate.of(context).translate("document_description"),
            style: _bold14),
        const SizedBox(width: 8.0),
        ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 500),
          child: Text(
            widget.task.description,
            textAlign: TextAlign.justify,
          ),
        )
      ],
    );
  }

  Widget _trainingDocuments() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(Translate.of(context).translate("training_documents"),
            style: _bold14),
        const SizedBox(height: 7),
        ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 700),
          child: Wrap(
            spacing: 10,
            runSpacing: 10,
            children: List.generate(
                widget.task.taskDocuments[0].document.documentFiles.length,
                (index) => _viewDocumentButton(
                      widget.task.taskDocuments[0].document.documentFiles[index]
                          .name,
                      widget.task.taskDocuments[0].document.documentFiles[index]
                          .path,
                    )),
          ),
        )
      ],
    );
  }

  Widget _viewDocumentButton(String name, String path) {
    return Container(
        height: 40,
        width: 200,
        child: OutlinedButton(
          onPressed: () async => isConfirmed = await _showMyDialog(name, path),
          child: Text("Training Document"),
        ));
  }

  Widget twoLineText(
      {String line1, String line2, Color line2Color = Colors.black}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(line1, style: _bold14),
        Text(line2, style: TextStyle(fontSize: 12, color: line2Color))
      ],
    );
  }

  Widget _createAndSignInfoCard({
    bool isSign,
    String title,
    String dept,
    String worker,
    String time,
    bool isSigned,
  }) {
    Widget twoLineText(
            {String line1, String line2, Color line2Color = Colors.black}) =>
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(line1, style: _bold14),
            Text(line2, style: TextStyle(fontSize: 12, color: line2Color))
          ],
        );

    return Container(
      width: double.infinity,
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(
        children: [
          Container(
            height: 40,
            padding: const EdgeInsets.only(left: 30),
            alignment: Alignment.centerLeft,
            color: Colors.grey.withOpacity(.2),
            child: Text(title, style: _bold14),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 30),
            alignment: Alignment.centerLeft,
            child: Wrap(spacing: 160, runSpacing: 20, children: [
              twoLineText(
                line1: Translate.of(context).translate("department"),
                line2: dept,
              ),
              twoLineText(
                line1: Translate.of(context)
                    .translate(isSign ? "sign_worker" : "create_worker"),
                line2: worker,
              ),
              twoLineText(
                line1: Translate.of(context)
                    .translate(isSign ? "sign_time" : "create_time"),
                line2: time,
              ),
              if (isSign)
                twoLineText(
                  line1: Translate.of(context).translate("sign_result"),
                  line2:
                      Translate.of(context).translate(isSigned ? "agree" : ""),
                  line2Color: isSigned ? Colors.lightGreen : Colors.redAccent,
                ),
            ]),
          )
        ],
      ),
    );
  }

  Widget _studentInfoCard({
    String name,
    String department,
    String beginTime,
    String endTime,
    String result,
  }) {
    return Container(
      width: double.infinity,
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(
        children: [
          Container(
            height: 40,
            padding: const EdgeInsets.only(left: 30),
            alignment: Alignment.centerLeft,
            color: Colors.grey.withOpacity(.2),
            child: Text(Translate.of(context).translate("student"),
                style: _bold14),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 30),
            alignment: Alignment.centerLeft,
            child: Wrap(spacing: 160, runSpacing: 20, children: [
              twoLineText(
                line1: Translate.of(context).translate("student_name"),
                line2: name,
              ),
              twoLineText(
                line1: Translate.of(context).translate("student_department"),
                line2: department,
              ),
              twoLineText(
                line1: Translate.of(context).translate("begin_time"),
                line2: beginTime,
              ),
              twoLineText(
                line1: Translate.of(context).translate("end_time"),
                line2: endTime,
              ),
              twoLineText(
                line1: Translate.of(context).translate("test_result"),
                line2: result,
                line2Color: result == "Pass" ? Colors.green : Colors.redAccent,
              ),
            ]),
          )
        ],
      ),
    );
  }

  get _bold14 => const TextStyle(fontSize: 14, fontWeight: FontWeight.bold);

  get _text12 => const TextStyle(fontSize: 12);

  get _fakeDept => "TODO";

  get _fakeWorker => "TODO";

  get _fakeTime => "TODO";

  final String _randomStr = "TODO";

  Future<bool> _showMyDialog(String name, String path) async {
    return showDialog<bool>(
        context: context,
        barrierDismissible: false, // user must tap button!
        builder: (context) => StudentViewDocumentDialog(
              name: name,
              path: path,
              isNeedConfirm: false,
            ));
  }
}
