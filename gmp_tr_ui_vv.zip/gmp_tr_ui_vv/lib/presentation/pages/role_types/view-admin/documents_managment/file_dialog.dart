import 'package:flutter/material.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'dart:ui' as ui;
// import 'dart:html' as html;

// import 'package:syncfusion_flutter_pdf/pdf.dart';

class FileDialog extends StatefulWidget {
  final List<DocumentFiles> documentFiles;
  const FileDialog({Key key, this.documentFiles}) : super(key: key);

  @override
  _FileDialogState createState() => _FileDialogState();
}

class _FileDialogState extends State<FileDialog> {
  @override
  void initState() {
    super.initState();
    AppBloc.documentsBloc.add(OnLoadDocuments());
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 700,
        height: 600,
        child: ListView.builder(
            itemCount: widget.documentFiles.length,
            itemBuilder: (context, index) {
              //ignore: undefined_prefixed_name
              // ui.platformViewRegistry.registerViewFactory('iframe',
              //     (int viewId) {
              //   var iframe = html.IFrameElement();
              //   iframe.src = 'http://139.9.146.31:3333' +
              //       '${widget.documentFiles[index].path}#toolbar=0';
              //   iframe.style.border = 'none';
              //   return iframe;
              // });

              return Container(
                width: 700,
                height: 480,
                child: HtmlElementView(
                  viewType: 'iframe',
                ),
              );
            }),
      ),
    );
  }
}
