import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class VADocumentFeatureManagementPage extends StatefulWidget {
  const VADocumentFeatureManagementPage({Key key}) : super(key: key);

  @override
  _VADocumentFeatureManagementPageState createState() =>
      _VADocumentFeatureManagementPageState();
}

class _VADocumentFeatureManagementPageState
    extends State<VADocumentFeatureManagementPage> {
  @override
  void initState() {
    super.initState();
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Translate.of(context)
                        .translate('document_feature_page_heading'),
                    style: TextStyle(
                        color: Color(0xff00439E),
                        fontSize: widthOfScreen(context) * 0.025,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                child: BlocBuilder<DocumentsFeatureListBloc,
                        DocumentsFeatureListState>(
                    bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
                    builder: (context, documentsFeatureList) {
                      if (documentsFeatureList is DocumentsFeatureLoading) {
                        return Center(child: CircularProgressIndicator());
                      } else if (documentsFeatureList
                          is DocumentsFeatureSuccess) {
                        return Container(
                          decoration: BoxDecoration(
                            border: Border(
                              top: BorderSide(color: Color(0xffD4E5F9)),
                              left: BorderSide(color: Color(0xffD4E5F9)),
                              right: BorderSide(color: Color(0xffD4E5F9)),
                            ),
                          ),
                          child: MyDocDynamicTreeView(
                            actionVisible: false,
                            data: documentsFeatureList.documentsFeature,
                            width: screenWidth * 0.7,
                            config: DocConfig(
                                rootId: "null",
                                parentPaddingEdgeInsets: EdgeInsets.only(
                                    left: 16, top: 0, bottom: 0)),
                          ),
                        );
                      } else if (documentsFeatureList is DocumentsFeatureFail) {
                        return Container(
                          child: Text(documentsFeatureList.code),
                        );
                      } else {
                        return Container(
                          child: Text(""),
                        );
                      }
                    }),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
