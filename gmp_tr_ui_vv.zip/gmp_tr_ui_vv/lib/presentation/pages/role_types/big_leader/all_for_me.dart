import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_document.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/document_detail.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'widgets/big_leader_sign_dialog.dart';
import 'widgets/big_leader_sign_or_back_dialog.dart';
import 'widgets/filters_box.dart';

///DATA TABLE VARIABLE DECLARATION
bool checkedBox = false;
List<int> selectedTaskIds = [];
List<int> selectedDocIds = [];
List<Task> paginatedTask = [];
final int rowsPerPage = 10;
List<DocumentsModel> paginatedDocuments = [];
List<int> taskIds = [];
List<int> docIds = [];

class BLAllForMePage extends StatefulWidget {
  const BLAllForMePage({Key key}) : super(key: key);

  @override
  _BLAllForMePageState createState() => _BLAllForMePageState();
}

class _BLAllForMePageState extends State<BLAllForMePage> {
  BigLeaderWidgets selectedWidgetPage = BigLeaderWidgets.dashboard;
  int taskStatusId = 12;

  Task task;
  DocumentsModel document;
  @override
  void initState() {
    super.initState();
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], bigLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  _signOrBackDoc(bool isSign, List<int> docIds) async {
    int userId = await showDialog(
      context: context,
      builder: (context) => BigLeaderSignOrBackDialog(Application.user.departmentIdFk, isSign),
    );
    if (userId != null) {
      isSign ? await Api.smallLeaderSignDoc(docIds, userId) : await Api.smallLeaderBackDoc(docIds, userId);

      AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(bigLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    }
  }

  _signTask(List<int> taskIds) async {
    bool userId = await showDialog(
      context: context,
      builder: (context) => BigLeaderSignDialog(),
    );
    if (userId) {
      await Api.signTask(taskIds, 6);

      AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
        ViewType.regularTask
      ], bigLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    }
  }

  _backTask(bool isSign, List<int> taskIds) async {
    int userId = await showDialog(
      context: context,
      builder: (context) => BigLeaderSignOrBackDialog(Application.user.departmentIdFk, isSign),
    );
    if (userId != null) {
      await Api.bigLeaderBackTask(
        taskIds,
        userId,
        4,
      );
      AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
        ViewType.regularTask
      ], bigLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    }
  }

  Widget getCustomContainer(context) {
    // switch (selectedWidgetPage) {
    //   case BigLeaderWidgets.dashboard:
    //     return dashboard(context);
    //   case BigLeaderWidgets.taskInfo:
    //     return taskInfo(context);
    //   case BigLeaderWidgets.docInfo:
    //     return docInfo(context);
    // }

    return dashboard(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == BigLeaderWidgets.dashboard) HeadingText(Translate.of(context).translate("all_for_me")),
                  if (selectedWidgetPage == BigLeaderWidgets.taskInfo || selectedWidgetPage == BigLeaderWidgets.docInfo) Container(),
                  if (selectedWidgetPage == BigLeaderWidgets.taskInfo)
                    Tooltip(
                      message: Translate.of(context).translate('close'),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedWidgetPage = BigLeaderWidgets.dashboard;
                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                                viewType: [
                                  ViewType.regularTask
                                ],
                                // selectedWidget == BigLeaderWidgets.taskInfo
                                //     ? [ViewType.regularTask]
                                //     : 3,
                                bigLeaderIdFk: Application.user.id,
                                taskDocStatusId: taskStatusId));
                          });
                        },
                        child: Icon(
                          Icons.close,
                          color: Color(0xff00A4E3),
                          size: 20,
                        ),
                      ),
                    ),
                  if (selectedWidgetPage == BigLeaderWidgets.docInfo)
                    Tooltip(
                      message: Translate.of(context).translate('close'),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedWidgetPage = BigLeaderWidgets.dashboard;
                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                                viewType: [
                                  ViewType.documents
                                ],
                                // selectedWidget == BigLeaderWidgets.taskInfo
                                //     ? [ViewType.regularTask]
                                //     : 3,
                                bigLeaderIdFk: Application.user.id,
                                taskDocStatusId: taskStatusId));
                          });
                        },
                        child: Icon(
                          Icons.close,
                          color: Color(0xff00A4E3),
                          size: 20,
                        ),
                      ),
                    ),
                ],
              ),
              Container(child: getCustomContainer(context))
            ],
          ),
        ),
      ],
    );
  }

  Widget dashboard(context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BLFiltersBox(taskStatusId: taskStatusId),
        const SizedBox(height: 20),
        BlocBuilder<TaskDocBloc, TaskDocState>(
          bloc: BlocProvider.of<TaskDocBloc>(context),
          builder: (context, state) {
            if (state is TaskDocSuccess) {
              TaskDataSource taskDataSource;
              DocDataSource docDataSource;
              taskDataSource = new TaskDataSource(
                state.tasks,
                context,
                taskStatusId,
              );

              List<Task> taskCount = state.tasks;
              List<DocumentsModel> docCount = state.documents;

              docDataSource = new DocDataSource(
                state.documents,
                context,
                taskStatusId,
              );

              return LayoutBuilder(builder: (context, constraints) {
                return Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.5,
                          width: constraints.maxWidth,
                          child: SfDataGrid(
                            allowSorting: true,
                            source: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                            columnWidthMode: ColumnWidthMode.fill,
                            columns: [
                              GridColumn(
                                columnName: 'id',
                                width: 50,
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.center,
                                  child: Checkbox(
                                    value: checkedBox,
                                    onChanged: (value) {
                                      setState(() {
                                        checkedBox = value;
                                        if (value == true) {
                                          if (taskDataSource.rows.length > 0) {
                                            state.tasks.forEach((e) {
                                              if (taskIds.length < taskDataSource.rows.length) {
                                                taskIds.add(e.id);
                                              }
                                            });
                                          } else {
                                            state.documents.forEach((e) {
                                              if (docIds.length < docDataSource.rows.length) {
                                                docIds.add(e.id);
                                              }
                                            });
                                          }
                                        } else {
                                          if (taskDataSource.rows.length > 0) {
                                            taskIds.clear();
                                          } else {
                                            docIds.clear();
                                          }
                                        }
                                      });
                                    },
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'title',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('title'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'description',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('description'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'version',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('version'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'beginTime',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('begin_time'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                  columnName: 'endTime',
                                  label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('end_time'),
                                      ))),
                              GridColumn(
                                columnName: 'createdDepWorker',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('created_dep_worker'),
                                  ),
                                ),
                              ),
                              if (taskDataSource.rows.length > 0)
                                GridColumn(
                                  columnName: 'students',
                                  minimumWidth: 150,
                                  label: Container(
                                    height: 50,
                                    color: Color(0xffEFF5FC),
                                    padding: EdgeInsets.all(16.0),
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      Translate.of(context).translate('students'),
                                    ),
                                  ),
                                ),
                              GridColumn(
                                columnName: 'filters',
                                label: Expanded(
                                  child: Container(
                                    height: 26,
                                    width: 130,
                                    constraints: BoxConstraints(maxHeight: 30),
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.black12, width: 1),
                                      borderRadius: BorderRadius.all(Radius.circular(4)),
                                    ),
                                    child: DropdownButton(
                                      onChanged: (val) {
                                        if (val == 1) {
                                          selectedTaskIds.isNotEmpty ? _signTask(selectedTaskIds) : _signOrBackDoc(true, selectedDocIds);
                                        } else if (val == 2) {
                                          selectedTaskIds.isNotEmpty ? _backTask(false, selectedTaskIds) : _signOrBackDoc(false, selectedDocIds);
                                        }
                                      },
                                      icon: const Icon(Icons.expand_more_outlined),
                                      underline: Container(color: Colors.white),
                                      hint: Text(Translate.of(context).translate("bulk_actions"), style: TextStyle(fontSize: 12)),
                                      items: [
                                        DropdownMenuItem(
                                          value: 1,
                                          child: Text(Translate.of(context).translate('sign'), style: TextStyle(fontSize: 12)),
                                        ),
                                        DropdownMenuItem(
                                          value: 2,
                                          child: Text(Translate.of(context).translate('back'), style: TextStyle(fontSize: 12)),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                            ],
                            selectionMode: SelectionMode.single,
                            onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                              if (taskDataSource.rows.length > 0) {
                                final index = taskDataSource.rows.indexOf(addedRows.last);
                                print("task >>> $index");
                              } else {
                                final index = docDataSource.rows.indexOf(addedRows.last);
                                print("document >>>> $index");
                              }
                              return true;
                            },
                            onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) async {
                              if (taskDataSource.rows.length > 0) {
                                final index = taskDataSource.rows.indexOf(addedRows.last);
                                await showDialog(
                                    context: context,
                                    builder: (context) => CreatorTaskInfoWidget(
                                          taskInfo: paginatedTask[index],
                                        ));
                                // setState(() {
                                //   selectedWidgetPage =
                                //       BigLeaderWidgets.taskInfo;
                                //   task = taskCount[index];
                                // });
                              } else {
                                final index = docDataSource.rows.indexOf(addedRows.first);
                                print("document >>>> $index");
                                await showDialog(
                                  context: context,
                                  builder: (context) => DocumentDetailPage(documentInfo: paginatedDocuments[index]),
                                );
                                // setState(() {
                                //   selectedWidgetPage = BigLeaderWidgets.docInfo;
                                //   document = docCount[index];
                                // });
                              }
                            },
                          ),
                        ),
                        Container(
                          height: 52,
                          width: constraints.maxWidth,
                          child: SfDataPager(
                            delegate: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                            pageCount: taskDataSource.rows.length > 0 ? (taskCount.length / rowsPerPage).ceilToDouble() : docCount.length / rowsPerPage,
                            direction: Axis.horizontal,
                          ),
                        )
                      ],
                    ),
                  ],
                );
              });
            } else if (state is TaskDocLoading) {
              return LoadingBox();
            } else if (state is TaskDocEmpty) {
              return Center(child: Text("No Records"));
            } else {
              return Text("load failed.");
            }
          },
        ),
      ],
    );
  }

  // Widget taskInfo(context) {
  //   return TaskInfoWidget(taskInfo: task);
  // }

  // Widget docInfo(context) {
  //   return DocumentDetailPage(documentInfo: document);
  // }
}

class TaskDataSource extends DataGridSource {
  BuildContext contxt;
  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  List<int> enableCheckboxFor = [
    4
  ];

  TaskDataSource(List<Task> tasksData, context, int statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    try {
      if (tasks.length < rowsPerPage) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  _signTask(List<int> taskIds) async {
    print(taskIds);
    bool userId = await showDialog(
      context: contxt,
      builder: (context) => BigLeaderSignDialog(),
    );
    if (userId) {
      await Api.signTask(taskIds, 6);

      AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
        ViewType.regularTask
      ], bigLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    }
  }

  _backTask(bool isSign, List<int> taskIds) async {
    int userId = await showDialog(
      context: contxt,
      builder: (context) => BigLeaderSignOrBackDialog(Application.user.departmentIdFk, isSign),
    );

    if (userId != null) {
      await Api.bigLeaderBackTask(
        taskIds,
        userId,
        7,
      );
      AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
        ViewType.regularTask
      ], bigLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    }
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell(columnName: 'id', value: e.selected),
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.taskDocuments.first.document.version),
              DataGridCell<String>(columnName: 'beginTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.startDate)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'students',
                value: e.taskStudents.fold<String>("", (previousValue, element) => previousValue + element.taskUser.username + ', '),
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.center,
          child: enableCheckboxFor.contains(row.getCells()[8].value.taskStatusIdFk)
              ? Checkbox(
                  value: taskIds.contains(row.getCells()[8].value.id),
                  onChanged: (value) {
                    var index;
                    if (value) {
                      selectedTaskIds = taskIds;
                      selectedTaskIds.add(row.getCells()[8].value.id);
                      index = _tasks.indexOf(row);
                    } else {
                      selectedTaskIds = taskIds;
                      index = _tasks.indexOf(row);
                      selectedTaskIds.remove(row.getCells()[8].value.id);
                    }

                    row.getCells()[0] = DataGridCell(value: taskIds.contains(row.getCells()[8].value.id), columnName: 'id');
                    notifyDataSourceListeners(rowColumnIndex: RowColumnIndex(index, 0));
                  },
                )
              : Checkbox(value: false, onChanged: null),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[1].value.toString(), child: Text(row.getCells()[1].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[2].value.toString(), child: Text(row.getCells()[2].value)),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[3].value.toString(), child: Text(row.getCells()[3].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[4].value.toString(), child: Text(row.getCells()[4].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[5].value.toString(), child: Text(row.getCells()[5].value)),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[6].value.toString(), child: Text(row.getCells()[6].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[7].value.toString(), child: Text(row.getCells()[7].value.toString())),
          ),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              TaskStatusWidget(taskStatusId: row.getCells()[8].value.taskStatusIdFk),
              SizedBox(width: 10),
              row.getCells()[8].value.taskStatusIdFk == 4
                  ? Tooltip(
                      message: Translate.of(contxt).translate("sign_task"),
                      child: InkWell(
                        onTap: () {
                          _signTask([
                            row.getCells()[8].value.id
                          ]);
                        },
                        child: Icon(
                          Icons.check_outlined,
                          color: Color(0xff00A4E3),
                        ),
                      ),
                    )
                  : SizedBox(),
              SizedBox(width: 10),
              InkWell(
                onTap: () => _backTask(false, [
                  row.getCells()[8].value.id
                ]),
                child: Icon(
                  Icons.arrow_back_outlined,
                  color: Color(0xff00A4E3),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// DOCUMENT TYPE
class DocDataSource extends DataGridSource {
  BuildContext contxt;
  int statusId;
  Task task;
  final Completer _completer = new Completer();
  List<int> enableCheckboxFor = [
    4
  ];

  DocDataSource(List<DocumentsModel> documentsData, context, int docStatusId) {
    try {
      documents = documentsData;
      contxt = context;
      statusId = docStatusId;

      if (documents.length < rowsPerPage) {
        paginatedDocuments = documents.toList();
      } else {
        paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  _signOrBackDoc(bool isSign, List<int> docIds) async {
    int userId = await showDialog(
      context: contxt,
      builder: (context) => BigLeaderSignOrBackDialog(Application.user.departmentIdFk, isSign),
    );
    if (userId != null) {
      isSign ? await Api.smallLeaderSignDoc(docIds, userId) : await Api.smallLeaderBackDoc(docIds, userId);

      AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
        ViewType.documents
      ], smallLeaderIdFk: Application.user.id, taskDocStatusId: statusId));
    }
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell(columnName: 'id', value: e.selected),
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.version),
              DataGridCell<String>(columnName: 'beginTime', value: ""),
              DataGridCell<String>(columnName: 'endTime', value: ""),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.docCreator.creatorDepartment.name + ", " + e.docCreator.name,
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.center,
          child: enableCheckboxFor.contains(row.getCells()[7].value.status)
              ? Checkbox(
                  value: docIds.contains(row.getCells()[7].value.id),
                  onChanged: (value) {
                    int index = _documents.indexOf(row);
                    if (value) {
                      selectedDocIds = docIds;
                      selectedDocIds.add(row.getCells()[7].value.id);
                    } else {
                      selectedDocIds = docIds;
                      selectedDocIds.remove(row.getCells()[7].value.id);
                    }
                    row.getCells()[0] = DataGridCell(value: docIds.contains(row.getCells()[7].value.id), columnName: 'id');
                    notifyDataSourceListeners(rowColumnIndex: RowColumnIndex(index, 0));
                  },
                )
              : Checkbox(value: false, onChanged: null),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[1].value.toString(), child: Text(row.getCells()[1].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[2].value.toString(), child: Text(row.getCells()[2].value)),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[3].value.toString(), child: Text(row.getCells()[3].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[6].value.toString(), child: Text(row.getCells()[6].value.toString())),
          ),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              InkWell(
                onTap: () {
                  _signOrBackDoc(true, [
                    row.getCells()[7].value.id
                  ]);
                },
                child: Icon(
                  Icons.check_outlined,
                  color: Color(0xff00A4E3),
                ),
              ),
              SizedBox(width: 10),
              InkWell(
                onTap: () => _signOrBackDoc(false, [
                  row.getCells()[7].value.id
                ]),
                child: Icon(
                  Icons.arrow_back_outlined,
                  color: Color(0xff00A4E3),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
