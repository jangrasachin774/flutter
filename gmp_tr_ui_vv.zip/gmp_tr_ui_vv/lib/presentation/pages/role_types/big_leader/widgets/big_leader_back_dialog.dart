import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/department_users/bloc.dart';
import 'package:gmptr/models/model_users_by_id.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/selection_box.dart';
import 'package:gmptr/utils/translate.dart';

class BigLeaderBackDialog extends StatefulWidget {
  final int departmentId;

  const BigLeaderBackDialog(this.departmentId, {Key key}) : super(key: key);

  @override
  _BigLeaderBackDialogState createState() => _BigLeaderBackDialogState();
}

class _BigLeaderBackDialogState extends State<BigLeaderBackDialog> {
  final userSelection = SelectionBoxController();
  final smallLeaderRoleId = 3;

  @override
  void initState() {
    super.initState();
    AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(
        departmentId: widget.departmentId, roleId: smallLeaderRoleId));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(
                Translate.of(context).translate("choose_small_leader"),
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlueAccent),
              ),
              const SizedBox(height: 35),
              // selection box, choose user
              BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
                bloc: BlocProvider.of<DepartmentUsersBloc>(context),
                builder: (context, state) {
                  if (state is DepartmentUsersSuccess) {
                    return SelectionBox<ReadUsersByIdModel>(
                      leading: null,
                      hint: "choose small leader",
                      controller: userSelection,
                      items: state.departmentsUser,
                      getText: (e) => e.name,
                    );
                  } else if (state is DepartmentUsersLoading) {
                    return LoadingBox(height: 20, width: 20);
                  } else {
                    return SelectionBox(
                      leading: null,
                      items: [],
                      getText: (e) => "",
                      controller: userSelection,
                      hint: "empty",
                    );
                  }
                },
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 45,
                child: ElevatedButton(
                    onPressed: () => _confirm(context),
                    child: Text(Translate.of(context).translate("confirm"))),
              )
            ]),
          ),
          Positioned(
            right: 0,
            child: IconButton(
              icon: Icon(Icons.close_outlined),
              onPressed: () => Navigator.of(context).pop(),
            ),
          )
        ],
      ),
    );
  }

  _confirm(BuildContext context) async {
    if (userSelection.value == null) {
      Navigator.of(context).pop();
      return;
    }
    Navigator.of(context).pop(userSelection.value.id);
  }
}
