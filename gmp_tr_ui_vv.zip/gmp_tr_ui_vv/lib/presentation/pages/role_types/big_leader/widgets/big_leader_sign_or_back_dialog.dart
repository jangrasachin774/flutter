import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/selection_box.dart';
import 'package:gmptr/utils/translate.dart';

class BigLeaderSignOrBackDialog extends StatefulWidget {
  final int departmentId;
  final bool isSign;

  const BigLeaderSignOrBackDialog(this.departmentId, this.isSign, {Key key})
      : super(key: key);

  @override
  _BigLeaderSignOrBackDialogState createState() =>
      _BigLeaderSignOrBackDialogState();
}

class _BigLeaderSignOrBackDialogState extends State<BigLeaderSignOrBackDialog> {
  final userSelection = SelectionBoxController();
  final creatorRoleId = 2;
  final studentsRoleId = 4;

  @override
  void initState() {
    super.initState();
    AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(
        departmentId: widget.departmentId,
        roleId: widget.isSign ? studentsRoleId : creatorRoleId));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(
                Translate.of(context).translate(
                    widget.isSign ? "choose_big_leader" : "choose_creator"),
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlueAccent),
              ),
              const SizedBox(height: 35),
              // selection box, choose user
              BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
                bloc: BlocProvider.of<DepartmentUsersBloc>(context),
                builder: (context, state) {
                  if (state is DepartmentUsersSuccess) {
                    return SelectionBox<ReadUsersByIdModel>(
                      leading: null,
                      hint: widget.isSign
                          ? "choose big leader"
                          : "choose creator",
                      controller: userSelection,
                      items: state.departmentsUser,
                      getText: (e) => e.name,
                    );
                  } else if (state is DepartmentUsersLoading) {
                    return LoadingBox(height: 20, width: 20);
                  } else {
                    return SelectionBox(
                      leading: null,
                      items: [],
                      getText: (e) => "",
                      controller: userSelection,
                      hint: "empty",
                    );
                  }
                },
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 45,
                child: ElevatedButton(
                    onPressed: () => _confirm(context),
                    child: Text(Translate.of(context).translate("confirm"))),
              )
            ]),
          ),
          Positioned(
            right: 0,
            child: IconButton(
              icon: Icon(Icons.close_outlined),
              onPressed: () => Navigator.of(context).pop(),
            ),
          )
        ],
      ),
    );
  }

  _confirm(BuildContext context) async {
    if (userSelection.value == null) {
      Navigator.of(context).pop();
      return;
    }
    Navigator.of(context).pop(userSelection.value.id);
  }
}
