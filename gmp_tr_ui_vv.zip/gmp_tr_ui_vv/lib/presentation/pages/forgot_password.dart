import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/image.dart';
import 'package:gmptr/configs/routes.dart';
import 'package:gmptr/presentation/widgets/app_button.dart';
import 'package:gmptr/presentation/widgets/app_text_input.dart';
import 'package:gmptr/utils/other.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:gmptr/utils/validate.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key key}) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ForgotPassword> {
  final _textEmailController = TextEditingController();

  String _validEmail;

  String _errMsg = "";

  Future<void> _forgotPassword() async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      if (_textEmailController.text != null)
        _validEmail = UtilValidator.validate(data: _textEmailController.text);
    });
    if (_validEmail == null) {}
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // background image
          Container(
            decoration: BoxDecoration(
              color: const Color(0xff00439E),
              image: DecorationImage(
                image: AssetImage(Images.LoginBg),
                fit: BoxFit.cover,
              ),
            ),
          ),

          // card
          Scaffold(
            backgroundColor: Colors.transparent,
            body: Center(
              child: Container(
                width: 420,
                height: 510,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.2),
                  color: Colors.white,
                ),
                padding: EdgeInsets.symmetric(vertical: 30, horizontal: 40),
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    // logo
                    Image(image: AssetImage(Images.Logo)),
                    const SizedBox(height: 20),

                    // title: reset password
                    Text(
                      Translate.of(context).translate('forgot_password'),
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),

                    // err msg
                    if (_errMsg.isNotEmpty)
                      Container(
                        height: 40,
                        alignment: Alignment.bottomCenter,
                        child: Text(
                          Translate.of(context)
                              .translate(_errMsg.toLowerCase()),
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.redAccent),
                        ),
                      ),
                    SizedBox(height: _errMsg.isNotEmpty ? 20 : 40),

                    // input: email id
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(Translate.of(context).translate('email'),
                            style: _bold12)),
                    const SizedBox(height: 8),
                    AppTextInput(
                      controller: _textEmailController,
                      errorText: Translate.of(context).translate(_validEmail),
                      onTapIcon: () async {
                        _textEmailController.clear();
                      },
                      icon: Icon(
                        Icons.clear,
                        size: 14,
                      ),
                      onChanged: (text) {
                        setState(() {
                          _validEmail = UtilValidator.validate(
                            data: _textEmailController.text,
                            type: ValidateType.email,
                          );
                        });
                      },
                    ),
                    const SizedBox(height: 14),
                    BlocBuilder<LoginBloc, LoginState>(
                      builder: (context, login) {
                        return BlocListener<LoginBloc, LoginState>(
                          listener: (context, state) {
                            if (state is LoginFail) {
                              Text("Invalid Email Id");
                            }
                            if (state is LoginSuccess) {}
                          },
                          child: AppButton(
                            Translate.of(context).translate('submit'),
                            onPressed: _forgotPassword,
                            loading: login is LoginLoading,
                            disabled: login is LoginLoading,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  get _bold12 => const TextStyle(fontSize: 12, fontWeight: FontWeight.bold);
}
