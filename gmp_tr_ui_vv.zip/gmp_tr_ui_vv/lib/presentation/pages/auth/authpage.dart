import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/pages/roles/user_roles.dart';
import 'package:gmptr/presentation/pages/signin/signin.dart';

// ignore: must_be_immutable
class AuthPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthenticationState>(
        builder: (context, state) {
      if (state is AuthenticationFail) {
        return SignIn();
      } else {
        return UserRoleTypes();
        // if (Platform.isAndroid || Platform.isIOS) {
        //   return StudentRoleType();
        // } else {
        //   return UserRoleTypes();
        // }
      }
    });
  }
}
