import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
// import 'package:gmptr/blocs/app_bloc.dart';
// import 'package:gmptr/blocs/authentication/bloc.dart';

import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model_user_login.dart';
// import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:collection/collection.dart';

class UserRoleTypes extends StatefulWidget {
  const UserRoleTypes({Key key}) : super(key: key);

  @override
  _UserRoleTypesState createState() => _UserRoleTypesState();
}

class _UserRoleTypesState extends State<UserRoleTypes> {
  List<UserRoles> userRoles;
  var userPageRoleId;

  @override
  void initState() {
    super.initState();

    userRoles = Application.user.userRoles;

    var roleId = userRoles.firstWhereOrNull((element) => element.roleIdFk == 5);

    if (roleId != null) {
      UtilPreferences.setString(
          Preferences.userRoleId,
          jsonEncode(
            5,
          ));
      userPageRoleId = UtilPreferences.getString(Preferences.userRoleId);
      SchedulerBinding.instance.addPostFrameCallback((_) {
        Navigator.pushNamed(context, Routes.home,
            arguments: int.parse(userPageRoleId));
      });
    } else {
      SchedulerBinding.instance.addPostFrameCallback((_) {
        Navigator.pushNamed(
          context,
          Routes.error,
        );
      });
    }
  }

  //User Roles Navigation
  // void _userRole(int id) {
  //   UtilPreferences.setString(
  //       Preferences.userRoleId,
  //       jsonEncode(
  //         id,
  //       ));
  //   userPageRoleId = UtilPreferences.getString(Preferences.userRoleId);
  //   Navigator.pushNamed(context, Routes.home,
  //       arguments: int.parse(userPageRoleId));
  // }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.loose,
      children: [
        Container(
          decoration: BoxDecoration(
            color: const Color(0xff00439E),
            image: DecorationImage(
              image: AssetImage(Images.LoginBg),
              fit: BoxFit.cover,
            ),
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: Center(
            // child: Container(
            //   width: 420,
            //   height: 620,
            //   decoration: BoxDecoration(
            //     borderRadius: BorderRadius.circular(2.2),
            //     color: Colors.white,
            //   ),
            //   padding: EdgeInsets.symmetric(vertical: 30, horizontal: 40),
            //   alignment: Alignment.center,
            //   child: Column(
            //     mainAxisSize: MainAxisSize.min,
            //     children: [
            //       Image(image: AssetImage(Images.Logo)),
            //       SizedBox(
            //         height: 18,
            //       ),
            //       Text(
            //         Translate.of(context).translate('caption'),
            //         style: TextStyle(fontWeight: FontWeight.bold),
            //       ),
            //       SizedBox(
            //         height: 40,
            //       ),
            //       Center(
            //         child: Text(
            //           Translate.of(context).translate('multiple_roles_desc'),
            //           textAlign: TextAlign.center,
            //         ),
            //       ),
            //       SizedBox(
            //         height: 15,
            //       ),
            //       ListView.builder(
            //         shrinkWrap: true,
            //         itemCount: userRoles.length,
            //         itemBuilder: (context, i) {
            //           return userRoles.length > 0
            //               ? userRoles[i].role.multiButtons == false
            //                   ? Padding(
            //                       padding: const EdgeInsets.all(8.0),
            //                       child: AppButton(
            //                         userRoles[i].role.name,
            //                         type: ButtonType.outline,
            //                         onPressed: () =>
            //                             _userRole(userRoles[i].role.id),
            //                       ),
            //                     )
            //                   : Column(
            //                       children: List.generate(
            //                           userRoles[i].userAdminPagees.length,
            //                           (index) => _userAdminPages(
            //                               userRoles[i].userAdminPagees[index])),
            //                     )
            //               : Container();
            //         },
            //       ),
            //       SizedBox(
            //         height: 10,
            //       ),
            //       TextButton(
            //         child: Text(
            //           Translate.of(context).translate('log_out'),
            //           style: TextStyle(
            //               color: Colors.blue,
            //               fontSize: 14,
            //               fontWeight: FontWeight.bold),
            //         ),
            //         onPressed: () {
            //           AppBloc.authBloc.add(OnClear());
            //           Navigator.popAndPushNamed(context, Routes.signIn);
            //         },
            //       )
            //     ],
            //   ),
            // ),
            child: CircularProgressIndicator(),
          ),
        ),
      ],
    );
  }

  // _userAdminPages(UserAdminPagee userAdminPagee) {
  //   return userAdminPagee.adminPage != null
  //       ? Padding(
  //           padding: const EdgeInsets.all(8.0),
  //           child: AppButton(
  //             userAdminPagee.adminPage.name,
  //             type: ButtonType.outline,
  //             onPressed: () => _userRole(userAdminPagee.adminPageIdFk),
  //           ),
  //         )
  //       : Container();
  // }
}
