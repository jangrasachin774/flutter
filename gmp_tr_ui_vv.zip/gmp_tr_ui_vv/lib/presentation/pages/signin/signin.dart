import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class SignIn extends StatefulWidget {
  final String from;

  const SignIn({Key key, this.from}) : super(key: key);
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final _textIDController = TextEditingController();
  final _textPassController = TextEditingController();
  final _focusID = FocusNode();
  final _focusPass = FocusNode();

  bool _showPassword = false;
  String _validID;
  String _validPass;

  ///On navigate forgot password
  void _forgotPassword() {
    Navigator.pushNamed(context, Routes.forgotPassword);
  }

  ///On login
  void _login() async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text);
      _validPass = UtilValidator.validate(data: _textPassController.text);
    });
    if (_validID == null && _validPass == null) {
      AppBloc.loginBloc.add(OnLogin(
        username: _textIDController.text,
        password: _textPassController.text,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xff00439E),
              image: DecorationImage(
                image: AssetImage(Images.LoginBg),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            body: Center(
              child: Container(
                width: 420,
                height: 450,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.2),
                  color: Colors.white,
                ),
                padding: EdgeInsets.symmetric(vertical: 30, horizontal: 40),
                alignment: Alignment.center,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    // mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image(image: AssetImage(Images.Logo)),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        Translate.of(context).translate('caption'),
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 40,
                      ),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Text(Translate.of(context)
                              .translate('sign_in_account'))),
                      BlocBuilder<LoginBloc, LoginState>(
                          builder: (context, state) {
                        if (state is LoginFail) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              state.code,
                              style: TextStyle(color: AppColors.red),
                            ),
                          );
                        } else {
                          return Text("");
                        }
                      }),
                      AppTextInput(
                        hintText: Translate.of(context).translate('username'),
                        // errorText: Translate.of(context).translate(_validID),
                        icon: Icon(Icons.clear),
                        controller: _textIDController,
                        focusNode: _focusID,
                        textInputAction: TextInputAction.next,
                        onChanged: (text) {
                          setState(() {
                            _validID = UtilValidator.validate(
                              data: _textIDController.text,
                            );
                          });
                        },
                        onSubmitted: (text) {
                          UtilOther.fieldFocusChange(
                              context, _focusID, _focusPass);
                        },
                        onTapIcon: () async {
                          _textIDController.clear();
                        },
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 14),
                      ),
                      AppTextInput(
                        hintText: Translate.of(context).translate('password'),
                        errorText: Translate.of(context).translate(_validPass),
                        textInputAction: TextInputAction.done,
                        onChanged: (text) {
                          setState(() {
                            _validPass = UtilValidator.validate(
                              data: _textPassController.text,
                            );
                          });
                        },
                        onSubmitted: (text) {
                          _login();
                        },
                        onTapIcon: () {
                          setState(() {
                            _showPassword = !_showPassword;
                          });
                        },
                        obscureText: !_showPassword,
                        icon: Icon(
                          _showPassword ? Icons.visibility : Icons.visibility_off,
                        ),
                        controller: _textPassController,
                        focusNode: _focusPass,
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 26),
                      ),
                      BlocBuilder<LoginBloc, LoginState>(
                        builder: (context, login) {
                          return BlocListener<LoginBloc, LoginState>(
                            listener: (context, state) {
                              if (state is LoginFail) {
                                Text("Login fail");
                              }
                              if (state is LoginSuccess) {
                                Navigator.pushNamed(context, Routes.roles);
                              }
                            },
                            child: AppButton(
                              Translate.of(context).translate('sign_in'),
                              onPressed: _login,
                              loading: login is LoginLoading,
                              disabled: login is LoginLoading,
                            ),
                          );
                        },
                      ),
                      // Padding(
                      //   padding: EdgeInsets.only(top: 10),
                      // ),

                      ///TODO - FORGOT PASSWORD
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.center,
                      //   crossAxisAlignment: CrossAxisAlignment.center,
                      //   children: <Widget>[
                      //     AppButton(
                      //       Translate.of(context).translate('forgot_password'),
                      //       onPressed: _forgotPassword,
                      //       type: ButtonType.text,
                      //       color: Color(0xff787E8C),
                      //     ),
                      //   ],
                      // ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
