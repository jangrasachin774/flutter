import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

typedef OnTrainingTap = Function(Map data);

class MyTrainingsTypeDynamicTreeView extends StatefulWidget {
  final List<TrainingsType> data;

  final OnTrainingTap onTap;

  final double width;

  final bool actionVisible;

  ///Configuration object for [MyTrainingsTypeDynamicTreeView]
  final TrainingsConfig config;
  MyTrainingsTypeDynamicTreeView({
    @required this.data,
    this.config = const TrainingsConfig(),
    this.onTap,
    this.width = 220.0,
    this.actionVisible,
  }) : assert(data != null);

  @override
  _MyDynamicTreeViewOriState createState() => _MyDynamicTreeViewOriState();
}

class _MyDynamicTreeViewOriState extends State<MyTrainingsTypeDynamicTreeView> {
  List<TrainingsParentWidget> treeView;
  ChildTapListener _childTapListener = ChildTapListener(null);
  final _textIDController = TextEditingController();
  final _textEditController = TextEditingController();

  String _validID;
  String _validEditID;

  var _focusID = FocusNode();
  @override
  void initState() {
    _buildTreeView();
    _childTapListener.addListener(childTapListener);
    super.initState();
  }

  void childTapListener() {
    if (widget.onTap != null) {
      var k = _childTapListener.getMapValue();
      widget.onTap(k);
    }
  }

  ///On create department Level
  _createDocFeature(parentId, level) async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text, min: 1);
    });
    if (_validID == null) {
      print(parentId);
      print(_textIDController.text);
      AppBloc.trainingsTypeBlocs.add(OnAddTrainingType(
          name: _textIDController.text, parentId: parentId, level: ++level));
      AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    }
  }

  ///Create TrainingType Form Level
  Future<void> _showForm(parentId, level) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  autoFocus: true,
                  hintText: Translate.of(context).translate('department_name'),
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textIDController,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      print(text);
                      _validID = UtilValidator.validate(
                        data: _textIDController.text,
                      );
                    });
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                    bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                    builder: (context, save) {
                      return BlocListener<TrainingsTypeListBloc,
                          TrainingsTypeListState>(
                        listener: (context, state) {
                          if (state is TrainingsTypsaveFail) {
                            Text(state.code);
                          }
                          if (state is TrainingsTypsaveSuccess) {
                            Text("Success");
                          }
                        },
                        child: AppButton(
                          Translate.of(context).translate('create'),
                          onPressed: () => _createDocFeature(parentId, level),
                          type: ButtonType.normal,
                          loading: save is TrainingsTypsaving,
                          disabled: save is TrainingsTypsaving,
                          color: Color(0xff787E8C),
                        ),
                      );
                    })
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  /// ON UPDATE CHILD
  void _updateDepartLevel2(id) {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validEditID =
          UtilValidator.validate(data: _textEditController.text, min: 1);
    });
    if (_validEditID == null) {
      print(id);
      AppBloc.trainingsTypeBlocs
          .add(OnUpdateTrainingType(name: _textEditController.text, id: id));
      AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    }
  }

  Future<void> _onEdit(id, name) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  hintText: name,
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textEditController..text = name,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      _validEditID = UtilValidator.validate(
                        data: _textEditController.text,
                      );
                    });
                  },
                  onSubmitted: (text) {
                    _updateDepartLevel2(id);
                    _textEditController.clear();
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                AppButton(
                  Translate.of(context).translate('update'),
                  onPressed: () {
                    setState(() {
                      _updateDepartLevel2(id);
                    });
                  },
                  type: ButtonType.normal,
                  color: Color(0xff787E8C),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  ///ON DELETE CHILD
  void _onDelete(id) {
    AppBloc.trainingsTypeBlocs.add(OnRemoveTrainingType(id: id));
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
  }

  @override
  void dispose() {
    _childTapListener.removeListener(childTapListener);
    _childTapListener.dispose();
    super.dispose();
  }

  _buildTreeView() {
    print("data ${widget.data}");
    var k = widget.data
        .where((data) {
          return data.getParentId() == widget.config.rootId;
        })
        .map((data) {
          print("map $data");
          return data.getId();
        })
        .toSet()
        .toList()
          ..sort((i, j) => i.compareTo(j));

    List<TrainingsParentWidget> widgets = [];
    k.forEach((f) {
      TrainingsParentWidget p = buildWidget(f, null);
      if (p != null) widgets.add(p);
    });
    setState(() {
      treeView = widgets;
    });
  }

  TrainingsParentWidget buildWidget(String parentId, String name) {
    var data = _getChildrenFromParent(parentId);
    TrainingsType d =
        widget.data.firstWhere((d) => d.getId() == parentId.toString());
    if (name == null) {
      name = d.getTitle();
    }

    var p = TrainingsParentWidget(
      buttonsVisible: widget.actionVisible,
      baseData: d,
      onTap: widget.onTap,
      config: widget.config,
      children: _buildChildren(data),
      key: ObjectKey({
        'id': '${d.getId()}',
        'parent_id': '${d.getParentId()}',
        'title': '${d.getTitle()}',
      }),
    );
    return p;
  }

  _buildChildren(List<TrainingsType> data) {
    List<Widget> cW = [];
    for (var k in data) {
      var c = _getChildrenFromParent(k.getId());
      if ((c?.length ?? 0) > 0) {
        //has children
        var name = widget.data
            .firstWhere((d) => d.getId() == k.getId().toString())
            .getTitle();
        cW.add(buildWidget(k.getId(), name));
      } else {
        cW.add(InkWell(
          onTap: () {},
          onHover: (value) {
            k.isHovered = value;
          },
          child: ListTile(
            hoverColor: Color(0xffEFF5FC),
            leading: SizedBox(
              width: 30,
            ),
            onTap: () {
              widget?.onTap({
                'id': '${k.getId()}',
                'parent_id': '${k.getParentId()}',
                'title': '${k.getTitle()}',
              });
            },
            contentPadding: EdgeInsets.only(
                left: 15.0 * (k.level.toDouble()), top: 0, bottom: 0),
            title: Text(
              "${k.getTitle()}",
              style: widget.config.childrenTextStyle,
            ),
            trailing: Container(
              width: 100,
              height: 30,
              child: Row(
                children: [
                  widget.actionVisible == true
                      ? InkWell(
                          onTap: () {
                            _onEdit(int.parse(k.getId()), k.getTitle());
                          },
                          child: Icon(
                            Icons.edit_outlined,
                            color: Color(0xff00A4E3),
                          ),
                        )
                      : SizedBox(),
                  SizedBox(
                    width: 10,
                  ),
                  widget.actionVisible == true
                      ? InkWell(
                          onTap: () {
                            _showForm(int.parse(k.getId()), k.level);
                          },
                          child: Icon(
                            Icons.add,
                            color: Color(0xff31B5E8),
                          ),
                        )
                      : SizedBox(),
                  SizedBox(
                    width: 10,
                  ),
                  widget.actionVisible == true
                      ? InkWell(
                          onTap: () {
                            _onDelete(int.parse(k.getId()));
                          },
                          child: Icon(
                            Icons.delete_forever_outlined,
                            color: Color(0xff00A4E3),
                          ),
                        )
                      : SizedBox(),
                ],
              ),
            ),
          ),
        ));
      }
    }
    return cW;
  }

  List<TrainingsType> _getChildrenFromParent(String parentId) {
    return widget.data
        .where((data) => data.getParentId() == parentId.toString())
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return treeView != null
        ? SingleChildScrollView(
            child: Container(
              width: widget.width,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: treeView,
                ),
                physics: BouncingScrollPhysics(),
              ),
            ),
            scrollDirection: Axis.horizontal,
            physics: BouncingScrollPhysics(),
          )
        : Container();
  }
}

class TrainingChildWidget extends StatefulWidget {
  final List<Widget> children;
  final bool shouldExpand;
  final TrainingsConfig config;
  final id;
  TrainingChildWidget(
      {this.children, this.config, this.shouldExpand = false, this.id});

  @override
  _ChildWidgetState createState() => _ChildWidgetState();
}

class _ChildWidgetState extends State<TrainingChildWidget>
    with SingleTickerProviderStateMixin {
  Animation<double> sizeAnimation;
  AnimationController expandController;

  @override
  void didUpdateWidget(TrainingChildWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.shouldExpand) {
      expandController.forward();
    } else {
      expandController.reverse();
    }
  }

  @override
  void initState() {
    prepareAnimation();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    expandController.dispose();
  }

  void prepareAnimation() {
    expandController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    Animation curve =
        CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    sizeAnimation = Tween(begin: 0.0, end: 1.0).animate(curve)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return SizeTransition(
      sizeFactor: sizeAnimation,
      axisAlignment: -1.0,
      child: Column(
        children: _buildChildren(),
      ),
    );
  }

  _buildChildren() {
    return widget.children.map((c) {
      // return c;
      return Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: Color(0xffD4E5F9)),
          ),
        ),
        child: Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: widget.config.childrenPaddingEdgeInsets,
              child: c,
            )),
      );
    }).toList();
  }
}

class TrainingsParentWidget extends StatefulWidget {
  final List<Widget> children;
  final TrainingsType baseData;
  final TrainingsConfig config;
  final OnTrainingTap onTap;
  final bool buttonsVisible;
  TrainingsParentWidget({
    this.baseData,
    this.onTap,
    this.children,
    this.config,
    this.buttonsVisible,
    Key key,
  }) : super(key: key);

  @override
  _ParentWidgetState createState() => _ParentWidgetState();
}

class _ParentWidgetState extends State<TrainingsParentWidget>
    with SingleTickerProviderStateMixin {
  bool shouldExpand = false;
  Animation<double> sizeAnimation;
  AnimationController expandController;
  final _textIDController = TextEditingController();

  String _validID;
  var _focusID = FocusNode();

  @override
  void dispose() {
    super.dispose();
    expandController.dispose();
  }

  @override
  void initState() {
    prepareAnimation();
    super.initState();
  }

  void prepareAnimation() {
    expandController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    Animation curve =
        CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    sizeAnimation = Tween(begin: 0.0, end: 0.5).animate(curve)
      ..addListener(() {
        setState(() {});
      });
  }

  ///On create department Level
  _createDocFeature(parentId, level) async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text, min: 1);
    });
    if (_validID == null) {
      print(parentId);
      print(_textIDController.text);
      AppBloc.trainingsTypeBlocs.add(OnAddTrainingType(
          name: _textIDController.text, parentId: parentId, level: ++level));
      AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    }
  }

  ///Create TrainingType Form Level
  Future<void> _showForm(parentId, level) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  autoFocus: true,
                  hintText: Translate.of(context).translate('department_name'),
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textIDController,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      print(text);
                      _validID = UtilValidator.validate(
                        data: _textIDController.text,
                      );
                    });
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                    bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                    builder: (context, save) {
                      return BlocListener<TrainingsTypeListBloc,
                          TrainingsTypeListState>(
                        listener: (context, state) {
                          if (state is TrainingsTypsaveFail) {
                            Text(state.code);
                          }
                          if (state is TrainingsTypsaveSuccess) {
                            Text("Success");
                          }
                        },
                        child: AppButton(
                          Translate.of(context).translate('create'),
                          onPressed: () => _createDocFeature(parentId, level),
                          type: ButtonType.normal,
                          loading: save is TrainingsTypsaving,
                          disabled: save is TrainingsTypsaving,
                          color: Color(0xff787E8C),
                        ),
                      );
                    })
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        InkWell(
          hoverColor: Color(0xffEFF5FC),
          onTap: () {
            print("object");
          },
          onHover: (value) {
            setState(() {
              widget.baseData.isHovered = value;
            });
          },
          child: Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xffD4E5F9)),
              ),
            ),
            child: ListTile(
              hoverColor: Color(0xffEFF5FC),
              leading: InkWell(
                highlightColor: Colors.transparent,
                onTap: () {
                  setState(() {
                    shouldExpand = !shouldExpand;
                  });
                  if (shouldExpand) {
                    expandController.forward();
                  } else {
                    expandController.reverse();
                  }
                },
                child: shouldExpand
                    ? Icon(
                        Icons.remove_circle_outline_outlined,
                        color: Color(0xff31B5E8),
                      )
                    : Icon(
                        Icons.add_circle_outlined,
                        color: Color(0xff31B5E8),
                      ),
              ),
              title: Text(widget.baseData.getTitle(),
                  style: widget.config.parentTextStyle),
              contentPadding: EdgeInsets.only(
                  left: 15.0 * (widget.baseData.level.toDouble()),
                  top: 0,
                  bottom: 0),
              trailing: Container(
                width: 30,
                height: 30,
                child:
                    widget.baseData.isHovered && widget.buttonsVisible == true
                        ? InkWell(
                            onTap: () {
                              setState(() {
                                print(widget.baseData.id);
                                _showForm(
                                    widget.baseData.id, widget.baseData.level);
                              });
                            },
                            child: Icon(
                              Icons.add,
                              color: Color(0xff31B5E8),
                            ),
                          )
                        : Container(),
              ),
            ),
          ),
        ),
        TrainingChildWidget(
          children: widget.children,
          id: widget.baseData.id,
          config: widget.config,
          shouldExpand: shouldExpand,
        )
      ],
    );
  }
}

abstract class TrainingBaseData {
  ///id of this data
  String getId();

  /// parentId of a child
  String getParentId();

  /// Text displayed on the parent/child tile
  String getTitle();
}

class TrainingsConfig {
  final TextStyle parentTextStyle;
  final TextStyle childrenTextStyle;
  final EdgeInsets childrenPaddingEdgeInsets;
  final EdgeInsets parentPaddingEdgeInsets;

  ///Animated icon when tile collapse/expand
  final Widget arrowIcon;

  ///the rootid of a treeview.This is needed to fetch all the immediate child of root
  ///Default is null
  final String rootId;

  const TrainingsConfig(
      {this.parentTextStyle =
          const TextStyle(color: Colors.black, fontSize: 12),
      this.parentPaddingEdgeInsets = const EdgeInsets.all(6.0),
      this.childrenTextStyle =
          const TextStyle(color: Colors.black, fontSize: 12),
      this.childrenPaddingEdgeInsets =
          const EdgeInsets.only(left: 0.0, top: 0, bottom: 0),
      this.rootId = "null",
      this.arrowIcon = const Icon(Icons.keyboard_arrow_down)});
}
