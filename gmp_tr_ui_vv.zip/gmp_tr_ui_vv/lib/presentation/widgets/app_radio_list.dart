import 'package:flutter/material.dart';

class MyRadioListTile<T> extends StatelessWidget {
  final T value;
  final T groupValue;
  final String leading;
  final Widget title;
  final ValueChanged<T> onChanged;

  const MyRadioListTile({
    @required this.value,
    @required this.groupValue,
    @required this.onChanged,
    this.leading,
    this.title,
  });

  @override
  Widget build(BuildContext context) {
    final title = this.title;
    return InkWell(
      hoverColor: Colors.transparent,
      onTap: () => onChanged(
        value,
      ),
      child: Container(
        height: 30,
        // padding: EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (title != null) title,
            SizedBox(width: 12),
            _customRadioButton,
          ],
        ),
      ),
    );
  }

  Widget get _customRadioButton {
    final isSelected = value == groupValue;
    return Container(
      width: 20,
      height: 20,
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: isSelected ? Colors.blue : null,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: isSelected ? Colors.blue : Color(0xff9B9B9B),
          width: 2,
        ),
      ),
      child: Text(
        '',
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.grey[600],
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
    );
  }
}
