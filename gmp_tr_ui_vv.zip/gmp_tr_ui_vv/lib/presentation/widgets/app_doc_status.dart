import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gmptr/configs/config.dart';

class DocStatusWidget extends StatelessWidget {
  final int docStatusId;
  const DocStatusWidget({Key key, this.docStatusId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String statusIcon;
    String hintText;
    if (this.docStatusId == 1) {
      statusIcon = CustomIcon.created;
      hintText = "Created";
    } else if (this.docStatusId == 2) {
      statusIcon = CustomIcon.creatorConfirmed;
      hintText = "Creator Confirmed";
    } else if (this.docStatusId == 3) {
      statusIcon = CustomIcon.creatorCancelled;
      hintText = "Creator Cancelled";
    } else if (this.docStatusId == 4) {
      statusIcon = CustomIcon.smallLeaderConfirmed;
      hintText = "Small Leader Confirmed";
    } else if (this.docStatusId == 5) {
      statusIcon = CustomIcon.smallLeaderSentBack;
      hintText = "Small Leader Send Back";
    } else if (this.docStatusId == 6) {
      statusIcon = CustomIcon.bigLeaderConfirmed;
      hintText = "Big Leader Confirmed";
    } else if (this.docStatusId == 7) {
      statusIcon = CustomIcon.bigLeaderSentBack;
      hintText = "Big Leader Sent Back";
    }
    return Container(
      child: Tooltip(
        message: hintText,
        child: SvgPicture.asset(
          statusIcon,
          width: 20,
          height: 20,
        ),
      ),
    );
  }
}
