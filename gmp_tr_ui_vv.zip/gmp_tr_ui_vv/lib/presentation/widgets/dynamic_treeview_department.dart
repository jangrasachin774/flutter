import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

typedef OnDepartTap = Function(Map data);

class MyDynamicTreeView extends StatefulWidget {
  final List<Departments> data;

  final OnDepartTap onTap;

  final double width;
  final bool actionVisible;

  ///Configuration object for [MyDynamicTreeView]
  final Config config;
  MyDynamicTreeView({
    @required this.data,
    this.config = const Config(),
    this.onTap,
    this.width = 220.0,
    this.actionVisible,
  }) : assert(data != null);

  @override
  _MyDynamicTreeViewOriState createState() => _MyDynamicTreeViewOriState();
}

class _MyDynamicTreeViewOriState extends State<MyDynamicTreeView> {
  List<ParentWidget> treeView;
  ChildTapListener _childTapListener = ChildTapListener(null);
  final _textIDController = TextEditingController();
  final _textEditController = TextEditingController();

  String _validID;
  String _validEditID;

  var _focusID = FocusNode();
  @override
  void initState() {
    _buildTreeView();
    _childTapListener.addListener(childTapListener);
    super.initState();
  }

  void childTapListener() {
    if (widget.onTap != null) {
      var k = _childTapListener.getMapValue();
      widget.onTap(k);
    }
  }

  ///On create department Level
  _createDepart(parentId, level) async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text, min: 1);
    });
    if (_validID == null) {
      print(parentId);
      print(_textIDController.text);
      AppBloc.departmentBlocs.add(OnAddDepartment(
          name: _textIDController.text, parentId: parentId, level: ++level));
      AppBloc.departmentBlocs.add(OnLoadDepartments());
    }
  }

  ///Create Department Form Level
  Future<void> _showForm(parentId, level) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  autoFocus: true,
                  hintText: Translate.of(context).translate('department_name'),
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textIDController,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      print(text);
                      _validID = UtilValidator.validate(
                        data: _textIDController.text,
                      );
                    });
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                    bloc: BlocProvider.of<DepartmentsListBloc>(context),
                    builder: (context, save) {
                      return BlocListener<DepartmentsListBloc,
                          DepartmentsListState>(
                        listener: (context, state) {
                          if (state is DepartmentsaveFail) {
                            Text(state.code);
                          }
                          if (state is DepartmentsaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text("Department Added Successfully"),
                            ));
                          }
                        },
                        child: AppButton(
                          Translate.of(context).translate('create'),
                          onPressed: () => _createDepart(parentId, level),
                          type: ButtonType.normal,
                          loading: save is Departmentsaving,
                          disabled: save is Departmentsaving,
                          color: Color(0xff787E8C),
                        ),
                      );
                    })
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  /// ON UPDATE CHILD
  void _updateDepartLevel2(id) {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validEditID =
          UtilValidator.validate(data: _textEditController.text, min: 1);
    });
    if (_validEditID == null) {
      print(id);
      AppBloc.departmentBlocs
          .add(OnUpdateDepartment(name: _textEditController.text, id: id));
      AppBloc.departmentBlocs.add(OnLoadDepartments());
    }
  }

  Future<void> _onEdit(id, name) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  hintText: name,
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textEditController..text = name,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      _validEditID = UtilValidator.validate(
                        data: _textEditController.text,
                      );
                    });
                  },
                  onSubmitted: (text) {
                    _updateDepartLevel2(id);
                    _textEditController.clear();
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                    bloc: BlocProvider.of<DepartmentsListBloc>(context),
                    builder: (context, update) {
                      return BlocListener<DepartmentsListBloc,
                          DepartmentsListState>(
                        listener: (context, state) {
                          if (state is DepartmentUpdatingSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text("Department Updated Successfully"),
                            ));
                          }
                        },
                        child: AppButton(
                          Translate.of(context).translate('update'),
                          onPressed: () {
                            setState(() {
                              _updateDepartLevel2(id);
                            });
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          loading: update is DepartmentUpdating,
                          disabled: update is DepartmentUpdating,
                        ),
                      );
                    }),
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  ///ON DELETE CHILD
  void _onDelete(id) {
    AppBloc.departmentBlocs.add(OnRemoveDepartment(id: id));
    AppBloc.departmentBlocs.add(OnLoadDepartments());
  }

  @override
  void dispose() {
    _childTapListener.removeListener(childTapListener);
    _childTapListener.dispose();
    super.dispose();
  }

  _buildTreeView() {
    var k = widget.data
        .where((data) {
          return data.getParentId() == widget.config.rootId;
        })
        .map((data) {
          return data.getId();
        })
        .toSet()
        .toList()
          ..sort((i, j) => i.compareTo(j));

    List<ParentWidget> widgets = [];
    k.forEach((f) {
      ParentWidget p = buildWidget(f, null);
      if (p != null) widgets.add(p);
    });
    setState(() {
      treeView = widgets;
    });
  }

  ParentWidget buildWidget(String parentId, String name) {
    var data = _getChildrenFromParent(parentId);
    Departments d =
        widget.data.firstWhere((d) => d.getId() == parentId.toString());
    if (name == null) {
      name = d.getTitle();
    }

    var p = ParentWidget(
      buttonVisible: widget.actionVisible,
      baseData: d,
      onTap: widget.onTap,
      config: widget.config,
      children: _buildChildren(data),
      key: ObjectKey({
        'id': '${d.getId()}',
        'parent_id': '${d.getParentId()}',
        'title': '${d.getTitle()}',
      }),
    );
    return p;
  }

  _buildChildren(List<Departments> data) {
    List<Widget> cW = [];
    for (var k in data) {
      var c = _getChildrenFromParent(k.getId());
      if ((c?.length ?? 0) > 0) {
        //has children
        var name = widget.data
            .firstWhere((d) => d.getId() == k.getId().toString())
            .getTitle();
        cW.add(buildWidget(k.getId(), name));
      } else {
        cW.add(InkWell(
          onTap: () {},
          onHover: (value) {
            k.isHovered = value;
          },
          child: ListTile(
            hoverColor: Color(0xffEFF5FC),
            leading: SizedBox(
              width: 30,
            ),
            onTap: () {
              widget?.onTap({
                'id': '${k.getId()}',
                'parent_id': '${k.getParentId()}',
                'title': '${k.getTitle()}',
              });
            },
            contentPadding: EdgeInsets.only(
              left: 15.0 * (k.level.toDouble()),
              top: 0,
              bottom: 0,
            ),
            title: Text(
              "${k.getTitle()}",
              style: widget.config.childrenTextStyle,
            ),
            trailing: Container(
              width: 100,
              height: 30,
              child: Row(
                children: [
                  widget.actionVisible == true
                      ? InkWell(
                          onTap: () {
                            _onEdit(int.parse(k.getId()), k.getTitle());
                          },
                          child: Icon(
                            Icons.edit_outlined,
                            color: Color(0xff00A4E3),
                          ),
                        )
                      : SizedBox(),
                  SizedBox(
                    width: 10,
                  ),
                  widget.actionVisible == true
                      ? InkWell(
                          onTap: () {
                            _showForm(int.parse(k.getId()), k.level);
                          },
                          child: Icon(
                            Icons.add,
                            color: Color(0xff31B5E8),
                          ),
                        )
                      : SizedBox(),
                  SizedBox(
                    width: 10,
                  ),
                  widget.actionVisible == true
                      ? InkWell(
                          onTap: () {
                            _onDelete(int.parse(k.getId()));
                          },
                          child: Icon(
                            Icons.delete_forever_outlined,
                            color: Color(0xff00A4E3),
                          ),
                        )
                      : SizedBox(),
                ],
              ),
            ),
          ),
        ));
      }
    }
    return cW;
  }

  List<Departments> _getChildrenFromParent(String parentId) {
    return widget.data
        .where((data) => data.getParentId() == parentId.toString())
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return treeView != null
        ? SingleChildScrollView(
            child: Container(
              width: widget.width,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: treeView,
                ),
                physics: BouncingScrollPhysics(),
              ),
            ),
            scrollDirection: Axis.horizontal,
            physics: BouncingScrollPhysics(),
          )
        : Container();
  }
}

class ChildWidget extends StatefulWidget {
  final List<Widget> children;
  final bool shouldExpand;
  final Config config;
  final id;
  ChildWidget({this.children, this.config, this.shouldExpand = false, this.id});

  @override
  _ChildWidgetState createState() => _ChildWidgetState();
}

class _ChildWidgetState extends State<ChildWidget>
    with SingleTickerProviderStateMixin {
  Animation<double> sizeAnimation;
  AnimationController expandController;

  @override
  void didUpdateWidget(ChildWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.shouldExpand) {
      expandController.forward();
    } else {
      expandController.reverse();
    }
  }

  @override
  void initState() {
    prepareAnimation();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    expandController.dispose();
  }

  void prepareAnimation() {
    expandController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    Animation curve =
        CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    sizeAnimation = Tween(begin: 0.0, end: 1.0).animate(curve)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return SizeTransition(
      sizeFactor: sizeAnimation,
      axisAlignment: -1.0,
      child: Column(
        children: _buildChildren(),
      ),
    );
  }

  _buildChildren() {
    return widget.children.map((c) {
      // return c;
      return Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: Color(0xffD4E5F9)),
          ),
        ),
        child: Align(alignment: Alignment.centerLeft, child: c),
      );
    }).toList();
  }
}

class ParentWidget extends StatefulWidget {
  final List<Widget> children;
  final Departments baseData;
  final Config config;
  final OnDepartTap onTap;
  final bool buttonVisible;
  ParentWidget({
    this.baseData,
    this.onTap,
    this.children,
    this.config,
    this.buttonVisible,
    Key key,
  }) : super(key: key);

  @override
  _ParentWidgetState createState() => _ParentWidgetState();
}

class _ParentWidgetState extends State<ParentWidget>
    with SingleTickerProviderStateMixin {
  bool shouldExpand = false;
  Animation<double> sizeAnimation;
  AnimationController expandController;
  final _textIDController = TextEditingController();

  String _validID;
  var _focusID = FocusNode();

  @override
  void dispose() {
    super.dispose();
    expandController.dispose();
  }

  @override
  void initState() {
    prepareAnimation();
    super.initState();
  }

  void prepareAnimation() {
    expandController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    Animation curve =
        CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    sizeAnimation = Tween(begin: 0.0, end: 0.5).animate(curve)
      ..addListener(() {
        setState(() {});
      });
  }

  ///On create department Level
  _createDepart(parentId, level) async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validID = UtilValidator.validate(data: _textIDController.text, min: 1);
    });
    if (_validID == null) {
      print(parentId);
      print(_textIDController.text);
      AppBloc.departmentBlocs.add(OnAddDepartment(
          name: _textIDController.text, parentId: parentId, level: ++level));
      AppBloc.departmentBlocs.add(OnLoadDepartments());
    }
  }

  ///Create Department Form Level
  Future<void> _showForm(parentId, level) async {
    _focusID = FocusNode();
    _focusID.addListener(() {
      if (_focusID.hasFocus) _textIDController.clear();
    });
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            Translate.of(context).translate('create_department'),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                AppTextInput(
                  autoFocus: true,
                  hintText: Translate.of(context).translate('department_name'),
                  errorText: Translate.of(context).translate(_validID),
                  icon: Icon(
                    Icons.clear,
                    size: 14,
                  ),
                  controller: _textIDController,
                  focusNode: _focusID,
                  onChanged: (text) {
                    setState(() {
                      print(text);
                      _validID = UtilValidator.validate(
                        data: _textIDController.text,
                      );
                    });
                  },
                ),
                SizedBox(
                  height: 15,
                ),
                BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                    bloc: BlocProvider.of<DepartmentsListBloc>(context),
                    builder: (context, save) {
                      return BlocListener<DepartmentsListBloc,
                          DepartmentsListState>(
                        listener: (context, state) {
                          if (state is DepartmentsaveFail) {
                            Text(state.code);
                          }
                          if (state is DepartmentsaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text("Department Added Successfully"),
                            ));
                          }
                        },
                        child: AppButton(
                          Translate.of(context).translate('create'),
                          onPressed: () => _createDepart(parentId, level),
                          type: ButtonType.normal,
                          loading: save is Departmentsaving,
                          disabled: save is Departmentsaving,
                          color: Color(0xff787E8C),
                        ),
                      );
                    })
              ],
            ),
          ),
          actions: <Widget>[
            AppButton(
              Translate.of(context).translate('close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
              type: ButtonType.text,
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    print("${15.0 * widget.baseData.level.toDouble()}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        InkWell(
          hoverColor: Color(0xffEFF5FC),
          onTap: () {
            print("object");
          },
          onHover: (value) {
            setState(() {
              widget.baseData.isHovered = value;
            });
          },
          child: Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xffD4E5F9)),
              ),
            ),
            child: ListTile(
              hoverColor: Color(0xffEFF5FC),
              leading: InkWell(
                highlightColor: Colors.transparent,
                onTap: () {
                  setState(() {
                    shouldExpand = !shouldExpand;
                  });
                  if (shouldExpand) {
                    expandController.forward();
                  } else {
                    expandController.reverse();
                  }
                },
                child: shouldExpand
                    ? Icon(
                        Icons.remove_circle_outline_outlined,
                        color: Color(0xff31B5E8),
                      )
                    : Icon(
                        Icons.add_circle_outlined,
                        color: Color(0xff31B5E8),
                      ),
              ),
              contentPadding: EdgeInsets.only(
                  left: 15.0 * (widget.baseData.level.toDouble()),
                  top: 0,
                  bottom: 0),
              title: Text(
                widget.baseData.getTitle(),
                style: widget.config.parentTextStyle,
              ),
              trailing: Container(
                width: 30,
                height: 30,
                child: widget.baseData.isHovered && widget.buttonVisible == true
                    ? InkWell(
                        onTap: () {
                          print("object");
                          setState(() {
                            _showForm(
                                widget.baseData.id, widget.baseData.level);
                          });
                        },
                        child: Icon(
                          Icons.add,
                          color: Color(0xff31B5E8),
                        ),
                      )
                    : Container(),
              ),
            ),
          ),
        ),
        ChildWidget(
          children: widget.children,
          id: widget.baseData.id,
          config: widget.config,
          shouldExpand: shouldExpand,
        )
      ],
    );
  }
}

///A singleton Child tap listener
class ChildTapListener extends ValueNotifier<Map<String, dynamic>> {
  /* static final ChildTapListener _instance = ChildTapListener.internal();

  factory ChildTapListener() => _instance;

  ChildTapListener.internal() : super(null); */
  Map<String, dynamic> mapValue;

  ChildTapListener(Map<String, dynamic> value) : super(value);

  // ChildTapListener() : super(null);

  void addMapValue(Map map) {
    this.mapValue = map;
    notifyListeners();
  }

  Map getMapValue() {
    return this.mapValue;
  }
}

///Dynamic TreeView will construct treeview based on parent-child relationship.So, its important to
///override getParentId() and getId() with proper values.
abstract class BaseData {
  ///id of this data
  String getId();

  /// parentId of a child
  String getParentId();

  /// Text displayed on the parent/child tile
  String getTitle();
}

class Config {
  final TextStyle parentTextStyle;
  final TextStyle childrenTextStyle;
  final EdgeInsets childrenPaddingEdgeInsets;
  final EdgeInsets parentPaddingEdgeInsets;

  ///Animated icon when tile collapse/expand
  final Widget arrowIcon;

  ///the rootid of a treeview.This is needed to fetch all the immediate child of root
  ///Default is null
  final String rootId;

  const Config(
      {this.parentTextStyle =
          const TextStyle(color: Colors.black, fontSize: 12),
      this.parentPaddingEdgeInsets =
          const EdgeInsets.only(left: 15.0, top: 0, bottom: 0),
      this.childrenTextStyle =
          const TextStyle(color: Colors.black, fontSize: 12),
      this.childrenPaddingEdgeInsets =
          const EdgeInsets.only(left: 15.0, top: 0, bottom: 0),
      this.rootId = "null",
      this.arrowIcon = const Icon(Icons.keyboard_arrow_down)});
}
