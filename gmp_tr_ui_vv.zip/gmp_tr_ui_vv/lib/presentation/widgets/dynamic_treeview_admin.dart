import 'package:flutter/material.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';
import 'package:gmptr/utils/utils.dart';

import 'app_admin_view_dropdown_depart_multiselect.dart';

typedef OnAdminPageTap = Function(Map data);

class MyDynamicAdminTreeView extends StatefulWidget {
  final List<AdminPagesModel> data;

  final List<UserAdminPageWithDeptModel> userData;

  final OnAdminPageTap onTap;
  final BuildContext contxt;
  final double width;

  ///Configuration object for [MyDynamicAdminTreeView]
  final AdminConfig config;
  MyDynamicAdminTreeView({
    @required this.data,
    this.config = const AdminConfig(),
    this.onTap,
    this.width = 220.0,
    this.userData,
    this.contxt,
  }) : assert(data != null);

  @override
  _MyDynamicAdminTreeViewOriState createState() => _MyDynamicAdminTreeViewOriState();
}

class _MyDynamicAdminTreeViewOriState extends State<MyDynamicAdminTreeView> {
  List<ParentWidget> treeView;
  ChildTapListener _childTapListener = ChildTapListener(null);
  List<String> selectedViewDepartsItems = [];
  List<String> selectedViewTrainingDepartsItems = [];
  var userAdminPagesRepository;
  int userAdminPageDepartmentId;
  String userRoleId;
  BuildContext context;
  @override
  void initState() {
    super.initState();
    _buildTreeView();
    _childTapListener.addListener(childTapListener);
  }

  void childTapListener() {
    if (widget.onTap != null) {
      var k = _childTapListener.getMapValue();
      widget.onTap(k);
    }
  }

  @override
  void dispose() {
    _childTapListener.removeListener(childTapListener);
    _childTapListener.dispose();
    super.dispose();
  }

  _buildTreeView() {
    var k = widget.data
        .where((data) {
          return data.getParentId() == widget.config.rootId;
        })
        .map((data) {
          return data.getId();
        })
        .toSet()
        .toList()
      ..sort((i, j) => i.compareTo(j));

    List<ParentWidget> widgets = [];
    k.forEach((f) {
      ParentWidget p = buildWidget(f, null);
      if (p != null) widgets.add(p);
    });
    setState(() {
      treeView = widgets;
    });
  }

  ParentWidget buildWidget(String parentId, String name) {
    var data = _getChildrenFromParent(parentId);
    AdminPagesModel d = widget.data.firstWhere((d) => d.getId() == parentId.toString());
    if (name == null) {
      name = d.getTitle();
    }

    var p = ParentWidget(
      userData: widget.userData,
      checkBox: d.isChecked,
      baseData: d,
      onTap: widget.onTap,
      config: widget.config,
      children: _buildChildren(data),
      key: ObjectKey({
        'id': '${d.getId()}',
        'parent_id': '${d.getParentId()}',
        'title': '${d.getTitle()}',
      }),
    );
    return p;
  }

  _buildChildren(List<AdminPagesModel> data) {
    List<Widget> cW = [];
    userAdminPagesRepository = UserAdminPagesRepository();

    List<String> rolesId = UtilPreferences.getStringList(
      Preferences.multipleUserRoleId,
    );

    // if (rolesId != null || rolesId.isNotEmpty || rolesId != []) {
    if (rolesId != null && rolesId.isNotEmpty) {
      var map = rolesId.asMap();
      map.forEach((key, value) {
        if (value.contains(
          "浏览者",
        )) {
          List<String> record = value.replaceAll("{", " ").replaceAll("}", " ").split(",").toList();
          final rec = record.first.split(":").toList();
          userRoleId = rec.last;
        }
      });
    }
    // print("userRoleId>>>>>>>>>>> $userRoleId");
    for (var k in data) {
      print("id >>>>>>>>>>> ${k.id}");
      widget.userData.map((element) {
        if (element.adminPageIdFk == k.id && element.userRoleIdFk == int.parse(userRoleId)) {
          k.isChecked = true;
        }
        if (k.id == element.adminPageIdFk && element.userRoleIdFk == int.parse(userRoleId)) {
          userAdminPagesRepository.saveUserAdmingPageRecord(element.id, k.name);
        }
        if (element.userAdminPageDepartments != null && element.userAdminPageDepartments.length > 0) {
          element.userAdminPageDepartments.map((e) {
            if (element.adminPageIdFk == k.id && element.userRoleIdFk == int.parse(userRoleId)) {
              userAdminPageDepartmentId = e.id;
            }
          }).toList();
          if (element.adminPageIdFk == k.id && k.id == 11 && element.userRoleIdFk == int.parse(userRoleId)) selectedViewDepartsItems = element.userAdminPageDepartments.map((e) => e.department.name).toList();

          if (element.adminPageIdFk == k.id && k.id == 14 && element.userRoleIdFk == int.parse(userRoleId)) selectedViewTrainingDepartsItems = element.userAdminPageDepartments.map((e) => e.department.name).toList();
        }
      }).toList();

      var c = _getChildrenFromParent(k.getId());
      if ((c?.length ?? 0) > 0) {
        //has children
        var name = widget.data.firstWhere((d) => d.getId() == k.getId().toString()).getTitle();
        cW.add(buildWidget(k.getId(), name));
      } else {
        cW.add(Column(
          children: [
            ListTile(
              contentPadding: EdgeInsets.only(
                left: 5.0,
                top: 0,
                bottom: 0,
              ),
              title: Text(
                '--${k.getTitle()}',
                style: widget.config.childrenTextStyle,
              ),
              trailing: Container(
                width: 40,
                height: 40,
                child: Checkbox(
                    value: k.isChecked,
                    onChanged: (value) {
                      setState(() {
                        k.isChecked = value;
                      });

                      if (value == true) {
                        print(k.id);
                        AppBloc.userAdminPageBloc.add(
                          OnCreateUserAdminPage(
                            adminPageId: k.id,
                            adminPageName: k.name,
                            roleName: 'viewer', //Translate.of(context).translate('viewer'),
                          ),
                        );
                        AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                      } else {
                        AppBloc.userAdminPageBloc.add(
                          OnRemoveUserAdminPage(
                            adminPageName: k.name,
                          ),
                        );
                        AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                      }
                    }),
              ),
            ),
            if (k.departments == true && k.id == 11 && k.isChecked)
              MyAdminViewDropDownMultiSelect(
                onChanged: (List<String> x) {
                  AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                  setState(() {
                    selectedViewDepartsItems = x;
                  });
                },
                selectedValues: selectedViewDepartsItems,
                whenEmpty: 'Select Department',
                adminPageName: k.name,
                userAdminPageDepartmentId: userAdminPageDepartmentId,
              )
          ],
        ));
      }
    }
    return cW;
  }

  List<AdminPagesModel> _getChildrenFromParent(String parentId) {
    return widget.data.where((data) => data.getParentId() == parentId.toString()).toList();
  }

  @override
  Widget build(BuildContext context) {
    return treeView != null
        ? SingleChildScrollView(
            child: Container(
              width: widget.width,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: treeView,
                ),
                physics: BouncingScrollPhysics(),
              ),
            ),
            scrollDirection: Axis.horizontal,
            physics: BouncingScrollPhysics(),
          )
        : Container();
  }
}

// ignore: must_be_immutable
class ChildWidget extends StatefulWidget {
  final List<Widget> children;
  bool shouldExpand;
  final AdminConfig config;
  final id;
  ChildWidget({this.children, this.config, this.shouldExpand = false, this.id});

  @override
  _ChildWidgetState createState() => _ChildWidgetState();
}

class _ChildWidgetState extends State<ChildWidget> with SingleTickerProviderStateMixin {
  Animation<double> sizeAnimation;
  AnimationController expandController;

  @override
  void didUpdateWidget(ChildWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.shouldExpand) {
      expandController.forward();
    } else {
      expandController.reverse();
    }
  }

  @override
  void initState() {
    prepareAnimation();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    expandController.dispose();
  }

  void prepareAnimation() {
    expandController = AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    Animation curve = CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    sizeAnimation = Tween(begin: 0.0, end: 1.0).animate(curve)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return SizeTransition(
      sizeFactor: sizeAnimation,
      axisAlignment: 1.0,
      child: Column(
        children: _buildChildren(context),
      ),
    );
  }

  _buildChildren(BuildContext context) {
    return widget.children.map((c) {
      print("children >> $c");
      // return c;
      return Container(
        child: Align(alignment: Alignment.centerLeft, child: c),
      );
    }).toList();
  }
}

// ignore: must_be_immutable
class ParentWidget extends StatefulWidget {
  final List<UserAdminPageWithDeptModel> userData;
  bool checkBox;
  final List<Widget> children;
  final AdminPagesModel baseData;
  final AdminConfig config;
  final OnAdminPageTap onTap;
  ParentWidget({
    this.checkBox,
    this.baseData,
    this.onTap,
    this.children,
    this.config,
    this.userData,
    Key key,
  }) : super(key: key);

  @override
  _ParentWidgetState createState() => _ParentWidgetState();
}

class _ParentWidgetState extends State<ParentWidget> with SingleTickerProviderStateMixin {
  bool shouldExpand = false;
  Animation<double> sizeAnimation;
  AnimationController expandController;

  List<String> selectedViewTrainingDepartsItems = [];
  List<String> selectedViewDepartsItems = [];

  @override
  void dispose() {
    super.dispose();
    expandController.dispose();
  }

  @override
  void initState() {
    prepareAnimation();
    super.initState();
  }

  void prepareAnimation() {
    expandController = AnimationController(vsync: this, duration: Duration(milliseconds: 300));
    Animation curve = CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    sizeAnimation = Tween(begin: 0.0, end: 0.5).animate(curve)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    print("widget.children >>>> ${widget.children}");
    final userAdminPagesRepository = UserAdminPagesRepository();
    int userAdminPageDepartmentId;
    String userRoleId;
    List<String> rolesId = UtilPreferences.getStringList(
      Preferences.multipleUserRoleId,
    );

    if (rolesId != null && rolesId.isNotEmpty) {
      var map = rolesId.asMap();
      map.forEach((key, value) {
        if (value.contains('浏览者'
            // Translate.of(context).translate('viewer'),
            )) {
          List<String> record = value.replaceAll("{", " ").replaceAll("}", " ").split(",").toList();
          final rec = record.first.split(":").toList();
          userRoleId = rec.last;
        }
      });
    }
    widget.userData.map((element) {
      if (element.adminPageIdFk == widget.baseData.id && element.userRoleIdFk == int.parse(userRoleId)) {
        widget.checkBox = true;
        shouldExpand = true;

        if (shouldExpand) {
          expandController.forward();
        } else {
          expandController.reverse();
        }
      }
      if (widget.baseData.id == element.adminPageIdFk && element.userRoleIdFk == int.parse(userRoleId)) {
        userAdminPagesRepository.saveUserAdmingPageRecord(element.id, widget.baseData.name);
      }
      if (element.userAdminPageDepartments != null && element.userAdminPageDepartments.length > 0) {
        element.userAdminPageDepartments.map((e) {
          if (element.adminPageIdFk == widget.baseData.id && element.userRoleIdFk == int.parse(userRoleId)) {
            userAdminPageDepartmentId = e.id;
          }
        }).toList();
        if (element.adminPageIdFk == widget.baseData.id && widget.baseData.id == 11 && element.userRoleIdFk == int.parse(userRoleId)) selectedViewDepartsItems = element.userAdminPageDepartments.map((e) => e.department.name).toList();

        if (element.adminPageIdFk == widget.baseData.id && widget.baseData.id == 14 && element.userRoleIdFk == int.parse(userRoleId)) selectedViewTrainingDepartsItems = element.userAdminPageDepartments.map((e) => e.department.name).toList();
      }
    }).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          child: ListTile(
            hoverColor: Color(0xffEFF5FC),
            contentPadding: EdgeInsets.only(left: 0, top: 0, bottom: 0),
            title: Text(
              widget.baseData.getTitle(),
              style: widget.config.parentTextStyle,
            ),
            trailing: Container(
              width: 30,
              height: 30,
              child: Checkbox(
                  value: widget.checkBox,
                  onChanged: (value) {
                    setState(() {
                      shouldExpand = !shouldExpand;
                      if (value == true) {
                        widget.checkBox = true;
                        print(widget.checkBox);
                        shouldExpand = true;
                        print(widget.baseData.getId());
                        AppBloc.userAdminPageBloc.add(
                          OnCreateUserAdminPage(
                            adminPageId: widget.baseData.id,
                            adminPageName: widget.baseData.name,
                            roleName: Translate.of(context).translate('viewer'),
                          ),
                        );
                        AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                      } else {
                        widget.checkBox = false;
                        print(widget.checkBox);
                        shouldExpand = false;
                        AppBloc.userAdminPageBloc.add(
                          OnRemoveUserAdminPage(
                            adminPageName: widget.baseData.name,
                          ),
                        );
                        AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                      }
                    });
                  }),
            ),
          ),
        ),
        if (widget.baseData.departments == true && widget.baseData.id == 14 && widget.checkBox)
          MyAdminViewDropDownMultiSelect(
            onChanged: (List<String> x) {
              print("dropdown");
              AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
              setState(() {
                selectedViewTrainingDepartsItems = x;
              });
            },
            selectedValues: selectedViewTrainingDepartsItems,
            whenEmpty: 'Select Department',
            adminPageName: widget.baseData.name,
            userAdminPageDepartmentId: userAdminPageDepartmentId,
          ),
        ChildWidget(
          children: widget.children,
          id: widget.baseData.id,
          config: widget.config,
          shouldExpand: shouldExpand,
        )
      ],
    );
  }
}

///A singleton Child tap listener
class ChildTapListener extends ValueNotifier<Map<String, dynamic>> {
  /* static final ChildTapListener _instance = ChildTapListener.internal();

  factory ChildTapListener() => _instance;

  ChildTapListener.internal() : super(null); */
  Map<String, dynamic> mapValue;

  ChildTapListener(Map<String, dynamic> value) : super(value);

  // ChildTapListener() : super(null);

  void addMapValue(Map map) {
    this.mapValue = map;
    notifyListeners();
  }

  Map getMapValue() {
    return this.mapValue;
  }
}

///Dynamic TreeView will construct treeview based on parent-child relationship.So, its important to
///override getParentId() and getId() with proper values.
abstract class BaseData {
  ///id of this data
  String getId();

  /// parentId of a child
  String getParentId();

  /// Text displayed on the parent/child tile
  String getTitle();
}

class AdminConfig {
  final TextStyle parentTextStyle;
  final TextStyle childrenTextStyle;
  final EdgeInsets childrenPaddingEdgeInsets;
  final EdgeInsets parentPaddingEdgeInsets;

  ///Animated icon when tile collapse/expand
  final Widget arrowIcon;

  ///the rootid of a treeview.This is needed to fetch all the immediate child of root
  ///Default is null
  final String rootId;

  const AdminConfig({this.parentTextStyle = const TextStyle(color: Colors.black, fontSize: 12), this.parentPaddingEdgeInsets = const EdgeInsets.only(left: 15.0, top: 0, bottom: 0), this.childrenTextStyle = const TextStyle(color: Colors.black, fontSize: 12), this.childrenPaddingEdgeInsets = const EdgeInsets.only(left: 15.0, top: 0, bottom: 0), this.rootId = "null", this.arrowIcon = const Icon(Icons.keyboard_arrow_down)});
}
