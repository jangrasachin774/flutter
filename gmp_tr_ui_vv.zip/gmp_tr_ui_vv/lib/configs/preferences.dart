class Preferences {
  static String reviewIntro = 'review';
  static String user = 'user';
  static String userroles = "roles";
  static String language = 'language';
  static String notification = 'notification';
  static String theme = 'theme';
  static String darkOption = 'darkOption';
  static String font = 'font';
  static String search = 'search';
  static String singleUserRoleId = "singleUserRoleId";
  static String multipleUserRoleId = "multiUserRoleId";
  static String userAdminPage = "userAdminPage";
  static String documentId = 'documentId';
  static String roles = "userRoles";
  static String userRoleId = "userRoleId";
  static String userId = "userId";
  static String filterDepartmentIdFk = "filterDeptIdFk";
  static String filterTrainingTypeIdFk = "filterTrainTypeIdFk";
  static String filterDocFeatureIdFk = "filterDocFeatureIdFk";

  ///Singleton factory
  static final Preferences _instance = Preferences._internal();

  factory Preferences() {
    return _instance;
  }

  Preferences._internal();
}
