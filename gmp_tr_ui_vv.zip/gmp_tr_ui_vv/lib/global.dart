enum WidgetChange {
  dashboard,
  taskInfo,
  docInfo,
  createDoc,
  createTask,
}

enum HomeWidgetChange {
  taskDocController,
  // createDoc,
  // createTask,
  taskInfo,
  docInfo,
  // updateTask,
  updateDoc,
}

enum AllForMeWidgetChange {
  dashboard,
  taskInfo,
  docInfo,
  // updateTask,
  updateDoc,
  createDoc,
  createTask,
}

enum ApproveHolidayWidgetChange {
  dashboard,
}

enum StudentsWidgets {
  dashboard,
  openTest,
  taskDetails,
}

enum SmallLeaderWidgets {
  dashboard,
  taskInfo,
  docInfo,
}

enum BigLeaderWidgets {
  dashboard,
  taskInfo,
  docInfo,
}

enum ViewTrainingWidgetChange {
  dashboard,
  taskInfo,
  docInfo,
}

class UserRolesId {
  static const int admin = 6;
  static const int creator = 2;
  static const int smallLeader = 3;
  static const int bigLeader = 4;
  static const int student = 5;
  static const int viewAdmin = 13;
  static const int viewTraining = 14;
}

class UserAdminPageId {
  static const int departmentManagment = 12;
  static const int userManagement = 11;
  static const int documentManagement = 10;
  static const int documentTypeManagement = 9;
  static const int trainingTypeManagement = 8;
  static const int viewAdmin = 13;
  static const int viewTraining = 14;
}

class StatusId {
  static const int all = 0;
  static const int created = 1;
  static const int confirmed = 2;
  static const int cancelled = 3;
  static const int smallLeaderConfirmed = 4;

  static const int smallLeaderSendBack = 5;
  static const int bigLeaderConfirmed = 6;
  static const int bigLeaderSendBack = 7;
  static const int begin = 8;
  static const int Studentfinised = 9;
  static const int expired = 10;
  static const int SLsAll = 11;
  static const int BLsAll = 12;
}

class ViewType {
  static const int regularTask = 1;
  static const int readOnlyTask = 2;
  static const int documents = 3;
  static const int documentTest = 4;
}

int selectedViewTypeCommon = 1;
