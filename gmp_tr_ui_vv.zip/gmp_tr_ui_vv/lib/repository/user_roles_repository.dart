import 'dart:convert';

import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class UserRolesRepository {
  ///
  Future<dynamic> loadingUserRole({int userId}) async {
    final params = {"user_id_fk": userId};
    print(params);
    return await Api.getUserRoles(params);
  }

  /// Create  User Role api
  Future<dynamic> createUserRole({
    int userId,
    int userRoles,
  }) async {
    final params = {
      "user_id_fk": userId,
      "role_id_fk": userRoles,
    };
    print(params);
    return await Api.createUserRole(params);
  }

  /// Delete  User Role  api
  Future<dynamic> deleteUserRole({
    int roleId,
    int userId,
  }) async {
    final params = {"role_id_fk": roleId, "user_id_fk": userId};
    print(params);
    return await Api.deleteUserRole(params);
  }

  /// Delete  User Role  api
  Future<dynamic> deleteUserRoleId({
    int id,
  }) async {
    final params = {
      "id": id,
    };
    print("pppppp $params");
    return await Api.deleteUserRole(params);
  }

  ///Save Multiple User Role id Storage
  Future<dynamic> saveUserRoleId(
      int userRoleId, int userId, int roleId, String name) async {
    List<String> rolesId = UtilPreferences.getStringList(
      Preferences.multipleUserRoleId,
    );
    if (rolesId != null) {
      if (!rolesId.contains(jsonEncode(name))) {
        print("anish");
        rolesId.add(jsonEncode({
          "userRoleId": userRoleId,
          "userId": userId,
          "roleId": roleId,
          "role_name": name
        }));
        await UtilPreferences.setStringList(
          Preferences.multipleUserRoleId,
          rolesId,
        );
      }
    } else {
      await UtilPreferences.setStringList(
        Preferences.multipleUserRoleId,
        [
          jsonEncode({
            "userRoleId": userRoleId,
            "userId": userId,
            "roleId": roleId,
            "role_name": name
          })
        ],
      );
    }
  }

  ///Get from Storage
  dynamic getUserRoleId() {
    return UtilPreferences.getStringList(Preferences.multipleUserRoleId);
  }

  ///DELETE Multiple User Role id Storage
  Future<dynamic> deleteUserRoleIdRepo(
    int roleId,
    int userId,
    String name,
  ) async {
    List<String> rolesId = UtilPreferences.getStringList(
      Preferences.multipleUserRoleId,
    );
    print("&&&&&&&& $rolesId");
    var ele;

    if (rolesId != null) {
      rolesId.forEach((element) {
        if (element.contains(name)) {
          ele = element;
        }
      });
      rolesId.remove(ele);
      await UtilPreferences.setStringList(
        Preferences.multipleUserRoleId,
        rolesId,
      );
    }
  }

  ///Save Single User Role id Storage
  Future<dynamic> saveSingleUserRoleId(int userRoleId) async {
    Application.userRoleId = userRoleId;
    return await UtilPreferences.setString(
      Preferences.singleUserRoleId,
      jsonEncode(
        userRoleId,
      ),
    );
  }

  ///Get from Storage
  dynamic getSingleUserRoleId() {
    return UtilPreferences.getString(Preferences.singleUserRoleId);
  }
}
