import 'dart:convert';
import 'dart:typed_data';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class DocumentFilesRepository {
  Future<dynamic> loadDocumentFiles() async {}

  Future<dynamic> saveDocumentFile({
    String identifier,
    int documentIdFk,
    String fileName,
    Uint8List file,
  }) async {
    final params = {
      "identifier": identifier,
      "document_id_fk": documentIdFk,
      "files": [
        {
          "fileName": fileName,
          "file": file,
        }
      ]
    };
    print(params);
    return await Api.saveDocumentFile(params);
  }

  Future<dynamic> updateDocumentFile(
      {int id,
      String identifier,
      String title,
      int trainingTypeIdFk,
      int documentTypeIdFk,
      int smallLeaderIdFk,
      String description,
      int bigLeaderIdFk,
      int creatorIdFk,
      int status,
      departmentIdFk}) async {}

  ///Save Document id Storage
  Future<dynamic> saveDocumentId(int documentId) async {
    Application.documentId = documentId;
    return await UtilPreferences.setString(
      Preferences.documentId,
      jsonEncode(
        documentId,
      ),
    );
  }

  ///Get from Storage
  dynamic getSingleUserRoleId() {
    return UtilPreferences.getString(Preferences.documentId);
  }
}
