import 'dart:convert';

import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/utils/utils.dart';

class UserRepository {
  ///Fetch api login
  Future<dynamic> login(
      {String username, String password, String source}) async {
    final params = {
      "username": username,
      "password": password,
      "login_source": source
    };
    return await Api.login(params);
  }

  ///Save Storage
  Future<dynamic> saveUser({UserModel user}) async {
    Application.user = user;
    return await UtilPreferences.setString(
      Preferences.user,
      jsonEncode(
        user.toJson(),
      ),
    );
  }

  ///Get from Storage
  dynamic getUser() {
    return UtilPreferences.getString(Preferences.user);
  }

  ///Delete User
  Future<dynamic> deleteUser() async {
    Application.user = null;

    ///Delete Storage
    return await UtilPreferences.remove(Preferences.user);
  }

  Future<dynamic> saveUserRoles({UserRoles userRoles}) async {
    Application.roles = userRoles;

    return await UtilPreferences.setString(
        Preferences.roles, jsonEncode(userRoles.toJson()));
  }
}
