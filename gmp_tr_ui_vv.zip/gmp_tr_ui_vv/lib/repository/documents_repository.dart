import 'dart:convert';

import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class DocumentsRepository {
  Future<dynamic> loadDocuments({
    int trainingTypeIdFk,
    int departmentIdFk,
    int creatorIdFk,
    int smallLeaderIdFk,
    int bigLeaderIdFk,
    int documentType,
    int criteria,
    String startDate,
    String endDate,
    List<int> docStatusId,
    int documentId,
    List<int> multiDepartIdFk,
    List<int> viewType,
    int viewTypeIdFk,
    int documentTypeIdFk,
  }) async {
    var params;
    if (criteria == 1) {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk": departmentIdFk,
        "document_type_id_fk": documentType,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "creator_confirm_date": {"starDate": startDate, "endDate": endDate},
      };
    } else if (criteria == 2) {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk": departmentIdFk,
        "document_type_id_fk": documentType,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "small_leader_confirm_date": {
          "starDate": startDate,
          "endDate": endDate
        },
      };
    } else if (criteria == 3) {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk": departmentIdFk,
        "document_type_id_fk": documentType,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "big_leader_confirm_date": {"starDate": startDate, "endDate": endDate},
      };
    } else {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk":
            departmentIdFk == null ? multiDepartIdFk : departmentIdFk,
        "document_type_id_fk": documentType,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "document_status_id_fk": docStatusId,
        "id": documentId,
        "view_id_fk": viewType == null ? viewTypeIdFk : viewType,
      };
    }

    return await Api.getDocuments(params);
  }

  Future<dynamic> saveDocument(
      {String identifier,
      String title,
      int trainingTypeIdFk,
      int documentTypeIdFk,
      int smallLeaderIdFk,
      String description,
      int bigLeaderIdFk,
      int creatorIdFk,
      int status,
      int departmentIdFk}) async {
    final params = {
      "identifier": identifier,
      "title": title,
      "training_type_id_fk": trainingTypeIdFk,
      "document_type_id_fk": documentTypeIdFk,
      "small_leader_id_fk": smallLeaderIdFk,
      "creator_id_fk": creatorIdFk,
      "description": description,
      "big_leader_id_fk": bigLeaderIdFk,
      "document_status_id_fk": status
    };
    print(params);
    return await Api.saveDocument(params);
  }

  ///UPDATE DOCUMENT STATUS
  Future<dynamic> updateDocumentStatus(
      {int id, int status, List<int> docIds}) async {
    var params;
    if (docIds.isEmpty || docIds.length == 0) {
      params = {
        "id": id,
        "document_status_id_fk": status,
      };
    } else {
      params = {
        "id": docIds,
        "document_status_id_fk": status,
      };
    }
    print("params >>>> $params");
    return await Api.updateDocumentStatus(params);
  }

  ///EDIT DOCUMENT
  Future<dynamic> updateDocument(
      {int id,
      String identifier,
      String title,
      int trainingTypeIdFk,
      int documentTypeIdFk,
      int smallLeaderIdFk,
      String description,
      int bigLeaderIdFk,
      int creatorIdFk,
      int status,
      departmentIdFk}) async {}

  ///Save Document id Storage
  Future<dynamic> saveDocumentId(int documentId) async {
    Application.documentId = documentId;
    return await UtilPreferences.setString(
      Preferences.documentId,
      jsonEncode(
        documentId,
      ),
    );
  }

  ///Get from Storage
  dynamic getdocumentId() {
    return UtilPreferences.getString(Preferences.documentId);
  }

  ///Validate Document versions
  Future<dynamic> validateDocVersions({String title, int viewIdFk}) async {
    final params = {
      "title": title,
      "view_id_fk": viewIdFk,
    };
    print(params);
    return await Api.getDocVersions2(params);
  }

  ///Validate Document versions
  Future<dynamic> validateTestDocVersions({String title, int viewIdFk}) async {
    final params = {
      "title": title,
      "view_id_fk": viewIdFk,
    };
    print(params);
    return await Api.getDocVersions(params);
  }

  ///Validate Document versions
  Future<dynamic> getDocVersions({
    int trainingTypeIdFk,
    int departmentIdFk,
    int documentType,
  }) async {
    final params = {
      "training_type_id_fk": trainingTypeIdFk,
      "department_id_fk": departmentIdFk,
      "document_type_id_fk": documentType,
    };
    print(params);
    return await Api.getDocVersions(params);
  }

  ///read Document titles
  Future<dynamic> getDocumentTitles({
    int trainingTypeIdFk,
    int departmentIdFk,
    int documentType,
    String version,
  }) async {
    final params = {
      "training_type_id_fk": trainingTypeIdFk,
      "department_id_fk": departmentIdFk,
      "document_type_id_fk": documentType,
      "version": version
    };
    print(params);
    return await Api.readTitles(params);
  }
}
