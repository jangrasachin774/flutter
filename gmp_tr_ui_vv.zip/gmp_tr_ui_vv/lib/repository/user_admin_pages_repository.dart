import 'dart:convert';

import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class UserAdminPagesRepository {
  Future<dynamic> loadUserAdminPageDept(
      {int userRoleIdFk, int adminPageIdFk}) async {
    final params = {"user_role_id_fk": userRoleIdFk};

    return await Api.loadUserAdminPagesDept(params);
  }

  ///Save User Admin Page
  Future<dynamic> saveUserAdminPages({int userRoleId, int adminPageId}) async {
    final params = {
      "user_role_id_fk": userRoleId,
      "admin_page_id_fk": adminPageId
    };
    return await Api.saveUserAdminPages(params);
  }

  ///DELETE User Admin Page
  Future<dynamic> deleteUserAdminPage(
      {int userAdminPageId, int adminPageId}) async {
    final params = {"id": userAdminPageId};
    print("DELETE USER ADMIN PAGE $params");
    return await Api.deleteUserAdminPage(params);
  }

  ///Save User Admin Pages Storage
  Future<dynamic> saveUserAdmingPageRecord(
      int userAdminPageId, String adminPageName) async {
    List<String> userAdminPage = UtilPreferences.getStringList(
      Preferences.userAdminPage,
    );
    print(userAdminPage);
    if (userAdminPage != null) {
      if (!userAdminPage.contains(jsonEncode(adminPageName))) {
        userAdminPage.add(
          jsonEncode(
            {
              "userAdminPageId": userAdminPageId,
              "adminPageName": adminPageName,
            },
          ),
        );
        await UtilPreferences.setStringList(
          Preferences.userAdminPage,
          userAdminPage,
        );
      }
    } else {
      await UtilPreferences.setStringList(
        Preferences.userAdminPage,
        [
          jsonEncode(
            {
              "userAdminPageId": userAdminPageId,
              "adminPageName": adminPageName,
            },
          )
        ],
      );
    }
  }

  ///Get from Storage
  dynamic getUserRoleId() {
    return UtilPreferences.getStringList(Preferences.userAdminPage);
  }

  ///DELETE Multiple User Role id Storage
  Future<dynamic> deleteUserAdminPageLocal(String adminPageName) async {
    List<String> userAdminPages = UtilPreferences.getStringList(
      Preferences.userAdminPage,
    );
    var ele;

    if (userAdminPages != null) {
      userAdminPages.forEach((element) {
        if (element.contains(adminPageName)) {
          ele = element;
        }
      });
      userAdminPages.remove(ele);
      await UtilPreferences.setStringList(
        Preferences.userAdminPage,
        userAdminPages,
      );
    }
  }
}
