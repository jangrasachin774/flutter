import 'package:gmptr/api/api.dart';

class RolesRepository {
  ///Fetch api loadRolesList
  Future<dynamic> loadRoles() async {
    return await Api.getRoles();
  }
}
