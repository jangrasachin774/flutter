import 'package:dio/dio.dart';
import 'package:file_picker/src/platform_file.dart';
import 'package:flutter/src/widgets/editable_text.dart';
import 'package:gmptr/api/api.dart';

import 'package:uuid/uuid.dart';

class TasksRepository {
  ///Fetch api loadTasksList
  Future<dynamic> loadTasks({
    int creatorIdFk,
    int smallLeaderIdFk,
    int bigLeaderIdFk,
    int documentTypeIdFk,
    int departmentIdFk,
    int trainingTypeIdFk,
    int criteria,
    String startDate,
    String endDate,
    List<int> taskStatusId,
    int taskId,
    int studentIdFk,
    List<int> viewType,
    List<int> multiDepartIdFk,
    int id,
  }) async {
    var params;
    if (criteria == 1) {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk": departmentIdFk,
        "document_type_id_fk": documentTypeIdFk,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "creator_confirm_date": {
          "starDate": startDate,
          "endDate": endDate,
        },
      };
    } else if (criteria == 2) {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk": departmentIdFk,
        "document_type_id_fk": documentTypeIdFk,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "small_leader_confirm_date": {
          "starDate": startDate,
          "endDate": endDate
        },
      };
    } else if (criteria == 3) {
      params = {
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk": departmentIdFk,
        "document_type_id_fk": documentTypeIdFk,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "big_leader_confirm_date": {"starDate": startDate, "endDate": endDate},
      };
    } else {
      params = {
        "id": taskId,
        "training_type_id_fk": trainingTypeIdFk,
        "department_id_fk":
            departmentIdFk == null ? multiDepartIdFk : departmentIdFk,
        "document_type_id_fk": documentTypeIdFk,
        "creator_id_fk": creatorIdFk,
        "small_leader_id_fk": smallLeaderIdFk,
        "big_leader_id_fk": bigLeaderIdFk,
        "task_status_id_fk": taskStatusId,
        "student_id_fk": studentIdFk,
        "view_id_fk": viewType,
      };
    }
    print("params to taskdoc >>> $params");

    return await Api.getTasks(params);
  }

  Future<dynamic> saveTask({
    String title,
    String identifier,
    String description,
    int trainingTypeIdFk,
    int documentTypeIdFk,
    int creatorIdFk,
    int smallLeaderIdFk,
    int departmentIdFk,
    bool readOnly,
  }) async {
    final params = {
      "title": title,
      "read_only": readOnly,
      "identifier": identifier,
      "description": description,
      "training_type_id_fk": trainingTypeIdFk,
      "document_type_id_fk": documentTypeIdFk,
      "creator_id_fk": creatorIdFk,
      "small_leader_id_fk": smallLeaderIdFk,
      "task_status_id_fk": 1
    };
    print(params);
    return await Api.saveTask(params);
  }

  Future<dynamic> saveTaskDocuments({
    int taskIdFk,
    int documentIdFk,
    String path,
    String name,
    String documentIdentifier,
  }) async {
    final params = {
      "identifier": documentIdentifier,
      "task_id_fk": taskIdFk,
      "path": path,
      "name": name,
      "document_id_fk": documentIdFk,
    };
    print("docs $params");
    return await Api.saveTaskDocs(params);
  }

  Future<dynamic> saveTaskDocumentTests({
    int documentIdFk,
    int selectedTestId,
    String selectedQuestion,
    List<String> selectedTotalAnswers,
    List<String> selectedCorrectAnsers,
    int taskIdFk,
    TextEditingController question,
  }) async {
    final params = {
      "question": selectedQuestion == null ? question : selectedQuestion,
      "task_id_fk": taskIdFk,
      "document_id_fk": documentIdFk,
      "document_test_id_fk": selectedTestId,
      "total_answers": selectedTotalAnswers,
      "right_answers": selectedCorrectAnsers,
    };
    print(params);
    return await Api.saveTaskDocumentsTests(params);
  }

  Future<dynamic> saveNewTaskDocumentFiles(
      {List<PlatformFile> documentFiles, int taskIdFk}) async {
    print(documentFiles);
    var params = FormData.fromMap({
      "identifier": Uuid().v4().replaceAll("-", ""),
      "task_id_fk": taskIdFk,
      "files": documentFiles
          .map((e) => MultipartFile.fromBytes(e.bytes, filename: e.name))
          .toList(),
    });
    print(params);
    return await Api.saveNewTaskDocumentFiles(params);
  }

  Future<dynamic> cancelCreatedTask(
      {int taskStatusId, List<int> taskIds}) async {
    final params = {"id": taskIds, "task_status_id_fk": taskStatusId};
    return await Api.cancelCreatedTask(params);
  }

  Future<dynamic> deleteTaskUsersRepo({int taskId, int studentIdFk}) async {
    final params = {
      "task_id_fk": taskId,
      "student_id_fk": studentIdFk,
    };
    return await Api.deleteTaskUsers(params);
  }

  // Future<dynamic> saveNewTaskDocumentTests(
  //     {int documentIdFk, List<TaskTestModel> taskTests, int taskIdFk}) async {
  //   final params = {
  //     "task_id_fk": taskIdFk,
  //     "document_id_fk": documentIdFk,
  //     "document_tests": taskTests
  //   };
  // }
}
