import 'package:gmptr/api/api.dart';

class UserRoleTrainingTypesRepo {
  Future<dynamic> loadUserRoleTraining({int userRoleIdFk}) async {
    final params = {"user_id_fk": userRoleIdFk};
    return await Api.getUserRoleTrainingTypes(params);
  }

  Future<dynamic> saveUserRoleTrainingType(
      {int userRoledIdFk, int trainingTypeIdFk, int status}) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "training_type_id_fk": trainingTypeIdFk,
      "status": status
    };
    print("training $params");
    return await Api.saveUserRoleTrainingType(params);
  }

  Future<dynamic> deleteUserRoleTrainingType(
      {int userRoledIdFk, int trainingTypeIdFk}) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "training_type_id_fk": trainingTypeIdFk
    };
    return await Api.deleteUserRoleTrainingType(params);
  }
}
