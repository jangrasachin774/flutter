import 'package:gmptr/api/api.dart';

class DepartmentsRepository {
  ///Fetch api loadDepartmentsList
  Future<dynamic> loadDepartments() async {
    return await Api.getDepartments();
  }

  /// Save api Department
  Future<dynamic> saveDepartments({
    int parentId,
    String name,
    int companyIdFk,
    int level,
    int status,
  }) async {
    final params = {
      "parent_department_id_fk": parentId,
      "name": name,
      "company_id_fk": companyIdFk,
      "level": level,
      "status": status
    };
    print("department $params");
    return await Api.saveDepartment(params);
  }

  /// UPDATE api Department
  Future<dynamic> updateDepartment({
    int id,
    String name,
  }) async {
    final params = {
      "id": id,
      "name": name,
    };
    print("department $params");
    return await Api.updateDepartment(params);
  }

  /// Delete api Department
  Future<dynamic> deleteDepartments({
    int id,
  }) async {
    final params = {
      "id": id,
    };
    print("department $params");
    return await Api.deleteDepartment(params);
  }

  Future<dynamic> departmentsUsers({int departmentIdFk, int roleIdFk}) async {
    final params = {"department_id_fk": departmentIdFk, "role_id_fk": roleIdFk};
    print("department users >>>> $params");
    return await Api.loadUsersById(params);
  }
}
