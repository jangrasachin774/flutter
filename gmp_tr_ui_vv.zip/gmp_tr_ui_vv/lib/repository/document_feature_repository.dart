import 'package:gmptr/api/api.dart';

class DocumentsFeatureRepository {
  ///Fetch api loadDocumentsFeatureList
  Future<dynamic> loadDocumentsFeature() async {
    return await Api.getDocumentsFeature();
  }

  /// Save api DocumentFeature
  Future<dynamic> saveDocumentsFeature({
    int parentId,
    String name,
    int companyIdFk,
    int level,
    int status,
  }) async {
    final params = {
      "parent_document_type_id_fk": parentId,
      "name": name,
      "level": level,
      "status": status
    };
    print("doc feature $params");
    return await Api.saveDocumentFeature(params);
  }

  /// UPDATE api DocumentFeature
  Future<dynamic> updateDocumentFeature({
    int id,
    String name,
  }) async {
    final params = {
      "id": id,
      "name": name,
    };
    print("doc feature $params");
    return await Api.updateDocumentFeature(params);
  }

  /// Delete api DocumentFeature
  Future<dynamic> deleteDocumentsFeature({
    int id,
  }) async {
    final params = {
      "id": id,
    };
    print("doc feature $params");
    return await Api.deleteDocumentFeature(params);
  }
}
