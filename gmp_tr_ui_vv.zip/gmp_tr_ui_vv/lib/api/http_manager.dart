import 'package:dio/dio.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/logger.dart';

Map<String, dynamic> dioErrorHandle(DioError error) {
  UtilLogger.log("ERROR", error);

  switch (error.type) {
    case DioErrorType.response:
      return error.response?.data;
    case DioErrorType.sendTimeout:
    case DioErrorType.receiveTimeout:
      return {"success": false, "code": "request_time_out"};

    default:
      return {"success": false, "code": "${error.message}"};
  }
}

class HTTPManager {
  BaseOptions baseOptions = BaseOptions(
    baseUrl: "http://139.9.146.31:3333/gmptr",
    connectTimeout: 10000,
    receiveTimeout: 10000,
    contentType: Headers.formUrlEncodedContentType,
    responseType: ResponseType.json,
  );

  ///Setup Option
  BaseOptions exportOption(BaseOptions options) {
    Map<String, dynamic> header = {
      "Lang": AppLanguage.defaultLanguage?.languageCode,
      "Access-Control-Allow-Origin": "*", // Required for CORS support to work
      "Access-Control-Allow-Headers":
          "Origin,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,locale",
      "Access-Control-Allow-Methods": "GET,POST, OPTIONS",
      'Content-Type': 'application/json;charset=UTF-8',
      'Charset': 'utf-8'
    };
    options.headers.addAll(header);
    // if (Application.user?.token != null) {
    //   options.headers["Authorization"] = "Bearer ${Application.user.token}";
    // }
    UtilLogger.log("headers", options.headers);
    return options;
  }

  ///Post form data
  Future<dynamic> formData({
    String url,
    FormData data,
    ProgressCallback onSendProgress,
  }) async {
    UtilLogger.log("POST URL", url);
    UtilLogger.log("DATA", data);
    Dio dio =
        new Dio(exportOption(baseOptions)..contentType = "Multipart/form-data");
    try {
      final response =
          await dio.post(url, data: data, onSendProgress: onSendProgress);

      return response.data;
    } on DioError catch (error) {
      print("dio $error");
      return dioErrorHandle(error);
    }
  }

  ///Post method
  Future<dynamic> post({
    String url,
    Map<String, dynamic> data,
    Options options,
  }) async {
    UtilLogger.log("POST URL", url);

    Dio dio = new Dio(exportOption(baseOptions));
    try {
      final response = await dio.post(
        url,
        data: data,
        options: options,
      );

      return response.data;
    } on DioError catch (error) {
      print("dio $error");
      return dioErrorHandle(error);
    }
  }

  ///Get method
  Future<dynamic> get({
    String url,
    Map<String, dynamic> params,
    Options options,
  }) async {
    UtilLogger.log("GET URL", url);
    UtilLogger.log("PARAMS", params);
    Dio dio = new Dio(exportOption(baseOptions));
    try {
      final response = await dio.get(
        url,
        queryParameters: params,
        options: options,
      );

      return response.data;
    } on DioError catch (error) {
      return dioErrorHandle(error);
    }
  }

  factory HTTPManager() {
    return HTTPManager._internal();
  }

  HTTPManager._internal();
}

HTTPManager httpManager = HTTPManager();
