import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UsersListState extends Equatable {
  const UsersListState();
  @override
  List<Object> get props => [];
}

class InitialUsersList extends UsersListState {}

class UsersLoading extends UsersListState {}

class UsersEmpty extends UsersListState {}

class UsersSuccess extends UsersListState {
  final List<UsersModel> users;
  UsersSuccess(this.users);
  @override
  List<Object> get props => [users];
}

class UsersFail extends UsersListState {
  final String code;
  UsersFail({this.code});
}

class FilteredUsersLoading extends UsersListState {}

class FilteredUsersEmpty extends UsersListState {}

class FilteredUsersSuccess extends UsersListState {
  final List<UsersModel> users;
  FilteredUsersSuccess(this.users);
  @override
  List<Object> get props => [users];
}

class FilteredUsersFail extends UsersListState {
  final String code;
  FilteredUsersFail({this.code});
}

class UserSaving extends UsersListState {}

class UserSaveSuccess extends UsersListState {}

class UserSaveFail extends UsersListState {
  final bool error;
  UserSaveFail(this.error);
}

class UserUpdating extends UsersListState {}

class UserUpdateSuccess extends UsersListState {}

class UserUpdateFail extends UsersListState {
  final bool error;
  UserUpdateFail(this.error);
}

class StatusUpdating extends UsersListState {}

class StatusUpdateSuccess extends UsersListState {
  final int userStatusIdFk;
  StatusUpdateSuccess({this.userStatusIdFk});
}

class StatusUpdateFail extends UsersListState {
  final String error;
  StatusUpdateFail({this.error});
}
