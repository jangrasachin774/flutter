import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleDocTypesListState extends Equatable {
  const UserRoleDocTypesListState();
  @override
  List<Object> get props => [];
}

class InitialUserRoleDocTypesList extends UserRoleDocTypesListState {}

class UserRoleDocTypesLoading extends UserRoleDocTypesListState {}

class UserRoleDocTypesSuccess extends UserRoleDocTypesListState {
  final List<UserRoleDocTypesModel> userroleDocType;
  UserRoleDocTypesSuccess(this.userroleDocType);
  @override
  List<Object> get props => [userroleDocType];
}

class UserRoleDocTypesFail extends UserRoleDocTypesListState {
  final String code;
  UserRoleDocTypesFail({this.code});
}

class UserRoleDocTypeSaving extends UserRoleDocTypesListState {}

class UserRoleDocTypeSaveSuccess extends UserRoleDocTypesListState {}

class UserRoleDocTypeSaveFail extends UserRoleDocTypesListState {
  final String error;
  UserRoleDocTypeSaveFail({this.error});
}

class UserRoleDocTypeDeleting extends UserRoleDocTypesListState {}

class UserRoleDocTypeDeleteSuccess extends UserRoleDocTypesListState {}

class UserRoleDocTypeDeleteFail extends UserRoleDocTypesListState {
  final String error;
  UserRoleDocTypeDeleteFail(this.error);
}
