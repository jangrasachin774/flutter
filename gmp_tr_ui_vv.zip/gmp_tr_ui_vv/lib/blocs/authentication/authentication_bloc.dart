import 'dart:async';
import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import 'authentication_event.dart';
import 'authentication_state.dart';

class AuthBloc extends Bloc<AuthenticationEvent, AuthenticationState> {
  AuthBloc() : super(InitialAuthenticationState());
  final userRepository = UserRepository();

  @override
  Stream<AuthenticationState> mapEventToState(event) async* {
    if (event is OnAuthCheck) {
      ///Notify state AuthenticationBeginCheck
      yield AuthenticationBeginCheck();
      final hasUser = userRepository.getUser();
      print("hasUser $hasUser");

      if (hasUser != null) {
        ///Getting data from Storage
        final user = UserModel.fromJson(jsonDecode(hasUser));

        ///Setter user
        Application.user = user;

        await userRepository.saveUser(user: user);
        yield AuthenticationSuccess();
      } else {
        ///Notify loading to UI
        yield AuthenticationFail();
      }
    }

    if (event is OnSaveUser) {
      ///Save to Storage user via repository
      await userRepository.saveUser(user: event.user);

      ///Notify loading to UI
      yield AuthenticationSuccess();
    }

    if (event is OnClear) {
      ///Delete user
      await userRepository.deleteUser();

      ///Check result delete user
      yield AuthenticationFail();
    }
  }
}
