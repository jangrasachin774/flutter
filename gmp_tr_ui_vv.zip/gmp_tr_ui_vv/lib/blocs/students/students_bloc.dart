import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/students/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class StudentsBloc extends Bloc<StudentsEvent, StudentsState> {
  StudentsBloc() : super(InitialStudents());

  final studentsRepository = StudentsRepository();

  @override
  Stream<StudentsState> mapEventToState(StudentsEvent event) async* {
    //Load Students
    if (event is OnLoadStudents) {
      yield StudentsLoading();

      try {
        ///Fetch API via repository
        final List<ReadUsersByIdModel> response =
            await studentsRepository.loadStudentsRepository(
                departmentIdFk: event.departmentIdFk, roleIdFk: event.roleIdFk);

        ///Notify loading to UI
        yield StudentsSuccess(response);
      } catch (e) {
        yield StudentsFail(code: e.toString());
      }
    }
    if (event is OnSearchStudents) {
      yield StudentsLoading();
      try {
        if (event.query.isNotEmpty) {
          final List<ReadUsersByIdModel> result = event.students
              .where((student) => student.name
                  .toLowerCase()
                  .contains(event.query.toLowerCase()))
              .toList();
          yield StudentsSuccess(result);
        } else if (event.query.isEmpty) {
          final List<ReadUsersByIdModel> response =
              await studentsRepository.loadStudentsRepository(
                  departmentIdFk: event.departmentIdFk,
                  roleIdFk: event.roleIdFk);

          ///Notify loading to UI
          yield StudentsSuccess(response);
        }
      } catch (e) {
        yield StudentsFail(code: e.toString());
      }
    }
  }
}
