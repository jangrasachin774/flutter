import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class StudentsState extends Equatable {
  const StudentsState();
  @override
  List<Object> get props => [];
}

class InitialStudents extends StudentsState {}

class StudentsLoading extends StudentsState {}

class StudentsSuccess extends StudentsState {
  final List<ReadUsersByIdModel> students;
  StudentsSuccess(this.students);
  @override
  List<Object> get props => [students];
}

class StudentsFail extends StudentsState {
  final String code;
  StudentsFail({this.code});
}

class Studentsaving extends StudentsState {}

class StudentsaveSuccess extends StudentsState {}

class StudentsaveFail extends StudentsState {
  final bool error;
  StudentsaveFail(this.error);
}
