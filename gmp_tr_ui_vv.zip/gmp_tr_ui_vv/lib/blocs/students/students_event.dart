import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class StudentsEvent extends Equatable {
  const StudentsEvent();
  @override
  List<Object> get props => [];
}

class OnLoadStudentsEvent extends StudentsEvent {}

class OnLoadStudents extends StudentsEvent {
  final int departmentIdFk;
  final int roleIdFk;
  final List<ReadUsersByIdModel> students;
  OnLoadStudents({this.students, this.departmentIdFk, this.roleIdFk});
  @override
  List<Object> get props => [students, departmentIdFk, roleIdFk];
}

class OnSearchStudents extends StudentsEvent {
  final String query;
  final List<ReadUsersByIdModel> students;
  final int departmentIdFk;
  final int roleIdFk;
  OnSearchStudents(
      {this.departmentIdFk, this.roleIdFk, this.students, this.query});
  @override
  List<Object> get props => [students, query, departmentIdFk, roleIdFk];
}

class OnUpdateTaskToUsers extends StudentsEvent {
  final int id;
  final int taskId;
  final int studentId;
  OnUpdateTaskToUsers({this.id, this.studentId, this.taskId});
}
