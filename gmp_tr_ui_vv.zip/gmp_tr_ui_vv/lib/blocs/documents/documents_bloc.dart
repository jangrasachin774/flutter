import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/documents/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class DocumentsBloc extends Bloc<DocumentsEvent, DocumentsState> {
  DocumentsBloc() : super(InitialDocuments());

  final documentsRepository = DocumentsRepository();

  @override
  Stream<DocumentsState> mapEventToState(DocumentsEvent event) async* {
    int currentUserId;

    //Load Documents
    if (event is OnLoadDocuments) {
      yield DocumentsLoading();

      try {
        List<DocumentsModel> response;

        ///Fetch API via repository
        response = await documentsRepository.loadDocuments(
            criteria: event.criteria,
            startDate: event.startDate,
            endDate: event.endDate,
            trainingTypeIdFk: event.trainingTypeIdFk,
            departmentIdFk: event.departmentIdFk,
            documentType: event.documentFeature,
            documentId: event.documentId,
            viewTypeIdFk: event.viewTypeIdFk,
            viewType: event.taskDocuments,
            documentTypeIdFk: event.documentTypeIdFk);
        if (response.isNotEmpty || response.length != 0) {
          ///Notify loading to UI
          yield DocumentsSuccess(response);
        } else {
          yield DocumentsEmpty();
        }
      } catch (e) {
        yield DocumentsFail(code: e.toString());
      }
    }

    /// ADD DOCUMENT
    if (event is OnAddDocument) {
      currentUserId = Application.user.id;
      yield Documentsaving();
      try {
        final DocumentsModel response = await documentsRepository.saveDocument(
          identifier: event.identifier,
          title: event.title,
          trainingTypeIdFk: event.trainingTypeIdFk,
          departmentIdFk: event.departmentIdFk,
          documentTypeIdFk: event.documentTypeIdFk,
          smallLeaderIdFk: event.smallLeaderIdFk,
          description: event.description,
          bigLeaderIdFk: event.bigLeaderIdFk,
          creatorIdFk: currentUserId,
          status: 1,
        );
        if (response.success) {
          final documentId = response.id;
          await documentsRepository.saveDocumentId(documentId);
          yield DocumentsaveSuccess();
        } else {
          yield DocumentsaveFail(response.success);
        }
      } catch (e) {
        print(e.toString());
      }
    }

    /// UPDATE DOCUMENT
    if (event is OnUpdateDocument) {
      currentUserId = Application.userId;
      yield DocumentUpdating();
      await documentsRepository.updateDocument(
        id: event.id,
        identifier: event.identifier,
        title: event.title,
        trainingTypeIdFk: event.trainingTypeIdFk,
        departmentIdFk: event.departmentIdFk,
        documentTypeIdFk: event.documentTypeIdFk,
        smallLeaderIdFk: event.smallLeaderIdFk,
        description: event.description,
        bigLeaderIdFk: event.bigLeaderIdFk,
        creatorIdFk: currentUserId,
        status: event.status,
      );
      await documentsRepository.saveDocumentId(event.id);
      yield DocumentUpdateSuccess();
    }

    /// UPDATE STATUS
    if (event is OnUpdateDocumentStatus) {
      yield OnUpdatingDocumentStatus();
      try {
        await documentsRepository.updateDocumentStatus(
          docIds: event.docIds,
          id: event.id,
          status: event.status,
        );
        yield OnUpdateDocumentStatusSuccess(docStatusId: event.status);
      } catch (e) {
        OnUpdatingDocumentStatusFail(error: e);
      }
    }

    // if (event is ValidatingDocVersion) {
    //   yield DocumentVersionFetching();
    //   try {
    //     List<DocVersionsModel> docVersions;
    //     docVersions =
    //         await documentsRepository.validateDocVersions(title: event.title);
    //     if (docVersions.isNotEmpty || docVersions.length != 0) {
    //       yield DocumentVersionFetchSuccess(versions: docVersions);
    //     } else {
    //       yield DocumentVersionEmpty();
    //     }
    //   } catch (e) {
    //     yield DocumentVersionFetchFailed();
    //   }
    // }

    if (event is OnLoadDocumentTitles) {
      yield DocumentsLoading();

      try {
        List<DocumentsModel> response;

        ///Fetch API via repository
        response = await documentsRepository.getDocumentTitles(
          trainingTypeIdFk: event.trainingTypeIdFk,
          departmentIdFk: event.departmentIdFk,
          documentType: event.documentFeature,
          version: event.version,
        );
        if (response.isNotEmpty || response.length != 0) {
          ///Notify loading to UI
          yield DocumentsSuccess(response);
        } else {
          yield DocumentsEmpty();
        }
      } catch (e) {
        yield DocumentsFail(code: e.toString());
      }
    }
  }
}
