import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentsState extends Equatable {
  const DocumentsState();
  @override
  List<Object> get props => [];
}

class InitialDocuments extends DocumentsState {}

class DocumentsLoading extends DocumentsState {}

class DocumentsSuccess extends DocumentsState {
  final List<DocumentsModel> documents;
  DocumentsSuccess(this.documents);
  @override
  List<Object> get props => [documents];
}

class DocumentsFail extends DocumentsState {
  final String code;
  DocumentsFail({this.code});
}

class DocumentsEmpty extends DocumentsState {}

class Documentsaving extends DocumentsState {}

class DocumentsaveSuccess extends DocumentsState {}

class DocumentsaveFail extends DocumentsState {
  final bool error;
  DocumentsaveFail(this.error);
}

class DocumentUpdating extends DocumentsState {}

class DocumentUpdateSuccess extends DocumentsState {}

class DocumentUpdateFail extends DocumentsState {
  final String error;
  DocumentUpdateFail(this.error);
}

class OnUpdatingDocumentStatus extends DocumentsState {}

class OnUpdateDocumentStatusSuccess extends DocumentsState {
  final int docStatusId;
  OnUpdateDocumentStatusSuccess({this.docStatusId});
}

class OnUpdatingDocumentStatusFail extends DocumentsState {
  final String error;
  OnUpdatingDocumentStatusFail({this.error});
}

// class DocumentVersionFetching extends DocumentsState {}

// class DocumentVersionFetchSuccess extends DocumentsState {
//   final List<DocVersionsModel> versions;
//   DocumentVersionFetchSuccess({this.versions});
// }

// class DocumentVersionEmpty extends DocumentsState {}

// class DocumentVersionFetchFailed extends DocumentsState {}
