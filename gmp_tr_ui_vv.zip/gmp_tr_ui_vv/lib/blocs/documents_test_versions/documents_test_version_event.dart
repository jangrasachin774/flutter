import 'package:equatable/equatable.dart';

abstract class DocumentTestVersionsEvent extends Equatable {
  const DocumentTestVersionsEvent();
  @override
  List<Object> get props => [];
}

// ignore: must_be_immutable
class ValidatingTestDocVersion extends DocumentTestVersionsEvent {
  String title;
  int viewIdFk = 4;
  String version;
  ValidatingTestDocVersion({this.title, this.version, this.viewIdFk});
}
