import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/documents_test_versions/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class DocumentTestVersionsBloc
    extends Bloc<DocumentTestVersionsEvent, DocumentTestVersionsState> {
  DocumentTestVersionsBloc() : super(InitialDocumentsTestVersions());

  final documentsRepository = DocumentsRepository();

  @override
  Stream<DocumentTestVersionsState> mapEventToState(
      DocumentTestVersionsEvent event) async* {
    if (event is ValidatingTestDocVersion) {
      yield DocumentTestVersionFetching();
      try {
        List<DocVersionsModel> testVersions;
        testVersions = await documentsRepository.validateTestDocVersions(
            title: event.title, viewIdFk: event.viewIdFk);
        if (testVersions.isNotEmpty || testVersions.length != 0) {
          yield DocumentTestVersionFetchSuccess(testVersions);
        } else {
          yield DocumentTestVersionEmpty();
        }
      } catch (e) {
        yield DocumentTestVersionFetchFailed();
      }
    }
  }
}
