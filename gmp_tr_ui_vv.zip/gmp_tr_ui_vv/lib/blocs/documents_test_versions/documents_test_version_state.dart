import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentTestVersionsState extends Equatable {
  const DocumentTestVersionsState();
  @override
  List<Object> get props => [];
}

class InitialDocumentsTestVersions extends DocumentTestVersionsState {}

class DocumentTestVersionFetching extends DocumentTestVersionsState {
  @override
  List<Object> get props => [];
}

class DocumentTestVersionFetchSuccess extends DocumentTestVersionsState {
  final List<DocVersionsModel> testVersions;
  DocumentTestVersionFetchSuccess(this.testVersions);
  @override
  List<Object> get props => [testVersions];
}

class DocumentTestVersionEmpty extends DocumentTestVersionsState {
  @override
  List<Object> get props => [];
}

class DocumentTestVersionFetchFailed extends DocumentTestVersionsState {
  @override
  List<Object> get props => [];
}
