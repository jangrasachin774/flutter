import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/forgot_password/bloc.dart';
import 'package:gmptr/repository/user_repository.dart';

class ForgotPassBloc extends Bloc<ForgotPassEvent, ForgotPassState> {
  ForgotPassBloc() : super(InitialForgotPass());
  final userRepository = UserRepository();

  @override
  Stream<ForgotPassState> mapEventToState(ForgotPassEvent event) async* {
    if (event is OnForgotPass) {
      yield ChangingPass();

      try {
        var res = await Api.forgotPasswordExist(event.emailId);
        if (res['ok']) {
          yield ForgotPassSuccess();
        } else {
          yield ForgotPassFail(error: res['msg']);
        }
      } catch (e) {
        yield ForgotPassFail(error: e.toString());
      }
    }
  }
}
