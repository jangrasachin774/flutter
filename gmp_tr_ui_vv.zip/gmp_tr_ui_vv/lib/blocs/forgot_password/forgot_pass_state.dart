import 'package:meta/meta.dart';

@immutable
abstract class ForgotPassState {}

class InitialForgotPass extends ForgotPassState {}

class ChangingPass extends ForgotPassState {}

class ForgotPassFail extends ForgotPassState {
  final String error;

  ForgotPassFail({this.error});
}

class ForgotPassSuccess extends ForgotPassState {}
