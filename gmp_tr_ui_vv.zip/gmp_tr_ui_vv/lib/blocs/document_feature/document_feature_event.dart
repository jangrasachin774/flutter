import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentsFeatureListEvent extends Equatable {
  const DocumentsFeatureListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadDocumentsFeatureEvent extends DocumentsFeatureListEvent {}

class OnLoadDocumentsFeature extends DocumentsFeatureListEvent {
  final List<DocumentsFeature> documentsFeature;
  OnLoadDocumentsFeature({this.documentsFeature});
}

class OnAddDocumentFeature extends DocumentsFeatureListEvent {
  final int parentId;
  final String name;

  final int level;
  final int status;
  OnAddDocumentFeature({
    this.parentId,
    this.name,
    this.level,
    this.status,
  });
  @override
  List<Object> get props => [];
}

class OnUpdateDocumentFeature extends DocumentsFeatureListEvent {
  final int id;
  final String name;

  OnUpdateDocumentFeature({this.id, this.name});
}

class OnRemoveDocumentFeature extends DocumentsFeatureListEvent {
  final int id;
  OnRemoveDocumentFeature({this.id});
}
