import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentsFeatureListState extends Equatable {
  const DocumentsFeatureListState();
  @override
  List<Object> get props => [];
}

class InitialDocumentsFeatureList extends DocumentsFeatureListState {}

class DocumentsFeatureLoading extends DocumentsFeatureListState {}

class DocumentsFeatureSuccess extends DocumentsFeatureListState {
  final List<DocumentsFeature> documentsFeature;
  DocumentsFeatureSuccess(this.documentsFeature);
  @override
  List<Object> get props => [documentsFeature];
}

class DocumentsFeatureFail extends DocumentsFeatureListState {
  final String code;
  DocumentsFeatureFail({this.code});
}

class DocumentsFeatureaving extends DocumentsFeatureListState {}

class DocumentsFeatureaveSuccess extends DocumentsFeatureListState {}

class DocumentsFeatureaveFail extends DocumentsFeatureListState {
  final String code;
  DocumentsFeatureaveFail({this.code});
}

class DocumentFeatureUpdating extends DocumentsFeatureListState {}

class DocumentFeatureUpdatingSuccess extends DocumentsFeatureListState {}

class DocumentFeatureUpdatingFail extends DocumentsFeatureListState {
  final String code;
  DocumentFeatureUpdatingFail({this.code});
}

class DocumentFeatureDeleting extends DocumentsFeatureListState {}

class DocumentFeatureDeleteSuccess extends DocumentsFeatureListState {}

class DocumentFeatureDeleteFail extends DocumentsFeatureListState {
  final String code;
  DocumentFeatureDeleteFail({this.code});
}
