import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TaskUsersListState extends Equatable {
  const TaskUsersListState();
  @override
  List<Object> get props => [];
}

class InitialTaskUsersList extends TaskUsersListState {}

class TaskUsersLoading extends TaskUsersListState {}

class TaskUsersSuccess extends TaskUsersListState {
  final List<TaskStudents> tasks;
  TaskUsersSuccess({this.tasks});
  @override
  List<Object> get props => [tasks];
}

class TaskUsersFail extends TaskUsersListState {
  final String code;
  TaskUsersFail({this.code});
}

class TaskUserDeleting extends TaskUsersListState {}

class TaskUserDeletedSuccess extends TaskUsersListState {}

class TaskUserDeleteFail extends TaskUsersListState {
  final String error;
  TaskUserDeleteFail(this.error);
}
