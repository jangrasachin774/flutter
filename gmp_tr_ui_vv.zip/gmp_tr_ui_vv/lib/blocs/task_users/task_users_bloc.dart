import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/task_users/bloc.dart';
import 'package:gmptr/repository/repository.dart';

class TaskUsersListBloc extends Bloc<TaskUsersListEvent, TaskUsersListState> {
  TaskUsersListBloc() : super(InitialTaskUsersList());

  final tasksRepository = TasksRepository();

  @override
  Stream<TaskUsersListState> mapEventToState(TaskUsersListEvent event) async* {
    if (event is InitialTaskUserPageEvent) {
      yield InitialTaskUsersList();
    }
    // UPDATE TaskUsers
    if (event is OnDeleteTaskUser) {
      yield TaskUserDeleting();
      try {
        await tasksRepository.deleteTaskUsersRepo(
          taskId: event.taskId,
          studentIdFk: event.studentIdFk,
        );
        yield TaskUserDeletedSuccess();
      } catch (e) {
        yield TaskUserDeleteFail(e);
      }
    }
  }
}
