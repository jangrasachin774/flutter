import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/user_role_departments/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class UserRoleDepartmentsListBloc
    extends Bloc<UserRoleDepartmentsListEvent, UserRoleDepartmentsListState> {
  UserRoleDepartmentsListBloc() : super(InitialUserRoleDepartmentsList());

  final userRoleDepartmentsRepository = UserRoleDepartmentsRepo();

  @override
  Stream<UserRoleDepartmentsListState> mapEventToState(
      UserRoleDepartmentsListEvent event) async* {
    int userRoleId;

    ///LOADING USER ROLE DEPARTMENTS
    if (event is OnLoadUserRoleDepartments) {
      print(event.userRoleIdFk);
      print("user role dep");

      yield UserRoleDepartmentsLoading();
      try {
        final List<UserRoleDepartmentsModel> userRoleDept =
            await userRoleDepartmentsRepository.loadUserRoleDept(
                userRoleIdFk: event.userRoleIdFk);
        yield UserRoleDepartmentsSuccess(userRoleDept);
      } catch (e) {
        yield UserRoleDepartmentsFail(code: e.toString());
      }
    }

    /// CREATE SINGLE USER ROLE DEPARTMENTS
    if (event is OnCreateSingleUserRoleDepartment) {
      userRoleId = Application.userRoleId;
      yield UserRoleDepartmentSaving();
      try {
        await userRoleDepartmentsRepository.saveUserRoleDepartment(
          userRoledIdFk: userRoleId,
          departmentIdFk: event.departmentIdFk,
          status: 0,
        );

        yield UserRoleDepartmentSaveSuccess();
      } catch (e) {
        yield UserRoleDepartmentSaveFail(error: e.toString());
      }
    }

    if (event is OnRemoveSingleUserRoleDepartment) {
      userRoleId = Application.userRoleId;
      yield UserRoleDepartmentDeleting();
      try {
        await userRoleDepartmentsRepository.deleteUserRoleDepartment(
          userRoledIdFk: userRoleId,
          departmentIdFk: event.departmentIdFk,
        );

        yield UserRoleDepartmentDeleteSuccess();
      } catch (e) {
        yield UserRoleDepartmentDeleteFail(e.toString());
      }
    }
  }
}
