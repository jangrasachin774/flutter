import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleDepartmentsListState extends Equatable {
  const UserRoleDepartmentsListState();
  @override
  List<Object> get props => [];
}

class InitialUserRoleDepartmentsList extends UserRoleDepartmentsListState {}

class UserRoleDepartmentsLoading extends UserRoleDepartmentsListState {}

class UserRoleDepartmentsSuccess extends UserRoleDepartmentsListState {
  final List<UserRoleDepartmentsModel> userroleDepartment;
  UserRoleDepartmentsSuccess(this.userroleDepartment);
  @override
  List<Object> get props => [userroleDepartment];
}

class UserRoleDepartmentsFail extends UserRoleDepartmentsListState {
  final String code;
  UserRoleDepartmentsFail({this.code});
}

class UserRoleDepartmentSaving extends UserRoleDepartmentsListState {}

class UserRoleDepartmentSaveSuccess extends UserRoleDepartmentsListState {}

class UserRoleDepartmentSaveFail extends UserRoleDepartmentsListState {
  final String error;
  UserRoleDepartmentSaveFail({this.error});
}

class UserRoleDepartmentDeleting extends UserRoleDepartmentsListState {}

class UserRoleDepartmentDeleteSuccess extends UserRoleDepartmentsListState {}

class UserRoleDepartmentDeleteFail extends UserRoleDepartmentsListState {
  final String error;
  UserRoleDepartmentDeleteFail(this.error);
}
