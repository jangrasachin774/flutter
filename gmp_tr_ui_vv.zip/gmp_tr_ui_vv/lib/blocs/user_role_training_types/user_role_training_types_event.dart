import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleTrainingTypesListEvent extends Equatable {
  const UserRoleTrainingTypesListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserRoleTrainingTypesEvent extends UserRoleTrainingTypesListEvent {}

class OnLoadUserRoleTrainingTypes extends UserRoleTrainingTypesListEvent {
  final int userRoleIdFk;
  final List<UserRoleTrainingTypesModel> userRoleTrainingType;
  OnLoadUserRoleTrainingTypes({this.userRoleTrainingType, this.userRoleIdFk});
  @override
  List<Object> get props => [userRoleTrainingType];
}

class OnCreateUserRoleTrainingType extends UserRoleTrainingTypesListEvent {
  final int userId;
  final int userRoles;
  OnCreateUserRoleTrainingType({this.userId, this.userRoles});
}

class OnCreateSingleUserRoleTrainingType
    extends UserRoleTrainingTypesListEvent {
  final int userRoldIdFk;
  final int trainingTypeIdFk;
  OnCreateSingleUserRoleTrainingType(
      {this.userRoldIdFk, this.trainingTypeIdFk});
}

class OnRemoveUserRoleTrainingType extends UserRoleTrainingTypesListEvent {
  final int id;
  final int trainingTypeIdFk;

  OnRemoveUserRoleTrainingType({this.id, this.trainingTypeIdFk});
}

class OnRemoveUserRoleTrainingTypeId extends UserRoleTrainingTypesListEvent {
  final int id;

  OnRemoveUserRoleTrainingTypeId({this.id});
}
