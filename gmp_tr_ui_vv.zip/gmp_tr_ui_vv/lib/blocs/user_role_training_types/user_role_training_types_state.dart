import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleTrainingTypesListState extends Equatable {
  const UserRoleTrainingTypesListState();
  @override
  List<Object> get props => [];
}

class InitialUserRoleTrainingTypesList extends UserRoleTrainingTypesListState {}

class UserRoleTrainingTypesLoading extends UserRoleTrainingTypesListState {}

class UserRoleTrainingTypesSuccess extends UserRoleTrainingTypesListState {
  final List<UserRoleTrainingTypesModel> userRoleTrainingType;
  UserRoleTrainingTypesSuccess(this.userRoleTrainingType);
  @override
  List<Object> get props => [userRoleTrainingType];
}

class UserRoleTrainingTypesFail extends UserRoleTrainingTypesListState {
  final String code;
  UserRoleTrainingTypesFail({this.code});
}

class UserRoleTrainingTypeSaving extends UserRoleTrainingTypesListState {}

class UserRoleTrainingTypeSaveSuccess extends UserRoleTrainingTypesListState {}

class UserRoleTrainingTypeSaveFail extends UserRoleTrainingTypesListState {
  final String error;
  UserRoleTrainingTypeSaveFail({this.error});
}

class UserRoleTrainingTypeDeleting extends UserRoleTrainingTypesListState {}

class UserRoleTrainingTypeDeleteSuccess extends UserRoleTrainingTypesListState {
}

class UserRoleTrainingTypeDeleteFail extends UserRoleTrainingTypesListState {
  final String error;
  UserRoleTrainingTypeDeleteFail(this.error);
}
