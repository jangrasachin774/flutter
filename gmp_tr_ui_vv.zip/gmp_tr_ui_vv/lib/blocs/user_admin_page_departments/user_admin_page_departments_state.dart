import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserAdminPageDepartmentsState extends Equatable {
  const UserAdminPageDepartmentsState();
  @override
  List<Object> get props => [];
}

class InitialUserAdminPageDepartments extends UserAdminPageDepartmentsState {}

class UserAdminPageDepartmentsLoading extends UserAdminPageDepartmentsState {}

class UserAdminPageDepartmentsSuccess extends UserAdminPageDepartmentsState {
  final List<UserAdminPageDepartmentsModel> adminPages;
  UserAdminPageDepartmentsSuccess(this.adminPages);
  @override
  List<Object> get props => [adminPages];
}

class UserAdminPageDepartmentsFail extends UserAdminPageDepartmentsState {
  final String code;
  UserAdminPageDepartmentsFail({this.code});
}

class UserAdminPageDepartmentSaving extends UserAdminPageDepartmentsState {}

class UserAdminPageDepartmentSaveSuccess extends UserAdminPageDepartmentsState {
}

class UserAdminPageDepartmentSaveFail extends UserAdminPageDepartmentsState {
  final String error;
  UserAdminPageDepartmentSaveFail(this.error);
}

class UserAdminPageDepartmentDeleting extends UserAdminPageDepartmentsState {}

class UserAdminPageDepartmentDeleteSuccess
    extends UserAdminPageDepartmentsState {}

class UserAdminPageDepartmentDeleteFail extends UserAdminPageDepartmentsState {
  final String error;
  UserAdminPageDepartmentDeleteFail({this.error});
  @override
  List<Object> get props => [this.error];
}
