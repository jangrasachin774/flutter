import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/view_type/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class ViewTypeListBloc extends Bloc<ViewTypeListEvent, ViewTypeListState> {
  ViewTypeListBloc() : super(InitialViewTypeList());

  final viewTypesRepository = ViewTypeRepository();

  @override
  Stream<ViewTypeListState> mapEventToState(ViewTypeListEvent event) async* {
    //Load ViewType
    if (event is OnLoadViewType) {
      yield ViewTypeLoading();

      try {
        ///Fetch API via repository
        final List<ViewTypeModel> response =
            await viewTypesRepository.loadViewTypes();
        print("view types >>>>> $response");

        ///Notify loading to UI
        yield ViewTypeSuccess(response);
      } catch (e) {
        print("error >>>>>> $e");
        yield ViewTypeFail(code: e.toString());
      }
    }
  }
}
