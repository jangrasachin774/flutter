import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/tests/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class TestsBloc extends Bloc<TestsEvent, TestsState> {
  TestsBloc() : super(InitialTests());

  final testsRepository = TestsRepository();

  @override
  Stream<TestsState> mapEventToState(TestsEvent event) async* {
    var attempts;

    ///SAVE TEST
    if (event is OnSaveTest) {
      yield Testsaving();

      final TaskTestAnswers testsResponse =
          await testsRepository.saveTestRepository(
        testIdFk: event.testIdFk,
        studentIdFk: event.studentIdFk,
        selectedAnswers: event.selectedAnswers,
      );

      if (testsResponse.success != null && testsResponse.success) {
        yield TestsaveSuccess();
      }
      if (testsResponse.error != null && testsResponse.error.isNotEmpty) {
        yield TestsaveFail("CANNOT_TAKE_TEST_STUDENT");
      }
      if (testsResponse.failed != null && testsResponse.failed) {
        attempts = testsResponse.attempts;
        yield TestAttemptsFailed(attempts: attempts);
      }
    }
  }
}
