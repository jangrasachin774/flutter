import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TestsEvent extends Equatable {
  const TestsEvent();
  @override
  List<Object> get props => [];
}

class OnLoadTestsEvent extends TestsEvent {}

class OnLoadTests extends TestsEvent {
  final int departmentIdFk;
  final int roleIdFk;
  final List<ReadUsersByIdModel> tests;
  OnLoadTests({this.tests, this.departmentIdFk, this.roleIdFk});
  @override
  List<Object> get props => [tests, departmentIdFk, roleIdFk];
}

class OnSaveTest extends TestsEvent {
  final int id;
  final int testIdFk;
  final int studentIdFk;
  final int taskDocumentTestIdFk;
  final List<dynamic> selectedAnswers;
  OnSaveTest(
      {this.id,
      this.testIdFk,
      this.studentIdFk,
      this.taskDocumentTestIdFk,
      this.selectedAnswers});
}
