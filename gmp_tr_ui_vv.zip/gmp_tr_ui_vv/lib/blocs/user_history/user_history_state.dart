import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UsersHistoryState extends Equatable {
  const UsersHistoryState();
  @override
  List<Object> get props => [];
}

class InitialUsersHistory extends UsersHistoryState {}

class UserHistoryLoading extends UsersHistoryState {}

class UserHistoryLoadedSuccess extends UsersHistoryState {
  final List<UserHistoryModel> userHistory;
  UserHistoryLoadedSuccess({this.userHistory});
}

class UserHistoryLoadFail extends UsersHistoryState {
  final String error;
  UserHistoryLoadFail({this.error});
}
