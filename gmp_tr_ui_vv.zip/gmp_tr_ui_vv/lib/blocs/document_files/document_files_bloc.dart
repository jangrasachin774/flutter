import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/document_files/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class DocumentFilesBloc extends Bloc<DocumentFilesEvent, DocumentFilesState> {
  DocumentFilesBloc() : super(InitialDocumentFiles());

  final documentFilesRepository = DocumentFilesRepository();

  @override
  Stream<DocumentFilesState> mapEventToState(DocumentFilesEvent event) async* {
    int currentDocumentId;

    //Load DocumentFiles
    if (event is OnLoadDocumentFiles) {
      yield DocumentFilesLoading();

      try {
        ///Fetch API via repository
        final List<DocumentFilesModel> response =
            await documentFilesRepository.loadDocumentFiles();

        ///Notify loading to UI
        yield DocumentFilesSuccess(response);
      } catch (e) {
        yield DocumentFilesFail(code: e.toString());
      }
    }

    /// ADD DOCUMENT
    if (event is OnAddDocumentFile) {
      currentDocumentId = Application.documentId;
      yield DocumentFilesaving();
      try {
        await documentFilesRepository.saveDocumentFile(
            identifier: event.identifier,
            documentIdFk: currentDocumentId,
            fileName: event.fileName,
            file: event.file);
        yield DocumentFilesaveSuccess();
      } catch (e) {
        yield DocumentFilesaveFail(e);
      }
    }

    /// UPDATE DOCUMENT
    if (event is OnUpdateDocumentFile) {
      currentDocumentId = Application.documentId;
      yield DocumentFileUpdating();
      await documentFilesRepository.updateDocumentFile(
        id: event.id,
        identifier: event.identifier,
      );
      yield DocumentFileUpdateSuccess();
    }
  }
}
