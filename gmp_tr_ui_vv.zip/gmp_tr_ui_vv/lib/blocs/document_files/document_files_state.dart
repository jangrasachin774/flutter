import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentFilesState extends Equatable {
  const DocumentFilesState();
  @override
  List<Object> get props => [];
}

class InitialDocumentFiles extends DocumentFilesState {}

class DocumentFilesLoading extends DocumentFilesState {}

class DocumentFilesSuccess extends DocumentFilesState {
  final List<DocumentFilesModel> documentFiles;
  DocumentFilesSuccess(this.documentFiles);
  @override
  List<Object> get props => [documentFiles];
}

class DocumentFilesFail extends DocumentFilesState {
  final String code;
  DocumentFilesFail({this.code});
}

class DocumentFilesaving extends DocumentFilesState {}

class DocumentFilesaveSuccess extends DocumentFilesState {}

class DocumentFilesaveFail extends DocumentFilesState {
  final bool error;
  DocumentFilesaveFail(this.error);
}

class DocumentFileUpdating extends DocumentFilesState {}

class DocumentFileUpdateSuccess extends DocumentFilesState {}

class DocumentFileUpdateFail extends DocumentFilesState {
  final String error;
  DocumentFileUpdateFail(this.error);
}
