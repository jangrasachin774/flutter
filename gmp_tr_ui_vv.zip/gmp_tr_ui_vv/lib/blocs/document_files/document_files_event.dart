import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentFilesEvent extends Equatable {
  const DocumentFilesEvent();
  @override
  List<Object> get props => [];
}

class OnLoadDocumentFilesEvent extends DocumentFilesEvent {}

class OnLoadDocumentFiles extends DocumentFilesEvent {
  final List<DocumentFilesModel> documentFiles;
  OnLoadDocumentFiles({this.documentFiles});
  @override
  List<Object> get props => [documentFiles];
}

class OnAddDocumentFile extends DocumentFilesEvent {
  final int id;
  final String identifier;
  final String fileName;
  final Uint8List file;
  OnAddDocumentFile({this.id, this.identifier, this.fileName, this.file});
}

class OnUpdateDocumentFile extends DocumentFilesEvent {
  final int id;
  final String identifier;
  final List<PlatformFile> files;
  OnUpdateDocumentFile({
    this.id,
    this.identifier,
    this.files,
  });

  get departmentIdFk => null;
}
