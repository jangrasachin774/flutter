import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRolesListState extends Equatable {
  const UserRolesListState();
  @override
  List<Object> get props => [];
}

class InitialUserRolesList extends UserRolesListState {}

class UserRolesLoading extends UserRolesListState {}

class UserRolesSuccess extends UserRolesListState {
  final List<UserRolesModel> userroles;
  UserRolesSuccess(this.userroles);
  @override
  List<Object> get props => [userroles];
}

class UserRolesFail extends UserRolesListState {
  final String code;
  UserRolesFail({this.code});
}

class UserRoleSaving extends UserRolesListState {}

class UserRoleSaveSuccess extends UserRolesListState {}

class UserRoleSaveFail extends UserRolesListState {
  final bool error;
  UserRoleSaveFail(this.error);
}

class SingleUserRoleSaving extends UserRolesListState {}

class SingleUserRoleSaveSuccess extends UserRolesListState {}

class SingleUserRoleSaveFail extends UserRolesListState {
  final bool error;
  SingleUserRoleSaveFail(this.error);
}

class UserRoleDeleting extends UserRolesListState {}

class UserRoleDeleteSuccess extends UserRolesListState {}

class UserRoleDeleteFail extends UserRolesListState {
  final bool error;
  UserRoleDeleteFail(this.error);
}

class SingleUserRoleDeleting extends UserRolesListState {}

class SingleUserRoleDeleteSuccess extends UserRolesListState {}

class SingleUserRoleDeleteFail extends UserRolesListState {
  final bool error;
  SingleUserRoleDeleteFail(this.error);
}
