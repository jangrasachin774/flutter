import 'package:bloc/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import 'user_role_view_types_event.dart';
import 'user_role_view_types_state.dart';

class UserRoleViewTypesListBloc extends Bloc<UserRoleViewTypesListEvent, UserRoleViewTypesListState> {
  UserRoleViewTypesListBloc() : super(InitialUserRoleViewTypesList());

  final viewTypeRepository = ViewTypeRepository();

  @override
  Stream<UserRoleViewTypesListState> mapEventToState(UserRoleViewTypesListEvent event) async* {
    int userRoleId;

    ///LOADING USER ROLE DOCUMENT TYPES
    if (event is OnLoadUserRoleViewTypes) {
      print("loading user role task types");
      yield UserRoleViewTypesLoading();
      try {
        final List<ViewTypeModel> userRoleTaskTypes = await viewTypeRepository.loadViewTypes();
        yield UserRoleViewTypesSuccess(userRoleTaskTypes);
      } catch (e) {
        print("catch ${e.toString()}");
        yield UserRoleViewTypesFail(code: e.toString());
      }
    }

    /// CREATE USER ROLE DOCUMENT TYPE
    if (event is OnCreateSingleUserRoleViewType) {
      userRoleId = Application.userRoleId;
      print("user role id $userRoleId");
      yield UserRoleViewTypeSaving();
      try {
        await viewTypeRepository.saveUserRoleViewType(
          userRoledIdFk: userRoleId,
          viewIdFk: event.taskTypeIdFk,
        );

        yield UserRoleViewTypeSaveSuccess();
      } catch (e) {
        yield UserRoleViewTypeSaveFail(error: e.toString());
      }
    }

    /// DELETE  USER ROLE DOCUMENTS TYPES
    if (event is OnRemoveUserRoleViewType) {
      userRoleId = Application.userRoleId;
      yield UserRoleViewTypeDeleting();
      try {
        await viewTypeRepository.deleteUserRoleViewType(
          userRoledIdFk: userRoleId,
          viewIdFk: event.taskTypeIdFk,
        );

        yield UserRoleViewTypeDeleteSuccess();
      } catch (e) {
        yield UserRoleViewTypeDeleteFail(e.toString());
      }
    }
  }
}
