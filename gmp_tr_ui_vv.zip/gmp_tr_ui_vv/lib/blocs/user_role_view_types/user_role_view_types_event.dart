import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleViewTypesListEvent extends Equatable {
  const UserRoleViewTypesListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserRoleViewTypesEvent extends UserRoleViewTypesListEvent {}

class OnLoadUserRoleViewTypes extends UserRoleViewTypesListEvent {
  final int userRoleIdFk;
  final List<ViewTypeModel> userroleTaskType;
  OnLoadUserRoleViewTypes({this.userroleTaskType, this.userRoleIdFk});
  @override
  List<Object> get props => [
        userroleTaskType
      ];
}

class OnCreateUserRoleViewType extends UserRoleViewTypesListEvent {
  final int userId;
  final int userRoles;
  OnCreateUserRoleViewType({this.userId, this.userRoles});
}

class OnCreateSingleUserRoleViewType extends UserRoleViewTypesListEvent {
  final int userRoldIdFk;
  final int taskTypeIdFk;
  OnCreateSingleUserRoleViewType({this.userRoldIdFk, this.taskTypeIdFk});
}

class OnRemoveUserRoleViewType extends UserRoleViewTypesListEvent {
  final int id;
  final int taskTypeIdFk;

  OnRemoveUserRoleViewType({this.id, this.taskTypeIdFk});
}

class OnRemoveUserRoleViewTypeId extends UserRoleViewTypesListEvent {
  final int id;

  OnRemoveUserRoleViewTypeId({this.id});
}
