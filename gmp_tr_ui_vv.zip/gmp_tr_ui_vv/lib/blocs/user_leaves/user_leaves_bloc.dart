import 'package:bloc/bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/user_leaves/bloc.dart';
import 'package:gmptr/models/model_leaves.dart';

class UserLeavesBloc extends Bloc<UserLeavesEvent, UserLeavesState> {
  UserLeavesBloc() : super(InitialUserLeaves());

  @override
  Stream<UserLeavesState> mapEventToState(UserLeavesEvent event) async* {
    if (event is OnLoadUserLeaves) {
      yield UserLeavesLoading();
      try {
        final List<UserLeavesModel> response =
            await Api.getLeavesList(event.departmentId);
        print(response.length);
        if (response.length > 0) {
          yield UserLeavesLoadedSuccess(userLeaves: response);
        } else {
          yield UserLeavesEmpty();
        }
      } catch (e) {
        yield UserLeavesLoadFail(error: e.toString());
      }
    } else if (event is OnLoadMyLeaves) {
      yield MyLeavesLoading();
      try {
        final List<UserLeavesModel> response =
            await Api.getMyLeavesList(event.studentId);
        if (response.length > 0) {
          yield MyLeavesLoadedSuccess(userLeaves: response);
        } else {
          yield MyLeavesLoadEmpty();
        }
      } catch (e) {
        yield MyLeavesLoadFail(error: e.toString());
      }
    }
  }
}
