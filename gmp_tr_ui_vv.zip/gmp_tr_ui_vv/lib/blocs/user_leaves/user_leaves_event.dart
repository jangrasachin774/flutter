import 'package:equatable/equatable.dart';

abstract class UserLeavesEvent extends Equatable {
  const UserLeavesEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserLeaves extends UserLeavesEvent {
  final int departmentId;
  OnLoadUserLeaves({this.departmentId});
}

class OnLoadMyLeaves extends UserLeavesEvent {
  final int studentId;
  OnLoadMyLeaves({this.studentId});
}
