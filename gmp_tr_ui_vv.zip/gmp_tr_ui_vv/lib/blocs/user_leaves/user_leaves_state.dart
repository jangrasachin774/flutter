import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';
import 'package:gmptr/models/model_leaves.dart';

abstract class UserLeavesState extends Equatable {
  const UserLeavesState();
  @override
  List<Object> get props => [];
}

class InitialUserLeaves extends UserLeavesState {}

class UserLeavesLoading extends UserLeavesState {}

class UserLeavesLoadedSuccess extends UserLeavesState {
  final List<UserLeavesModel> userLeaves;
  UserLeavesLoadedSuccess({this.userLeaves});
}

class UserLeavesEmpty extends UserLeavesState {}

class UserLeavesLoadFail extends UserLeavesState {
  final String error;
  UserLeavesLoadFail({this.error});
}

class MyLeavesLoading extends UserLeavesState {}

class MyLeavesLoadedSuccess extends UserLeavesState {
  final List<UserLeavesModel> userLeaves;
  MyLeavesLoadedSuccess({this.userLeaves});
}

class MyLeavesLoadFail extends UserLeavesState {
  final String error;
  MyLeavesLoadFail({this.error});
}

class MyLeavesLoadEmpty extends UserLeavesState {}
