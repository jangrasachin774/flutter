abstract class ApplicationState {}

class InitialApplicationState extends ApplicationState {}

class ApplicationWaiting extends ApplicationState {}

class ApplicationSetupCompleted extends ApplicationState {}
