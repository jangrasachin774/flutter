import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/authentication/bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app_bloc.dart';
import 'bloc.dart';

class ApplicationBloc extends Bloc<ApplicationEvent, ApplicationState> {
  ApplicationBloc() : super(InitialApplicationState());

  @override
  Stream<ApplicationState> mapEventToState(event) async* {
    if (event is OnSetupApplication) {
      ///Pending loading to UI
      yield ApplicationWaiting();

      ///Setup SharedPreferences
      Application.preferences = await SharedPreferences.getInstance();

      // AppBloc.usersBloc.add(OnLoadUsers());

      // AppBloc.departmentBlocs.add(OnLoadDepartments());

      ///Authentication begin check
      AppBloc.authBloc.add(OnAuthCheck());
    }
  }
}
