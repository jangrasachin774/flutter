import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class RolesListEvent extends Equatable {
  const RolesListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadRolesEvent extends RolesListEvent {}

class OnLoadRoles extends RolesListEvent {
  final List<RoleTypes> roles;
  OnLoadRoles({this.roles});
  @override
  List<Object> get props => [roles];
}
