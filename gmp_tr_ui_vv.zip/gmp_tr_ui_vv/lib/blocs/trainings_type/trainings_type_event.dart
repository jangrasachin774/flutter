import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TrainingsTypeListEvent extends Equatable {
  const TrainingsTypeListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadTrainingsTypeEvent extends TrainingsTypeListEvent {}

class OnLoadTrainingsType extends TrainingsTypeListEvent {
  final List<TrainingsType> documentsFeature;
  OnLoadTrainingsType({this.documentsFeature});
}

class OnAddTrainingType extends TrainingsTypeListEvent {
  final int parentId;
  final String name;
  final int companyIdFk;
  final int level;
  final int status;
  OnAddTrainingType({
    this.parentId,
    this.name,
    this.companyIdFk,
    this.level,
    this.status,
  });
  @override
  List<Object> get props => [];
}

class OnUpdateTrainingType extends TrainingsTypeListEvent {
  final int id;
  final String name;

  OnUpdateTrainingType({this.id, this.name});
}

class OnRemoveTrainingType extends TrainingsTypeListEvent {
  final int id;
  OnRemoveTrainingType({this.id});
}
