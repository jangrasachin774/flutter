import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TrainingsTypeListState extends Equatable {
  const TrainingsTypeListState();
  @override
  List<Object> get props => [];
}

class InitialTrainingsTypeList extends TrainingsTypeListState {}

class TrainingsTypeLoading extends TrainingsTypeListState {}

class TrainingsTypeSuccess extends TrainingsTypeListState {
  final List<TrainingsType> trainingTypes;
  TrainingsTypeSuccess(this.trainingTypes);
  @override
  List<Object> get props => [trainingTypes];
}

class TrainingsTypeFail extends TrainingsTypeListState {
  final String code;
  TrainingsTypeFail({this.code});
}

class TrainingsTypsaving extends TrainingsTypeListState {}

class TrainingsTypsaveSuccess extends TrainingsTypeListState {}

class TrainingsTypsaveFail extends TrainingsTypeListState {
  final String code;
  TrainingsTypsaveFail({this.code});
}

class TrainingTypeUpdating extends TrainingsTypeListState {}

class TrainingTypeUpdatingSuccess extends TrainingsTypeListState {}

class TrainingTypeUpdatingFail extends TrainingsTypeListState {
  final String code;
  TrainingTypeUpdatingFail({this.code});
}

class TrainingTypeDeleting extends TrainingsTypeListState {}

class TrainingTypeDeleteSuccess extends TrainingsTypeListState {}

class TrainingTypeDeleteFail extends TrainingsTypeListState {
  final String code;
  TrainingTypeDeleteFail({this.code});
}
