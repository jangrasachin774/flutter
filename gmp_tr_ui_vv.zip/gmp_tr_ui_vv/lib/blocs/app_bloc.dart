import 'package:gmptr/blocs/document_files/bloc.dart';
import 'package:gmptr/blocs/documents/bloc.dart';
import 'package:gmptr/blocs/user_admin_page_departments/bloc.dart';
import 'package:gmptr/blocs/user_admin_pages/bloc.dart';
import 'package:gmptr/blocs/user_role_training_types/bloc.dart';
import 'bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'user_role_view_types/bloc.dart';

class AppBloc {
  static final applicationBloc = ApplicationBloc();
  static final loginBloc = LoginBloc();
  static final authBloc = AuthBloc();
  static final languageBloc = LanguageBloc();
  static final rolesBloc = RolesListBloc();
  static final usersBloc = UsersListBloc();
  static final departmentBlocs = DepartmentsListBloc();
  static final documentFeatureBlocs = DocumentsFeatureListBloc();
  static final trainingsTypeBlocs = TrainingsTypeListBloc();
  static final userRolesBloc = UserRolesListBloc();
  static final adminPagesBloc = AdminPagesBloc();
  static final userRoleDepartmentsBloc = UserRoleDepartmentsListBloc();
  static final userRoleDocTypesBloc = UserRoleDocTypesListBloc();
  static final userRoleViewTypesBloc = UserRoleViewTypesListBloc();
  static final userAdminPageBloc = UserAdminPagesBloc();
  static final userAdminPageDepartmentsBloc = UserAdminPageDepartmentsBloc();
  static final tasksBloc = TasksListBloc();
  static final userRoleTrainingTypes = UserRoleTrainingTypesListBloc();
  static final documentsBloc = DocumentsBloc();
  static final departmentUserBloc = DepartmentUsersBloc();
  static final documentFilesBloc = DocumentFilesBloc();
  static final usersHistoryBloc = UsersHistoryBloc();
  static final studentsBloc = StudentsBloc();
  static final tasksDocBloc = TaskDocBloc();
  static final testsBloc = TestsBloc();
  static final taskUsersBloc = TaskUsersListBloc();
  static final userLeavesBloc = UserLeavesBloc();
  static final changePassBloc = ChangePassBloc();
  static final viewTypesBloc = ViewTypeListBloc();
  static final documentVersionsBloc = DocumentVersionsBloc();
  static final documentTestVersionsBloc = DocumentTestVersionsBloc();

  static final List<BlocProvider> providers = [
    BlocProvider<LoginBloc>(
      create: (context) => loginBloc,
    ),
    BlocProvider<AuthBloc>(
      create: (context) => authBloc,
    ),
    BlocProvider<LanguageBloc>(
      create: (context) => languageBloc,
    ),
    BlocProvider<RolesListBloc>(
      create: (context) => rolesBloc,
    ),
    BlocProvider<UsersListBloc>(
      create: (context) => usersBloc,
    ),
    BlocProvider<DepartmentsListBloc>(
      create: (context) => departmentBlocs,
    ),
    BlocProvider<DocumentsFeatureListBloc>(
      create: (context) => documentFeatureBlocs,
    ),
    BlocProvider<TrainingsTypeListBloc>(
      create: (context) => trainingsTypeBlocs,
    ),
    BlocProvider<UserRolesListBloc>(
      create: (context) => userRolesBloc,
    ),
    BlocProvider<AdminPagesBloc>(
      create: (context) => adminPagesBloc,
    ),
    BlocProvider<UserRoleDepartmentsListBloc>(
      create: (context) => userRoleDepartmentsBloc,
    ),
    BlocProvider<UserRoleDocTypesListBloc>(
      create: (context) => userRoleDocTypesBloc,
    ),
    BlocProvider<UserRoleViewTypesListBloc>(
      create: (context) => userRoleViewTypesBloc,
    ),
    BlocProvider<UserAdminPagesBloc>(
      create: (context) => userAdminPageBloc,
    ),
    BlocProvider<UserAdminPageDepartmentsBloc>(
      create: (context) => userAdminPageDepartmentsBloc,
    ),
    BlocProvider<TasksListBloc>(
      create: (context) => tasksBloc,
    ),
    BlocProvider<UserRoleTrainingTypesListBloc>(
      create: (context) => userRoleTrainingTypes,
    ),
    BlocProvider<DocumentsBloc>(
      create: (context) => documentsBloc,
    ),
    BlocProvider<DepartmentUsersBloc>(
      create: (context) => departmentUserBloc,
    ),
    BlocProvider<DocumentFilesBloc>(
      create: (context) => documentFilesBloc,
    ),
    BlocProvider<UsersHistoryBloc>(
      create: (context) => usersHistoryBloc,
    ),
    BlocProvider<StudentsBloc>(
      create: (context) => studentsBloc,
    ),
    BlocProvider<TaskDocBloc>(
      create: (context) => tasksDocBloc,
    ),
    BlocProvider<TestsBloc>(
      create: (context) => testsBloc,
    ),
    BlocProvider<TaskUsersListBloc>(
      create: (context) => taskUsersBloc,
    ),
    BlocProvider<UserLeavesBloc>(
      create: (context) => userLeavesBloc,
    ),
    BlocProvider<ChangePassBloc>(
      create: (context) => changePassBloc,
    ),
    BlocProvider<ViewTypeListBloc>(
      create: (context) => viewTypesBloc,
    ),
    BlocProvider<DocumentVersionsBloc>(
      create: (context) => documentVersionsBloc,
    ),
    BlocProvider<DocumentTestVersionsBloc>(
      create: (context) => documentTestVersionsBloc,
    ),
  ];

  static void dispose() {
    loginBloc.close();
    authBloc.close();
    languageBloc.close();
    rolesBloc.close();
    usersBloc.close();
    departmentBlocs.close();
    documentFeatureBlocs.close();
    trainingsTypeBlocs.close();
    userRolesBloc.close();
    adminPagesBloc.close();
    userRoleDepartmentsBloc.close();
    userRoleDocTypesBloc.close();
    userRoleViewTypesBloc.close();
    userAdminPageBloc.close();
    userAdminPageDepartmentsBloc.close();
    tasksBloc.close();
    userRoleTrainingTypes.close();
    documentsBloc.close();
    departmentUserBloc.close();
    documentFilesBloc.close();
    usersHistoryBloc.close();
    studentsBloc.close();
    tasksDocBloc.close();
    testsBloc.close();
    taskUsersBloc.close();
    userLeavesBloc.close();
    changePassBloc.close();
    viewTypesBloc.close();
    documentVersionsBloc.close();
    documentTestVersionsBloc.close();
  }

  ///Singleton factory
  static final AppBloc _instance = AppBloc._internal();

  factory AppBloc() {
    return _instance;
  }

  AppBloc._internal();
}
