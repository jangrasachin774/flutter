import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/tasks_and_documents/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import '../../global.dart';

class TaskDocBloc extends Bloc<TaskDocEvent, TaskDocState> {
  TaskDocBloc() : super(null);

  final documentsRepository = DocumentsRepository();
  final tasksRepository = TasksRepository();

  @override
  Stream<TaskDocState> mapEventToState(TaskDocEvent event) async* {
    // List<Task> filteredTask = [];
    // List<DocumentsModel> documentsType = [];
    List<int> taskStatusIds = [];

    //Load task document
    if (event is OnLoadTaskDocEvent) {
      yield TaskDocLoading();
      // print("initstate4");

      ///CHECKS STATUS ID
      if (event.taskDocStatusId == StatusId.confirmed) {
        taskStatusIds = [StatusId.confirmed];
      } else if (event.taskDocStatusId == StatusId.Studentfinised) {
        taskStatusIds = [StatusId.Studentfinised];
      } else if (event.taskDocStatusId == StatusId.bigLeaderConfirmed) {
        taskStatusIds = [StatusId.bigLeaderConfirmed];
      } else if (event.taskDocStatusId == StatusId.smallLeaderConfirmed) {
        taskStatusIds = [StatusId.smallLeaderConfirmed];
      } else if (event.taskDocStatusId == StatusId.all) {
        taskStatusIds = [
          StatusId.created,
          StatusId.confirmed,
          // StatusId.cancelled,
          StatusId.smallLeaderConfirmed,
          StatusId.smallLeaderSendBack,
          StatusId.bigLeaderConfirmed,
          StatusId.bigLeaderSendBack
        ];
      } else if (event.taskDocStatusId == StatusId.SLsAll) {
        taskStatusIds = [
          StatusId.confirmed,
          StatusId.smallLeaderConfirmed,
          StatusId.smallLeaderSendBack,
          StatusId.bigLeaderConfirmed,
          StatusId.bigLeaderSendBack,
          StatusId.Studentfinised,
        ];
      } else if (event.taskDocStatusId == StatusId.BLsAll) {
        taskStatusIds = [
          StatusId.smallLeaderConfirmed,
          StatusId.smallLeaderSendBack,
          StatusId.bigLeaderConfirmed,
          StatusId.bigLeaderSendBack,
          StatusId.Studentfinised,
        ];
      } else {
        taskStatusIds = [
          StatusId.created,
          StatusId.confirmed,
          // StatusId.cancelled,
          StatusId.smallLeaderSendBack,
          StatusId.bigLeaderSendBack
        ];
      }
      try {
        List<DocumentsModel> documents;
        List<Task> tasks;

        documents = await documentsRepository.loadDocuments(
          criteria: event.criteria,
          startDate: event.startDate,
          endDate: event.endDate,
          departmentIdFk: event.departmentIdFk,
          trainingTypeIdFk: event.trainingTypeIdFk,
          documentType: event.documentFeatureIdFk,
          creatorIdFk: event.creatorIdFk,
          smallLeaderIdFk: event.smallLeaderIdFk,
          bigLeaderIdFk: event.bigLeaderIdFk,
          viewType: event.viewType,
          docStatusId: taskStatusIds,
          multiDepartIdFk: event.multiDepartIdFk,
        );

        tasks = await tasksRepository.loadTasks(
          taskId: event.id,
          criteria: event.criteria,
          startDate: event.startDate,
          endDate: event.endDate,
          studentIdFk: event.studentIdFk,
          departmentIdFk: event.departmentIdFk,
          trainingTypeIdFk: event.trainingTypeIdFk,
          documentTypeIdFk: event.documentFeatureIdFk,
          creatorIdFk: event.creatorIdFk,
          smallLeaderIdFk: event.smallLeaderIdFk,
          bigLeaderIdFk: event.bigLeaderIdFk,
          taskStatusId: taskStatusIds,
          viewType: event.viewType,
          multiDepartIdFk: event.multiDepartIdFk,
        );
        print("tasks bloc $tasks");
        // if (event.viewType == 2) {
        //   filteredTask.clear();
        //   for (var t in tasks) {
        //     filteredTask.add(t);
        //   }
        // } else if (event.viewType == 3) {
        //   filteredTask.clear();
        //   for (var d in documents) {
        //     documentsType.add(d);
        //   }
        // } else if (event.viewType == 1) {
        //   filteredTask.clear();
        //   for (var t in tasks) {
        //     filteredTask.add(t);
        //   }
        // }
        if (tasks.length > 0 &&
            (event.viewType.contains(ViewType.regularTask) ||
                event.viewType.contains(ViewType.readOnlyTask))) {
          yield TaskDocSuccess(tasks: tasks);
        } else if (documents.length > 0 &&
            (event.viewType.contains(ViewType.documents) ||
                event.viewType.contains(ViewType.documentTest))) {
          yield TaskDocSuccess(documents: documents);
        } else {
          yield TaskDocEmpty();
        }
      } catch (e) {
        yield TaskDocFail(code: e.toString());
      }
    } else if (event is CancelCreatedTask) {
      yield TaskCanceling();
      try {
        await tasksRepository.cancelCreatedTask(
            taskStatusId: event.taskStatusId, taskIds: event.taskIds);
        yield TaskCancelledSuccess();
      } catch (e) {
        yield TaskCancelledFailure(code: e.toString());
      }
    }
  }
}
