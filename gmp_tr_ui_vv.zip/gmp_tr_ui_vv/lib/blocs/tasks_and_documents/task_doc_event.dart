import 'package:equatable/equatable.dart';
import 'package:gmptr/models/model.dart';

abstract class TaskDocEvent extends Equatable {
  const TaskDocEvent();

  @override
  List<Object> get props => [];
}

// ignore: must_be_immutable
class OnLoadTaskDocEvent extends TaskDocEvent {
  final int id;
  final int roleTypeIdFk;
  final int workerIdFk;
  final int trainingTypeIdFk;
  final int departmentIdFk;
  final int documentFeatureIdFk;
  final int creatorIdFk;
  final int smallLeaderIdFk;
  final int bigLeaderIdFk;
  final int criteria;
  final String startDate;
  final String endDate;
  final int taskDocStatusId;
  final int studentIdFk;
  List<int> viewType;
  List<TaskDocuments> taskDocuments;

  List<int> multiDepartIdFk;

  OnLoadTaskDocEvent({
    this.id,
    this.roleTypeIdFk,
    this.workerIdFk,
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentFeatureIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.bigLeaderIdFk,
    this.studentIdFk,
    this.viewType,
    this.criteria,
    this.startDate,
    this.endDate,
    this.taskDocStatusId,
    this.multiDepartIdFk,
    this.taskDocuments,
  });
}

class CancelCreatedTask extends TaskDocEvent {
  final int taskStatusId;
  final List<int> taskIds;
  CancelCreatedTask({this.taskStatusId, this.taskIds});
}

class CancelCreatedDoc extends TaskDocEvent {
  final int taskStatusId;
  final List<int> taskIds;
  CancelCreatedDoc({this.taskStatusId, this.taskIds});
}
