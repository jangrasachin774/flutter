import 'package:bloc/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import 'bloc.dart';

class DepartmentsListBloc
    extends Bloc<DepartmentsListEvent, DepartmentsListState> {
  DepartmentsListBloc() : super(InitialDepartmentsList());

  final departmentsRepository = DepartmentsRepository();

  @override
  Stream<DepartmentsListState> mapEventToState(
      DepartmentsListEvent event) async* {
    ///Load Departments
    if (event is OnLoadDepartments) {
      yield DepartmentsLoading();
      try {
        final List<Departments> response =
            await departmentsRepository.loadDepartments();
        print("response $response");
        yield DepartmentsSuccess(response);
      } catch (e) {
        yield DepartmentsFail(code: e.toString());
      }
    } else if (event is OnAddDepartment) {
      /// Save Department
      print("adding");
      yield Departmentsaving();

      ///Case Success
      try {
        await departmentsRepository.saveDepartments(
          parentId: event.parentId,
          name: event.name,
          companyIdFk: 1,
          level: event.level,
          status: 1,
        );
        yield DepartmentsaveSuccess();
      } catch (e) {
        yield DepartmentsaveFail(code: e.toString());
      }
    } else if (event is OnRemoveDepartment) {
      ///Delete Department
      yield DepartmentDeleting();

      try {
        await departmentsRepository.deleteDepartments(id: event.id);
        yield DepartmentDeleteSuccess();
      } catch (e) {
        yield DepartmentDeleteFail(code: e.toString());
      }
    } else if (event is OnUpdateDepartment) {
      ///UPDATE DEPARTMENT
      yield Departmentsaving();

      ///Case Success
      try {
        await departmentsRepository.updateDepartment(
          id: event.id,
          name: event.name,
        );
        yield DepartmentUpdatingSuccess();
      } catch (e) {
        yield DepartmentUpdatingFail(code: e.toString());
      }
    }
  }
}
