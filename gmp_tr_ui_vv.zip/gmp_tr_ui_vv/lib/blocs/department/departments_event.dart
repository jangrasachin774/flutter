import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DepartmentsListEvent extends Equatable {
  const DepartmentsListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadDepartmentsEvent extends DepartmentsListEvent {}

class OnLoadDepartments extends DepartmentsListEvent {
  final List<Departments> departments;
  OnLoadDepartments({this.departments});
}

class OnAddDepartment extends DepartmentsListEvent {
  final int parentId;
  final String name;
  final int companyIdFk;
  final int level;
  final int status;
  OnAddDepartment({
    this.parentId,
    this.name,
    this.companyIdFk,
    this.level,
    this.status,
  });
  @override
  List<Object> get props => [];
}

class OnUpdateDepartment extends DepartmentsListEvent {
  final int id;
  final String name;

  OnUpdateDepartment({this.id, this.name});
}

class OnRemoveDepartment extends DepartmentsListEvent {
  final int id;
  OnRemoveDepartment({this.id});
}
