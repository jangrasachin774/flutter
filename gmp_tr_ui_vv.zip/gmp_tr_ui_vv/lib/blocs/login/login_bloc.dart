import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/authentication/authentication_event.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:io' show Platform;

import '../app_bloc.dart';
import 'login_event.dart';
import 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  LoginBloc() : super(InitialLoginState());
  final userRepository = UserRepository();

  @override
  Stream<LoginState> mapEventToState(event) async* {
    ///Event for login
    if (event is OnLogin) {
      ///Notify loading to UI
      yield LoginLoading();

      ///Getting Platform running Source
      var source;
      if (kIsWeb) {
        source = "web";
      } else {
        if (Platform.isAndroid) {
          source = "android";
        } else if (Platform.isIOS) {
          source = "ios";
        }
      }

      ///Fetch API via repository
      final ResultApiModel result = await userRepository.login(
          username: event.username, password: event.password, source: source);
      print("result $result");

      ///Case API fail but not have token
      if (result.success) {
        ///Login API success
        final UserModel user = UserModel.fromJson(result.data);

        ///Begin start AuthBloc Event AuthenticationSave
        AppBloc.authBloc.add(OnSaveUser(user));

        ///Notify loading to UI
        yield LoginSuccess();
      } else {
        print("error: ${result.code}");

        ///Notify loading to UI
        yield LoginFail(result.code);
      }
    }

    ///Event for logout
    if (event is OnLogout) {
      yield LogoutLoading();

      ///Begin start AuthBloc Event OnProcessLogout
      AppBloc.authBloc.add(OnClear());
      await Future.delayed(Duration(seconds: 1));

      ///Notify loading to UI
      yield LogoutSuccess();
    }
  }
}
