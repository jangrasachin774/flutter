import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/admin_pages/bloc.dart';
import 'package:gmptr/models/model.dart';

import 'package:gmptr/repository/repository.dart';

class AdminPagesBloc extends Bloc<AdminPagesEvent, AdminPagesState> {
  AdminPagesBloc() : super(InitialAdminPages());

  final adminPagesRepository = AdminPagesRepository();

  @override
  Stream<AdminPagesState> mapEventToState(AdminPagesEvent event) async* {
    ///Load TrainingsType
    if (event is OnLoadAdminPages) {
      yield AdminPagesLoading();
      try {
        final List<AdminPagesModel> response =
            await adminPagesRepository.loadAdminPages();
        print("response $response");
        yield AdminPagesSuccess(response);
      } catch (e) {
        yield AdminPagesFail(code: e.toString());
      }
    }
  }
}
