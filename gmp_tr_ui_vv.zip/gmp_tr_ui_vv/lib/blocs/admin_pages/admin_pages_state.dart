import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class AdminPagesState extends Equatable {
  const AdminPagesState();
  @override
  List<Object> get props => [];
}

class InitialAdminPages extends AdminPagesState {}

class AdminPagesLoading extends AdminPagesState {}

class AdminPagesSuccess extends AdminPagesState {
  final List<AdminPagesModel> adminPages;
  AdminPagesSuccess(this.adminPages);
  @override
  List<Object> get props => [adminPages];
}

class AdminPagesFail extends AdminPagesState {
  final String code;
  AdminPagesFail({this.code});
}

// class UserAdminPageSaving extends AdminPagesState {}

// class UserAdminPageSaveSuccess extends AdminPagesState {}

// class UserAdminPageSaveFail extends AdminPagesState {
//   final bool error;
//   UserAdminPageSaveFail(this.error);
// }

// class UserAdminPageDeleting extends AdminPagesState {}

// class UserAdminPageDeleteSuccess extends AdminPagesState {}

// class UserAdminPageDeleteFail extends AdminPagesState {
//   final bool error;
//   UserAdminPageDeleteFail(this.error);
// }
