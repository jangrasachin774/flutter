import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/user_admin_pages/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_user_admin_pages.dart';
import 'package:gmptr/repository/repository.dart';
import 'package:gmptr/utils/utils.dart';

class UserAdminPagesBloc
    extends Bloc<UserAdminPagesEvent, UserAdminPagesState> {
  UserAdminPagesBloc() : super(InitialUserAdminPages());

  final userAdminPagesRepository = UserAdminPagesRepository();

  @override
  Stream<UserAdminPagesState> mapEventToState(
      UserAdminPagesEvent event) async* {
    if (event is OnLoadUserAdminPagesWithDepartment) {
      yield UserAdminPagesLoading();
      try {
        final List<UserAdminPageWithDeptModel> userAdminPageDept =
            await userAdminPagesRepository.loadUserAdminPageDept(
                userRoleIdFk: event.userRoleIdFk);
        yield UserAdminPagesSuccess(userAdminPageDept);
      } catch (e) {
        yield UserAdminPagesFail(code: e.toString());
      }
    } else if (event is OnCreateUserAdminPage) {
      yield UserAdminPageSaving();

      String userRoleId;
      List<String> rolesId = UtilPreferences.getStringList(
        Preferences.multipleUserRoleId,
      );
      if (rolesId != null) {
        var map = rolesId.asMap();
        print("map $map");
        map.forEach((key, value) {
          if (value.contains(event.roleName)) {
            List<String> record = value
                .replaceAll("{", " ")
                .replaceAll("}", " ")
                .split(",")
                .toList();
            final rec = record.first.split(":").toList();
            userRoleId = rec.last;
          }
        });
      }
      print("before responsess");
      final UserAdminPageModel response =
          await userAdminPagesRepository.saveUserAdminPages(
        userRoleId: int.parse(userRoleId),
        adminPageId: event.adminPageId,
      );

      if (response.success) {
        print("responsesss");
        final userAdminPageId = response.id;

        await userAdminPagesRepository.saveUserAdmingPageRecord(
            userAdminPageId, event.adminPageName);
        yield UserAdminPageSaveSuccess();
      } else {
        yield UserAdminPageSaveFail(response.success);
      }
    } else if (event is OnRemoveUserAdminPage) {
      yield UserAdminPageDeleting();
      String userAdminPageId;
      List<String> userAdminPages = UtilPreferences.getStringList(
        Preferences.userAdminPage,
      );
      if (userAdminPages != null) {
        var map = userAdminPages.asMap();
        print("map-------- $map");
        map.forEach((key, value) {
          if (value.contains(event.adminPageName)) {
            List<String> record = value
                .replaceAll("{", " ")
                .replaceAll("}", " ")
                .split(",")
                .toList();
            final rec = record.first.split(":").toList();
            userAdminPageId = rec.last;
          }
        });
      }

      print(
          "userAdminPageId-------- $userAdminPageId + ${event.userAdminPageIdFk}");

      ///DELETE DB RECORD
      await userAdminPagesRepository.deleteUserAdminPage(
          userAdminPageId: userAdminPageId != null
              ? int.parse(userAdminPageId)
              : event.userAdminPageIdFk);

      ///DELETE LOCAL STORAGE RECORD
      await userAdminPagesRepository
          .deleteUserAdminPageLocal(event.adminPageName);

      yield UserAdminPageDeleteSuccess();
    }
  }
}
