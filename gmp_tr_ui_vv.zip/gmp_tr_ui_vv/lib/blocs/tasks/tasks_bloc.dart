import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/tasks/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import '../../global.dart';

class TasksListBloc extends Bloc<TasksListEvent, TasksListState> {
  TasksListBloc() : super(InitialTasksList());

  final tasksRepository = TasksRepository();

  @override
  Stream<TasksListState> mapEventToState(TasksListEvent event) async* {
    // Load Tasks
    if (event is OnLoadTasksEvent) {
      yield TasksLoading();
      List<Task> filteredTask = [];

      List<int> taskStatusIds = [];

      ///CHECKS STATUS ID
      if (event.taskStatusId == StatusId.confirmed) {
        taskStatusIds = [StatusId.confirmed];
      } else if (event.taskStatusId == StatusId.Studentfinised) {
        taskStatusIds = [StatusId.Studentfinised];
      } else if (event.taskStatusId == StatusId.bigLeaderConfirmed) {
        taskStatusIds = [StatusId.bigLeaderConfirmed];
      } else if (event.taskStatusId == StatusId.smallLeaderConfirmed) {
        taskStatusIds = [StatusId.smallLeaderConfirmed];
      } else if (event.taskStatusId == StatusId.all) {
        taskStatusIds = [
          StatusId.created,
          StatusId.confirmed,
          // StatusId.cancelled,
          StatusId.smallLeaderConfirmed,
          StatusId.smallLeaderSendBack,
          StatusId.bigLeaderConfirmed,
          StatusId.bigLeaderSendBack
        ];
      } else {
        taskStatusIds = [
          StatusId.created,
          StatusId.confirmed,
          // StatusId.cancelled,
          StatusId.smallLeaderSendBack,
          StatusId.bigLeaderSendBack
        ];
      }

      try {
        List<Task> tasks = await tasksRepository.loadTasks(
          criteria: event.criteria,
          startDate: event.startDate,
          endDate: event.endDate,
          studentIdFk: event.studentIdFk,
          departmentIdFk: event.departmentIdFk,
          trainingTypeIdFk: event.trainingTypeIdFk,
          documentTypeIdFk: event.documentFeatureIdFk,
          creatorIdFk: event.creatorIdFk,
          smallLeaderIdFk: event.smallLeaderIdFk,
          bigLeaderIdFk: event.bigLeaderIdFk,
          taskId: event.taskId,
          taskStatusId: taskStatusIds,
          viewType: event.viewType,
        );
        print("tasks task task >>>>>> $tasks");
        if (event.viewType == [1]) {
          for (var t in tasks) {
            if (t.isReadonly == true) {
              filteredTask.add(t);
            }
          }
        } else {
          for (var t in tasks) {
            if (t.isReadonly == false) {
              filteredTask.add(t);
            }
          }
        }

        if (filteredTask.length > 0 &&
            (event.viewType.contains(ViewType.regularTask) ||
                event.viewType.contains(ViewType.readOnlyTask))) {
          yield TasksSuccess(tasks: filteredTask);
        } else {
          yield TasksEmpty();
        }
      } catch (e) {
        yield TasksFail();
      }
    } else if (event is OnAddTask) {
      yield Tasksaving();
      try {
        final Task response = await tasksRepository.saveTask(
          readOnly: event.readOnly,
          title: event.title,
          identifier: event.identifier,
          description: event.description,
          trainingTypeIdFk: event.trainingTypeIdFk,
          documentTypeIdFk: event.documentTypeIdFk,
          creatorIdFk: event.creatorIdFk,
          smallLeaderIdFk: event.smallLeaderIdFk,
          departmentIdFk: event.departmentIdFk,
        );

        if (response.isSuccess) {
          int taskIdFk = response.id;

          if (event.documentIdFk != null) {
            await tasksRepository.saveTaskDocuments(
              documentIdFk: event.documentIdFk,
              documentIdentifier: event.documentIdentifier,
              path: event.path,
              name: event.name,
              taskIdFk: taskIdFk,
            );
          } else {
            await tasksRepository.saveNewTaskDocumentFiles(
              documentFiles: event.documentFiles,
              taskIdFk: taskIdFk,
            );
          }

          await tasksRepository.saveTaskDocumentTests(
            documentIdFk: event.documentIdFk,
            selectedTestId: event.selectedTestId,
            selectedQuestion: event.selectedQuestion,
            selectedTotalAnswers: event.selectedTotalAnswers,
            selectedCorrectAnsers: event.selectedCorrectAnswers,
            taskIdFk: taskIdFk,
          );
          yield TasksaveSuccess();
        }
      } catch (e) {
        // print("task error $e");
        yield TasksaveFail(e.toString());
      }
    }
  }
}
