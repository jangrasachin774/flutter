import 'package:equatable/equatable.dart';
import 'package:file_picker/file_picker.dart';
import 'package:gmptr/models/model.dart';

import '../../global.dart';

abstract class TasksListEvent extends Equatable {
  const TasksListEvent();
  @override
  List<Object> get props => [];
}

class InitialTaskPageEvent extends TasksListEvent {
  @override
  String toString() => 'InitializePageEvent';
}

// ignore: must_be_immutable
class OnLoadTasksEvent extends TasksListEvent {
  final List<Task> tasks;
  final int taskStatusId;
  int taskId = 1;
  final int studentIdFk;
  final int roleTypeIdFk;
  final int workerIdFk;
  final int trainingTypeIdFk;
  final int departmentIdFk;
  final int documentFeatureIdFk;
  final int creatorIdFk;
  final int smallLeaderIdFk;
  final int bigLeaderIdFk;
  final int criteria;
  final String startDate;
  final String endDate;
  List<int> viewType = [ViewType.regularTask];
  OnLoadTasksEvent({
    this.roleTypeIdFk,
    this.workerIdFk,
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentFeatureIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.bigLeaderIdFk,
    this.studentIdFk,
    this.viewType,
    this.criteria,
    this.startDate,
    this.endDate,
    this.tasks,
    this.taskId,
    this.taskStatusId,
  });

  @override
  List<Object> get props => [tasks];
}

class OnAddTask extends TasksListEvent {
  final bool readOnly;
  final int id;
  final String identifier;
  final String title;
  final int trainingTypeIdFk;
  final int departmentIdFk;
  final int documentTypeIdFk;
  final int smallLeaderIdFk;
  final int creatorIdFk;
  final String description;
  final int bigLeaderIdFk;
  final int documentIdFk;
  final String documentIdentifier;
  final String path;
  final String name;
  final int selectedTestId;
  final String selectedQuestion;
  final List<String> selectedTotalAnswers;
  final List<String> selectedCorrectAnswers;
  final List<PlatformFile> documentFiles;
  final List<TaskTestModel> taskTests;
  final int status;

  OnAddTask({
    this.readOnly,
    this.id,
    this.identifier,
    this.title,
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentTypeIdFk,
    this.smallLeaderIdFk,
    this.description,
    this.bigLeaderIdFk,
    this.creatorIdFk,
    this.documentIdFk,
    this.documentIdentifier,
    this.path,
    this.name,
    this.status,
    this.selectedTestId,
    this.selectedQuestion,
    this.documentFiles,
    this.selectedTotalAnswers,
    this.selectedCorrectAnswers,
    this.taskTests,
  });
}
