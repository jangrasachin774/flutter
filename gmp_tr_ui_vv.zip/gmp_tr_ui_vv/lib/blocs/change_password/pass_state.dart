import 'package:meta/meta.dart';

@immutable
abstract class ChangePassState {}

class InitialChangePass extends ChangePassState {}

class ChangingPass extends ChangePassState {}

class ChangePassFail extends ChangePassState {
  final String error;

  ChangePassFail({this.error});
}

class ChangePassSuccess extends ChangePassState {}

