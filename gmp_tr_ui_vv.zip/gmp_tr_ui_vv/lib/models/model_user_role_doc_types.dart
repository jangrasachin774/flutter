class UserRoleDocTypesModel {
  int id;
  int userRoleIdFk;
  int documentTypeIdFk;
  int status;
  String createdAt;
  String updatedAt;
  DocumentType documentType;

  UserRoleDocTypesModel(
      {this.id,
      this.userRoleIdFk,
      this.documentTypeIdFk,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.documentType});

  UserRoleDocTypesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleIdFk = json['user_role_id_fk'];
    documentTypeIdFk = json['document_type_id_fk'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    documentType = json['document_type'] != null
        ? new DocumentType.fromJson(json['document_type'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['document_type_id_fk'] = this.documentTypeIdFk;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.documentType != null) {
      data['document_type'] = this.documentType.toJson();
    }
    return data;
  }
}

class DocumentType {
  int id;
  String name;
  int parentDocumentTypeIdFk;
  int level;

  DocumentType({this.id, this.name, this.parentDocumentTypeIdFk, this.level});

  DocumentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    parentDocumentTypeIdFk = json['parent_document_type_id_fk'];
    level = json['level'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['parent_document_type_id_fk'] = this.parentDocumentTypeIdFk;
    data['level'] = this.level;
    return data;
  }
}
