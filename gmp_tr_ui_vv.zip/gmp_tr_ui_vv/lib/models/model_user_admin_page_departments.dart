class UserAdminPageDepartmentsModel {
  int id;
  int userAdminPageIdFk;
  int departmentIdFk;
  String updatedAt;
  String createdAt;

  UserAdminPageDepartmentsModel(
      {this.id,
      this.userAdminPageIdFk,
      this.departmentIdFk,
      this.updatedAt,
      this.createdAt});

  UserAdminPageDepartmentsModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userAdminPageIdFk = json['user_admin_page_id_fk'];
    departmentIdFk = json['department_id_fk'];
    updatedAt = json['updatedAt'];
    createdAt = json['createdAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_admin_page_id_fk'] = this.userAdminPageIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['updatedAt'] = this.updatedAt;
    data['createdAt'] = this.createdAt;
    return data;
  }
}
