class HolidayRequestModel {
  int id;
  String studentName;
  String comment;
  String applyTime;
  bool approved;
  String approveTime;
  String approvePerson;
  String reason;

  bool selected = false;

  HolidayRequestModel({
    this.id,
    this.studentName,
    this.comment,
    this.applyTime,
    this.approved,
    this.approveTime,
    this.approvePerson,
    this.reason,
  });

  HolidayRequestModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    studentName = json[''];
    studentName = json[''];
    studentName = json[''];
    studentName = json[''];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;

    return data;
  }
}
