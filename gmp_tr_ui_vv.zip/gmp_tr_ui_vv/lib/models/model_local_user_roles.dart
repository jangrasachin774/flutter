class LocalStorageModel {
  int roleId;
  int userId;
  int userRoleId;
  String roleName;

  LocalStorageModel({this.roleId, this.userId, this.userRoleId, this.roleName});

  LocalStorageModel.fromJson(Map<String, dynamic> json) {
    roleId = json['roleId'];
    userId = json['userId'];
    userRoleId = json['userRoleId'];
    roleName = json['role_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['roleId'] = this.roleId;
    data['userId'] = this.userId;
    data['userRoleId'] = this.userRoleId;
    data['role_name'] = this.roleName;
    return data;
  }
}
