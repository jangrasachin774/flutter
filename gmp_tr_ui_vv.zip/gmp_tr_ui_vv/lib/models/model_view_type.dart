class ViewTypeModel {
  int id;
  int identifier;
  String name;
  String type;
  String description;
  String createdAt;
  String updatedAt;
  int viewTypeIdFk;

  ViewTypeModel({
    this.id,
    this.identifier,
    this.name,
    this.type,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.viewTypeIdFk,
  });

  ViewTypeModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    type = json['type'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    viewTypeIdFk = json['view_type_id_fk'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['type'] = this.type;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['view_type_id_fk'] = this.viewTypeIdFk;
    return data;
  }
}
