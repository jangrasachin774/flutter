import 'package:file_picker/file_picker.dart';

class TaskDocumentFilesModel {
  int id;
  String identifier;
  int documentIdFk;
  List<PlatformFile> files;
  bool success;

  TaskDocumentFilesModel(
      {this.id, this.identifier, this.documentIdFk, this.files, this.success});

  TaskDocumentFilesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    documentIdFk = json['document_id_fk'];
    files = json['files'].cast<String>();
    success = json['error'] != null ? false : true;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['document_id_fk'] = this.documentIdFk;
    data['files'] = this.files.cast<String>();
    return data;
  }
}
