class RoleTypes {
  int id;
  String identifier;
  String name;
  String description;
  String createdAt;
  String updatedAt;
  bool multiSelect;
  List<Roles> roles;

  RoleTypes({
    this.id,
    this.identifier,
    this.name,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.multiSelect,
    this.roles,
  });

  RoleTypes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    final Iterable refactorRoles = json['roles'] ?? [];
    final listRoles = refactorRoles.map((item) {
      return Roles.fromJson(item);
    }).toList();
    multiSelect = json['multiselect'] as bool ?? false;
    roles = listRoles;
    // if (json['roles'] != null) {
    //   List<Roles> roles = [];
    //   json['roles'].forEach((v) {
    //     roles.add(new Roles.fromJson(v));
    //   });
    // }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.roles != null) {
      data['roles'] = this.roles.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Roles {
  int id;
  String identifier;
  String name;
  int roleTypeIdFk;
  String description;
  String createdAt;
  String updatedAt;
  bool isCheck = false;

  Roles({
    this.id,
    this.identifier,
    this.name,
    this.roleTypeIdFk,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.isCheck,
  });

  Roles.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    roleTypeIdFk = json['role_type_id_fk'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    isCheck = json['name'] == "学生" ? true : false;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['role_type_id_fk'] = this.roleTypeIdFk;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}
