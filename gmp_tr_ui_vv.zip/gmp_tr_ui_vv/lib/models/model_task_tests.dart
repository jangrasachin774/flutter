class TaskTestModel {
  int id;
  String question;
  int documentIdFk;
  int taskIdFk;
  int documentTestIdFk;
  List<String> totalAnswers;
  List<String> rightAnswers;

  TaskTestModel.create({
    this.id,
    this.question,
    this.documentIdFk,
    this.totalAnswers,
    this.rightAnswers,
    this.taskIdFk,
    this.documentTestIdFk,
  });

  TaskTestModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    question = json['question'];
    documentIdFk = json['document_id_fk'];
    totalAnswers = json['total_answers'].cast<String>();
    rightAnswers = json['right_answers'].cast<String>();
    taskIdFk = json['task_id_fk'];
    documentTestIdFk = json["document_test_id_fk"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['question'] = this.question;
    data['document_id_fk'] = this.documentIdFk;
    data['total_answers'] = this.totalAnswers;

    data['right_answers'] = this.rightAnswers;
    data['task_id_fk'] = this.taskIdFk;
    data['document_test_id_fk'] = this.documentTestIdFk;
    return data;
  }
}
