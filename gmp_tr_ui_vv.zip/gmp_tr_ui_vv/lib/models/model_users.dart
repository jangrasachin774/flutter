import 'model.dart';

class UsersModel {
  int id;
  int identifier;
  String username;
  String password;
  int gender;
  String workNo;
  String contact;
  String email;
  String name;
  String realCompany;
  String realDepartment;
  int companyIdFk;
  int departmentIdFk;
  int userStatusIdFk;
  int creatorIdFk;
  String createdAt;
  String updatedAt;
  Department department;
  List<UserRole> userRoles;
  bool success;

  UsersModel(
      {this.id,
      this.identifier,
      this.username,
      this.password,
      this.gender,
      this.workNo,
      this.contact,
      this.email,
      this.name,
      this.realCompany,
      this.realDepartment,
      this.companyIdFk,
      this.departmentIdFk,
      this.userStatusIdFk,
      this.creatorIdFk,
      this.createdAt,
      this.updatedAt,
      this.department,
      this.userRoles,
      this.success});

  UsersModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    username = json['username'];
    password = json['password'];
    gender = json['gender'];
    workNo = json['work_no'];
    contact = json['contact'];
    email = json['email'];
    name = json['name'];
    realCompany = json['real_company'];
    realDepartment = json['real_department'];
    companyIdFk = json['company_id_fk'];
    departmentIdFk = json['department_id_fk'];
    userStatusIdFk = json['user_status_id_fk'];
    creatorIdFk = json['creator_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    department = json['department'] != null
        ? new Department.fromJson(json['department'])
        : null;
    final Iterable refactorRoles = json['user_roles'] ?? [];
    final listRoles = refactorRoles.map((item) {
      return UserRole.fromJson(item);
    }).toList();

    userRoles = listRoles;
    success = json['error'] != null ? false : true;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['username'] = this.username;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['work_no'] = this.workNo;
    data['contact'] = this.contact;
    data['email'] = this.email;
    data['name'] = this.name;
    data['real_company'] = this.realCompany;
    data['real_department'] = this.realDepartment;
    data['company_id_fk'] = this.companyIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['user_status_id_fk'] = this.userStatusIdFk;
    data['creator_id_fk'] = this.creatorIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }

    if (this.userRoles != null) {
      data['user_roles'] = this.userRoles.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Department {
  int id;
  String name;
  String identifier;
  int level;

  Department({this.id, this.name, this.identifier, this.level});

  Department.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? "";
    name = json['name'] ?? "";
    identifier = json['identifier'] ?? "";
    level = json['level'] ?? "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['identifier'] = this.identifier;
    data['level'] = this.level;
    return data;
  }
}

class UserRole {
  int id;
  int userIdFk;
  int roleIdFk;
  String createdAt;
  String updatedAt;
  Role role;
  bool success;
  List<UserAdminPagee> userAdminPagees;
  List<UserRoleDept> userRoleDept;

  UserRole({
    this.id,
    this.userIdFk,
    this.roleIdFk,
    this.createdAt,
    this.updatedAt,
    this.role,
    this.success,
  });

  UserRole.fromJson(Map<String, dynamic> json) {
    final Iterable refactoruserAdminPagees = json['user_admin_pages'] ?? [];
    final listuserAdminPagees = refactoruserAdminPagees.map((item) {
      return UserAdminPagee.fromJson(item);
    }).toList();
    final Iterable refactoruserRoleDept = json['user_role_departments'] ?? [];
    final listuserRoleDept = refactoruserRoleDept.map((item) {
      return UserRoleDept.fromJson(item);
    }).toList();
    print("listuserRoleDept ${json['user_role_departments']}");
    id = json['id'];
    userIdFk = json['user_id_fk'];
    roleIdFk = json['role_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    role = json['role'] != null ? new Role.fromJson(json['role']) : null;
    success = json['error'] == null ? true : false;
    userAdminPagees = listuserAdminPagees;
    userRoleDept = listuserRoleDept;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id_fk'] = this.userIdFk;
    data['role_id_fk'] = this.roleIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.role != null) {
      data['role'] = this.role.toJson();
    }
    return data;
  }
}

class Role {
  int id;
  String identifier;
  String name;
  int roleTypeIdFk;
  String description;
  String createdAt;
  String updatedAt;

  Role(
      {this.id,
      this.identifier,
      this.name,
      this.roleTypeIdFk,
      this.description,
      this.createdAt,
      this.updatedAt});

  Role.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    roleTypeIdFk = json['role_type_id_fk'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['role_type_id_fk'] = this.roleTypeIdFk;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}
