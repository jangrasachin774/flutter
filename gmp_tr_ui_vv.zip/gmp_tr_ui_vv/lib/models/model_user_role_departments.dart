class UserRoleDepartmentsModel {
  int id;
  int userRoleIdFk;
  int departmentIdFk;
  int status;
  String createdAt;
  String updatedAt;
  Dept department;

  UserRoleDepartmentsModel(
      {this.id,
      this.userRoleIdFk,
      this.departmentIdFk,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.department});

  UserRoleDepartmentsModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleIdFk = json['user_role_id_fk'];
    departmentIdFk = json['department_id_fk'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    department = json['department'] != null
        ? new Dept.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    return data;
  }
}

class Dept {
  int id;
  String name;
  String identifier;
  int level;

  Dept({this.id, this.name, this.identifier, this.level});

  Dept.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    identifier = json['identifier'];
    level = json['level'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['identifier'] = this.identifier;
    data['level'] = this.level;
    return data;
  }
}
