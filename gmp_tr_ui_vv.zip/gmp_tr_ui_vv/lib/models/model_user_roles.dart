class UserRolesModel {
  int id;
  int userIdFk;
  int roleIdFk;
  String createdAt;
  String updatedAt;
  bool success;

  UserRolesModel({
    this.id,
    this.userIdFk,
    this.roleIdFk,
    this.createdAt,
    this.updatedAt,
    this.success,
  });

  UserRolesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userIdFk = json['user_id_fk'];
    roleIdFk = json['role_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    success = json['error'] == null ? true : false;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id_fk'] = this.userIdFk;
    data['role_id_fk'] = this.roleIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;

    return data;
  }
}
