class UserLeavesModel {
  int id;
  int userIdFk;
  int departmentIdFk;
  int confirmedByIdFk;
  String confirmedDate;
  String returnDate;
  String userDescription;
  String approverDescription;
  int status;
  String createdAt;
  String updatedAt;
  User user;
  User confirmedBy;

  UserLeavesModel(
      {this.id,
      this.userIdFk,
      this.departmentIdFk,
      this.confirmedByIdFk,
      this.confirmedDate,
      this.returnDate,
      this.userDescription,
      this.approverDescription,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.user,
      this.confirmedBy});

  UserLeavesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userIdFk = json['user_id_fk'];
    departmentIdFk = json['department_id_fk'];
    confirmedByIdFk = json['confirmed_by_id_fk'] ?? null;
    confirmedDate = json['confirmed_date'] ?? null;
    returnDate = json['return_date'] ?? null;
    userDescription = json['user_description'];
    approverDescription = json['approver_description'] ?? null;
    status = json['status'] ?? null;
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    confirmedBy = json['confirmedBy'] != null
        ? new User.fromJson(json['confirmedBy'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id_fk'] = this.userIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['confirmed_by_id_fk'] = this.confirmedByIdFk;
    data['confirmed_date'] = this.confirmedDate;
    data['return_date'] = this.returnDate;
    data['user_description'] = this.userDescription;
    data['approver_description'] = this.approverDescription;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.user != null) {
      data['user'] = this.user.toJson();
    }
    if (this.confirmedBy != null) {
      data['confirmedBy'] = this.confirmedBy.toJson();
    }
    return data;
  }
}

class User {
  int id;
  String username;
  UserDepart department;

  User({this.id, this.username, this.department});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'] ?? "";
    department = json['department'] != null
        ? new UserDepart.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    return data;
  }
}

class UserDepart {
  String name;

  UserDepart({this.name});

  UserDepart.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    return data;
  }
}
