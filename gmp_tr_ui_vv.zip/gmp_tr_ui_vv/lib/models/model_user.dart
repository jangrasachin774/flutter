class UserByIdModel {
  int id;
  int identifier;
  String username;
  String password;
  int gender;
  String workNo;
  String contact;
  String email;
  String name;
  String realCompany;
  String realDeptmnt;
  int companyIdFk;
  int departmentIdFk;
  int userStatusIdFk;
  int creatorIdFk;
  String createdAt;
  String updatedAt;
  Deptmnt department;
  List<UserByIdRole> userRoles;

  UserByIdModel(
      {this.id,
      this.identifier,
      this.username,
      this.password,
      this.gender,
      this.workNo,
      this.contact,
      this.email,
      this.name,
      this.realCompany,
      this.realDeptmnt,
      this.companyIdFk,
      this.departmentIdFk,
      this.userStatusIdFk,
      this.creatorIdFk,
      this.createdAt,
      this.updatedAt,
      this.department,
      this.userRoles});

  UserByIdModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    username = json['username'];
    password = json['password'];
    gender = json['gender'];
    workNo = json['work_no'];
    contact = json['contact'];
    email = json['email'];
    name = json['name'];
    realCompany = json['real_company'];
    realDeptmnt = json['real_department'];
    companyIdFk = json['company_id_fk'];
    departmentIdFk = json['department_id_fk'];
    userStatusIdFk = json['user_status_id_fk'];
    creatorIdFk = json['creator_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    department = json['department'] != null
        ? new Deptmnt.fromJson(json['department'])
        : null;
    final Iterable refactorRoles = json['user_roles'] ?? [];
    final userRolesById = refactorRoles.map((item) {
      return UserByIdRole.fromJson(item);
    }).toList();
    userRoles = userRolesById;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['username'] = this.username;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['work_no'] = this.workNo;
    data['contact'] = this.contact;
    data['email'] = this.email;
    data['name'] = this.name;
    data['real_company'] = this.realCompany;
    data['real_department'] = this.realDeptmnt;
    data['company_id_fk'] = this.companyIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['user_status_id_fk'] = this.userStatusIdFk;
    data['creator_id_fk'] = this.creatorIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    if (this.userRoles != null) {
      data['user_roles'] = this.userRoles.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Deptmnt {
  int id;
  String name;
  String identifier;
  int level;

  Deptmnt({this.id, this.name, this.identifier, this.level});

  Deptmnt.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    identifier = json['identifier'];
    level = json['level'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['identifier'] = this.identifier;
    data['level'] = this.level;
    return data;
  }
}

class UserByIdRole {
  int id;
  int userIdFk;
  int roleIdFk;
  String createdAt;
  String updatedAt;
  RoleByUser role;
  List<UserAdminPages> userAdminPages;
  List<UserByIdRoleDeptmnts> userRoleDeptmnts;
  List<UserRoleDocumentTypes> userRoleDocumentTypes;
  List<UserRoleTrainingTypes> userRoleTrainingTypes;

  UserByIdRole(
      {this.id,
      this.userIdFk,
      this.roleIdFk,
      this.createdAt,
      this.updatedAt,
      this.role,
      this.userAdminPages,
      this.userRoleDeptmnts,
      this.userRoleDocumentTypes,
      this.userRoleTrainingTypes});

  UserByIdRole.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userIdFk = json['user_id_fk'];
    roleIdFk = json['role_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    role = json['role'] != null ? new RoleByUser.fromJson(json['role']) : null;
    if (json['user_admin_pages'] != null) {
      List<UserAdminPages> userAdminPages = [];
      json['user_admin_pages'].forEach((v) {
        userAdminPages.add(new UserAdminPages.fromJson(v));
      });
    }
    if (json['user_role_departments'] != null) {
      List<UserByIdRoleDeptmnts> userRoleDeptmnts = [];
      json['user_role_departments'].forEach((v) {
        userRoleDeptmnts.add(new UserByIdRoleDeptmnts.fromJson(v));
      });
    }
    if (json['user_role_document_types'] != null) {
      List<UserRoleDocumentTypes> userRoleDocumentTypes = [];
      json['user_role_document_types'].forEach((v) {
        userRoleDocumentTypes.add(new UserRoleDocumentTypes.fromJson(v));
      });
    }
    if (json['user_role_training_types'] != null) {
      List<UserRoleTrainingTypes> userRoleTrainingTypes = [];
      json['user_role_training_types'].forEach((v) {
        userRoleTrainingTypes.add(new UserRoleTrainingTypes.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id_fk'] = this.userIdFk;
    data['role_id_fk'] = this.roleIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.role != null) {
      data['role'] = this.role.toJson();
    }
    if (this.userAdminPages != null) {
      data['user_admin_pages'] =
          this.userAdminPages.map((v) => v.toJson()).toList();
    }
    if (this.userRoleDeptmnts != null) {
      data['user_role_departments'] =
          this.userRoleDeptmnts.map((v) => v.toJson()).toList();
    }
    if (this.userRoleDocumentTypes != null) {
      data['user_role_document_types'] =
          this.userRoleDocumentTypes.map((v) => v.toJson()).toList();
    }
    if (this.userRoleTrainingTypes != null) {
      data['user_role_training_types'] =
          this.userRoleTrainingTypes.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UserRoleTrainingTypes {
  int id;
  int userRoleTypeIdFk;
  int trainingTypeIdFk;
  String description;
  String createdAt;
  String updatedAt;

  UserRoleTrainingTypes(
      {this.id,
      this.userRoleTypeIdFk,
      this.trainingTypeIdFk,
      this.description,
      this.createdAt,
      this.updatedAt});

  UserRoleTrainingTypes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleTypeIdFk = json['user_role_id_fk'];
    trainingTypeIdFk = json['training_type_id_fk'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['role_type_id_fk'] = this.userRoleTypeIdFk;
    data['training_type_id_fk'] = this.trainingTypeIdFk;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class UserRoleDocumentTypes {
  int id;
  int userRoleTypeIdFk;
  int documentTypeIdFk;
  String description;
  String createdAt;
  String updatedAt;

  UserRoleDocumentTypes(
      {this.id,
      this.userRoleTypeIdFk,
      this.documentTypeIdFk,
      this.description,
      this.createdAt,
      this.updatedAt});

  UserRoleDocumentTypes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleTypeIdFk = json['user_role_id_fk'];
    documentTypeIdFk = json['document_type_id_fk'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['role_type_id_fk'] = this.userRoleTypeIdFk;
    data['document_type_id_fk'] = this.documentTypeIdFk;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class RoleByUser {
  int id;
  String identifier;
  String name;
  int roleTypeIdFk;
  String description;
  String createdAt;
  String updatedAt;

  RoleByUser(
      {this.id,
      this.identifier,
      this.name,
      this.roleTypeIdFk,
      this.description,
      this.createdAt,
      this.updatedAt});

  RoleByUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    roleTypeIdFk = json['role_type_id_fk'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['role_type_id_fk'] = this.roleTypeIdFk;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class UserAdminPages {
  int id;
  int userRoleIdFk;
  int adminPageIdFk;
  String createdAt;
  String updatedAt;
  AdminPage adminPage;
  List<UserAdminPageDeptmnts> userAdminPageDeptmnts;

  UserAdminPages(
      {this.id,
      this.userRoleIdFk,
      this.adminPageIdFk,
      this.createdAt,
      this.updatedAt,
      this.adminPage,
      this.userAdminPageDeptmnts});

  UserAdminPages.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleIdFk = json['user_role_id_fk'];
    adminPageIdFk = json['admin_page_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    adminPage = json['admin_page'] != null
        ? new AdminPage.fromJson(json['admin_page'])
        : null;
    if (json['user_admin_page_departments'] != null) {
      List<UserAdminPageDeptmnts> userAdminPageDeptmnts = [];
      json['user_admin_page_departments'].forEach((v) {
        userAdminPageDeptmnts.add(new UserAdminPageDeptmnts.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['admin_page_id_fk'] = this.adminPageIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.adminPage != null) {
      data['admin_page'] = this.adminPage.toJson();
    }
    if (this.userAdminPageDeptmnts != null) {
      data['user_admin_page_departments'] =
          this.userAdminPageDeptmnts.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UserAdminPageDeptmnts {
  int id;
  int userAdminPageIdFk;
  int departmentIdFk;
  int status;
  String createdAt;
  String updatedAt;

  UserAdminPageDeptmnts(
      {this.id,
      this.userAdminPageIdFk,
      this.departmentIdFk,
      this.status,
      this.createdAt,
      this.updatedAt});

  UserAdminPageDeptmnts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userAdminPageIdFk = json['user_admin_page_id_fk'];
    departmentIdFk = json['department_id_fk'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_admin_page_id_fk'] = this.userAdminPageIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class AdminPage {
  int id;
  String name;
  int level;
  int parentAdminPageIdFk;
  bool departments;
  String description;
  String createdAt;
  String updatedAt;

  AdminPage(
      {this.id,
      this.name,
      this.level,
      this.parentAdminPageIdFk,
      this.departments,
      this.description,
      this.createdAt,
      this.updatedAt});

  AdminPage.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    level = json['level'];
    parentAdminPageIdFk = json['parent_admin_page_id_fk'];
    departments = json['departments'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['level'] = this.level;
    data['parent_admin_page_id_fk'] = this.parentAdminPageIdFk;
    data['departments'] = this.departments;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class UserByIdRoleDeptmnts {
  int id;
  int userRoleIdFk;
  int departmentIdFk;
  int status;
  String createdAt;
  String updatedAt;

  UserByIdRoleDeptmnts(
      {this.id,
      this.userRoleIdFk,
      this.departmentIdFk,
      this.status,
      this.createdAt,
      this.updatedAt});

  UserByIdRoleDeptmnts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleIdFk = json['user_role_id_fk'];
    departmentIdFk = json['department_id_fk'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}
