import 'package:uuid/uuid.dart';

class DocumentModel {
  int id;
  String identifier;
  String title;
  String description;
  int viewTypeIdFk;
  int trainingTypeIdFk;
  int documentTypeIdFk;
  int creatorIdFk;
  int smallLeaderIdFk;
  int bigLeaderIdFk;
  int departmentIdFk;
  String smallLeaderConfirmDate;
  String bigLeaderConfirmDate;
  String creatorConfirmDate;
  int status;
  String fileVersion;

  DocumentModel.create({
    this.title,
    this.description,
    this.trainingTypeIdFk,
    this.documentTypeIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.departmentIdFk,
    this.fileVersion,
    this.viewTypeIdFk,
  }) {
    this.identifier = new Uuid().v4().replaceAll("-", "");
    // this.status = 1;
  }

  DocumentModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    title = json['title'];
    viewTypeIdFk = json['view_id_fk'];
    fileVersion = json['version'];
    description = json['description'];
    departmentIdFk = json['department_id_fk'];
    trainingTypeIdFk = json['training_type_id_fk'];
    documentTypeIdFk = json['document_type_id_fk'];
    creatorIdFk = json['creator_id_fk'];
    smallLeaderIdFk = json['small_leader_id_fk'];
    bigLeaderIdFk = json['big_leader_id_fk'];
    smallLeaderConfirmDate = json['small_leader_confirm_date'];
    bigLeaderConfirmDate = json['big_leader_confirm_date'];
    creatorConfirmDate = json['creator_confirm_date'];
    status = json['document_status_id_fk'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['identifier'] = this.identifier;
    data['title'] = this.title;
    data['version'] = this.fileVersion;
    data['description'] = this.description;
    data['view_id_fk'] = this.viewTypeIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['training_type_id_fk'] = this.trainingTypeIdFk;
    data['document_type_id_fk'] = this.documentTypeIdFk;
    data['creator_id_fk'] = this.creatorIdFk;
    data['small_leader_id_fk'] = this.smallLeaderIdFk;
    data['big_leader_id_fk'] = this.bigLeaderIdFk;
    data['small_leader_confirm_date'] = this.smallLeaderConfirmDate;
    data['big_leader_confirm_date'] = this.bigLeaderConfirmDate;
    data['creator_confirm_date'] = this.creatorConfirmDate;
    data['document_status_id_fk'] = this.status;
    return data;
  }
}
