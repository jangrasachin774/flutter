import 'package:equatable/equatable.dart';

// ignore: must_be_immutable
class TaskModel extends Equatable {
  int id;
  String title;
  bool isReadonly;
  String description;
  int viewTypeIdFk;
  String identifier;
  int trainingTypeIdFk;
  int documentTypeIdFk;
  int departmentIdFk;
  int creatorIdFk;
  int smallLeaderIdFk;
  int bigLeaderIdFk;
  int taskStatusIdFk;
  bool beginOnSign;
  String startDate;
  String endDate;
  String smallLeaderConfirmDate;
  String bigLeaderConfirmDate;
  String creatorConfirmDate;
  String createdAt;
  String updatedAt;
  bool isSuccess;
  List<int> taskDocuments;

  int taskStatusId;
  bool selected = false;
  TaskModel.create({
    this.isReadonly,
    this.departmentIdFk,
    this.viewTypeIdFk,
    this.title,
    this.description,
    this.trainingTypeIdFk,
    this.documentTypeIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.startDate,
    this.endDate,
    this.taskStatusIdFk,
    this.taskDocuments,
  });

  TaskModel(
      {this.id,
      this.isReadonly,
      this.title,
      this.description,
      this.identifier,
      this.viewTypeIdFk,
      this.trainingTypeIdFk,
      this.documentTypeIdFk,
      this.departmentIdFk,
      this.smallLeaderIdFk,
      this.creatorIdFk,
      this.taskStatusIdFk,
      this.startDate,
      this.endDate,
      this.createdAt,
      this.updatedAt,
      this.taskDocuments});

  TaskModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    title = json['title'];
    isReadonly = json['read_only'];
    viewTypeIdFk = json['view_id_fk'];
    description = json['description'];
    trainingTypeIdFk = json['training_type_id_fk'];
    documentTypeIdFk = json['document_type_id_fk'];
    departmentIdFk = json['department_id_fk'];
    creatorIdFk = json['creator_id_fk'];
    smallLeaderIdFk = json['small_leader_id_fk'];

    taskStatusIdFk = json['task_status_id_fk'];
    beginOnSign = json['begin_on_sign'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    taskDocuments = json['task_documents'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> json = new Map<String, dynamic>();
    json['id'] = id;
    json['title'] = title;
    json['read_only'] = isReadonly;
    json['view_id_fk'] = viewTypeIdFk;
    json['description'] = description;
    json['identifier'] = identifier ?? "";
    json['training_type_id_fk'] = trainingTypeIdFk;
    json['document_type_id_fk'] = documentTypeIdFk;
    json['department_id_fk'] = departmentIdFk;
    json['creator_id_fk'] = creatorIdFk;
    json['small_leader_id_fk'] = smallLeaderIdFk;

    json['task_status_id_fk'] = taskStatusIdFk;
    json['start_date'] = startDate ?? "";
    json['end_date'] = endDate ?? "";
    json['task_documents'] = taskDocuments ?? "";
    json['createdAt'] = createdAt ?? "";
    json['updatedAt'] = updatedAt ?? "";

    return json;
  }

  List<Object> get props => [
        isReadonly,
        id,
        title,
        description,
        identifier,
        trainingTypeIdFk,
        documentTypeIdFk,
        departmentIdFk,
        creatorIdFk,
        taskStatusIdFk,
        beginOnSign,
        startDate,
        endDate,
        createdAt,
        updatedAt,
      ];
}
