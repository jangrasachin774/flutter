import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleDepartmentsListEvent extends Equatable {
  const UserRoleDepartmentsListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserRoleDepartmentsEvent extends UserRoleDepartmentsListEvent {}

class OnLoadUserRoleDepartments extends UserRoleDepartmentsListEvent {
  final int userRoleIdFk;
  final List<UserRoleDepartmentsModel> userroleDepartment;
  OnLoadUserRoleDepartments({this.userroleDepartment, this.userRoleIdFk});
  @override
  List<Object> get props => [userroleDepartment];
}

class OnCreateUserRoleDepartment extends UserRoleDepartmentsListEvent {
  final int userId;
  final int userRoles;
  OnCreateUserRoleDepartment({this.userId, this.userRoles});
}

class OnCreateSingleUserRoleDepartment extends UserRoleDepartmentsListEvent {
  final int userRoldIdFk;
  final int departmentIdFk;
  OnCreateSingleUserRoleDepartment({this.userRoldIdFk, this.departmentIdFk});
}

class OnRemoveSingleUserRoleDepartment extends UserRoleDepartmentsListEvent {
  final int id;
  final int departmentIdFk;

  OnRemoveSingleUserRoleDepartment({this.id, this.departmentIdFk});
}

class OnRemoveUserRoleDepartment extends UserRoleDepartmentsListEvent {
  final int id;

  OnRemoveUserRoleDepartment({this.id});
}
