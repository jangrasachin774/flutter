import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/user_role_training_types/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class UserRoleTrainingTypesListBloc extends Bloc<UserRoleTrainingTypesListEvent,
    UserRoleTrainingTypesListState> {
  UserRoleTrainingTypesListBloc() : super(InitialUserRoleTrainingTypesList());

  final userRoleTrainingTypesRepository = UserRoleTrainingTypesRepo();

  @override
  Stream<UserRoleTrainingTypesListState> mapEventToState(
      UserRoleTrainingTypesListEvent event) async* {
    int userRoleId;

    ///LOADING USER ROLE TRAINING TYPES
    if (event is OnLoadUserRoleTrainingTypes) {
      print("event.userRoleIdFk ${event.userRoleIdFk}");
      yield UserRoleTrainingTypesLoading();
      try {
        final List<UserRoleTrainingTypesModel> userRoleTraining =
            await userRoleTrainingTypesRepository.loadUserRoleTraining(
                userRoleIdFk: event.userRoleIdFk);
        yield UserRoleTrainingTypesSuccess(userRoleTraining);
      } catch (e) {
        yield UserRoleTrainingTypesFail(code: e.toString());
      }
    }

    /// CREATE USER ROLE TRAINING TYPE
    if (event is OnCreateSingleUserRoleTrainingType) {
      userRoleId = Application.userRoleId;
      yield UserRoleTrainingTypeSaving();
      try {
        await userRoleTrainingTypesRepository.saveUserRoleTrainingType(
          userRoledIdFk: userRoleId,
          trainingTypeIdFk: event.trainingTypeIdFk,
          status: 0,
        );

        yield UserRoleTrainingTypeSaveSuccess();
      } catch (e) {
        yield UserRoleTrainingTypeSaveFail(error: e.toString());
      }
    }

    /// DELETE  USER ROLE TRAINING TYPES
    if (event is OnRemoveUserRoleTrainingType) {
      userRoleId = Application.userRoleId;
      yield UserRoleTrainingTypeDeleting();
      try {
        await userRoleTrainingTypesRepository.deleteUserRoleTrainingType(
          userRoledIdFk: userRoleId,
          trainingTypeIdFk: event.trainingTypeIdFk,
        );

        yield UserRoleTrainingTypeDeleteSuccess();
      } catch (e) {
        yield UserRoleTrainingTypeDeleteFail(e.toString());
      }
    }
  }
}
