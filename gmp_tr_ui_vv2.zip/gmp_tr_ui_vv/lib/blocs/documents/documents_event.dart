import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentsEvent extends Equatable {
  const DocumentsEvent();
  @override
  List<Object> get props => [];
}

class OnLoadDocumentsEvent extends DocumentsEvent {}

class OnLoadDocuments extends DocumentsEvent {
  final int trainingTypeIdFk;
  final int departmentIdFk;
  final int documentFeature;
  final int criteria;
  final String startDate;
  final String endDate;
  final List<DocumentsModel> documents;
  final int documentId;
  final int smallLeaderIdFk;
  final List<int> taskDocuments;
  final int viewTypeIdFk;
  final int documentTypeIdFk;
  OnLoadDocuments({
    this.documents,
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentFeature,
    this.criteria,
    this.startDate,
    this.endDate,
    this.documentId,
    this.smallLeaderIdFk,
    this.taskDocuments,
    this.documentTypeIdFk,
    this.viewTypeIdFk,
  });
  @override
  List<Object> get props => [documents];
}

class OnAddDocument extends DocumentsEvent {
  final int id;
  final String identifier;
  final String title;
  final int trainingTypeIdFk;
  final int departmentIdFk;
  final int documentTypeIdFk;
  final int smallLeaderIdFk;
  final int creatorIdFk;
  final String description;
  final int bigLeaderIdFk;

  final int status;

  OnAddDocument({
    this.id,
    this.identifier,
    this.title,
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentTypeIdFk,
    this.smallLeaderIdFk,
    this.description,
    this.bigLeaderIdFk,
    this.creatorIdFk,
    this.status,
  });
}

class OnUpdateDocument extends DocumentsEvent {
  final int id;
  final String identifier;
  final String title;
  final int trainingTypeIdFk;
  final int documentTypeIdFk;
  final int smallLeaderIdFk;
  final int creatorIdFk;
  final String description;
  final int bigLeaderIdFk;

  final int status;
  OnUpdateDocument({
    this.id,
    this.identifier,
    this.title,
    this.trainingTypeIdFk,
    this.documentTypeIdFk,
    this.smallLeaderIdFk,
    this.description,
    this.bigLeaderIdFk,
    this.creatorIdFk,
    this.status,
  });

  get departmentIdFk => null;
}

class OnUpdateDocumentStatus extends DocumentsEvent {
  final int id;
  final int status;
  final List<int> docIds;
  OnUpdateDocumentStatus({this.id, this.status, this.docIds});
}

// ignore: must_be_immutable
// class ValidatingDocVersion extends DocumentsEvent {
//   String title;
//   int version;
//   ValidatingDocVersion({this.title, this.version});
// }
class OnLoadDocumentTitles extends DocumentsEvent {
  final int trainingTypeIdFk;
  final int departmentIdFk;
  final int documentFeature;
  final int viewTypeIdFk;
  final int documentTypeIdFk;
  final String version;
  OnLoadDocumentTitles({
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentFeature,
    this.documentTypeIdFk,
    this.viewTypeIdFk,
    this.version,
  });
  @override
  List<Object> get props => [];
}
