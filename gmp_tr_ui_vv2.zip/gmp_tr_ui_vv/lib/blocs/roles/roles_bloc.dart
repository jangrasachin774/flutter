import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/roles/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import '../bloc.dart';

class RolesListBloc extends Bloc<RolesListEvent, RolesListState> {
  RolesListBloc() : super(InitialRolesList());

  final rolesRepository = RolesRepository();

  @override
  Stream<RolesListState> mapEventToState(RolesListEvent event) async* {
    //Load Roles
    if (event is OnLoadRoles) {
      yield RolesLoading();

      try {
        ///Fetch API via repository
        final List<RoleTypes> response = await rolesRepository.loadRoles();

        ///Notify loading to UI
        yield RolesSuccess(response);
      } catch (e) {
        yield RolesFail(code: e.toString());
      }
    }
  }
}
