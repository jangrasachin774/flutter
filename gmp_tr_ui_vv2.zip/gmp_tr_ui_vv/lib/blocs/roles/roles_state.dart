import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class RolesListState extends Equatable {
  const RolesListState();
  @override
  List<Object> get props => [];
}

class InitialRolesList extends RolesListState {}

class RolesLoading extends RolesListState {}

class RolesSuccess extends RolesListState {
  final List<RoleTypes> roles;
  RolesSuccess(this.roles);
  @override
  List<Object> get props => [roles];
}

class RolesFail extends RolesListState {
  final String code;
  RolesFail({this.code});
}
