import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TasksListState extends Equatable {
  const TasksListState();
  @override
  List<Object> get props => [];
}

class InitialTasksList extends TasksListState {}

class TasksLoading extends TasksListState {}

class TasksSuccess extends TasksListState {
  final List<Task> tasks;
  TasksSuccess({this.tasks});
  @override
  List<Object> get props => [tasks];
}

class TasksEmpty extends TasksListState {}

class TasksFail extends TasksListState {
  final String code;
  TasksFail({this.code});
}

class Tasksaving extends TasksListState {}

class TasksaveSuccess extends TasksListState {}

class TasksaveFail extends TasksListState {
  final String error;
  TasksaveFail(this.error);
}
