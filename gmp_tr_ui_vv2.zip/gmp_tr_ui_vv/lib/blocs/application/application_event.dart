abstract class ApplicationEvent {}

///Event notification setup application
class OnSetupApplication extends ApplicationEvent {}
