import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserAdminPagesState extends Equatable {
  const UserAdminPagesState();
  @override
  List<Object> get props => [];
}

class InitialUserAdminPages extends UserAdminPagesState {}

class UserAdminPagesLoading extends UserAdminPagesState {}

class UserAdminPagesSuccess extends UserAdminPagesState {
  final List<UserAdminPageWithDeptModel> userAdminPages;
  UserAdminPagesSuccess(this.userAdminPages);
  @override
  List<Object> get props => [userAdminPages];
}

class UserAdminPagesFail extends UserAdminPagesState {
  final String code;
  UserAdminPagesFail({this.code});
}

class UserAdminPageSaving extends UserAdminPagesState {}

class UserAdminPageSaveSuccess extends UserAdminPagesState {}

class UserAdminPageSaveFail extends UserAdminPagesState {
  final bool error;
  UserAdminPageSaveFail(this.error);
}

class UserAdminPageDeleting extends UserAdminPagesState {}

class UserAdminPageDeleteSuccess extends UserAdminPagesState {}

class UserAdminPageDeleteFail extends UserAdminPagesState {
  final bool error;
  UserAdminPageDeleteFail(this.error);
}
