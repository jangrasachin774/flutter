import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserAdminPagesEvent extends Equatable {
  const UserAdminPagesEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserAdminPagesEvent extends UserAdminPagesEvent {}

class OnLoadUserAdminPagesWithDepartment extends UserAdminPagesEvent {
  final int userRoleIdFk;
  final int adminPageIdFk;
  final List<UserAdminPageWithDeptModel> adminPagesDepart;
  OnLoadUserAdminPagesWithDepartment(
      {this.adminPagesDepart, this.userRoleIdFk, this.adminPageIdFk});
  @override
  List<Object> get props => [adminPagesDepart];
}

class OnCreateUserAdminPage extends UserAdminPagesEvent {
  final int userRoleId;
  final int adminPageId;
  final String roleName;
  final String adminPageName;
  OnCreateUserAdminPage({
    this.userRoleId,
    this.adminPageId,
    this.roleName,
    this.adminPageName,
  });
}

class OnCreateSingleUserAdminPage extends UserAdminPagesEvent {
  final int userId;
  final int userRoles;
  OnCreateSingleUserAdminPage({this.userId, this.userRoles});
}

class OnRemoveUserAdminPage extends UserAdminPagesEvent {
  final int id;
  final String adminPageName;
  final int adminPageId;
  final int userAdminPageIdFk;
  OnRemoveUserAdminPage(
      {this.id, this.adminPageName, this.adminPageId, this.userAdminPageIdFk});
}

class OnRemoveUserAdminPageId extends UserAdminPagesEvent {
  final int id;

  OnRemoveUserAdminPageId({this.id});
}
