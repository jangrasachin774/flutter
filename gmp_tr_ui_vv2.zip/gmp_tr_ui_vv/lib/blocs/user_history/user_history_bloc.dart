import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/user_history/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class UsersHistoryBloc extends Bloc<UsersHistoryEvent, UsersHistoryState> {
  UsersHistoryBloc() : super(InitialUsersHistory());

  final usersRepository = UsersRepository();

  @override
  Stream<UsersHistoryState> mapEventToState(UsersHistoryEvent event) async* {
    if (event is UserHistory) {
      yield UserHistoryLoading();
      try {
        final List<UserHistoryModel> response =
            await usersRepository.userHistory(userId: event.userId);

        yield UserHistoryLoadedSuccess(userHistory: response);
      } catch (e) {
        yield UserHistoryLoadFail(error: e.toString());
      }
    }
  }
}
