import 'package:equatable/equatable.dart';

abstract class UsersHistoryEvent extends Equatable {
  const UsersHistoryEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUsersHistoryEvent extends UsersHistoryEvent {}

class UserHistory extends UsersHistoryEvent {
  final int userId;
  UserHistory({this.userId});
}
