import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleViewTypesListState extends Equatable {
  const UserRoleViewTypesListState();
  @override
  List<Object> get props => [];
}

class InitialUserRoleViewTypesList extends UserRoleViewTypesListState {}

class UserRoleViewTypesLoading extends UserRoleViewTypesListState {}

class UserRoleViewTypesSuccess extends UserRoleViewTypesListState {
  final List<ViewTypeModel> userroleTaskType;
  UserRoleViewTypesSuccess(this.userroleTaskType);
  @override
  List<Object> get props => [
        userroleTaskType
      ];
}

class UserRoleViewTypesFail extends UserRoleViewTypesListState {
  final String code;
  UserRoleViewTypesFail({this.code});
}

class UserRoleViewTypeSaving extends UserRoleViewTypesListState {}

class UserRoleViewTypeSaveSuccess extends UserRoleViewTypesListState {}

class UserRoleViewTypeSaveFail extends UserRoleViewTypesListState {
  final String error;
  UserRoleViewTypeSaveFail({this.error});
}

class UserRoleViewTypeDeleting extends UserRoleViewTypesListState {}

class UserRoleViewTypeDeleteSuccess extends UserRoleViewTypesListState {}

class UserRoleViewTypeDeleteFail extends UserRoleViewTypesListState {
  final String error;
  UserRoleViewTypeDeleteFail(this.error);
}
