import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class ViewTypeListEvent extends Equatable {
  const ViewTypeListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadViewTypeEvent extends ViewTypeListEvent {}

class OnLoadViewType extends ViewTypeListEvent {
  final List<ViewTypeModel> views;
  OnLoadViewType({this.views});
  @override
  List<Object> get props => [views];
}
