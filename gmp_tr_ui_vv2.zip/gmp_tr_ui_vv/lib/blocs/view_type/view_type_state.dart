import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class ViewTypeListState extends Equatable {
  const ViewTypeListState();
  @override
  List<Object> get props => [];
}

class InitialViewTypeList extends ViewTypeListState {}

class ViewTypeLoading extends ViewTypeListState {}

class ViewTypeSuccess extends ViewTypeListState {
  final List<ViewTypeModel> views;
  ViewTypeSuccess(this.views);
  @override
  List<Object> get props => [views];
}

class ViewTypeFail extends ViewTypeListState {
  final String code;
  ViewTypeFail({this.code});
}
