import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/user_admin_page_departments/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';

import 'package:gmptr/repository/repository.dart';
import 'package:gmptr/utils/utils.dart';

class UserAdminPageDepartmentsBloc
    extends Bloc<UserAdminPageDepartmentsEvent, UserAdminPageDepartmentsState> {
  UserAdminPageDepartmentsBloc() : super(InitialUserAdminPageDepartments());

  final userAdminPageDepartmentRepository =
      UserAdminPageDepartmentsRepository();

  @override
  Stream<UserAdminPageDepartmentsState> mapEventToState(
      UserAdminPageDepartmentsEvent event) async* {
    ///LOADING USER ADMIN PAGE DEPARTMENTS
    if (event is OnLoadUserAdminPageDepartments) {
      yield UserAdminPageDepartmentsLoading();
      try {
        final List<UserAdminPageDepartmentsModel> adminPagesDepartments =
            await userAdminPageDepartmentRepository.loadAdminPageDepartments();
        yield UserAdminPageDepartmentsSuccess(adminPagesDepartments);
      } catch (e) {}
    }
    if (event is OnCreateUserAdminPageDepartment) {
      /// CREATE USER ADMIN PAGE DEPARTMENT
      yield UserAdminPageDepartmentSaving();
      String userAdminPageId;
      List<String> userAdminPages = UtilPreferences.getStringList(
        Preferences.userAdminPage,
      );
      if (userAdminPages != null) {
        var map = userAdminPages.asMap();
        print("event.adminPageName ${event.adminPageName}");
        map.forEach(
          (key, value) {
            if (value.contains(event.adminPageName)) {
              List<String> record = value
                  .replaceAll("{", " ")
                  .replaceAll("}", " ")
                  .split(",")
                  .toList();
              final rec = record.first.split(":").toList();
              userAdminPageId = rec.last;
            }
          },
        );
      }

      print("anish userAdminPageId------- $userAdminPageId");
      await userAdminPageDepartmentRepository.saveUserAdminPageDepartments(
        departmentId: event.departmentId,
        useradminPageId: userAdminPageId != null
            ? int.parse(userAdminPageId)
            : event.userAdminPageIdFk,
      );

      yield UserAdminPageDepartmentSaveSuccess();
    }

    /// DELETE USER ADMIN PAGE DEPARTMENT

    if (event is OnRemoveUserAdminPageDepartment) {
      yield UserAdminPageDepartmentDeleting();
      String userAdminPageId;
      if (event.adminPageName != "") {
        List<String> userAdminPages = UtilPreferences.getStringList(
          Preferences.userAdminPage,
        );
        if (userAdminPages != null && userAdminPages != []) {
          var map = userAdminPages.asMap();
          print("map $map");
          map.forEach(
            (key, value) {
              if (value.contains(event.adminPageName)) {
                List<String> record = value
                    .replaceAll("{", " ")
                    .replaceAll("}", " ")
                    .split(",")
                    .toList();
                final rec = record.first.split(":").toList();
                userAdminPageId = rec.last;
              }
            },
          );
        }
      }

      print("eventid ${event.id}");
      if (event.departmentId != null && userAdminPageId != null) {
        await userAdminPageDepartmentRepository.deleteUserAdminPageDepartments(
          departmentId: event.departmentId,
          useradminPageId: int.parse(userAdminPageId),
        );
      } else {
        await userAdminPageDepartmentRepository
            .deleteUserAdminPageDepartmentsById(
          id: event.id,
        );
      }

      yield UserAdminPageDepartmentDeleteSuccess();
    }
  }
}
