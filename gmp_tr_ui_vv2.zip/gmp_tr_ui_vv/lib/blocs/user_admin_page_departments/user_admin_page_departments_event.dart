import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserAdminPageDepartmentsEvent extends Equatable {
  const UserAdminPageDepartmentsEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserAdminPageDepartmentsEvent
    extends UserAdminPageDepartmentsEvent {}

class OnLoadUserAdminPageDepartments extends UserAdminPageDepartmentsEvent {
  final List<UserAdminPageDepartmentsModel> adminPagesDepartments;
  OnLoadUserAdminPageDepartments({this.adminPagesDepartments});
  @override
  List<Object> get props => [adminPagesDepartments];
}

class OnCreateUserAdminPageDepartment extends UserAdminPageDepartmentsEvent {
  final int userAdminPageIdFk;
  final int departmentId;
  final int adminPageId;
  final String adminPageName;
  OnCreateUserAdminPageDepartment(
      {this.departmentId,
      this.adminPageId,
      this.adminPageName,
      this.userAdminPageIdFk});
}

class OnCreateSingleUserAdminPageDepartment
    extends UserAdminPageDepartmentsEvent {
  final int userId;
  final int userRoles;
  OnCreateSingleUserAdminPageDepartment({this.userId, this.userRoles});
}

class OnRemoveUserAdminPageDepartment extends UserAdminPageDepartmentsEvent {
  final int id;
  final int departmentId;
  final int roleId;
  final String adminPageName;
  OnRemoveUserAdminPageDepartment(
      {this.id, this.departmentId, this.roleId, this.adminPageName});
}
