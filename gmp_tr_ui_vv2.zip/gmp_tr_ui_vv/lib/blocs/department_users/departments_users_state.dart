import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DepartmentUsersState extends Equatable {
  const DepartmentUsersState();
  @override
  List<Object> get props => [];
}

class InitialDepartmentUsers extends DepartmentUsersState {}

class DepartmentUsersLoading extends DepartmentUsersState {}

class DepartmentUsersSuccess extends DepartmentUsersState {
  final List<ReadUsersByIdModel> departmentsUser;
  DepartmentUsersSuccess(this.departmentsUser);
}

class DepartmentUsersLoadingFail extends DepartmentUsersState {
  final String code;
  DepartmentUsersLoadingFail({this.code});
}
