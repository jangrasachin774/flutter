import 'package:equatable/equatable.dart';

abstract class DepartmentUsersEvent extends Equatable {
  const DepartmentUsersEvent();
  @override
  List<Object> get props => [];
}

class OnLoadDepartmentUsersEvent extends DepartmentUsersEvent {}

class OnLoadDepartmentUsers extends DepartmentUsersEvent {
  final int departmentId;
  final int roleId;
  OnLoadDepartmentUsers({this.departmentId, this.roleId});
}

class ReadDepartmentUsers extends DepartmentUsersEvent {
  final int departmentIdFk;
  final int roleIdFk;

  ReadDepartmentUsers({this.departmentIdFk, this.roleIdFk});
}

class OnUpdateDepartmentUser extends DepartmentUsersEvent {
  final int id;
  final String name;

  OnUpdateDepartmentUser({this.id, this.name});
}

class OnRemoveDepartmentUser extends DepartmentUsersEvent {
  final int id;
  OnRemoveDepartmentUser({this.id});
}
