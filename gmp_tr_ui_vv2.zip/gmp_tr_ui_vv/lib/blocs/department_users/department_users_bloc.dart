import 'package:bloc/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import 'bloc.dart';

class DepartmentUsersBloc
    extends Bloc<DepartmentUsersEvent, DepartmentUsersState> {
  DepartmentUsersBloc() : super(InitialDepartmentUsers());

  final departmentsRepository = DepartmentsRepository();

  @override
  Stream<DepartmentUsersState> mapEventToState(
      DepartmentUsersEvent event) async* {
    ///Load Department Users

    if (event is OnLoadDepartmentUsers) {
      print("deparment users");
      yield DepartmentUsersLoading();
      try {
        final List<ReadUsersByIdModel> departmentUsers =
            await departmentsRepository.departmentsUsers(
                departmentIdFk: event.departmentId, roleIdFk: event.roleId);
        yield DepartmentUsersSuccess(departmentUsers);
      } catch (e) {
        yield DepartmentUsersLoadingFail(code: e.toString());
      }
    }
  }
}
