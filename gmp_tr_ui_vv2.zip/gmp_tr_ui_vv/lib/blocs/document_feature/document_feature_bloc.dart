import 'package:bloc/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import 'bloc.dart';

class DocumentsFeatureListBloc
    extends Bloc<DocumentsFeatureListEvent, DocumentsFeatureListState> {
  DocumentsFeatureListBloc() : super(InitialDocumentsFeatureList());

  final documentFeatureRepository = DocumentsFeatureRepository();

  @override
  Stream<DocumentsFeatureListState> mapEventToState(
      DocumentsFeatureListEvent event) async* {
    ///Load DocumentsFeature
    if (event is OnLoadDocumentsFeature) {
      yield DocumentsFeatureLoading();

      try {
        final List<DocumentsFeature> response =
            await documentFeatureRepository.loadDocumentsFeature();
        print("response $response");
        yield DocumentsFeatureSuccess(response);
      } catch (e) {
        yield DocumentsFeatureFail(code: e.toString());
      }
    } else if (event is OnAddDocumentFeature) {
      /// Save DocumentFeature
      print("adding");
      yield DocumentsFeatureaving();

      ///Case Success
      try {
        await documentFeatureRepository.saveDocumentsFeature(
          parentId: event.parentId,
          name: event.name,
          level: event.level,
          status: 1,
        );
        yield DocumentsFeatureaveSuccess();
      } catch (e) {
        yield DocumentsFeatureaveFail(code: e.toString());
      }
    } else if (event is OnRemoveDocumentFeature) {
      ///Delete DocumentFeature
      yield DocumentFeatureDeleting();

      try {
        await documentFeatureRepository.deleteDocumentsFeature(id: event.id);
        yield DocumentFeatureDeleteSuccess();
      } catch (e) {
        yield DocumentFeatureDeleteFail(code: e.toString());
      }
    } else if (event is OnUpdateDocumentFeature) {
      ///UPDATE DEPARTMENT
      yield DocumentsFeatureaving();

      ///Case Success
      try {
        await documentFeatureRepository.updateDocumentFeature(
          id: event.id,
          name: event.name,
        );
        yield DocumentFeatureUpdatingSuccess();
      } catch (e) {
        yield DocumentFeatureUpdatingFail(code: e.toString());
      }
    }
  }
}
