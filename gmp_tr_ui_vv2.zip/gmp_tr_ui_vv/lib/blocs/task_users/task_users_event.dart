import 'package:equatable/equatable.dart';
import 'package:gmptr/models/model.dart';

abstract class TaskUsersListEvent extends Equatable {
  const TaskUsersListEvent();
  @override
  List<Object> get props => [];
}

class InitialTaskUserPageEvent extends TaskUsersListEvent {
  @override
  String toString() => 'InitializePageEvent';
}

// ignore: must_be_immutable
class OnLoadTaskUsersEvent extends TaskUsersListEvent {
  final List<TaskUser> tasks;
  final int taskStatusId;
  int taskId = 1;
  final int studentIdFk;
  OnLoadTaskUsersEvent(
      {this.tasks, this.taskId, this.studentIdFk, this.taskStatusId});

  @override
  List<Object> get props => [tasks];
}

class OnDeleteTaskUser extends TaskUsersListEvent {
  final int taskId;

  final int studentIdFk;

  OnDeleteTaskUser({
    this.taskId,
    this.studentIdFk,
  });
}
