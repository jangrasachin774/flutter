import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRoleDocTypesListEvent extends Equatable {
  const UserRoleDocTypesListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserRoleDocTypesEvent extends UserRoleDocTypesListEvent {}

class OnLoadUserRoleDocTypes extends UserRoleDocTypesListEvent {
  final int userRoleIdFk;
  final List<UserRoleDocTypesModel> userroleDocType;
  OnLoadUserRoleDocTypes({this.userroleDocType, this.userRoleIdFk});
  @override
  List<Object> get props => [userroleDocType];
}

class OnCreateUserRoleDocType extends UserRoleDocTypesListEvent {
  final int userId;
  final int userRoles;
  OnCreateUserRoleDocType({this.userId, this.userRoles});
}

class OnCreateSingleUserRoleDocType extends UserRoleDocTypesListEvent {
  final int userRoldIdFk;
  final int documentTypeIdFk;
  OnCreateSingleUserRoleDocType({this.userRoldIdFk, this.documentTypeIdFk});
}

class OnRemoveUserRoleDocType extends UserRoleDocTypesListEvent {
  final int id;
  final int departmentIdFk;

  OnRemoveUserRoleDocType({this.id, this.departmentIdFk});
}

class OnRemoveUserRoleDocTypeId extends UserRoleDocTypesListEvent {
  final int id;

  OnRemoveUserRoleDocTypeId({this.id});
}
