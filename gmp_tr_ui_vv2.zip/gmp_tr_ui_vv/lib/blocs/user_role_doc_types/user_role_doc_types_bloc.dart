import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/user_role_doc_types/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class UserRoleDocTypesListBloc
    extends Bloc<UserRoleDocTypesListEvent, UserRoleDocTypesListState> {
  UserRoleDocTypesListBloc() : super(InitialUserRoleDocTypesList());

  final userRoleDocTypesRepository = UserRoleDocTypesRepo();

  @override
  Stream<UserRoleDocTypesListState> mapEventToState(
      UserRoleDocTypesListEvent event) async* {
    int userRoleId;

    ///LOADING USER ROLE DOCUMENT TYPES
    if (event is OnLoadUserRoleDocTypes) {
      print("anish loading user role doc types");
      yield UserRoleDocTypesLoading();
      try {
        final List<UserRoleDocTypesModel> userRoleDoc =
            await userRoleDocTypesRepository.loadUserRoleDoc(
                userRoleIdFk: event.userRoleIdFk);
        yield UserRoleDocTypesSuccess(userRoleDoc);
      } catch (e) {
        print("anish catch ${e.toString()}");
        yield UserRoleDocTypesFail(code: e.toString());
      }
    }

    /// CREATE USER ROLE DOCUMENT TYPE
    if (event is OnCreateSingleUserRoleDocType) {
      userRoleId = Application.userRoleId;
      print("anish user role id $userRoleId");
      yield UserRoleDocTypeSaving();
      try {
        await userRoleDocTypesRepository.saveUserRoleDocType(
          userRoledIdFk: userRoleId,
          documentTypeIdFk: event.documentTypeIdFk,
          status: 0,
        );

        yield UserRoleDocTypeSaveSuccess();
      } catch (e) {
        yield UserRoleDocTypeSaveFail(error: e.toString());
      }
    }

    /// DELETE  USER ROLE DOCUMENTS TYPES
    if (event is OnRemoveUserRoleDocType) {
      userRoleId = Application.userRoleId;
      yield UserRoleDocTypeDeleting();
      try {
        await userRoleDocTypesRepository.deleteUserRoleDocType(
          userRoledIdFk: userRoleId,
          documentTypeIdFk: event.departmentIdFk,
        );

        yield UserRoleDocTypeDeleteSuccess();
      } catch (e) {
        yield UserRoleDocTypeDeleteFail(e.toString());
      }
    }
  }
}
