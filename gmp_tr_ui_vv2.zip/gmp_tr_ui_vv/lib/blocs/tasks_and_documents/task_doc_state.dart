import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TaskDocState extends Equatable {
  const TaskDocState();

  @override
  List<Object> get props => [];
}

class InitialTaskDocState extends TaskDocState {
  @override
  List<Object> get props => [];
}

class TaskDocLoading extends TaskDocState {
  @override
  List<Object> get props => [];
}

class TaskDocSuccess extends TaskDocState {
  final List<DocumentsModel> documents;
  final List<Task> tasks;

  TaskDocSuccess({this.tasks, this.documents});

  @override
  List<Object> get props => [documents, tasks];
}

class TaskDocFail extends TaskDocState {
  final String code;

  TaskDocFail({this.code});
}

class TaskDocEmpty extends TaskDocState {
  List<Object> get props => [];
}

class TaskCanceling extends TaskDocState {}

class TaskCancelledSuccess extends TaskDocState {}

class TaskCancelledFailure extends TaskDocState {
  final String code;
  TaskCancelledFailure({this.code});
}
