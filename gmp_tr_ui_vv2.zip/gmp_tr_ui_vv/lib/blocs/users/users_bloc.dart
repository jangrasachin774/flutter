import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/users/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class UsersListBloc extends Bloc<UsersListEvent, UsersListState> {
  UsersListBloc() : super(InitialUsersList());

  final usersRepository = UsersRepository();

  @override
  Stream<UsersListState> mapEventToState(UsersListEvent event) async* {
    int currentUserId;

    //Load Users
    // if (event is OnLoadUsers) {
    //   yield UsersLoading();
    //   List<UsersModel> response;
    //   try {
    //     ///Fetch API via repository
    //     response = await usersRepository.loadUsers();

    //     ///Notify loading to UI
    //     yield UsersSuccess(response);
    //   } catch (e) {
    //     yield UsersFail(code: e.toString());
    //   }
    // } else
    if (event is OnLoadFilteredUsers) {
      //Load Filtered Users
      yield FilteredUsersLoading();
      List<UsersModel> filterByName = [];
      List<UsersModel> response;
      try {
        ///Fetch API via repository
        response = await usersRepository.loadFilteredUsers(departmentIdFk: event.departmentIdFk);

        if (event.username != null) {
          filterByName.clear();
          for (var user in response) {
            if (user.username.toLowerCase().startsWith(event.username.toLowerCase())) {
              filterByName.add(user);
            }
          }
        } else {
          filterByName.clear();
          filterByName.addAll(response);
        }

        if (filterByName.length > 0) {
          ///Notify loading to UI
          yield FilteredUsersSuccess(filterByName);
        } else {
          yield FilteredUsersEmpty();
        }
      } catch (e) {
        yield FilteredUsersFail(code: e.toString());
      }
    }

    /// ADD USER
    if (event is OnAddUser) {
      Application.userId = null;
      yield UserSaving();

      final UsersModel response = await usersRepository.saveUser(
        name: event.name,
        username: event.username,
        password: event.password,
        gender: event.gender,
        workNo: event.workNo,
        contact: event.contact,
        email: event.email,
        realCompany: event.realCompany,
        realDept: event.realDepartment,
        status: event.userStatusIdFk,
        departmentId: event.departmentIdFk,
      );
      if (response.success) {
        currentUserId = response.id;
        await usersRepository.saveUserId(currentUserId);
        yield UserSaveSuccess();
      } else {
        yield UserSaveFail(response.success);
      }
    }

    /// UPDATE USER
    if (event is OnUpdateUser) {
      Application.userId = null;
      yield UserUpdating();

      await usersRepository.updateUser(
        id: event.id,
        name: event.name,
        username: event.username,
        password: event.password,
        gender: event.gender,
        workNo: event.workNo,
        contact: event.contact,
        email: event.email,
        realCompany: event.realCompany,
        realDept: event.realDepartment,
        status: event.userStatusIdFk,
        departmentId: event.departmentIdFk,
      );

      await usersRepository.saveUserId(event.id);
      yield UserUpdateSuccess();
    }

    if (event is ChangeStatus) {
      yield StatusUpdating();
      try {
        if (event.reasonForComment == null) {
          await usersRepository.changeStatus(userId: event.userId, userStatusIdFk: event.userStatusIdFk);
        } else {
          await usersRepository.changeStatus(
            reasonForDisable: event.reasonForComment,
            userId: event.userId,
            userStatusIdFk: event.userStatusIdFk,
          );
        }
        yield StatusUpdateSuccess(userStatusIdFk: event.userStatusIdFk);
      } catch (e) {
        yield StatusUpdateFail(error: e.toString());
      }
    }
  }
}
