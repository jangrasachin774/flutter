import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UsersListEvent extends Equatable {
  const UsersListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUsersEvent extends UsersListEvent {}

// class OnLoadUsers extends UsersListEvent {
//   final List<UsersModel> users;
//   OnLoadUsers({this.users});
//   @override
//   List<Object> get props => [users];
// }

class OnLoadFilteredUsers extends UsersListEvent {
  final List<int> departmentIdFk;
  final String username;
  OnLoadFilteredUsers({this.departmentIdFk, this.username});
  @override
  List<Object> get props => [
        departmentIdFk
      ];
}

class OnAddUser extends UsersListEvent {
  final int id;
  final int identifier;
  final String username;
  final String password;
  final int gender;
  final String workNo;
  final String contact;
  final String email;
  final String name;
  final String realCompany;
  final String realDepartment;
  final int companyIdFk;
  final int departmentIdFk;
  final int userStatusIdFk;
  final int creatorIdFk;
  OnAddUser({this.id, this.identifier, this.userStatusIdFk, this.username, this.password, this.gender, this.workNo, this.contact, this.email, this.name, this.companyIdFk, this.creatorIdFk, this.departmentIdFk, this.realCompany, this.realDepartment});
}

class OnUpdateUser extends UsersListEvent {
  final int id;
  final int identifier;
  final String username;
  final String password;
  final int gender;
  final String workNo;
  final String contact;
  final String email;
  final String name;
  final String realCompany;
  final String realDepartment;
  final int companyIdFk;
  final int departmentIdFk;
  final int userStatusIdFk;
  final int creatorIdFk;
  OnUpdateUser({this.id, this.identifier, this.userStatusIdFk, this.username, this.password, this.gender, this.workNo, this.contact, this.email, this.name, this.companyIdFk, this.creatorIdFk, this.departmentIdFk, this.realCompany, this.realDepartment});
}

class ChangeStatus extends UsersListEvent {
  final int userId;
  final int userStatusIdFk;
  final String reasonForComment;
  ChangeStatus({this.userId, this.userStatusIdFk, this.reasonForComment});
}
