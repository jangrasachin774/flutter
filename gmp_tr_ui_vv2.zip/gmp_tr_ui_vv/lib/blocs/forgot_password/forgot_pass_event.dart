abstract class ForgotPassEvent {}

class OnForgotPass extends ForgotPassEvent {
  final String emailId;

  OnForgotPass({this.emailId});
}
