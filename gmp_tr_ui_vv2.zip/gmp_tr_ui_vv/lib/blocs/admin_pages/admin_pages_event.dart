import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class AdminPagesEvent extends Equatable {
  const AdminPagesEvent();
  @override
  List<Object> get props => [];
}

class OnLoadAdminPagesEvent extends AdminPagesEvent {}

class OnLoadAdminPages extends AdminPagesEvent {
  final List<AdminPagesModel> adminPages;
  OnLoadAdminPages({this.adminPages});
  @override
  List<Object> get props => [adminPages];
}

// class OnCreateUserAdminPage extends AdminPagesEvent {
//   final int userId;
//   final int userRoles;
//   OnCreateUserAdminPage({this.userId, this.userRoles});
// }

// class OnCreateSingleUserAdminPage extends AdminPagesEvent {
//   final int userId;
//   final int userRoles;
//   OnCreateSingleUserAdminPage({this.userId, this.userRoles});
// }

// class OnRemoveUserAdminPage extends AdminPagesEvent {
//   final int id;
//   final int roleId;
//   OnRemoveUserAdminPage({this.id, this.roleId});
// }

// class OnRemoveUserAdminPageId extends AdminPagesEvent {
//   final int id;

//   OnRemoveUserAdminPageId({this.id});
// }
