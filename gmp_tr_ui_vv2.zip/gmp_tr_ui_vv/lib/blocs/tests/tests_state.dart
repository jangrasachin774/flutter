import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class TestsState extends Equatable {
  const TestsState();
  @override
  List<Object> get props => [];
}

class InitialTests extends TestsState {}

class TestsLoading extends TestsState {}

class TestsSuccess extends TestsState {
  final List<ReadUsersByIdModel> tests;
  TestsSuccess(this.tests);
  @override
  List<Object> get props => [tests];
}

class TestsFail extends TestsState {
  final String code;
  TestsFail({this.code});
}

class Testsaving extends TestsState {}

class TestsaveSuccess extends TestsState {}

class TestsaveFail extends TestsState {
  final String error;
  TestsaveFail(this.error);
}

class TestAttemptsFailed extends TestsState {
  final int attempts;
  TestAttemptsFailed({this.attempts});
}
