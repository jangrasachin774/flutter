abstract class ChangePassEvent {}

class OnChangePass extends ChangePassEvent {
  final String oldPass;
  final String newPass;


  OnChangePass({this.oldPass, this.newPass});
}

