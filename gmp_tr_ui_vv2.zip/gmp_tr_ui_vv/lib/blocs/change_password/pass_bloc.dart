import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/change_password/bloc.dart';
import 'package:gmptr/repository/user_repository.dart';

class ChangePassBloc extends Bloc<ChangePassEvent, ChangePassState> {
  ChangePassBloc() : super(InitialChangePass());
  final userRepository = UserRepository();

  @override
  Stream<ChangePassState> mapEventToState(ChangePassEvent event) async* {
    if (event is OnChangePass) {
      yield ChangingPass();

      final String oldPass = event.oldPass;
      final String newPass = event.newPass;

      try {
        var res = await Api.changePassword(oldPass, newPass);
        if (res['ok']) {
          yield ChangePassSuccess();
        } else {
          yield ChangePassFail(error: res['msg']);
        }
      } catch (e) {
        yield ChangePassFail(error: e.toString());
      }
    }
  }
}
