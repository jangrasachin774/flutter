import 'package:bloc/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

import 'bloc.dart';

class TrainingsTypeListBloc
    extends Bloc<TrainingsTypeListEvent, TrainingsTypeListState> {
  TrainingsTypeListBloc() : super(InitialTrainingsTypeList());

  final documentFeatureRepository = TrainingsTypeRepository();

  @override
  Stream<TrainingsTypeListState> mapEventToState(
      TrainingsTypeListEvent event) async* {
    ///Load TrainingsType
    if (event is OnLoadTrainingsType) {
      yield TrainingsTypeLoading();

      try {
        final List<TrainingsType> response =
            await documentFeatureRepository.loadTrainingsType();
        yield TrainingsTypeSuccess(response);
      } catch (e) {
        yield TrainingsTypeFail(code: e.toString());
      }
    }
    if (event is OnAddTrainingType) {
      /// Save TrainingType
      yield TrainingsTypsaving();

      ///Case Success
      try {
        await documentFeatureRepository.saveTrainingType(
          parentId: event.parentId,
          name: event.name,
          companyIdFk: 1,
          level: event.level,
          status: 1,
        );
        yield TrainingsTypsaveSuccess();
      } catch (e) {
        yield TrainingsTypsaveFail(code: e.toString());
      }
    } else if (event is OnRemoveTrainingType) {
      ///Delete TrainingType
      yield TrainingTypeDeleting();

      try {
        await documentFeatureRepository.deleteTrainingType(id: event.id);
        yield TrainingTypeDeleteSuccess();
      } catch (e) {
        yield TrainingTypeDeleteFail(code: e.toString());
      }
    } else if (event is OnUpdateTrainingType) {
      ///UPDATE DEPARTMENT
      yield TrainingTypeUpdating();

      ///Case Success
      try {
        await documentFeatureRepository.updateTrainingType(
          id: event.id,
          name: event.name,
        );
        yield TrainingTypeUpdatingSuccess();
      } catch (e) {
        yield TrainingTypeUpdatingFail(code: e.toString());
      }
    }
  }
}
