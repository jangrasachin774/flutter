import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/documents_versions/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class DocumentVersionsBloc
    extends Bloc<DocumentVersionsEvent, DocumentVersionsState> {
  DocumentVersionsBloc() : super(InitialDocumentVersion());

  final documentsRepository = DocumentsRepository();

  @override
  Stream<DocumentVersionsState> mapEventToState(
      DocumentVersionsEvent event) async* {
    if (event is ValidatingDocVersion) {
      yield DocumentVersionFetching();
      try {
        List<DocVersionsModel> docVersions;
        docVersions = await documentsRepository.validateDocVersions(
            title: event.title, viewIdFk: event.viewIdFk);
        if (docVersions.isNotEmpty || docVersions.length != 0) {
          yield DocumentVersionFetchSuccess(docVersions);
        } else {
          yield DocumentVersionEmpty();
        }
      } catch (e) {
        yield DocumentVersionFetchFailed();
      }
    }

    if (event is OnLoadDocVersion) {
      yield DocumentVersionFetching();

      try {
        List<DocVersionsModel> docVersions;
        docVersions = await documentsRepository.getDocVersions(
            trainingTypeIdFk: event.trainingTypeIdFk,
            departmentIdFk: event.departmentIdFk,
            documentType: event.documentFeature);
        if (docVersions.isNotEmpty || docVersions.length != 0) {
          yield DocumentVersionFetchSuccess(docVersions);
        } else {
          yield DocumentVersionEmpty();
        }
      } catch (e) {
        yield DocumentVersionFetchFailed();
      }
    }
  }
}
