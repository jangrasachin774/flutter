import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DocumentVersionsState extends Equatable {
  const DocumentVersionsState();
  @override
  List<Object> get props => [];
}

class InitialDocumentVersion extends DocumentVersionsState {
  @override
  List<Object> get props => [];
}

class DocumentVersionFetching extends DocumentVersionsState {}

class DocumentVersionFetchSuccess extends DocumentVersionsState {
  final List<DocVersionsModel> versions;
  DocumentVersionFetchSuccess(this.versions);
  @override
  List<Object> get props => [versions];
}

class DocumentVersionEmpty extends DocumentVersionsState {
  @override
  List<Object> get props => [];
}

class DocumentVersionFetchFailed extends DocumentVersionsState {
  @override
  List<Object> get props => [];
}
