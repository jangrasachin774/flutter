import 'package:equatable/equatable.dart';

abstract class DocumentVersionsEvent extends Equatable {
  const DocumentVersionsEvent();
  @override
  List<Object> get props => [];
}

// ignore: must_be_immutable
class ValidatingDocVersion extends DocumentVersionsEvent {
  String title;
  int viewIdFk = 3;
  String version;
  ValidatingDocVersion({this.title, this.version, this.viewIdFk});
}

// ignore: must_be_immutable
class OnLoadDocVersion extends DocumentVersionsEvent {
  int trainingTypeIdFk;
  int departmentIdFk;
  int documentFeature;
  OnLoadDocVersion({
    this.trainingTypeIdFk,
    this.departmentIdFk,
    this.documentFeature,
  });
}
