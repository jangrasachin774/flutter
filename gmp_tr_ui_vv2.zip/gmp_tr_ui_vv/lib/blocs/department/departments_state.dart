import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class DepartmentsListState extends Equatable {
  const DepartmentsListState();
  @override
  List<Object> get props => [];
}

class InitialDepartmentsList extends DepartmentsListState {}

class DepartmentsLoading extends DepartmentsListState {}

class DepartmentsSuccess extends DepartmentsListState {
  final List<Departments> departments;
  DepartmentsSuccess(this.departments);
  @override
  List<Object> get props => [departments];
}

class DepartmentsFail extends DepartmentsListState {
  final String code;
  DepartmentsFail({this.code});
}

class Departmentsaving extends DepartmentsListState {}

class DepartmentsaveSuccess extends DepartmentsListState {}

class DepartmentsaveFail extends DepartmentsListState {
  final String code;
  DepartmentsaveFail({this.code});
}

class DepartmentUpdating extends DepartmentsListState {}

class DepartmentUpdatingSuccess extends DepartmentsListState {}

class DepartmentUpdatingFail extends DepartmentsListState {
  final String code;
  DepartmentUpdatingFail({this.code});
}

class DepartmentDeleting extends DepartmentsListState {}

class DepartmentDeleteSuccess extends DepartmentsListState {}

class DepartmentDeleteFail extends DepartmentsListState {
  final String code;
  DepartmentDeleteFail({this.code});
}
