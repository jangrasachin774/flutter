import 'package:bloc/bloc.dart';
import 'package:gmptr/blocs/user_roles/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/repository/repository.dart';

class UserRolesListBloc extends Bloc<UserRolesListEvent, UserRolesListState> {
  UserRolesListBloc() : super(InitialUserRolesList());

  final userRolesRepository = UserRolesRepository();

  @override
  Stream<UserRolesListState> mapEventToState(UserRolesListEvent event) async* {
    int userId;

    /// LOADING USER ROLE
    if (event is OnLoadUserRoles) {
      print("////// user id ${event.userId}");
      yield UserRolesLoading();

      try {
        final List<UserRolesModel> userRoles =
            await userRolesRepository.loadingUserRole(userId: event.userId);
        print("userRoles ${userRoles.length}");

        yield UserRolesSuccess(userRoles);
      } catch (e) {
        yield UserRolesFail(code: e.toString());
      }
    }

    /// CREATE MULTIPLE USER ROLE
    if (event is OnCreateUserRole) {
      userId = Application.userId;
      yield UserRoleSaving();

      final UserRolesModel response = await userRolesRepository.createUserRole(
        userId: userId,
        userRoles: event.userRoles,
      );
      if (response.success) {
        final userRoleId = response.id;
        final roleId = response.roleIdFk;
        await userRolesRepository.saveUserRoleId(
            userRoleId, userId, roleId, event.roleName);
        yield UserRoleSaveSuccess();
      } else {
        yield UserRoleSaveFail(response.success);
      }
    }

    /// CREATE SINGLE USER ROLE
    if (event is OnCreateSingleUserRole) {
      userId = Application.userId;

      yield SingleUserRoleSaving();

      final UserRolesModel response = await userRolesRepository.createUserRole(
        userId: userId,
        userRoles: event.roleId,
      );
      if (response.success) {
        final roleId = response.id;
        await userRolesRepository.saveSingleUserRoleId(roleId);
        yield SingleUserRoleSaveSuccess();
      } else {
        yield SingleUserRoleSaveFail(response.success);
      }
    }

    /// Delete Trainer Role
    if (event is OnRemoveUserRoleId) {
      int roleId = Application.userRoleId;
      yield SingleUserRoleDeleting();
      await userRolesRepository.deleteUserRoleId(
        id: roleId,
      );
      yield SingleUserRoleDeleteSuccess();
    }

    /// Delete Trainee/Others Role
    if (event is OnRemoveUserRole) {
      userId = Application.userId;
      yield UserRoleDeleting();
      await userRolesRepository.deleteUserRole(
          roleId: event.roleId, userId: userId);
      await userRolesRepository.deleteUserRoleIdRepo(
          event.roleId, userId, event.rolename);
      yield UserRoleDeleteSuccess();
    }
  }
}
