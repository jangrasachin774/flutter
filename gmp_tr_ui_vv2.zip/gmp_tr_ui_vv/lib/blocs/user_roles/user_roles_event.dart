import 'package:gmptr/models/model.dart';
import 'package:equatable/equatable.dart';

abstract class UserRolesListEvent extends Equatable {
  const UserRolesListEvent();
  @override
  List<Object> get props => [];
}

class OnLoadUserRolesEvent extends UserRolesListEvent {}

class OnLoadUserRoles extends UserRolesListEvent {
  final int userId;
  final List<UserRolesModel> userroles;
  OnLoadUserRoles({this.userId, this.userroles});
  @override
  List<Object> get props => [userroles];
}

class OnCreateUserRole extends UserRolesListEvent {
  final int userId;
  final int userRoles;
  final String roleName;
  OnCreateUserRole({this.userId, this.userRoles, this.roleName});
}

class OnCreateSingleUserRole extends UserRolesListEvent {
  final int userId;
  final int roleId;
  OnCreateSingleUserRole({this.userId, this.roleId});
}

class OnRemoveUserRole extends UserRolesListEvent {
  final int id;
  final int roleId;
  final String rolename;

  OnRemoveUserRole({this.id, this.roleId, this.rolename});
}

class OnRemoveUserRoleId extends UserRolesListEvent {
  final int id;

  OnRemoveUserRoleId({this.id});
}
