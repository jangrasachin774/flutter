import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:url_strategy/url_strategy.dart';
import 'app.dart';
import 'blocs/app_bloc.dart';
import 'blocs/bloc.dart';
import 'dart:html' as html;

/// Custom [BlocObserver] which observes all bloc and cubit instances.
class SimpleBlocObserver extends BlocObserver {
  @override
  void onEvent(Bloc bloc, Object event) {
    super.onEvent(bloc, event);
    print(event);
  }

  @override
  void onTransition(Bloc bloc, Transition transition) {
    super.onTransition(bloc, transition);
    print(transition);
  }

  @override
  void onError(BlocBase bloc, Object error, StackTrace stackTrace) {
    print(error);
    super.onError(bloc, error, stackTrace);
  }
}

void main() {
  html.window.onBeforeUnload.listen((event) {
    html.window.onUnload.listen((event) {
      event.preventDefault();
      AppBloc.authBloc.add(OnClear());
      return true;
    });
    return false;
  });
  Bloc.observer = SimpleBlocObserver();
  WidgetsFlutterBinding.ensureInitialized();
  setPathUrlStrategy();
  runApp(App());
}
