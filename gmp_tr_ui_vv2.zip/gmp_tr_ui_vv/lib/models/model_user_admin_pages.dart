class UserAdminPageModel {
  int id;
  int adminPageIdFk;
  int userRoleIdFk;
  String updatedAt;
  String createdAt;
  bool success;

  UserAdminPageModel({
    this.id,
    this.adminPageIdFk,
    this.userRoleIdFk,
    this.updatedAt,
    this.createdAt,
    this.success,
  });

  UserAdminPageModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    adminPageIdFk = json['admin_page_id_fk'];
    userRoleIdFk = json['user_role_id_fk'];
    updatedAt = json['updatedAt'];
    createdAt = json['createdAt'];
    success = json['error'] == null ? true : false;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['admin_page_id_fk'] = this.adminPageIdFk;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['updatedAt'] = this.updatedAt;
    data['createdAt'] = this.createdAt;
    return data;
  }
}
