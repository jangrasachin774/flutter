class UserModel {
  int id;
  String username;
  int gender;
  String workNo;
  String contact;
  String email;
  String name;
  int companyIdFk;
  int departmentIdFk;
  String realCompany;
  String realDepartment;
  UserDepartment department;
  int userStatusIdFk;
  int status;
  List<UserRoles> userRoles;
  String createdAt;
  String updatedAt;

  UserModel({
    this.id,
    this.username,
    this.gender,
    this.workNo,
    this.contact,
    this.email,
    this.name,
    this.realCompany,
    this.realDepartment,
    this.userStatusIdFk,
    this.companyIdFk,
    this.departmentIdFk,
    this.status,
    this.department,
    this.userRoles,
    this.createdAt,
    this.updatedAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    try {
      final Iterable refactorRoles = json['user_roles'] ?? [];
      final listRoles = refactorRoles.map((item) {
        return UserRoles.fromJson(item);
      }).toList();

      return UserModel(
        id: json['id'] as int ?? 0,
        username: json['username'] as String ?? "UnKnown",
        gender: json['gender'] as int ?? null,
        workNo: json['work_no'] as String ?? "Unknown",
        contact: json['contact'] as String ?? "unKnown",
        email: json['email'] as String ?? "Unknown",
        name: json['name'] as String ?? "Unknown",
        realCompany: json['real_company'] as String ?? "Unknown",
        realDepartment: json['real_department'] as String ?? "Unknown",
        userStatusIdFk: json['user_status_id_fk'],
        companyIdFk: json['company_id_fk'] as int ?? 0,
        departmentIdFk: json['department_id_fk'] as int ?? 0,
        status: json['status'] as int ?? null,
        userRoles: listRoles,
        createdAt: json['createdAt'] as String ?? "Unknown",
        updatedAt: json['updatedAt'] as String ?? "Unknown",
        department: json['department'] != null
            ? UserDepartment.fromJson(json['department'])
            : null,
      );
    } catch (error) {
      return null;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': this.id,
      'username': this.username,
      'gender': this.gender,
      'work_no': this.workNo,
      'contact': this.contact,
      'email': this.email,
      'name': this.name,
      'company_id_fk': this.companyIdFk,
      'department_id_fk': this.departmentIdFk,
      'status': this.status,
      'user_roles': this.userRoles,
      'createdAt': this.createdAt,
      'updatedAt': this.updatedAt,
    };
  }
}

class UserDepartment {
  int id;
  String name;

  UserDepartment({
    this.id,
    this.name,
  });

  UserDepartment.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? "";
    name = json['name'] ?? "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class UserRoles {
  int id;
  int roleIdFk;
  MyRole role;
  List<UserAdminPagee> userAdminPagees;
  List<UserRoleDept> userRoleDept;

  UserRoles(
      {this.id,
      this.roleIdFk,
      this.role,
      this.userAdminPagees,
      this.userRoleDept});

  factory UserRoles.fromJson(Map<String, dynamic> json) {
    try {
      final Iterable refactoruserAdminPagees = json['user_admin_pages'] ?? [];
      final listuserAdminPagees = refactoruserAdminPagees.map((item) {
        return UserAdminPagee.fromJson(item);
      }).toList();
      final Iterable refactoruserRoleDept = json['user_role_departments'] ?? [];
      final listuserRoleDept = refactoruserRoleDept.map((item) {
        return UserRoleDept.fromJson(item);
      }).toList();

      return UserRoles(
        id: json['id'],
        roleIdFk: json['role_id_fk'],
        role: json['role'] != null ? new MyRole.fromJson(json['role']) : null,
        userAdminPagees: listuserAdminPagees,
        userRoleDept: listuserRoleDept,
      );
    } catch (e) {
      return null;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['role_id_fk'] = this.roleIdFk;
    if (this.role != null) {
      data['role'] = this.role.toJson();
    }
    if (this.userAdminPagees != null) {
      data['user_admin_pages'] =
          this.userAdminPagees.map((v) => v.toJson()).toList();
    }
    if (this.userRoleDept != null) {
      data['user_role_departments'] =
          this.userRoleDept.map((v) => v.toJson()).toList();
    }

    return data;
  }
}

class MyRole {
  int id;
  String identifier;
  String name;
  bool multiButtons;
  int roleTypeIdFk;
  String description;
  String createdAt;
  String updatedAt;

  MyRole({
    this.id,
    this.identifier,
    this.name,
    this.multiButtons,
    this.roleTypeIdFk,
    this.description,
    this.createdAt,
    this.updatedAt,
  });

  MyRole.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    multiButtons = json['multi_buttons'];
    roleTypeIdFk = json['role_type_id_fk'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['multi_buttons'] = this.multiButtons;
    data['role_type_id_fk'] = this.roleTypeIdFk;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class UserRoleDept {
  int id;
  int userRoleIdFk;
  int deptIdFk;
  int status;
  String createdAt;
  String updatedAt;
  RoleDept roleDept;

  UserRoleDept({
    this.id,
    this.userRoleIdFk,
    this.deptIdFk,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.roleDept,
  });

  factory UserRoleDept.fromJson(Map<String, dynamic> json) {
    try {
      return UserRoleDept(
        id: json['id'],
        userRoleIdFk: json['user_role_id_fk'],
        deptIdFk: json['department_id_fk'],
        status: json['status'],
        createdAt: json['createdAt'],
        updatedAt: json['updatedAt'],
        roleDept: json['department'] != null
            ? new RoleDept.fromJson(json['department'])
            : null,
      );
    } catch (e) {
      return null;
    }
  }
  Map<String, dynamic> toJson() {
    return {
      'id': this.id,
      'user_role_id_fk': this.userRoleIdFk,
      'department_id_fk': this.deptIdFk,
      'createdAt': this.createdAt,
      'updatedAt': this.updatedAt,
      'department': this.roleDept,
    };
  }
}

class UserAdminPagee {
  int id;
  int userRoleIdFk;
  int adminPageIdFk;
  String createdAt;
  String updatedAt;
  AdminPagee adminPage;
  List<UserAdminPageDepts> userAdminPageDepartments;

  UserAdminPagee(
      {this.id,
      this.userRoleIdFk,
      this.adminPageIdFk,
      this.createdAt,
      this.updatedAt,
      this.adminPage,
      this.userAdminPageDepartments});

  factory UserAdminPagee.fromJson(Map<String, dynamic> json) {
    try {
      final Iterable refactoruserAdminPageDepartments =
          json['user_admin_page_departments'] ?? [];
      final listuserAdminPageDepartments =
          refactoruserAdminPageDepartments.map((item) {
        return UserAdminPageDepts.fromJson(item);
      }).toList();
      return UserAdminPagee(
        id: json['id'],
        userRoleIdFk: json['user_role_id_fk'],
        adminPageIdFk: json['admin_page_id_fk'],
        createdAt: json['createdAt'],
        updatedAt: json['updatedAt'],
        adminPage: json['admin_page'] != null
            ? new AdminPagee.fromJson(json['admin_page'])
            : null,
        userAdminPageDepartments: listuserAdminPageDepartments,
      );
    } catch (e) {
      return null;
    }
  }
  Map<String, dynamic> toJson() {
    return {
      'id': this.id,
      'user_role_id_fk': this.userRoleIdFk,
      'admin_page_id_fk': this.adminPageIdFk,
      'createdAt': this.createdAt,
      'updatedAt': this.updatedAt,
      'admin_page': this.adminPage,
      'user_admin_page_departments': this.userAdminPageDepartments,
    };
  }
}

class AdminPagee {
  int id;
  String name;
  int level;
  int parentAdminPageeIdFk;
  bool departments;
  String description;
  String createdAt;
  String updatedAt;

  AdminPagee(
      {this.id,
      this.name,
      this.level,
      this.parentAdminPageeIdFk,
      this.departments,
      this.description,
      this.createdAt,
      this.updatedAt});

  AdminPagee.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    level = json['level'];
    parentAdminPageeIdFk = json['parent_admin_page_id_fk'];
    departments = json['departments'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['level'] = this.level;
    data['parent_admin_page_id_fk'] = this.parentAdminPageeIdFk;
    data['departments'] = this.departments;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}

class RoleDept {
  int id;
  String name;

  RoleDept({
    this.id,
    this.name,
  });

  RoleDept.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;

    return data;
  }
}

class UserAdminPageDepts {
  int id;
  int userAdminPageIdFk;
  int departmentIdfk;
  int status;
  AdminPageDeptName adminPageDept;

  UserAdminPageDepts({
    this.id,
    this.userAdminPageIdFk,
    this.departmentIdfk,
    this.status,
    this.adminPageDept,
  });

  UserAdminPageDepts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userAdminPageIdFk = json['user_admin_page_id_fk'];
    departmentIdfk = json['department_id_fk'];
    status = json['status'];
    adminPageDept = json['department'] != null
        ? new AdminPageDeptName.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_admin_page_id_fk'] = this.userAdminPageIdFk;
    data['department_id_fk'] = this.departmentIdfk;
    data['status'] = this.status;
    data['department'] = this.adminPageDept;
    return data;
  }
}

class AdminPageDeptName {
  int id;
  String name;

  AdminPageDeptName({
    this.id,
    this.name,
  });

  AdminPageDeptName.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;

    return data;
  }
}
