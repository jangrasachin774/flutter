class UserAdminPageWithDeptModel {
  int id;
  int userRoleIdFk;
  int adminPageIdFk;
  String createdAt;
  String updatedAt;
  List<UserAdminPageDepartments> userAdminPageDepartments;

  UserAdminPageWithDeptModel(
      {this.id,
      this.userRoleIdFk,
      this.adminPageIdFk,
      this.createdAt,
      this.updatedAt,
      this.userAdminPageDepartments});

  UserAdminPageWithDeptModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleIdFk = json['user_role_id_fk'];
    adminPageIdFk = json['admin_page_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];

    final Iterable refactorUserAdminPageDept =
        json['user_admin_page_departments'] ?? [];
    final listUserAdminDept = refactorUserAdminPageDept.map((item) {
      return UserAdminPageDepartments.fromJson(item);
    }).toList();
    userAdminPageDepartments = listUserAdminDept;
    // if (json['user_admin_page_departments'] != null) {
    //   List<UserAdminPageDepartments> userAdminPageDepartments = [];
    //   json['user_admin_page_departments'].forEach((v) {
    //     userAdminPageDepartments.add(new UserAdminPageDepartments.fromJson(v));
    //   });
    // }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['admin_page_id_fk'] = this.adminPageIdFk;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.userAdminPageDepartments != null) {
      data['user_admin_page_departments'] =
          this.userAdminPageDepartments.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UserAdminPageDepartments {
  int id;
  int userAdminPageIdFk;
  int departmentIdFk;
  int status;
  Depart department;

  UserAdminPageDepartments(
      {this.id,
      this.userAdminPageIdFk,
      this.departmentIdFk,
      this.status,
      this.department});

  UserAdminPageDepartments.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userAdminPageIdFk = json['user_admin_page_id_fk'];
    departmentIdFk = json['department_id_fk'];
    status = json['status'];
    department = json['department'] != null
        ? new Depart.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_admin_page_id_fk'] = this.userAdminPageIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['status'] = this.status;
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    return data;
  }
}

class Depart {
  int id;
  String name;
  String identifier;
  int level;

  Depart({this.id, this.name, this.identifier, this.level});

  Depart.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    identifier = json['identifier'];
    level = json['level'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['identifier'] = this.identifier;
    data['level'] = this.level;
    return data;
  }
}
