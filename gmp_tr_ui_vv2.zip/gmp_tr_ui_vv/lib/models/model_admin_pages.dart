class AdminPagesModel {
  int id;
  String name;
  int level;
  int parentAdminPageIdFk;
  bool departments;
  String description;
  String createdAt;
  String updatedAt;
  bool isChecked = false;

  AdminPagesModel({
    this.id,
    this.name,
    this.level,
    this.parentAdminPageIdFk,
    this.departments,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.isChecked,
  });

  AdminPagesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    level = json['level'];
    parentAdminPageIdFk = json['parent_admin_page_id_fk'];
    departments = json['departments'];
    description = json['description'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['level'] = this.level;
    data['parent_admin_page_id_fk'] = this.parentAdminPageIdFk;
    data['departments'] = this.departments;
    data['description'] = this.description;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }

  String getId() {
    return this.id.toString();
  }

  String getParentId() {
    return this.parentAdminPageIdFk.toString();
  }

  String getTitle() {
    return this.name;
  }

  bool getChecked() {
    return this.isChecked;
  }
}
