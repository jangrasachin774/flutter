class Departments {
  int id;
  String identifier;
  String name;
  int companyIdFk;
  int parentDepartmentIdFk;
  int level;
  int status;
  String createdAt;
  String updatedAt;
  bool isHovered = false;

  Departments({
    this.id,
    this.identifier,
    this.name,
    this.companyIdFk,
    this.parentDepartmentIdFk,
    this.level,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.isHovered,
  });

  Departments.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    companyIdFk = json['company_id_fk'];
    parentDepartmentIdFk = json['parent_department_id_fk'];
    level = json['level'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['company_id_fk'] = this.companyIdFk;
    data['parent_department_id_fk'] = this.parentDepartmentIdFk;
    data['level'] = this.level;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }

  String getId() {
    return this.id.toString();
  }

  String getParentId() {
    return this.parentDepartmentIdFk.toString();
  }

  String getTitle() {
    return this.name;
  }
}
