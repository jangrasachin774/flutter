class DocumentsTaskDocs {
  int id;
  String path;
  int documentIdFk;
  int taskIdFk;
  String name;
  bool isSuccess;

  DocumentsTaskDocs({
    this.id,
    this.path,
    this.documentIdFk,
    this.taskIdFk,
    this.name,
    this.isSuccess,
  });

  DocumentsTaskDocs.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    path = json['path'];
    documentIdFk = json['document_id_fk'];
    taskIdFk = json['task_id_fk'];
    name = json['name'];
    isSuccess = json['error'] != null ? false : true;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['path'] = this.path;
    data['document_id_fk'] = this.documentIdFk;
    data['task_id_fk'] = this.taskIdFk;
    data['name'] = this.name;
    return data;
  }
}
