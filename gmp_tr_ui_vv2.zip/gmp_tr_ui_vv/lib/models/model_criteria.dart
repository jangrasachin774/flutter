import 'package:gmptr/utils/utils.dart';

class FilterCriteria {
  int id;
  String name;

  FilterCriteria({
    this.id,
    this.name,
  });
}

List<FilterCriteria> criteria = [
  FilterCriteria(
    id: 1,
    name: '创建时间',
  ),
  FilterCriteria(
    id: 2,
    name: '审核时间',
  ),
  FilterCriteria(
    id: 3,
    name: '审批时间',
  ),
  FilterCriteria(
    id: 4,
    name: '结束时间',
  ),
  FilterCriteria(
    id: 5,
    name: '完成时间',
  ),
];
