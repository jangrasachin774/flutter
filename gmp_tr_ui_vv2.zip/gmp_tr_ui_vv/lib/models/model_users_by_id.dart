class ReadUsersByIdModel {
  int id;
  int identifier;
  String name;

  ReadUsersByIdModel({
    this.id,
    this.identifier,
    this.name,
  });

  ReadUsersByIdModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;

    return data;
  }
}
