class DocumentTestModel {
  int id;
  String question;
  int documentIdFk;

  List<String> totalAnswers;
  List<String> rightAnswers;
  int documentTestIdFk;

  DocumentTestModel.create({
    this.question,
    this.documentIdFk,
    this.totalAnswers,
    this.rightAnswers,
    this.documentTestIdFk,
  });

  DocumentTestModel.fromJson(Map<String, dynamic> json) {
    documentTestIdFk = json['id'];
    question = json['question'];
    documentIdFk = json['document_id_fk'];
    totalAnswers = json['total_answers'].cast<String>();
    rightAnswers = json['right_answers'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.documentTestIdFk;
    data['question'] = this.question;
    data['document_id_fk'] = this.documentIdFk;
    data['total_answers'] = this.totalAnswers;
    data['right_answers'] = this.rightAnswers;
    return data;
  }
}
