import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filterable.dart';

class DocumentsModel implements Filterable {
  int id;
  String identifier;
  String title;
  String description;
  String version;
  int viewIdFk;
  int departmentIdFk;
  int trainingTypeIdFk;
  int documentTypeIdFk;
  int creatorIdFk;
  int smallLeaderIdFk;
  int bigLeaderIdFk;
  String smallLeaderConfirmDate;
  String bigLeaderConfirmDate;
  String creatorConfirmDate;
  int status;
  String createdAt;
  String updatedAt;
  int departmentTypeIdFk;
  int documentTypesIdFk;
  DepartmentType department;
  DocTrainingType trainingType;
  Creator docCreator;

  DocType documentType;
  List<DocumentFiles> documentFiles;
  List<DocumentTests> documentTests;
  bool success;
  bool selected = false;
  DocStatus docStatus;
  List<int> otherDocIds = [];

  DocumentsModel({
    this.id,
    this.identifier,
    this.title,
    this.viewIdFk,
    this.description,
    this.version,
    this.departmentIdFk,
    this.trainingTypeIdFk,
    this.documentTypeIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.bigLeaderIdFk,
    this.smallLeaderConfirmDate,
    this.bigLeaderConfirmDate,
    this.creatorConfirmDate,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.departmentTypeIdFk,
    this.documentTypesIdFk,
    this.department,
    this.trainingType,
    this.docCreator,
    this.documentType,
    this.documentFiles,
    this.documentTests,
    this.success,
    this.docStatus,
  });

  DocumentsModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    title = json['title'];
    viewIdFk = json['view_id_fk'];
    description = json['description'];
    version = json['version'];
    departmentIdFk = json['department_id_fk'];
    trainingTypeIdFk = json['training_type_id_fk'];
    documentTypeIdFk = json['document_type_id_fk'];
    creatorIdFk = json['creator_id_fk'];
    smallLeaderIdFk = json['small_leader_id_fk'];
    bigLeaderIdFk = json['big_leader_id_fk'];
    smallLeaderConfirmDate = json['small_leader_confirm_date'];
    bigLeaderConfirmDate = json['big_leader_confirm_date'];
    creatorConfirmDate = json['creator_confirm_date'];
    status = json['document_status_id_fk'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    departmentTypeIdFk = json['department_type_id_fk'];
    documentTypesIdFk = json['document_types_id_fk'];
    department = json['department'] != null
        ? new DepartmentType.fromJson(json['department'])
        : null;

    trainingType = json['training_type'] != null
        ? new DocTrainingType.fromJson(json['training_type'])
        : null;

    documentType = json['document_type'] != null
        ? new DocType.fromJson(json['document_type'])
        : null;
    docCreator =
        json['creator'] != null ? new Creator.fromJson(json['creator']) : null;
    docStatus = json['document_status'] != null
        ? new DocStatus.fromJson(json['document_status'])
        : null;
    final Iterable refactorDocuments = json['document_files'] ?? [];
    final documentsLists = refactorDocuments.map((item) {
      return DocumentFiles.fromJson(item);
    }).toList();
    documentFiles = documentsLists;
    final Iterable refactorDocumentTests = json['document_tests'] ?? [];
    final documentTestss = refactorDocumentTests.map((item) {
      return DocumentTests.fromJson(item);
    }).toList();
    documentTests = documentTestss;

    success = json['error'] != null ? false : true;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['title'] = this.title;
    data['view_id_fk'] = this.viewIdFk;
    data['description'] = this.description;
    data['version'] = this.version;
    data['department_id_fk'] = this.departmentIdFk;
    data['training_type_id_fk'] = this.trainingTypeIdFk;
    data['document_type_id_fk'] = this.documentTypeIdFk;
    data['creator_id_fk'] = this.creatorIdFk;
    data['small_leader_id_fk'] = this.smallLeaderIdFk;
    data['big_leader_id_fk'] = this.bigLeaderIdFk;
    data['small_leader_confirm_date'] = this.smallLeaderConfirmDate;
    data['big_leader_confirm_date'] = this.bigLeaderConfirmDate;
    data['creator_confirm_date'] = this.creatorConfirmDate;
    data['document_status_id_fk'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['department_type_id_fk'] = this.departmentTypeIdFk;
    data['document_types_id_fk'] = this.documentTypesIdFk;

    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    if (this.trainingType != null) {
      data['training_type'] = this.trainingType.toJson();
    }
    if (this.documentType != null) {
      data['document_type'] = this.documentType.toJson();
    }

    if (this.documentFiles != null) {
      data['document_files'] =
          this.documentFiles.map((v) => v.toJson()).toList();
    }
    if (this.documentTests != null) {
      data['document_tests'] =
          this.documentTests.map((v) => v.toJson()).toList();
    }
    return data;
  }

  @override
  DateTime get bigLeaderSignTime => DateTime.parse(bigLeaderConfirmDate);

  @override
  DateTime get creatorSignTime => DateTime.parse(creatorConfirmDate);

  @override
  int get departmentId => department.id;

  @override
  int get documentFeatureId => documentTypeIdFk;

  @override
  // ignore: todo
  // TODO: implement endTime
  DateTime get endTime => throw UnimplementedError();

  @override
  // ignore: todo
  // TODO: implement finishTime
  DateTime get finishTime => throw UnimplementedError();

  @override
  // ignore: todo
  // TODO: implement resultId
  int get resultId => throw UnimplementedError();

  @override
  // ignore: todo
  // TODO: implement roleTypeId
  int get roleTypeId => throw UnimplementedError();

  @override
  DateTime get smallLeaderSignTime => DateTime.parse(smallLeaderConfirmDate);

  @override
  int get trainingTypeId => trainingTypeIdFk;

  @override
  int get workerId => creatorIdFk;

  // static List<DocumentsModel> data =
  //     Api.getDocuments({}) as List<DocumentsModel>;
}

class DepartmentType {
  int id;
  String name;

  DepartmentType({this.id, this.name});

  DepartmentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class DocStatus {
  int id;
  String name;

  DocStatus({this.id, this.name});

  DocStatus.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class DocTrainingType {
  int id;
  String name;

  DocTrainingType({this.id, this.name});

  DocTrainingType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class DocType {
  int id;
  String name;

  DocType({this.id, this.name});

  DocType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class Creator {
  int id;
  String name;
  CreatorDepartment creatorDepartment;
  Creator({this.id, this.name, this.creatorDepartment});

  Creator.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['username'];
    creatorDepartment = json['department'] != null
        ? new CreatorDepartment.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.name;
    return data;
  }
}

class CreatorDepartment {
  String name;

  CreatorDepartment({
    this.name,
  });

  CreatorDepartment.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();

    data['name'] = this.name;

    return data;
  }
}

class DocumentFiles {
  int id;
  String name;
  String path;

  DocumentFiles({this.id, this.name, this.path});

  DocumentFiles.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    path = json['path'];
    print("json path >>> $path");
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['path'] = this.path;
    return data;
  }
}

class DocumentTests {
  List<String> totalAnswers;
  List<String> rightAnswers;
  int id;
  String question;
  int taskIdFk;
  int documentTestIdFk;

  DocumentTests(
      {this.totalAnswers,
      this.rightAnswers,
      this.id,
      this.question,
      this.documentTestIdFk,
      this.taskIdFk});

  DocumentTests.fromJson(Map<String, dynamic> json) {
    totalAnswers = json['total_answers'].cast<String>();
    rightAnswers = json['right_answers'].cast<String>();
    id = json['id'];
    question = json['question'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['total_answers'] = this.totalAnswers;
    data['right_answers'] = this.rightAnswers;
    data['id'] = this.id;
    data['question'] = this.question;
    return data;
  }
}
