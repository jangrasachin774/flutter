import 'model_documents.dart';

class DocVersionsModel {
  int documentId;
  String identifier;
  String description;
  String version;
  String title;
  int viewIdFk;
  List<DocumentFiles> documentFiles;
  List<DocumentTests> documentTests;
  List<int> otherDocIds = [];

  DocVersionsModel({
    this.documentId,
    this.identifier,
    this.version,
    this.description,
    this.title,
    this.viewIdFk,
  });

  DocVersionsModel.fromJson(Map<String, dynamic> json) {
    documentId = json['id'];
    identifier = json['identifier'];
    viewIdFk = json['view_id_fk'];
    version = json['version'];
    description = json['description'];
    final Iterable refactorDocuments = json['document_files'] ?? [];

    final documentsLists = refactorDocuments.map((item) {
      return DocumentFiles.fromJson(item);
    }).toList();
    documentFiles = documentsLists;
    final Iterable refactorDocumentTests = json['document_tests'] ?? [];
    final documentTestss = refactorDocumentTests.map((item) {
      return DocumentTests.fromJson(item);
    }).toList();
    documentTests = documentTestss;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.documentId;
    data['title'] = this.title;
    data['view_id_fk'] = this.viewIdFk;
    return data;
  }
}
