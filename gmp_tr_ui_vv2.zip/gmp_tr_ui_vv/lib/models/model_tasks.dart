import 'package:equatable/equatable.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filterable.dart';

import 'model_documents.dart';
import 'model_task_tests.dart';

// ignore: must_be_immutable
class Task extends Equatable implements Filterable {
  int id;
  String title;
  bool isReadonly;
  String description;
  String identifier;
  int viewTypeIdFk;
  int trainingTypeIdFk;
  int documentTypeIdFk;
  int departmentIdFk;
  int creatorIdFk;
  int smallLeaderIdFk;
  int bigLeaderIdFk;
  int taskStatusIdFk;
  bool beginOnSign;
  String startDate;
  String endDate;
  String smallLeaderConfirmDate;
  String bigLeaderConfirmDate;
  String creatorConfirmDate;
  String createdAt;
  String updatedAt;
  bool isSuccess;
  TaskDept dept;
  TaskCreator taskCreator;
  DocTrainingType taskTrainingType;
  TaskDocumentType taskDocumentType;
  // List<DocumentFiles> taskDocumentFiles;
  List<TaskDocuments> taskDocuments;
  // List<TaskTestModel> taskDocumentTests;
  List<TaskStudents> taskStudents;
  int taskStatusId;
  SmallLeaders smallLeader;
  BigLeader bigLeader;

  TaskStatus taskStatus;

  bool selected = false;

  Task({
    this.id,
    this.title,
    this.isReadonly,
    this.description,
    this.identifier,
    this.viewTypeIdFk,
    this.trainingTypeIdFk,
    this.documentTypeIdFk,
    this.departmentIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.bigLeaderIdFk,
    this.taskStatusIdFk,
    this.beginOnSign,
    this.startDate,
    this.endDate,
    this.smallLeaderConfirmDate,
    this.bigLeaderConfirmDate,
    this.creatorConfirmDate,
    this.createdAt,
    this.updatedAt,
    this.isSuccess,
    this.dept,
    this.taskCreator,
    this.taskDocumentType,
    this.taskTrainingType,
    this.taskDocuments,
    this.taskStudents,
    this.taskStatusId,
    // this.taskDocumentTests,
    this.smallLeader,
    this.bigLeader,
    this.taskStatus,
    this.selected,
  });

  factory Task.fromJson(Map<String, dynamic> json) {
    try {
      final Iterable refactorTaskDocument = json['task_documents'] ?? [];
      final taskDocumentss = refactorTaskDocument.map((item) {
        return TaskDocuments.fromJson(item);
      }).toList();
      final Iterable refactorTaskStudents = json['task_students'] ?? [];
      final taskStudentss = refactorTaskStudents.map((item) {
        return TaskStudents.fromJson(item);
      }).toList();
      return Task(
        id: json['id'],
        identifier: json['identifier'],
        title: json['title'],
        isReadonly: json['read_only'],
        viewTypeIdFk: json['view_id_fk'],
        description: json['description'],
        trainingTypeIdFk: json['training_type_id_fk'],
        documentTypeIdFk: json['document_type_id_fk'],
        departmentIdFk: json['department_id_fk'],
        creatorIdFk: json['creator_id_fk'],
        smallLeaderIdFk: json['small_leader_id_fk'],
        bigLeaderIdFk: json['big_leader_id_fk'],
        taskStatusIdFk: json['task_status_id_fk'],
        beginOnSign: json['begin_on_sign'],
        startDate: json['start_date'],
        endDate: json['end_date'],
        smallLeaderConfirmDate: json['small_leader_confirm_date'],
        bigLeaderConfirmDate: json['big_leader_confirm_date'],
        creatorConfirmDate: json['creator_confirm_date'],
        createdAt: json['createdAt'],
        updatedAt: json['updatedAt'],
        isSuccess: json['error'] != null ? false : true,
        dept: json['department'] != null
            ? new TaskDept.fromJson(json['department'])
            : null,
        taskCreator: json['creators'] != null
            ? new TaskCreator.fromJson(json['creators'])
            : null,
        taskTrainingType: json['training_type'] != null
            ? new DocTrainingType.fromJson(json['training_type'])
            : null,
        taskDocumentType: json['document_type'] != null
            ? new TaskDocumentType.fromJson(json['document_type'])
            : null,
        taskDocuments: taskDocumentss,
        taskStatus: json['task_status'] != null
            ? new TaskStatus.fromJson(json['task_status'])
            : null,
        taskStudents: taskStudentss,
        taskStatusId: json["task_status_id_fk"],
        smallLeader: json['small_leaders'] != null
            ? new SmallLeaders.fromJson(json['small_leaders'])
            : null,
        bigLeader: json['big_leaders'] != null
            ? new BigLeader.fromJson(json['big_leaders'])
            : null,
      );
    } catch (e) {
      return null;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> json = new Map<String, dynamic>();
    json['id'] = id;
    json['title'] = title;
    json['description'] = description;
    json['view_id_fk'] = viewTypeIdFk;
    json['identifier'] = identifier ?? "";
    json['training_type_id_fk'] = trainingTypeIdFk;
    json['document_type_id_fk'] = documentTypeIdFk;
    json['department_id_fk'] = departmentIdFk;
    json['creator_id_fk'] = creatorIdFk;
    json['small_leader_id_fk'] = smallLeaderIdFk;
    json['big_leader_id_fk'] = bigLeaderIdFk;
    json['task_status_id_fk'] = taskStatusIdFk;
    json['begin_on_sign'] = beginOnSign ?? false;
    json['start_date'] = startDate ?? "";
    json['end_date'] = endDate ?? "";
    json['small_leader_confirm_date'] = smallLeaderConfirmDate ?? "";
    json['big_leader_confirm_date'] = bigLeaderConfirmDate ?? "";
    json['creator_confirm_date'] = creatorConfirmDate ?? "";
    json['createdAt'] = createdAt ?? "";
    json['updatedAt'] = updatedAt ?? "";
    if (this.dept != null) {
      json['department'] = this.dept.toJson();
    }
    if (this.taskCreator != null) {
      json['creators'] = this.taskCreator.toJson();
    }
    json['task_status_id_fk'] = this.taskStatusId;
    return json;
  }

  Task.create({
    this.isReadonly,
    this.viewTypeIdFk,
    this.departmentIdFk,
    this.title,
    this.description,
    this.trainingTypeIdFk,
    this.documentTypeIdFk,
    this.creatorIdFk,
    this.smallLeaderIdFk,
    this.startDate,
    this.endDate,
    this.taskStatusIdFk,
  });

  @override
  DateTime get bigLeaderSignTime => DateTime.parse(bigLeaderConfirmDate);

  @override
  DateTime get creatorSignTime => DateTime.parse(creatorConfirmDate);

  @override
  // ignore: todo
  // TODO: implement departmentId
  int get departmentId => throw UnimplementedError();

  @override
  int get documentFeatureId => documentTypeIdFk;

  @override
  DateTime get endTime => DateTime.parse(endDate);

  @override
  // ignore: todo
  // TODO: implement finishTime
  DateTime get finishTime => throw UnimplementedError();

  @override
  // ignore: todo
  // TODO: implement resultId
  int get resultId => throw UnimplementedError();

  @override
  // ignore: todo
  // TODO: implement roleTypeId
  int get roleTypeId => throw UnimplementedError();

  @override
  DateTime get smallLeaderSignTime => DateTime.parse(smallLeaderConfirmDate);

  @override
  int get trainingTypeId => trainingTypeIdFk;

  @override
  int get workerId => creatorIdFk;

  List<Object> get props => [
        isReadonly,
        id,
        title,
        description,
        identifier,
        trainingTypeIdFk,
        documentTypeIdFk,
        departmentIdFk,
        creatorIdFk,
        smallLeaderIdFk,
        bigLeaderIdFk,
        taskStatusIdFk,
        beginOnSign,
        startDate,
        endDate,
        smallLeaderConfirmDate,
        bigLeaderConfirmDate,
        creatorConfirmDate,
        createdAt,
        updatedAt,
        dept,
        taskCreator,
        taskStudents,
      ];
}

class TaskDocuments {
  int id;
  Document document;

  TaskDocuments({this.id, this.document});

  TaskDocuments.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    document = json['document'] != null
        ? new Document.fromJson(json['document'])
        : null;
    print("json documents >>>> $document");
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.document != null) {
      data['document'] = this.document.toJson();
    }
    return data;
  }
}

class Document {
  String title;
  String identifier;
  int id;
  String description;
  String version;
  List<DocumentFiles> documentFiles;
  List<DocumentTests> documentTests;

  Document(
      {this.title,
      this.identifier,
      this.id,
      this.description,
      this.version,
      this.documentFiles,
      this.documentTests});

  Document.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    identifier = json['identifier'];
    id = json['id'];
    description = json['description'];
    version = json['version'];
    final Iterable refactorDocuments = json['document_files'] ?? [];
    final taskDocumentsLists = refactorDocuments.map((item) {
      return DocumentFiles.fromJson(item);
    }).toList();

    documentFiles = taskDocumentsLists;
    print("json documentFiles >>>> $documentFiles");

    final Iterable refactorDocumentTests = json['document_tests'] ?? [];
    final taskDocumentTestss = refactorDocumentTests.map((item) {
      return DocumentTests.fromJson(item);
    }).toList();
    documentTests = taskDocumentTestss;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['identifier'] = this.identifier;
    data['id'] = this.id;
    data['description'] = this.description;
    data['version'] = this.version;
    if (this.documentFiles != null) {
      data['document_files'] =
          this.documentFiles.map((v) => v.toJson()).toList();
    }
    if (this.documentTests != null) {
      data['document_tests'] =
          this.documentTests.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

// class DocumentFiles {
//   int id;
//   String identifier;
//   String name;
//   String path;

//   DocumentFiles({this.id, this.identifier, this.name, this.path});

//   DocumentFiles.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     identifier = json['identifier'];
//     name = json['name'];
//     path = json['path'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['identifier'] = this.identifier;
//     data['name'] = this.name;
//     data['path'] = this.path;
//     return data;
//   }
// }

class TaskDept {
  int id;
  String name;

  TaskDept({this.id, this.name});

  TaskDept.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class SmallLeaders {
  int id;
  String username;
  LeadersDep department;

  SmallLeaders({
    this.id,
    this.username,
    this.department,
  });

  SmallLeaders.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];

    department = json['department'] != null
        ? new LeadersDep.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    return data;
  }
}

class BigLeader {
  int id;
  String username;
  LeadersDep department;

  BigLeader({
    this.id,
    this.username,
    this.department,
  });

  BigLeader.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];

    department = json['department'] != null
        ? new LeadersDep.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    return data;
  }
}

class LeadersDep {
  String name;

  LeadersDep({this.name});

  LeadersDep.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();

    data['name'] = this.name;
    return data;
  }
}

class TaskTrainingType {
  int id;
  String name;

  TaskTrainingType({this.id, this.name});

  TaskTrainingType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class TaskStatus {
  int id;
  String name;
  String statusIcons;

  TaskStatus({this.id, this.name, this.statusIcons, taskStatusid});

  TaskStatus.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

List<TaskStatus> icons = [
  TaskStatus(statusIcons: CustomIcon.begin),
  TaskStatus(statusIcons: CustomIcon.bigLeaderConfirmed),
  TaskStatus(statusIcons: CustomIcon.bigLeaderSentBack),
  TaskStatus(statusIcons: CustomIcon.created),
  TaskStatus(statusIcons: CustomIcon.creatorCancelled),
  TaskStatus(statusIcons: CustomIcon.creatorConfirmed),
  TaskStatus(statusIcons: CustomIcon.expired),
  TaskStatus(statusIcons: CustomIcon.finished),
  TaskStatus(statusIcons: CustomIcon.smallLeaderConfirmed),
  TaskStatus(statusIcons: CustomIcon.smallLeaderSentBack),
];

class TaskDocumentType {
  int id;
  String name;

  TaskDocumentType({this.id, this.name});

  TaskDocumentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class TaskStudents {
  int id;
  int studentIdFk;
  int result;
  String startDate;
  String endDate;
  String finishedDate;
  TaskUser taskUser;

  TaskStudents({
    this.id,
    this.studentIdFk,
    this.taskUser,
    this.result,
    this.startDate,
    this.endDate,
    this.finishedDate,
  });

  TaskStudents.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    studentIdFk = json['student_id_fk'];
    result = json['result'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    finishedDate = json['finished_date'];
    taskUser =
        json['user'] != null ? new TaskUser.fromJson(json['user']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['student_id_fk'] = this.studentIdFk;
    data['result'] = this.result;
    return data;
  }
}

class TaskUser {
  String username;
  TaskCreatorDept department;

  TaskUser({
    this.username,
    this.department,
  });
  TaskUser.fromJson(Map<String, dynamic> json) {
    username = json['username'];
    department = json['department'] != null
        ? new TaskCreatorDept.fromJson(json['department'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['username'] = this.username;
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    return data;
  }
}

class TaskCreator {
  int id;
  String name;
  TaskCreatorDept department;

  TaskCreator({this.id, this.name, this.department});

  TaskCreator.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['username'];
    department = json['department'] != null
        ? new TaskCreatorDept.fromJson(json['department'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.name;
    if (this.department != null) {
      data['creators'] = this.department.toJson();
    }
    return data;
  }
}

class TaskCreatorDept {
  String name;

  TaskCreatorDept({
    this.name,
  });

  TaskCreatorDept.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();

    data['name'] = this.name;
    return data;
  }
}

// class DocumentFiles {
//   int id;
//   String name;
//   String path;

//   DocumentFiles({this.id, this.name, this.path});

//   DocumentFiles.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     name = json['name'];
//     path = json['path'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['name'] = this.name;
//     data['path'] = this.path;
//     return data;
//   }
// }

// class TaskDocumentTests {
//   List<String> totalAnswers;
//   List<String> rightAnswers;
//   int id;
//   String question;

//   TaskDocumentTests({this.totalAnswers, this.rightAnswers, this.id, this.question});

//   TaskDocumentTests.fromJson(Map<String, dynamic> json) {
//     totalAnswers = json['total_answers'].cast<String>();
//     rightAnswers = json['right_answers'].cast<String>();
//     id = json['id'];
//     question = json['question'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['total_answers'] = this.totalAnswers;
//     data['right_answers'] = this.rightAnswers;
//     data['id'] = this.id;
//     data['question'] = this.question;
//     return data;
//   }
// }

enum TaskType { RegularTask, ReadOnlyTask }
