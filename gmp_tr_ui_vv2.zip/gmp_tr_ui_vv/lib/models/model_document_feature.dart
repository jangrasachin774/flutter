class DocumentsFeature {
  int id;
  String identifier;
  String name;
  int parentDocumentFeatureIdFk;
  int level;
  int status;
  String createdAt;
  String updatedAt;
  bool isHovered = false;

  DocumentsFeature({
    this.id,
    this.identifier,
    this.name,
    this.parentDocumentFeatureIdFk,
    this.level,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.isHovered,
  });

  DocumentsFeature.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    parentDocumentFeatureIdFk = json['parent_document_type_id_fk'];
    level = json['level'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['parent_document_type_id_fk'] = this.parentDocumentFeatureIdFk;
    data['level'] = this.level;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }

  String getId() {
    return this.id.toString();
  }

  String getParentId() {
    return this.parentDocumentFeatureIdFk.toString();
  }

  String getTitle() {
    return this.name;
  }

  String getLevel() {
    return this.level.toString();
  }
}
