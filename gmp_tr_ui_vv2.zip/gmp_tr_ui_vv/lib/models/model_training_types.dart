class TrainingsType {
  int id;
  String identifier;
  String name;
  int companyIdFk;
  int parentTrainingTypeIdFk;
  int level;
  int status;
  String createdAt;
  String updatedAt;
  bool isHovered = false;

  TrainingsType({
    this.id,
    this.identifier,
    this.name,
    this.companyIdFk,
    this.parentTrainingTypeIdFk,
    this.level,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.isHovered,
  });

  TrainingsType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    name = json['name'];
    companyIdFk = json['company_id_fk'];
    parentTrainingTypeIdFk = json['parent_training_type_id_fk'];
    level = json['level'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['name'] = this.name;
    data['company_id_fk'] = this.companyIdFk;
    data['parent_training_type_id_fk'] = this.parentTrainingTypeIdFk;
    data['level'] = this.level;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }

  String getId() {
    return this.id.toString();
  }

  String getParentId() {
    return this.parentTrainingTypeIdFk.toString();
  }

  String getTitle() {
    return this.name;
  }
}
