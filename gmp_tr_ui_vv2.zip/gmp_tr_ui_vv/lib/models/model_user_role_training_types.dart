class UserRoleTrainingTypesModel {
  int id;
  int userRoleIdFk;
  int trainingTypeIdFk;
  int status;
  String createdAt;
  String updatedAt;
  TrainingType trainingType;

  UserRoleTrainingTypesModel({this.id, this.userRoleIdFk, this.trainingTypeIdFk, this.status, this.createdAt, this.updatedAt, this.trainingType});

  UserRoleTrainingTypesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userRoleIdFk = json['user_role_id_fk'];
    trainingTypeIdFk = json['training_type_id_fk'];
    status = json['status'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    trainingType = json['training_type'] != null ? new TrainingType.fromJson(json['training_type']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_role_id_fk'] = this.userRoleIdFk;
    data['training_type_id_fk'] = this.trainingTypeIdFk;
    data['status'] = this.status;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.trainingType != null) {
      data['training_type'] = this.trainingType.toJson();
    }
    return data;
  }
}

class TrainingType {
  int id;
  String name;
  int parentTrainingTypeIdFk;
  int level;

  TrainingType({this.id, this.name, this.parentTrainingTypeIdFk, this.level});

  TrainingType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    parentTrainingTypeIdFk = json['parent_training_type_id_fk'];
    level = json['level'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['parent_training_type_id_fk'] = this.parentTrainingTypeIdFk;
    data['level'] = this.level;
    return data;
  }
}
