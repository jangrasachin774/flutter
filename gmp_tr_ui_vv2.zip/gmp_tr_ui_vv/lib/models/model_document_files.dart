import 'dart:io';

class DocumentFilesModel {
  int id;
  String identifier;
  int documentIdFk;
  List<Files> files;

  DocumentFilesModel({this.id, this.identifier, this.documentIdFk, this.files});

  DocumentFilesModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    identifier = json['identifier'];
    documentIdFk = json['document_id_fk'];
    files = json['files'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['identifier'] = this.identifier;
    data['document_id_fk'] = this.documentIdFk;
    data['files'] = this.files;
    return data;
  }
}

class Files {
  String fileName;
  File file;

  Files({this.fileName, this.file});
}
