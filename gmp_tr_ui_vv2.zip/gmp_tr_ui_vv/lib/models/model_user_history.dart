class UserHistoryModel {
  int id;
  int originalId;
  Null identifier;
  String username;
  String password;
  int gender;
  String workNo;
  String contact;
  String email;
  String name;
  String realCompany;
  String realDepartment;
  int companyIdFk;
  int departmentIdFk;
  int userStatusIdFk;
  Null creatorIdFk;
  String type;
  String createdAt;
  String updatedAt;
  UserStatus userStatus;
  UserHisDepartment department;
  Null creator;

  UserHistoryModel(
      {this.id,
      this.originalId,
      this.identifier,
      this.username,
      this.password,
      this.gender,
      this.workNo,
      this.contact,
      this.email,
      this.name,
      this.realCompany,
      this.realDepartment,
      this.companyIdFk,
      this.departmentIdFk,
      this.userStatusIdFk,
      this.creatorIdFk,
      this.type,
      this.createdAt,
      this.updatedAt,
      this.userStatus,
      this.department,
      this.creator});

  UserHistoryModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    originalId = json['original_id'];
    identifier = json['identifier'];
    username = json['username'];
    password = json['password'];
    gender = json['gender'];
    workNo = json['work_no'];
    contact = json['contact'];
    email = json['email'];
    name = json['name'];
    realCompany = json['real_company'];
    realDepartment = json['real_department'];
    companyIdFk = json['company_id_fk'];
    departmentIdFk = json['department_id_fk'];
    userStatusIdFk = json['user_status_id_fk'];
    creatorIdFk = json['creator_id_fk'];
    type = json['type'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    userStatus = json['user_status'] != null
        ? new UserStatus.fromJson(json['user_status'])
        : null;
    department = json['department'] != null
        ? new UserHisDepartment.fromJson(json['department'])
        : null;
    creator = json['creator'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['original_id'] = this.originalId;
    data['identifier'] = this.identifier;
    data['username'] = this.username;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['work_no'] = this.workNo;
    data['contact'] = this.contact;
    data['email'] = this.email;
    data['name'] = this.name;
    data['real_company'] = this.realCompany;
    data['real_department'] = this.realDepartment;
    data['company_id_fk'] = this.companyIdFk;
    data['department_id_fk'] = this.departmentIdFk;
    data['user_status_id_fk'] = this.userStatusIdFk;
    data['creator_id_fk'] = this.creatorIdFk;
    data['type'] = this.type;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    if (this.userStatus != null) {
      data['user_status'] = this.userStatus.toJson();
    }
    if (this.department != null) {
      data['department'] = this.department.toJson();
    }
    data['creator'] = this.creator;
    return data;
  }
}

class UserStatus {
  int id;
  String name;
  String description;

  UserStatus({this.id, this.name, this.description});

  UserStatus.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['description'] = this.description;
    return data;
  }
}

class UserHisDepartment {
  int id;
  String name;

  UserHisDepartment({this.id, this.name});

  UserHisDepartment.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}
