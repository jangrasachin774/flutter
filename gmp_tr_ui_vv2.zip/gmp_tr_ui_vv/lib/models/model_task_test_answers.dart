class TaskTestAnswers {
  int id;
  int testIdFk;
  int studentIdFk;
  List<dynamic> testData;
  bool success;
  String error;
  bool failed;
  int attempts;

  TaskTestAnswers({
    this.id,
    this.studentIdFk,
    this.testData,
    this.testIdFk,
    this.success,
    this.error,
    this.failed,
    this.attempts,
  });

  TaskTestAnswers.fromJson(Map<String, dynamic> json) {
    // id = json['id'];
    // testIdFk = json['task_id_fk'];
    // studentIdFk = json['student_id_fk'];
    // testData = json['test_data'];
    success = json['success'] != null ?? true;
    error = json['error'];
    failed = json['failed'] != null ?? true;
    attempts = json['attempts'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['task_id_fk'] = this.testIdFk;
    data['student_id_fk'] = this.studentIdFk;
    data['test_data'] = this.testData;
    data['success'] = this.success;
    data['failed'] = this.failed;
    data['attempts'] = this.attempts;

    return data;
  }
}
