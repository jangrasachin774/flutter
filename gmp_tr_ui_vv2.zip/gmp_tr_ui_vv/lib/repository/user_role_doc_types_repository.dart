import 'package:gmptr/api/api.dart';

class UserRoleDocTypesRepo {
  /// SAVE USER ROLE DEPARTMENT
  Future<dynamic> saveUserRoleDocType({
    int userRoledIdFk,
    int documentTypeIdFk,
    int status,
  }) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "document_type_id_fk": documentTypeIdFk,
      "status": status
    };
    print("u r d $params");
    return await Api.saveUserRoleDocType(params);
  }

  Future<dynamic> loadUserRoleDoc({int userRoleIdFk}) async {
    final params = {"user_role_id_fk": userRoleIdFk};
    return await Api.loadUserRoleDocs(params);
  }

  Future<dynamic> deleteUserRoleDocType(
      {int userRoledIdFk, int documentTypeIdFk}) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "document_type_id_fk": documentTypeIdFk
    };
    return await Api.deleteUserRoleDocs(params);
  }
}
