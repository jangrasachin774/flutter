import 'package:gmptr/api/api.dart';

class StudentsRepository {
  Future<dynamic> loadStudentsRepository(
      {int departmentIdFk, int roleIdFk}) async {
    final params = {"department_id_fk": departmentIdFk, "role_id_fk": roleIdFk};
    return await Api.loadUsersById(params);
  }
}
