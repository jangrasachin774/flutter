import 'package:gmptr/api/api.dart';

class ViewTypeRepository {
  ///Fetch api loadViewTypeList
  Future<dynamic> loadViewTypes() async {
    return await Api.getViewType();
  }

  Future<dynamic> loadUserRoleViewTypes({int userRoleIdFk}) async {
    final params = {
      "user_id_fk": userRoleIdFk
    };
    return await Api.getUserRoleViewType(params);
  }

  Future<dynamic> saveUserRoleViewType({int userRoledIdFk, int viewIdFk}) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "view_id_fk": viewIdFk,
    };
    print("params $params");
    return await Api.saveUserRoleViewType(params);
  }

  Future<dynamic> deleteUserRoleViewType({int userRoledIdFk, int viewIdFk}) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "view_id_fk": viewIdFk,
    };
    return await Api.deleteUserRoleViewType(params);
  }
}
