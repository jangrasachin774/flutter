import 'package:gmptr/api/api.dart';

class UserRoleDepartmentsRepo {
  /// SAVE USER ROLE DEPARTMENT
  Future<dynamic> saveUserRoleDepartment({
    int userRoledIdFk,
    int departmentIdFk,
    int status,
  }) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "department_id_fk": departmentIdFk,
      "status": status
    };
    print("u r d $params");
    return await Api.saveUserRoleDepartment(params);
  }

  Future<dynamic> deleteUserRoleDepartment({
    int userRoledIdFk,
    int departmentIdFk,
  }) async {
    final params = {
      "user_role_id_fk": userRoledIdFk,
      "department_id_fk": departmentIdFk,
    };
    print("u r d $params");
    return await Api.deleteUserRoleDepartment(params);
  }

  Future<dynamic> loadUserRoleDept({int userRoleIdFk}) async {
    final params = {"user_role_id_fk": userRoleIdFk};
    return await Api.getUserRoleDepartment(params);
  }
}
