import 'dart:convert';

import 'package:gmptr/api/api.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/utils/utils.dart';

class UsersRepository {
  ///Fetch api loadUsersList
  Future<dynamic> loadUsers() async {
    return await Api.getUsers();
  }

  ///Fetch api loadFilteredUsersList
  Future<dynamic> loadFilteredUsers({List<int> departmentIdFk}) async {
    final params = {
      "department_id_fk": departmentIdFk,
    };
    print("department id fk >> $params");
    return await Api.getFilteredUsers(params);
  }

  /// Save  User api
  Future<dynamic> saveUser({
    String name,
    String username,
    String password,
    int gender,
    String workNo,
    String contact,
    String email,
    String realCompany,
    String realDept,
    int status,
    int departmentId,
  }) async {
    final params = {
      "name": name,
      "username": username,
      "password": password,
      "gender": gender,
      "work_no": workNo,
      "contact": contact,
      "email": email,
      "real_company": realCompany,
      "real_department": realDept,
      "company_id_fk": 1,
      "department_id_fk": departmentId,
      "user_status_id_fk": status,
    };
    print(params);
    return await Api.saveUser(params);
  }

  /// Update  User api
  Future<dynamic> updateUser({
    int id,
    String name,
    String username,
    String password,
    int gender,
    String workNo,
    String contact,
    String email,
    String realCompany,
    String realDept,
    int status,
    int departmentId,
  }) async {
    final params = {
      "id": id,
      "name": name,
      "username": username,
      "password": password,
      "gender": gender,
      "work_no": workNo,
      "contact": contact,
      "email": email,
      "real_company": realCompany,
      "real_department": realDept,
      "company_id_fk": 1,
      "department_id_fk": departmentId,
      "user_status_id_fk": status,
    };
    print(params);
    return await Api.updateUser(params);
  }

  Future<dynamic> userHistory({int userId}) async {
    final params = {"user_id_fk": userId};
    return await Api.userHistory(params);
  }

  ///Save User id Storage
  Future<dynamic> saveUserId(int userId) async {
    Application.userId = userId;
    return await UtilPreferences.setString(
      Preferences.userId,
      jsonEncode(
        userId,
      ),
    );
  }

  ///Get from Storage
  dynamic getUserId() {
    return UtilPreferences.getString(Preferences.userId);
  }

  ///Delete User Id
  Future<dynamic> deleteUserId() async {
    Application.userId = null;

    ///Delete Storage
    return await UtilPreferences.remove(Preferences.userId);
  }

  Future<dynamic> changeStatus(
      {int userId, int userStatusIdFk, String reasonForDisable}) async {
    var params;
    if (reasonForDisable == null) {
      params = {"id": userId, "user_status_id_fk": userStatusIdFk};
    } else {
      params = {
        "id": userId,
        "description": reasonForDisable,
        "user_status_id_fk": userStatusIdFk
      };
    }
    return await Api.changeStatus(params);
  }
}
