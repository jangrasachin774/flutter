import 'package:gmptr/api/api.dart';

class TrainingsTypeRepository {
  ///Fetch api loadTrainingTypeList
  Future<dynamic> loadTrainingsType() async {
    return await Api.getTrainingsType();
  }

  /// Save api TrainingType
  Future<dynamic> saveTrainingType({
    int parentId,
    String name,
    int companyIdFk,
    int level,
    int status,
  }) async {
    final params = {
      "parent_training_type_id_fk": parentId,
      "name": name,
      "company_id_fk": companyIdFk,
      "level": level,
      "status": status
    };
    print("training $params");
    return await Api.saveTrainingType(params);
  }

  /// UPDATE api TrainingType
  Future<dynamic> updateTrainingType({
    int id,
    String name,
  }) async {
    final params = {
      "id": id,
      "name": name,
    };
    print("training $params");
    return await Api.updateTrainingType(params);
  }

  /// Delete api TrainingType
  Future<dynamic> deleteTrainingType({
    int id,
  }) async {
    final params = {
      "id": id,
    };
    print("training $params");
    return await Api.deleteTrainingType(params);
  }
}
