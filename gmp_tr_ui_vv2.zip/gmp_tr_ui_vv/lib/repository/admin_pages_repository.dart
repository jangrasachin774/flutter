import 'package:gmptr/api/api.dart';

class AdminPagesRepository {
  ///Fetch api loadTrainingTypeList
  Future<dynamic> loadAdminPages() async {
    return await Api.getAdminPages();
  }
}
