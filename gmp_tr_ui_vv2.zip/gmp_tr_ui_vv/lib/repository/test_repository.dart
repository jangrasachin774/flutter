import 'package:gmptr/api/api.dart';

class TestsRepository {
  Future<dynamic> saveTestRepository(
      {int testIdFk, int studentIdFk, List<dynamic> selectedAnswers}) async {
    final params = {
      "task_id_fk": testIdFk,
      "student_id_fk": studentIdFk,
      "test_data": selectedAnswers,
    };
    print(params);
    return await Api.saveTest(params);
  }
}
