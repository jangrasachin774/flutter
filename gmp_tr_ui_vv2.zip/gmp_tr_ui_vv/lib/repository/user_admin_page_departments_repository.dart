import 'package:gmptr/api/api.dart';

class UserAdminPageDepartmentsRepository {
  ///LOADING USER ADMIN PAGE DEPARTMENTS
  Future<dynamic> loadAdminPageDepartments() async {
    // return await Api.loadUserAdminPagesDept();
  }

  ///Create User Admin Page Department
  Future<dynamic> saveUserAdminPageDepartments(
      {int departmentId, int useradminPageId}) async {
    final params = {
      "department_id_fk": departmentId,
      "user_admin_page_id_fk": useradminPageId,
      "status": 1
    };
    print("anish User Admin Page Department---- $params");
    return await Api.saveUserAdminPageDepartments(params);
  }

  ///Delete User Admin Page Department
  Future<dynamic> deleteUserAdminPageDepartments(
      {int id, int departmentId, int useradminPageId}) async {
    final params = {
      "department_id_fk": departmentId,
      "user_admin_page_id_fk": useradminPageId
    };
    print("anish user admin dept repo $params");
    return await Api.deleteUserAdminPageDepartments(params);
  }

  Future<dynamic> deleteUserAdminPageDepartmentsById({int id}) async {
    final params = {
      "id": id,
    };
    print("anish ----$params");
    return await Api.deleteUserAdminPageDepartments(params);
  }
}
