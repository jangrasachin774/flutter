import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_document.dart';
import 'package:gmptr/models/model_document_tests.dart';
import 'package:uuid/uuid.dart';

import 'http_manager.dart';

class Api {
  static const String AUTH_LOGIN = "/users/login";
  static const String USERS_LIST = "/users/readAll";
  static const String SAVE_USER = "/users/create";
  static const String UPDATE_USER = "/users/update";

  static const String USER_ROLES_LIST = "/user_roles/readAll";

  static const String USER_ROLES = "/user_roles/create";
  static const String DELETE_USER_ROLE = "/user_roles/delete";

  static const String DEPARTMENTS_LIST = "/departments/readAll";
  static const String SAVE_DEPARTMENT = "/departments/create";
  static const String DELETE_DEPARTMENT = "/departments/delete";
  static const String UPDATE_DEPARTMENT = "/departments/update";

  static const String DOCUMENT_FEATURE_LIST = "/document_types/readAll";
  static const String SAVE_DOCUMENT_FEATURE = "/document_types/create";
  static const String DELETE_DOCUMENT_FEATURE = "/document_types/delete";
  static const String UPDATE_DOCUMENT_FEATURE = "/document_types/update";

  static const String TRAININGS_TYPE_LIST = "/training_types/readAll";
  static const String SAVE_TRAINING_TYPE = "/training_types/create";
  static const String DELETE_TRAINING_TYPE = "/training_types/delete";
  static const String UPDATE_TRAINING_TYPE = "/training_types/update";

  static const String ROLES_LIST = "/role_types/readAll";

  static const String SAVE_USER_ROLE_DEPARTMENTS = "/user_role_departments/create";
  static const String DELETE_USER_ROLE_DEPARTMENTS = "/user_role_departments/delete";
  static const String USER_ROLE_DEPARTMENTS_LIST = "/user_role_departments/readAll";

  static const String USER_ROLE_DOCUMENT_TYPES_LIST = "/user_role_document_types/readAll";
  static const String SAVE_USER_ROLE_DOC_TYPES = "/user_role_document_types/create";
  static const String DELETE_USER_ROLE_DOCUMENT_TYPE = "/user_role_document_types/delete";

  static const String SAVE_USER_ADMIN_PAGES = "/user_admin_pages/create";
  static const String DELETE_USER_ADMIN_PAGES = "/user_admin_pages/delete";

  static const String USER_ADMIN_PAGE_DEPARTMENTS_LIST = "/user_admin_pages/readAll";
  static const String SAVE_USER_ADMIN_PAGE_DEPARTMENTS = "/user_admin_page_departments/create";
  static const String DELETE_USER_ADMIN_PAGE_DEPARTMENTS = "/user_admin_page_departments/delete";

  static const String ADMIN_PAGES_LIST = "/admin_pages/readAll";

  static const String SAVE_USER_ROLE_TRAINING_TYPE = "/user_role_training_types/create";
  static const String USER_ROLE_TRAINING_TYPES_LIST = "/user_role_training_types/readAll";
  static const String DELETE_USER_ROLE_TRAINING_TYPE = "/user_role_training_types/delete";

  static const String TASK_LIST = "/tasks/readAll";
  static const String SAVE_TASK = "/tasks/create";
  static const String SAVE_TASK_DOCUMENTS = "/task_document_files/create";

  static const String SAVE_DOCUMENTS = "/documents/create";
  static const String UPDATE_DOCUMENTS = "/documents/update";

  static const String GET_DEPARTMENT_USERS = "/users/readDepartmentUsers";

  static const String SAVE_DOCUMENT_FILE = "/files/uploadDocuments";
  static const String UPLOAD_DOCUMENT_FILES = "/files/uploadDocuments";
  static const String CREATE_DOCUMENT_TEST = "/document_tests/create";
  static const String UPDATE_DOCUMENT_TEST = "/document_tests/update";
  static const String DELETE_TEST_QUESTION = "/document_tests/delete";

  static const String LOAD_DOCUMENTS = "/documents/readAll";
  // static const String LOAD_DOCUMENTS = "/documents/readTitles";
  static const String UPDATE_DOCUMENT_STATUS = "/documents/update";

  static const String USER_HISTORY = "/audit_users/readAll";

  static const String SAVE_TASK_DOCUMENT_TEST = "/task_document_tests/create";

  static const String UPLOAD_TASK_DOCUMENT_FILES = "/files/uploadTaskDocuments";
  static const String DELETE_DOC_FILE = "/document_files/delete";

  static const String SAVE_TASK_TO_USER = "/task_students/create";
  static const String DELETE_TASK_USER = "/task_students/delete";
  static const String UPDATE_TASK_TO_USER = "/task_students/update";

  static const String UPDATE_DOCUMENT = "/documents/update";

  static const String UPDATE_TASK = "/tasks/update";

  static const String UPDATE_TASK_DOCUMENT_TEST = "/task_document_tests/update";
  static const String DELETE_TASK_TEST_QUESTION = "/task_document_tests/delete";
  static const String DELETE_TASK_DOC_FILE = "/task_document_files/delete";
  static const String TASK_TEST = "/task_test_answers/create";
  static const String APPLY_LEAVE = "/user_leaves/create";
  static const String GET_LEAVES_LIST = "/user_leaves/readall";
  static const String UPDATE_LEAVE = "/user_leaves/update";
  static const String CHANGE_PASS = "/users/resetPassword";
  static const String VIEW_TYPES = '/views/readAll';
  static const String USER_ROLE_VIEW_TYPES_LIST = '/user_role_views/readAll';
  static const String SAVE_USER_ROLE_VIEW_TYPES = '/user_role_views/create';
  static const String DELETE_USER_ROLE_VIEW_TYPES = '/user_role_views/delete';
  static const String READ_VERSIONS = '/documents/readVersions';
  static const String READ_TITLES = "/documents/readTitles";

  ///Login api
  static Future<dynamic> login(params) async {
    final result = await httpManager.post(url: AUTH_LOGIN, data: params);
    return ResultApiModel.fromJson(result);
  }

  /// GET ALL USERS LIST
  static Future<dynamic> getUsers() async {
    List<UsersModel> users = [];
    final result = await httpManager.get(url: USERS_LIST);
    users = (result as List).map((i) => UsersModel.fromJson(i)).toList();
    return users;
  }

  /// GET FILTERED USERS LIST
  static Future<dynamic> getFilteredUsers(params) async {
    List<UsersModel> users = [];
    final result = await httpManager.post(url: USERS_LIST, data: params);
    users = (result as List).map((i) => UsersModel.fromJson(i)).toList();
    return users;
  }

  /// SAVE USER
  static Future<dynamic> saveUser(params) async {
    final result = await httpManager.post(url: SAVE_USER, data: params);

    return UsersModel.fromJson(result);
  }

  /// UPDATE USER
  static Future<dynamic> updateUser(params) async {
    final result = await httpManager.post(url: UPDATE_USER, data: params);

    return UsersModel.fromJson(result);
  }

  ///GET USER ROLES
  static Future<dynamic> getUserRoles(params) async {
    List<UserRolesModel> userRoles = [];
    final result = await httpManager.post(url: USER_ROLES_LIST, data: params);
    userRoles = (result as List).map((i) => UserRolesModel.fromJson(i)).toList();

    return userRoles;
  }

  /// CREATE USER ROLE
  static Future<dynamic> createUserRole(params) async {
    final result = await httpManager.post(url: USER_ROLES, data: params);

    return UserRolesModel.fromJson(result);
  }

  /// DELETE USER ROLE
  static Future<dynamic> deleteUserRole(params) async {
    final result = await httpManager.post(url: DELETE_USER_ROLE, data: params);

    return UserRolesModel.fromJson(result);
  }

  /// GET ALL DEPARTMENTS
  static Future<dynamic> getDepartments() async {
    List<Departments> departments = [];
    final result = await httpManager.post(
      url: DEPARTMENTS_LIST,
    );
    departments = (result as List).map((i) => Departments.fromJson(i)).toList();
    return departments;
  }

  ///SAVE DEPARTMENT
  static Future<dynamic> saveDepartment(params) async {
    final result = await httpManager.post(url: SAVE_DEPARTMENT, data: params);

    return Departments.fromJson(result);
  }

  ///UPDATE DEPARTMENT
  static Future<dynamic> updateDepartment(params) async {
    final result = await httpManager.post(url: UPDATE_DEPARTMENT, data: params);

    return Departments.fromJson(result);
  }

  /// DELETE DEPARTMENT
  static Future<dynamic> deleteDepartment(params) async {
    final result = await httpManager.post(url: DELETE_DEPARTMENT, data: params);

    return Departments.fromJson(result);
  }

  /// GET ALL DOCUMENT FEATURE
  static Future<dynamic> getDocumentsFeature() async {
    List<DocumentsFeature> departments = [];
    final result = await httpManager.post(
      url: DOCUMENT_FEATURE_LIST,
    );
    departments = (result as List).map((i) => DocumentsFeature.fromJson(i)).toList();
    return departments;
  }

  ///SAVE DOCUMENT FEATURE
  static Future<dynamic> saveDocumentFeature(params) async {
    final result = await httpManager.post(url: SAVE_DOCUMENT_FEATURE, data: params);

    return DocumentsFeature.fromJson(result);
  }

  ///UPDATE DOCUMENT FEATURE
  static Future<dynamic> updateDocumentFeature(params) async {
    final result = await httpManager.post(url: UPDATE_DOCUMENT_FEATURE, data: params);

    return Departments.fromJson(result);
  }

  /// DELETE DOCUMENT FEATURE
  static Future<dynamic> deleteDocumentFeature(params) async {
    final result = await httpManager.post(url: DELETE_DOCUMENT_FEATURE, data: params);

    return Departments.fromJson(result);
  }

  /// GET ALL DOCUMENT FEATURE
  static Future<dynamic> getTrainingsType() async {
    List<TrainingsType> trainingstype = [];
    final result = await httpManager.post(
      url: TRAININGS_TYPE_LIST,
    );
    trainingstype = (result as List).map((i) => TrainingsType.fromJson(i)).toList();
    return trainingstype;
  }

  ///SAVE DOCUMENT FEATURE
  static Future<dynamic> saveTrainingType(params) async {
    final result = await httpManager.post(url: SAVE_TRAINING_TYPE, data: params);

    return TrainingsType.fromJson(result);
  }

  ///UPDATE DOCUMENT FEATURE
  static Future<dynamic> updateTrainingType(params) async {
    final result = await httpManager.post(url: UPDATE_TRAINING_TYPE, data: params);

    return TrainingsType.fromJson(result);
  }

  /// DELETE DOCUMENT FEATURE
  static Future<dynamic> deleteTrainingType(params) async {
    final result = await httpManager.post(url: DELETE_TRAINING_TYPE, data: params);

    return TrainingsType.fromJson(result);
  }

  /// GET ROLES
  static Future<dynamic> getRoles() async {
    List<RoleTypes> roles = [];
    final result = await httpManager.post(
      url: ROLES_LIST,
    );
    roles = (result as List).map((i) => RoleTypes.fromJson(i)).toList();
    return roles;
  }

  ///GET ADMIN PAGES
  static Future<dynamic> getAdminPages() async {
    List<AdminPagesModel> adminPages = [];
    final result = await httpManager.post(
      url: ADMIN_PAGES_LIST,
    );
    adminPages = (result as List).map((i) => AdminPagesModel.fromJson(i)).toList();
    return adminPages;
  }

  /// SAVE USER ROLE DEPARTMENTS
  static Future<dynamic> saveUserRoleDepartment(params) async {
    final result = await httpManager.post(url: SAVE_USER_ROLE_DEPARTMENTS, data: params);

    return UserRoleDepartmentsModel.fromJson(result);
  }

  /// DELETE USER ROLE DEPARTMENTS
  static Future<dynamic> deleteUserRoleDepartment(params) async {
    final result = await httpManager.post(url: DELETE_USER_ROLE_DEPARTMENTS, data: params);

    return UserRoleDepartmentsModel.fromJson(result);
  }

  /// SAVE USER ROLE DEPARTMENTS
  static Future<dynamic> saveUserRoleDocType(params) async {
    final result = await httpManager.post(url: SAVE_USER_ROLE_DOC_TYPES, data: params);

    return UserRoleDepartmentsModel.fromJson(result);
  }

  /// GET USER ROLE DEPARTMENTS
  static Future<dynamic> getUserRoleDepartment(params) async {
    List<UserRoleDepartmentsModel> userRoleDepartments = [];
    final result = await httpManager.post(url: USER_ROLE_DEPARTMENTS_LIST, data: params);
    userRoleDepartments = (result as List).map((i) => UserRoleDepartmentsModel.fromJson(i)).toList();

    return userRoleDepartments;
  }

  /// SAVE USER ADMIN PAGES
  static Future<dynamic> saveUserAdminPages(params) async {
    final result = await httpManager.post(url: SAVE_USER_ADMIN_PAGES, data: params);

    return UserAdminPageModel.fromJson(result);
  }

  /// DELETE USER ADMIN PAGES
  static Future<dynamic> deleteUserAdminPage(params) async {
    final result = await httpManager.post(url: DELETE_USER_ADMIN_PAGES, data: params);

    return UserAdminPageModel.fromJson(result);
  }

  /// SAVE USER ADMIN PAGE DEPARTMENTS
  static Future<dynamic> saveUserAdminPageDepartments(params) async {
    final result = await httpManager.post(url: SAVE_USER_ADMIN_PAGE_DEPARTMENTS, data: params);

    return UserAdminPageDepartmentsModel.fromJson(result);
  }

  /// DELETE USER ADMIN PAGE DEPARTMENTS
  static Future<dynamic> deleteUserAdminPageDepartments(params) async {
    final result = await httpManager.post(url: DELETE_USER_ADMIN_PAGE_DEPARTMENTS, data: params);

    return UserAdminPageDepartmentsModel.fromJson(result);
  }

  /// GET USER ADMIN PAGES WITH DEPARTMENTS
  static Future<dynamic> loadUserAdminPagesDept(params) async {
    List<UserAdminPageWithDeptModel> userAdminPageDepartments = [];
    final result = await httpManager.post(url: USER_ADMIN_PAGE_DEPARTMENTS_LIST, data: params);
    userAdminPageDepartments = (result as List).map((i) => UserAdminPageWithDeptModel.fromJson(i)).toList();
    return userAdminPageDepartments;
  }

  // region Creator API

  /// get tasks
  static Future<dynamic> getTasks(params) async {
    List<Task> tasks = [];
    final result = await httpManager.post(url: TASK_LIST, data: params);
    print("print task result $result");
    tasks = (result as List).map((e) => Task.fromJson(e)).toList();
    return tasks;
  }

  // endregion

  ///CHANGE STATUS OF USER
  static Future<dynamic> changeStatus(params) async {
    final result = await httpManager.post(url: UPDATE_USER, data: params);

    return UsersModel.fromJson(result);
  }

  /// GET USER ROLES DOCS
  static Future<dynamic> loadUserRoleDocs(params) async {
    List<UserRoleDocTypesModel> userRoleDocs = [];
    final result = await httpManager.post(url: USER_ROLE_DOCUMENT_TYPES_LIST, data: params);

    userRoleDocs = (result as List).map((i) => UserRoleDocTypesModel.fromJson(i)).toList();
    return userRoleDocs;
  }

  /// DELETE USER ROLE DOCUMENT TYPE
  static Future<dynamic> deleteUserRoleDocs(params) async {
    final result = await httpManager.post(url: DELETE_USER_ROLE_DOCUMENT_TYPE, data: params);

    return UserRoleDocTypesModel.fromJson(result);
  }

  /// GET USER ROLE TRAINING TYPES LIST
  static Future<dynamic> getUserRoleTrainingTypes(params) async {
    List<UserRoleTrainingTypesModel> userRoleTrainings = [];
    final result = await httpManager.post(url: USER_ROLE_TRAINING_TYPES_LIST, data: params);
    userRoleTrainings = (result as List).map((i) => UserRoleTrainingTypesModel.fromJson(i)).toList();
    return userRoleTrainings;
  }

  /// SAVE USER ROLE TRAINING TYPE
  static Future<dynamic> saveUserRoleTrainingType(params) async {
    final result = await httpManager.post(url: SAVE_USER_ROLE_TRAINING_TYPE, data: params);

    return UserRoleTrainingTypesModel.fromJson(result);
  }

  /// DELETE USER ROLE TRAINING TYPE
  static Future<dynamic> deleteUserRoleTrainingType(params) async {
    final result = await httpManager.post(url: DELETE_USER_ROLE_TRAINING_TYPE, data: params);
    return UserRoleTrainingTypesModel.fromJson(result);
  }

  /// SAVE DOCUMENTS
  static Future<dynamic> saveDocument(params) async {
    final result = await httpManager.post(url: SAVE_DOCUMENTS, data: params);

    return DocumentsModel.fromJson(result);
  }

  /// LOAD DEPARTMENT USERS BY DEPARTMENT ID AND ROLE ID
  static Future<dynamic> loadUsersById(params) async {
    List<ReadUsersByIdModel> departmentUsers;
    final result = await httpManager.post(url: GET_DEPARTMENT_USERS, data: params);
    departmentUsers = (result as List).map((i) => ReadUsersByIdModel.fromJson(i)).toList();
    return departmentUsers;
  }

  /// SAVE DOCUMENT FILES
  static Future<dynamic> saveDocumentFile(params) async {
    final result = await httpManager.post(url: SAVE_DOCUMENT_FILE, data: params);

    return DocumentFilesModel.fromJson(result);
  }

  /// create document
  static Future<DocumentModel> createDocument(DocumentModel document) async {
    final result = await httpManager.post(url: SAVE_DOCUMENTS, data: {
      "title": document.title,
      "description": document.description,
      'version': document.fileVersion,
      "training_type_id_fk": document.trainingTypeIdFk,
      "document_type_id_fk": document.documentTypeIdFk,
      "creator_id_fk": document.creatorIdFk,
      "department_id_fk": document.departmentIdFk,
      "small_leader_id_fk": document.smallLeaderIdFk,
      "identifier": document.identifier,
      "document_status_id_fk": 1,
      "view_id_fk": document.viewTypeIdFk,
    });
    return DocumentModel.fromJson(result);
  }

  /// create single document test
  static Future<DocumentTestModel> createDocumentTest(DocumentTestModel test) async {
    final result = await httpManager.post(url: CREATE_DOCUMENT_TEST, data: {
      "question": test.question,
      "document_id_fk": test.documentIdFk,
      "total_answers": test.totalAnswers,
      "right_answers": test.rightAnswers
    });
    return DocumentTestModel.fromJson(result);
  }

  /// upload document files
  static Future<void> uploadDocumentFiles(int documentId, List<PlatformFile> files) async {
    var formData = FormData.fromMap({
      "identifier": Uuid().v4().replaceAll("-", ""),
      "document_id_fk": documentId,
      "files": files.map((e) => MultipartFile.fromBytes(e.bytes, filename: e.name)).toList(),
    });

    await httpManager.formData(
        url: UPLOAD_DOCUMENT_FILES,
        data: formData,
        onSendProgress: (int progress, int total) {
          print("$progress bytes in total: $total");
        });
  }

  ///GET ALL DOCUMENTS AND FILTER USING PARAMS
  static Future<dynamic> getDocuments(params) async {
    List<DocumentsModel> documentsList;
    final result = await httpManager.post(url: LOAD_DOCUMENTS, data: params);
    print("documents >>>>>> $result");

    var documents = [];
    var values = [];
    (result as List).forEach((u) {
      if (values.contains(u["title"])) {
        print("duplicate");
      } else {
        values.add(u["title"]);
        documents.add(u);
      }
    });
    documentsList = documents.map((i) => DocumentsModel.fromJson(i)).toList();
    return documentsList;
  }

  ///UPDATE DOCUMENT STATUS
  static Future<dynamic> updateDocumentStatus(params) async {
    final result = await httpManager.post(url: UPDATE_DOCUMENT_STATUS, data: params);
    return DocumentsModel.fromJson(result);
  }

  /// read user history
  static Future<dynamic> userHistory(params) async {
    List<UserHistoryModel> userhistory;
    final result = await httpManager.post(url: USER_HISTORY, data: params);
    userhistory = (result as List).map((i) => UserHistoryModel.fromJson(i)).toList();

    return userhistory;
  }

  /// SAVE TASK
  static Future<dynamic> saveTask(params) async {
    final result = await httpManager.post(url: SAVE_TASK, data: params);

    return Task.fromJson(result);
  }

  /// SAVE DOCUMENTS FILES WITH TASK ID
  static Future<dynamic> saveTaskDocs(params) async {
    final result = await httpManager.post(url: SAVE_TASK_DOCUMENTS, data: params);

    return DocumentsTaskDocs.fromJson(result);
  }

  static Future<dynamic> saveTaskDocumentsTests(params) async {
    final result = await httpManager.post(url: SAVE_TASK_DOCUMENT_TEST, data: params);

    return TaskTestModel.fromJson(result);
  }

  static Future<dynamic> saveNewTaskDocumentFiles(FormData params) async {
    await httpManager.formData(
        url: UPLOAD_TASK_DOCUMENT_FILES,
        data: params,
        onSendProgress: (int progress, int total) {
          print("$progress bytes in total: $total");
        });
  }

  static Future<dynamic> createTask(TaskModel task) async {
    print("task.taskDocuments >>>> ${task.taskDocuments}");
    final result = await httpManager.post(url: SAVE_TASK, data: {
      "read_only": task.isReadonly,
      "view_id_fk": task.viewTypeIdFk,
      "department_id_fk": task.departmentIdFk,
      "title": task.title,
      "description": task.description,
      "training_type_id_fk": task.trainingTypeIdFk,
      "document_type_id_fk": task.documentTypeIdFk,
      "creator_id_fk": task.creatorIdFk,
      "small_leader_id_fk": task.smallLeaderIdFk,
      "identifier": new Uuid().v4().replaceAll("-", ""),
      "start_date": task.startDate,
      "end_date": task.endDate,
      "task_status_id_fk": task.taskStatusIdFk,
      "task_documents": task.taskDocuments
    });

    print("create task result >>>>> $result");

    return Task.fromJson(result);
  }

  static Future<dynamic> createTaskTest(TaskTestModel test) async {
    final result = await httpManager.post(url: SAVE_TASK_DOCUMENT_TEST, data: {
      "question": test.question,
      "task_id_fk": test.taskIdFk,
      "document_test_id_fk": test.documentTestIdFk,
      "document_id_fk": test.documentIdFk,
      "total_answers": test.totalAnswers,
      "right_answers": test.rightAnswers
    });
    return TaskTestModel.fromJson(result);
  }

  static Future<dynamic> uploadTaskDocumentFiles(int taskId, List<PlatformFile> choseDocuments) async {
    var formData = FormData.fromMap({
      "identifier": Uuid().v4().replaceAll("-", ""),
      "task_id_fk": taskId,
      "files": choseDocuments.map((e) => MultipartFile.fromBytes(e.bytes, filename: e.name)).toList(),
    });
    await httpManager.formData(
        url: UPLOAD_TASK_DOCUMENT_FILES,
        data: formData,
        onSendProgress: (int progress, int total) {
          print("$progress bytes in total: $total");
        });
  }

  static Future<dynamic> uploadExistsTaskDocumentFiles(int taskIdFk, String path, String name, int documentIdFk, String selectedIdentifier) async {
    print("document name >>>>> $name");
    await httpManager.post(url: SAVE_TASK_DOCUMENTS, data: {
      "identifier": selectedIdentifier,
      "task_id_fk": taskIdFk,
      "path": path,
      "name": name,
      "document_id_fk": documentIdFk,
    });
  }

  static Future<dynamic> saveTaskToUsers(int taskId, int studentIdFk) async {
    await httpManager.post(url: SAVE_TASK_TO_USER, data: {
      "task_id_fk": taskId,
      "student_id_fk": studentIdFk,
    });
  }

  static Future<dynamic> saveTaskDateToUsers(int taskId, int studentIdFk, String startDate, String endDate) async {
    await httpManager.post(url: SAVE_TASK_TO_USER, data: {
      "task_id_fk": taskId,
      "student_id_fk": studentIdFk,
      "start_date": startDate,
      "end_date": endDate,
    });
  }

  static Future<dynamic> updateTaskDateToUsers(int id, String startDate, String endDate) async {
    await httpManager.post(url: UPDATE_TASK_TO_USER, data: {
      "id": id,
      // "task_id_fk": taskId,
      // "student_id_fk": studentIdFk,
      "start_date": startDate,
      "end_date": endDate,
    });
  }

  /// creator sign doc
  static Future<dynamic> creatorSignDoc(List<int> ids) async {
    await httpManager.post(url: UPDATE_DOCUMENT, data: {
      "id": ids,
      "document_status_id_fk": 2,
      "creator_confirm_date": "${DateTime.now().toUtc()}",
    });
  }

  static Future<dynamic> creatorSignTask(List<int> ids) async {
    final result = await httpManager.post(url: UPDATE_TASK, data: {
      "id": ids,
      "task_status_id_fk": 2,
      "creator_confirm_date": "${DateTime.now().toUtc()}",
    });

    return Task.fromJson(result);
  }

  ///CANCEL CREATED TASK
  static Future<dynamic> cancelCreatedTask(params) async {
    final result = await httpManager.post(url: UPDATE_TASK, data: params);
    return Task.fromJson(result);
  }

  ///UPDATE DOCUMENT
  static Future<dynamic> updateDocument(DocumentModel document, int docId) async {
    final result = await httpManager.post(url: UPDATE_DOCUMENTS, data: {
      "id": [
        docId
      ],
      "title": document.title,
      "description": document.description,
      "training_type_id_fk": document.trainingTypeIdFk,
      "document_type_id_fk": document.documentTypeIdFk,
      "creator_id_fk": document.creatorIdFk,
      "department_id_fk": document.departmentIdFk,
      "small_leader_id_fk": document.smallLeaderIdFk,
      "status": document.status,
      "identifier": document.identifier
    });
    print("update document >>>>> $result");
  }

  ///UPDATE DOCUMENT TEST
  static Future<dynamic> updateDocumentTest(DocumentTestModel test) async {
    final result = await httpManager.post(url: UPDATE_DOCUMENT_TEST, data: {
      "id": test.documentTestIdFk,
      "question": test.question,
      "document_id_fk": test.documentIdFk,
      "total_answers": test.totalAnswers,
      "right_answers": test.rightAnswers
    });
    print("update document tests >>>>> $result");
  }

  ///DELTE QUESTION BY TEST ID
  static Future<dynamic> deleteQuestion(int documentTestIdFk) async {
    final result = await httpManager.post(url: DELETE_TEST_QUESTION, data: {
      "id": documentTestIdFk,
    });
    return DocumentTestModel.fromJson(result);
  }

  /// DELETE DOCUMENT FILE BY FILE ID
  static Future<dynamic> deleteDocumentFile(int id) async {
    await httpManager.post(url: DELETE_DOC_FILE, data: {
      "id": id,
    });
  }

  ///UPDATE TASK
  static Future<dynamic> updateTask(Task task, int id) async {
    print(task.startDate);
    final result = await httpManager.post(url: UPDATE_TASK, data: {
      "id": [
        id
      ],
      "read_only": task.isReadonly,
      "department_id_fk": task.departmentIdFk,
      "title": task.title,
      "description": task.description,
      "training_type_id_fk": task.trainingTypeIdFk,
      "document_type_id_fk": task.documentTypeIdFk,
      "creator_id_fk": task.creatorIdFk,
      "small_leader_id_fk": task.smallLeaderIdFk,
      "identifier": task.identifier,
      "start_date": task.startDate,
      "end_date": task.endDate,
    });
    print("task updated >>>> $result");

    return Task.fromJson(result);
  }

  /// UPDATE TASK TEST BY TEST ID
  static Future<dynamic> updateTaskTest(TaskTestModel test) async {
    print(test.documentTestIdFk);
    print(test.question);
    await httpManager.post(url: UPDATE_TASK_DOCUMENT_TEST, data: {
      "question": test.question,
      "task_id_fk": test.taskIdFk,
      "id": test.id,
      "document_test_id_fk": test.documentTestIdFk,
      "document_id_fk": test.documentIdFk,
      "total_answers": test.totalAnswers,
      "right_answers": test.rightAnswers
    });
  }

  static Future<dynamic> updateTaskToUsers(int element, int id) async {}

  static Future<dynamic> deleteTaskDocumentFile(int id) async {
    await httpManager.post(url: DELETE_TASK_DOC_FILE, data: {
      "id": id,
    });
  }

  static Future<dynamic> deleteTaskQuestion(int id) async {
    final result = await httpManager.post(url: DELETE_TASK_TEST_QUESTION, data: {
      "id": id,
    });
    return TaskTestModel.fromJson(result);
  }

  /// small leader sign doc
  static Future<dynamic> smallLeaderSignDoc(List<int> ids, int bigLeaderId) async {
    await httpManager.post(url: UPDATE_DOCUMENT, data: {
      "id": ids,
      "big_leader_id_fk": bigLeaderId,
      "small_leader_confirm_date": "${DateTime.now().toUtc()}",
      "task_status_id_fk": 4
    });
  }

  /// small leader back doc
  static Future<dynamic> smallLeaderBackDoc(List<int> ids, int creatorId) async {
    await httpManager.post(url: UPDATE_DOCUMENT, data: {
      "id": ids,
      "creator_id_fk": creatorId,
      "small_leader_confirm_date": null,
      "small_leader_id_fk": null,
      "task_status_id_fk": 5
    });
  }

  /// small leader sign doc
  static Future<dynamic> smallLeaderSignTask(List<int> ids, int bigLeaderId, int taskStatusId) async {
    await httpManager.post(url: UPDATE_TASK, data: {
      "id": ids,
      "big_leader_id_fk": bigLeaderId,
      "task_status_id_fk": taskStatusId,
      "small_leader_confirm_date": "${DateTime.now().toUtc()}",
    });
  }

  /// small leader back doc
  static Future<dynamic> smallLeaderBackTask(List<int> ids, int creatorId, int taskStatusId) async {
    await httpManager.post(url: UPDATE_TASK, data: {
      "id": ids,
      "creator_id_fk": creatorId,
      "task_status_id_fk": taskStatusId,
      "small_leader_confirm_date": null,
    });
  }

  /// big leader back doc
  static Future<dynamic> bigLeaderBackTask(List<int> ids, int userId, int taskStatusId) async {
    await httpManager.post(url: UPDATE_TASK, data: {
      "id": ids,
      "creator_id_fk": userId,
      "task_status_id_fk": taskStatusId,
      "big_leader_confirm_date": null,
      "big_leader_id_fk": null,
    });
  }

  static Future<dynamic> signTask(List<int> ids, int taskStatusId) async {
    await httpManager.post(
      url: UPDATE_TASK,
      data: {
        "id": ids,
        "task_status_id_fk": taskStatusId,
        "big_leader_confirm_date": "${DateTime.now().toUtc()}",
      },
    );
  }

  static Future<dynamic> saveTest(params) async {
    final result = await httpManager.post(url: TASK_TEST, data: params);

    return TaskTestAnswers.fromJson(result);
  }

  static Future<dynamic> deleteTaskUsers(params) async {
    await httpManager.post(url: DELETE_TASK_USER, data: params);
  }

  //Apply for leave
  static Future<dynamic> applyLeave(String leaveDesc, int userId, int departmentId) async {
    final data = await httpManager.post(url: APPLY_LEAVE, data: {
      "user_id_fk": userId,
      "department_id_fk": departmentId,
      "user_description": leaveDesc
    });
    print("applyLeave >>>> $data");
    return data;
  }

  //Apply for back
  static Future<dynamic> applyBack(String backDesc, int userId, int departmentId) async {
    List<UserLeavesModel> list = await getLeavesList(userId);
    list.forEach((element) {
      if (element.status == 1 && element.userIdFk == userId) {
        httpManager.post(url: UPDATE_LEAVE, data: {
          "id": element.id,
          "status": 2,
          "user_description": backDesc,
        });
      }
    });
  }

  /// creator approve leave
  static Future<dynamic> approveLeave(int recordId, bool isApprove, String desc, int userId) async {
    final data = await httpManager.post(url: UPDATE_LEAVE, data: {
      "id": recordId,
      "status": isApprove,
      "confirmed_by_id_fk": userId,
      "approver_description": desc,
    });
    print("approve apply response: $data");
    return data;
  }

  /// GET LEAVES LIST BY DEPARTMENT
  static Future<List<UserLeavesModel>> getLeavesList(int departmentId) async {
    List<dynamic> jsonList = await httpManager.post(url: GET_LEAVES_LIST, data: {
      "department_id_fk": departmentId,
    });

    var ret = jsonList.map((e) => UserLeavesModel.fromJson(e)).toList();
    return ret;
  }

  ///GET STUDENT LEAVES LIST
  static Future<List<UserLeavesModel>> getMyLeavesList(int studentId) async {
    List<dynamic> jsonList = await httpManager.post(url: GET_LEAVES_LIST, data: {
      "user_id_fk": studentId,
    });
    var ret = jsonList.map((e) => UserLeavesModel.fromJson(e)).toList();
    return ret;
  }

  /// change password
  static Future<Map<String, dynamic>> changePassword(String oldPass, String newPass) async {
    dynamic res = await httpManager.post(url: CHANGE_PASS, data: {
      "id": Application.user.id,
      "old_pwd": oldPass,
      "new_pwd": newPass,
    });

    var ret = {
      "msg": res['error'],
      "ok": res['error'] == null,
    };

    return ret;
  }

  /// FORGOT PASSWORD - VALIDATE EMAIL EXISTS
  static Future<dynamic> forgotPasswordExist(String emailId) async {}

  /// GET VIEW TYPES
  static Future<dynamic> getViewType() async {
    List<ViewTypeModel> views = [];
    final result = await httpManager.post(url: VIEW_TYPES);
    views = (result as List).map((i) => ViewTypeModel.fromJson(i)).toList();
    return views;
  }

  /// GET USER ROLE VIEW TYPES
  static Future<dynamic> getUserRoleViewType(params) async {
    List<ViewTypeModel> views = [];
    final result = await httpManager.post(url: USER_ROLE_VIEW_TYPES_LIST, data: params);
    views = (result as List).map((i) => ViewTypeModel.fromJson(i)).toList();
    return views;
  }

  /// save user role VIEW TYPES
  static Future<dynamic> saveUserRoleViewType(params) async {
    final result = await httpManager.post(url: SAVE_USER_ROLE_VIEW_TYPES, data: params);
    return ViewTypeModel.fromJson(result);
  }

  /// delete user role VIEW TYPES
  static Future<dynamic> deleteUserRoleViewType(params) async {
    final result = await httpManager.post(url: DELETE_USER_ROLE_VIEW_TYPES, data: params);
    return ViewTypeModel.fromJson(result);
  }

  static Future<dynamic> getDocVersions(params) async {
    List<DocVersionsModel> reads = [];
    final result = await httpManager.post(url: READ_VERSIONS, data: params);
    print(result);
    var versions = [];
    var values = [];
    (result as List).forEach((u) {
      if (values.contains(u["version"])) {
        print("duplicate");
      } else {
        values.add(u["version"]);
        versions.add(u);
      }
    });
    reads = versions.map((i) => DocVersionsModel.fromJson(i)).toList();
    return reads;
  }

  static Future<dynamic> getDocVersions2(params) async {
    // List<DocVersionsModel> reads = [];
    final result = await httpManager.post(url: READ_VERSIONS, data: params);
    print(result);
    var versions = <DocVersionsModel>[];
    var values = [];
    (result as List).forEach((u) {
      if (values.contains(u["version"])) {
        print("duplicate");
        var docVersionModel = DocVersionsModel.fromJson(u);
        var index = values.indexOf(u["version"]);
        if (versions[index].documentFiles.isEmpty) {
          versions[index].documentFiles = docVersionModel.documentFiles;
        }
        if (versions[index].documentTests.isEmpty) {
          versions[index].documentTests = docVersionModel.documentTests;
        }
        versions[index].otherDocIds.add(docVersionModel.documentId);
      } else {
        values.add(u["version"]);
        versions.add(DocVersionsModel.fromJson(u));
      }
    });
    // reads = versions.map((i) => DocVersionsModel.fromJson(i)).toList();
    return versions;
  }

  static Future<dynamic> readTitles(params) async {
    // List<DocumentsModel> documentsList;
    final result = await httpManager.post(url: READ_TITLES, data: params);
    print("documents >>>>>> $result");

    var documentsList = <DocumentsModel>[];
    var values = [];
    (result as List).forEach((u) {
      if (values.contains(u["title"])) {
        print("duplicate");
        var docModel = DocumentsModel.fromJson(u);
        var index = values.indexOf(u["title"]);
        if (documentsList[index].documentFiles.isEmpty) {
          documentsList[index].documentFiles = docModel.documentFiles;
        }
        if (documentsList[index].documentTests.isEmpty) {
          documentsList[index].documentTests = docModel.documentTests;
        }
        documentsList[index].otherDocIds.add(docModel.id);
      } else {
        values.add(u["title"]);
        documentsList.add(DocumentsModel.fromJson(u));
      }
    });
    // reads = versions.map((i) => DocVersionsModel.fromJson(i)).toList();
    return documentsList;
  }
}
