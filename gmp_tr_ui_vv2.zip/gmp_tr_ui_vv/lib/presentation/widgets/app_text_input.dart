import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppTextInput extends StatelessWidget {
  final Color borderColor;
  final int height;
  final String hintText;
  final TextEditingController controller;
  final FocusNode focusNode;
  final VoidCallback onTapIcon;
  final GestureTapCallback onTap;
  final ValueChanged<dynamic> onChanged;
  final ValueChanged<String> onSubmitted;
  final Icon icon;
  final Icon prefixIcon;
  final bool obscureText;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final String errorText;
  final int maxLines;
  final bool autoFocus;
  final List<TextInputFormatter> inputFormatters;

  AppTextInput({
    Key key,
    this.borderColor,
    this.height,
    this.hintText,
    this.controller,
    this.focusNode,
    this.onTapIcon,
    this.onTap,
    this.onChanged,
    this.onSubmitted,
    this.icon,
    this.prefixIcon,
    this.obscureText = false,
    this.keyboardType,
    this.textInputAction,
    this.errorText,
    this.maxLines = 1,
    this.autoFocus = false,
    this.inputFormatters,
  }) : super(key: key);

  Widget _buildErrorLabel(BuildContext context) {
    if (errorText == null) {
      return Container();
    }

    return Container(
      padding: EdgeInsets.only(left: 16, right: 16),
      child: Text(
        errorText,
        style: Theme.of(context)
            .textTheme
            .caption
            .copyWith(color: Theme.of(context).errorColor),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: this.height ?? 40,
      alignment: Alignment.center,
      padding: EdgeInsets.zero,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(2.2),
          border: Border.all(width: 1, color: this.borderColor ?? Colors.grey)),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: <Widget>[
          TextField(
            inputFormatters: inputFormatters,
            autofocus: autoFocus,
            onTap: onTap,
            textAlignVertical: TextAlignVertical.center,
            onSubmitted: onSubmitted,
            controller: controller,
            focusNode: focusNode,
            onChanged: onChanged,
            obscureText: obscureText,
            keyboardType: keyboardType,
            textInputAction: textInputAction,
            maxLines: maxLines,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              hintText: hintText,
              hintStyle: TextStyle(fontSize: 14.0),
              suffixIcon: icon != null
                  ? GestureDetector(
                      dragStartBehavior: DragStartBehavior.down,
                      onTap: onTapIcon,
                      child: icon,
                    )
                  : null,
              prefixIcon: prefixIcon != null
                  ? GestureDetector(
                      dragStartBehavior: DragStartBehavior.down,
                      onTap: onTapIcon,
                      child: prefixIcon,
                    )
                  : null,
              border: InputBorder.none,
            ),
          ),
          _buildErrorLabel(context)
        ],
      ),
    );
  }
}
