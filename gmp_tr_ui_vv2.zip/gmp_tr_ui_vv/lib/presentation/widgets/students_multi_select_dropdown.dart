library multiselect;

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:states_rebuilder/states_rebuilder.dart';

class _TheState {}

var _theState = RM.inject(() => _TheState());

class _SelectRow extends StatelessWidget {
  final Function(bool) onChange;
  final bool selected;
  final String text;

  const _SelectRow(
      {Key key,
      @required this.onChange,
      @required this.selected,
      @required this.text})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Checkbox(
            value: selected,
            onChanged: (x) {
              print(x);
              onChange(x);
              _theState.notify();
            }),
        Text(text)
      ],
    );
  }
}

///
/// A Dropdown multiselect menu
///
///
class StudentsDropDownMultiSelect extends StatefulWidget {
  /// The options form which a user can select
  final List<String> options;

  /// Selected Values
  final List<String> selectedValues;

  ///Selected Ids
  final List<int> selectedIds;

  ///Selected Department Id
  final int departmentIdFk;

  ///Students role id
  final int studentsRoleId;

  /// This function is called whenever a value changes
  final Function(List<String>, List<int>) onChanged;

  /// defines whether the field is dense
  final bool isDense;

  /// defines whether the widget is enabled;
  final bool enabled;

  /// Input decoration
  final InputDecoration decoration;

  /// this text is shown when there is no selection
  final String whenEmpty;

  /// a function to build custom childern
  final Widget Function(List<String> selectedValues) childBuilder;

  /// a function to build custom menu items
  final Widget Function(String option) menuItembuilder;

  const StudentsDropDownMultiSelect({
    Key key,
    this.options,
    @required this.selectedValues,
    @required this.onChanged,
    @required this.whenEmpty,
    this.childBuilder,
    this.menuItembuilder,
    this.isDense = false,
    this.enabled = true,
    this.decoration,
    this.departmentIdFk,
    this.studentsRoleId,
    this.selectedIds,
  }) : super(key: key);
  @override
  _StudentsDropDownMultiSelectState createState() =>
      _StudentsDropDownMultiSelectState();
}

class _StudentsDropDownMultiSelectState
    extends State<StudentsDropDownMultiSelect> {
  @override
  void initState() {
    super.initState();
    AppBloc.studentsBloc.add(OnLoadStudents(
        departmentIdFk: widget.departmentIdFk,
        roleIdFk: widget.studentsRoleId));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      child: Stack(
        children: [
          _theState.rebuilder(() => widget.childBuilder != null
              ? widget.childBuilder(widget.selectedValues)
              : Align(
                  child: Padding(
                      padding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                      child: Text(
                        widget.selectedValues.length > 0
                            ? widget.selectedValues
                                .reduce((a, b) => a + ' , ' + b)
                            : widget.whenEmpty ?? '',
                        style: TextStyle(fontSize: 12),
                      )),
                  alignment: Alignment.centerLeft)),
          Align(
              alignment: Alignment.centerLeft,
              child: BlocBuilder<StudentsBloc, StudentsState>(
                  bloc: BlocProvider.of<StudentsBloc>(context),
                  builder: (context, studentsList) {
                    if (studentsList is StudentsLoading) {
                      return Text(
                        Translate.of(context).translate("choose_student"),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 12,
                        ),
                      );
                    } else if (studentsList is StudentsSuccess) {
                      return DropdownButtonFormField(
                        decoration: widget.decoration != null
                            ? widget.decoration
                            : InputDecoration(
                                border: OutlineInputBorder(),
                                isDense: true,
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 12,
                                  horizontal: 10,
                                ),
                              ),
                        isDense: true,
                        onChanged: widget.enabled ? (x) {} : null,
                        value: null,
                        selectedItemBuilder: (context) {
                          return studentsList.students
                              .map((e) => DropdownMenuItem(
                                    child: Container(),
                                  ))
                              .toList();
                        },
                        items: studentsList.students
                            .map(
                              (x) => DropdownMenuItem(
                                child: _theState.rebuilder(() {
                                  return widget.menuItembuilder != null
                                      ? widget.menuItembuilder(x.name)
                                      : _SelectRow(
                                          selected: widget.selectedValues
                                              .contains(x.name),
                                          text: x.name,
                                          onChange: (isSelected) {
                                            if (isSelected) {
                                              var ns = widget.selectedValues;
                                              var ids = widget.selectedIds;
                                              ns.add(x.name.toString());
                                              ids.add(x.id);
                                              widget.onChanged(ns, ids);
                                            } else {
                                              var ns = widget.selectedValues;
                                              var ids = widget.selectedIds;
                                              ns.remove(x.name.toString());
                                              ids.remove(x.id);

                                              widget.onChanged(ns, ids);
                                            }
                                          },
                                        );
                                }),
                                value: x.id,
                                onTap: () {
                                  if (widget.selectedValues.contains(x)) {
                                    var ns = widget.selectedValues;
                                    var ids = widget.selectedIds;
                                    ns.remove(x.name.toString());
                                    ids.remove(x.id);
                                    widget.onChanged(ns, ids);
                                  } else {
                                    var ns = widget.selectedValues;
                                    var ids = widget.selectedIds;
                                    ns.add(x.name.toString());
                                    ids.add(x.id);
                                    widget.onChanged(ns, ids);
                                  }
                                },
                              ),
                            )
                            .toList(),
                      );
                    } else {
                      return LoadingBox(
                        height: 20,
                      );
                    }
                  })),
        ],
      ),
    );
  }
}

class StudentsMultiSelect extends StatefulWidget {
  /// The options form which a user can select
  final List<String> options;

  /// Selected Values
  final List<String> selectedValues;

  ///Selected Ids
  final List<int> selectedIds;

  ///Selected Department Id
  final int departmentIdFk;

  ///Students role id
  final int studentsRoleId;

  /// This function is called whenever a value changes
  final Function(List<String>, List<int>) onChanged;

  /// defines whether the field is dense
  final bool isDense;

  /// defines whether the widget is enabled;
  final bool enabled;

  /// Input decoration
  final InputDecoration decoration;

  /// this text is shown when there is no selection
  final String whenEmpty;

  /// a function to build custom childern
  final Widget Function(List<String> selectedValues) childBuilder;

  /// a function to build custom menu items
  final Widget Function(String option) menuItembuilder;

  const StudentsMultiSelect({
    Key key,
    this.options,
    @required this.selectedValues,
    @required this.onChanged,
    @required this.whenEmpty,
    this.childBuilder,
    this.menuItembuilder,
    this.isDense = false,
    this.enabled = true,
    this.decoration,
    this.departmentIdFk,
    this.studentsRoleId,
    this.selectedIds,
  }) : super(key: key);
  @override
  _StudentsMultiSelectState createState() => _StudentsMultiSelectState();
}

class _StudentsMultiSelectState extends State<StudentsMultiSelect> {
  MyTextEditingController searchController = MyTextEditingController();
  @override
  void initState() {
    super.initState();
    AppBloc.studentsBloc.add(OnLoadStudents(
        departmentIdFk: widget.departmentIdFk,
        roleIdFk: widget.studentsRoleId));
  }

  var students = <ReadUsersByIdModel>[];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // _theState.rebuilder(
        //   () => widget.childBuilder != null ? widget.childBuilder(widget.selectedValues) : Container(),
        // ),
        Material(
          child: InputSearchBox(
            hint: 'Students',
            controller: searchController,
            onChanged: (query) {
              AppBloc.studentsBloc.add(OnSearchStudents(
                query: query,
                students: students,
                departmentIdFk: widget.departmentIdFk,
                roleIdFk: widget.studentsRoleId,
              ));
            },
          ),
        ),
        SizedBox(height: 8),
        Expanded(
          child: BlocBuilder<StudentsBloc, StudentsState>(
            bloc: BlocProvider.of<StudentsBloc>(context),
            builder: (context, studentsList) {
              if (studentsList is StudentsSuccess) {
                students = studentsList.students;
                return SingleChildScrollView(
                  child: Column(
                    children: studentsList.students
                        .map(
                          (student) => Material(
                            child: CheckboxListTile(
                              value:
                                  widget.selectedValues.contains(student.name),
                              title: Text(student.name),
                              onChanged: (isSelected) {
                                if (isSelected) {
                                  var ns = widget.selectedValues;
                                  var ids = widget.selectedIds;
                                  ns.add(student.name.toString());
                                  ids.add(student.id);
                                  widget.onChanged(ns, ids);
                                } else {
                                  var ns = widget.selectedValues;
                                  var ids = widget.selectedIds;
                                  ns.remove(student.name.toString());
                                  ids.remove(student.id);

                                  widget.onChanged(ns, ids);
                                }
                                _theState.notify();
                              },
                            ),
                          ),
                        )
                        .toList(),
                  ),
                );
              }
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(child: LoadingBox(width: 20, height: 20)),
              );
            },
          ),
        ),
      ],
    );
  }
}
