import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gmptr/configs/config.dart';

class TaskStatusWidget extends StatelessWidget {
  final int taskStatusId;
  const TaskStatusWidget({Key key, this.taskStatusId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String statusIcon;
    String hintText;
    if (this.taskStatusId == 1) {
      statusIcon = CustomIcon.created;
      hintText = "Created";
    } else if (this.taskStatusId == 2) {
      statusIcon = CustomIcon.creatorConfirmed;
      hintText = "Creator Confirmed";
    } else if (this.taskStatusId == 3) {
      statusIcon = CustomIcon.creatorCancelled;
      hintText = "Creator Cancelled";
    } else if (this.taskStatusId == 4) {
      statusIcon = CustomIcon.smallLeaderConfirmed;
      hintText = "Small Leader Confirmed";
    } else if (this.taskStatusId == 5) {
      statusIcon = CustomIcon.smallLeaderSentBack;
      hintText = "Small Leader Send Back";
    } else if (this.taskStatusId == 6) {
      statusIcon = CustomIcon.bigLeaderConfirmed;
      hintText = "Big Leader Confirmed";
    } else if (this.taskStatusId == 7) {
      statusIcon = CustomIcon.bigLeaderSentBack;
      hintText = "Big Leader Sent Back";
    } else if (this.taskStatusId == 8) {
      statusIcon = CustomIcon.begin;
      hintText = "Begin";
    } else if (this.taskStatusId == 9) {
      statusIcon = CustomIcon.finished;
      hintText = "Finished";
    } else if (this.taskStatusId == 10) {
      statusIcon = CustomIcon.expired;
      hintText = "Expired";
    }
    return Container(
      child: Tooltip(
        message: hintText,
        child: SvgPicture.asset(
          statusIcon,
          width: 20,
          height: 20,
        ),
      ),
    );
  }
}
