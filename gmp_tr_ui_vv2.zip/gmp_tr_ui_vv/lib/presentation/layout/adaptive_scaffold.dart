import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/configs/routes.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

bool _isLargeScreen(BuildContext context) {
  return MediaQuery.of(context).size.width > 960.0;
}

class AdaptiveScaffoldDestination {
  final String title;
  final IconData icon;

  const AdaptiveScaffoldDestination({
    this.title,
    this.icon,
  });
}

class AdaptiveScaffold extends StatefulWidget {
  final Widget title;
  final List<Widget> actions;
  final Widget body;
  final int currentIndex;
  final List<AdaptiveScaffoldDestination> destinations;
  final ValueChanged<int> onNavigationIndexChange;
  final String username;
  final int userRole;

  const AdaptiveScaffold({this.title, this.body, this.actions = const [], @required this.currentIndex, @required this.destinations, this.onNavigationIndexChange, this.username, this.userRole});

  @override
  _AdaptiveScaffoldState createState() => _AdaptiveScaffoldState();
}

class _AdaptiveScaffoldState extends State<AdaptiveScaffold> {
  List<bool> isSelected;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  int selectedIndex = 0;
  bool expandable = true;

  List<UserRoles> userRoles;
  var userPageRoleId;
  @override
  void initState() {
    super.initState();
    userRoles = Application.user.userRoles;
    userPageRoleId = UtilPreferences.getString(Preferences.userRoleId) ?? 2;
  }

  //User Roles Navigation
  void _userRole(int id) {
    UtilPreferences.setString(
        Preferences.userRoleId,
        jsonEncode(
          id,
        ));
    userPageRoleId = UtilPreferences.getString(Preferences.userRoleId) ?? 2;
    Navigator.pushNamed(context, Routes.home, arguments: int.parse(userPageRoleId));
  }

  @override
  Widget build(BuildContext context) {
    String roleName;
    if (widget.userRole == 6) {
      roleName = Translate.of(context).translate('admin');
    } else if (widget.userRole == 5) {
      roleName = Translate.of(context).translate('student');
    } else if (widget.userRole == 4) {
      roleName = Translate.of(context).translate('big_leader');
    } else if (widget.userRole == 3) {
      roleName = Translate.of(context).translate('small_leader');
    } else if (widget.userRole == 2) {
      roleName = Translate.of(context).translate('task_creator');
    } else if (widget.userRole == 13) {
      roleName = Translate.of(context).translate('admin_view');
    } else if (widget.userRole == 14) {
      roleName = Translate.of(context).translate('training_view');
    }
    // Show a Drawer
    if (_isLargeScreen(context)) {
      return Row(
        children: [
          expandable
              ? Container(
                  width: 220,
                  child: Drawer(
                    child: Container(
                      color: Color(0xff00439E),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Container(
                                color: Color(0xffEFF5FC),
                                height: 66,
                                child: DrawerHeader(
                                  margin: EdgeInsets.zero,
                                  padding: EdgeInsets.all(0),
                                  child: Center(
                                    child: Image.asset(Images.Logo),
                                  ),
                                ),
                              ),
                              for (var d in widget.destinations)
                                Container(
                                  color: widget.destinations.indexOf(d) == widget.currentIndex ? Colors.white : Color(0xff00439E),
                                  child: ListTile(
                                    hoverColor: Colors.white,
                                    title: Text(
                                      d.title,
                                      style: TextStyle(fontSize: 12, color: widget.destinations.indexOf(d) == widget.currentIndex ? Color(0xff00439E) : Colors.white),
                                    ),
                                    selected: widget.destinations.indexOf(d) == widget.currentIndex,
                                    onTap: () => _destinationTapped(d),
                                  ),
                                ),
                            ],
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(vertical: 30),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    PopupMenuButton(
                                      onSelected: (value) {
                                        if (value == 3) {
                                          Navigator.pushNamed(context, Routes.roles);
                                        }
                                        if (value == 1) {
                                          showDialog(
                                            context: context,
                                            builder: (context) {
                                              return MyInfoCard(user: Application.user);
                                            },
                                          );
                                        }
                                        if (value == 2) {
                                          Navigator.pushNamed(context, Routes.changePassword);
                                        }
                                      },
                                      color: Colors.white,
                                      child: Container(
                                        child: Icon(
                                          Icons.account_circle_outlined,
                                          color: Colors.white,
                                        ),
                                      ),
                                      itemBuilder: (context) => [
                                        PopupMenuItem(
                                          child: Text(
                                            Translate.of(context).translate('my_profile'),
                                            style: TextStyle(color: Color(0xff00A4E3), fontSize: 11),
                                          ),
                                          value: 1,
                                        ),
                                        PopupMenuItem(
                                          child: Text(
                                            Translate.of(context).translate('reset_password'),
                                            style: TextStyle(color: Color(0xff00A4E3), fontSize: 11),
                                          ),
                                          value: 2,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          Translate.of(context).translate('welcome'),
                                          style: TextStyle(color: Colors.white, fontSize: 12),
                                          textAlign: TextAlign.left,
                                        ),
                                        SizedBox(
                                          height: 3,
                                        ),
                                        Text(
                                          widget.username,
                                          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.left,
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          roleName,
                                          style: TextStyle(color: Color(0xff00A4E3), fontWeight: FontWeight.w100, fontSize: 11),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                TextButton(
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Icon(
                                        Icons.logout,
                                        color: Colors.white,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        Translate.of(context).translate('log_out'),
                                        style: TextStyle(color: Colors.white, fontSize: 11),
                                      )
                                    ],
                                  ),
                                  onPressed: () {
                                    AppBloc.authBloc.add(OnClear());
                                    Navigator.popAndPushNamed(context, Routes.signIn);
                                  },
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              : Container(),
          Expanded(
            child: Scaffold(
              key: _scaffoldKey,
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: IconButton(
                            icon: Icon(
                              Icons.menu,
                              color: Color(0xff00A4E3),
                            ),
                            onPressed: () {
                              setState(() {
                                if (expandable) {
                                  expandable = false;
                                } else {
                                  expandable = true;
                                }
                              });
                            },
                          ),
                        ),
                        Container(
                          height: 80,
                          child: ListView.builder(
                            shrinkWrap: true,
                            scrollDirection: Axis.horizontal,
                            itemCount: userRoles.length,
                            itemBuilder: (context, i) {
                              return userRoles.length > 0
                                  ? userRoles[i].role.multiButtons == false
                                      ? Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: SizedBox(
                                            height: 50,
                                            child: AppButton(
                                              userRoles[i].role.name,
                                              type: ButtonType.text,
                                              activeColor: int.parse(userPageRoleId) == userRoles[i].role.id ? Color(0xff00A4E3) : Color(0xffFFFFFF),
                                              onPressed: () => _userRole(userRoles[i].role.id),
                                            ),
                                          ),
                                        )
                                      : Row(
                                          children: List.generate(userRoles[i].userAdminPagees.length, (index) => _userAdminPages(userRoles[i].userAdminPagees[index])),
                                        )
                                  : Container();
                            },
                          ),
                        ),
                      ],
                    ),
                    widget.body,
                  ],
                ),
              ),
            ),
          ),
        ],
      );
    }

    // Show a bottom app bar
    return Scaffold(
      body: widget.body,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(66.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppBar(
              leading: Builder(
                builder: (contxt) => GestureDetector(
                  onTap: () {
                    Scaffold.of(contxt).openDrawer();
                  },
                  child: Icon(
                    Icons.menu,
                    color: Color(0xff00439E), // add custom icons also
                  ),
                ),
              ),
              title: Image(image: AssetImage(Images.Logo)),
              backgroundColor: Color(0xffEFF5FC),
              actions: [
                PopupMenuButton(
                  onSelected: (value) {
                    if (value == 3) {
                      Navigator.pushNamed(context, Routes.roles);
                    }
                    if (value == 1) {
                      return MyInfoCard(user: Application.user);
                    }
                    if (value == 2) {
                      Navigator.pushNamed(context, Routes.changePassword);
                    }
                  },
                  color: Colors.white,
                  child: Container(
                    child: Icon(
                      Icons.account_circle_outlined,
                      color: Color(0xff00439E),
                    ),
                  ),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      child: Text(
                        Translate.of(context).translate('my_profile'),
                        style: TextStyle(color: Color(0xff00A4E3), fontSize: 11),
                      ),
                      value: 1,
                    ),
                    PopupMenuItem(
                      child: Text(
                        Translate.of(context).translate('reset_password'),
                        style: TextStyle(color: Color(0xff00A4E3), fontSize: 11),
                      ),
                      value: 2,
                    ),
                  ],
                ),
                TextButton(
                  child: Icon(
                    Icons.logout,
                    color: Color(0xff00439E),
                  ),
                  onPressed: () {
                    AppBloc.authBloc.add(OnClear());
                    Navigator.popAndPushNamed(context, Routes.signIn);
                  },
                )
              ],
            ),
          ],
        ),
      ),
      drawer: Container(
        width: 280,
        child: Drawer(
          child: Container(
            color: Color(0xff00439E),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Container(
                      color: Color(0xffEFF5FC),
                      height: 66,
                      child: DrawerHeader(
                        margin: EdgeInsets.zero,
                        padding: EdgeInsets.all(0),
                        child: Center(
                          child: Image.asset(Images.Logo),
                        ),
                      ),
                    ),
                    for (var d in widget.destinations)
                      Container(
                        color: widget.destinations.indexOf(d) == widget.currentIndex ? Colors.white : Color(0xff00439E),
                        child: ListTile(
                          hoverColor: Colors.white,
                          title: Text(
                            d.title,
                            style: TextStyle(fontSize: 12, color: widget.destinations.indexOf(d) == widget.currentIndex ? Color(0xff00439E) : Colors.white),
                          ),
                          selected: widget.destinations.indexOf(d) == widget.currentIndex,
                          onTap: () {
                            _destinationTapped(d);
                            Navigator.pop(context);
                          },
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _destinationTapped(AdaptiveScaffoldDestination destination) {
    var idx = widget.destinations.indexOf(destination);
    if (idx != widget.currentIndex) {
      widget.onNavigationIndexChange(idx);
    }
  }

  _userAdminPages(UserAdminPagee userAdminPagee) {
    return userAdminPagee.adminPage != null
        ? Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
              height: 50,
              child: AppButton(
                userAdminPagee.adminPage.name,
                type: ButtonType.text,
                activeColor: int.parse(userPageRoleId) == userAdminPagee.adminPage.id ? Color(0xff00A4E3) : Color(0xffFFFFFF),
                onPressed: () => _userRole(userAdminPagee.adminPageIdFk),
              ),
            ),
          )
        : Container();
  }
}
