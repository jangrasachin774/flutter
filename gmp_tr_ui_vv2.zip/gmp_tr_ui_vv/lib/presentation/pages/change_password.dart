import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/image.dart';
import 'package:gmptr/configs/routes.dart';
import 'package:gmptr/presentation/widgets/app_button.dart';
import 'package:gmptr/presentation/widgets/app_text_input.dart';
import 'package:gmptr/utils/other.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:gmptr/utils/validate.dart';

import 'role_types/student/my_finished_work.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key key}) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final _oldPassController = TextEditingController();
  final _newPassController = TextEditingController();
  final _confirmNewPassController = TextEditingController();
  final _focusOldPass = FocusNode();
  final _focusNewPass = FocusNode();
  final _focusConfirmNewPass = FocusNode();

  String _validOldPass;
  String _validNewPass;
  String _validConfirmNewPass;

  bool _showOld = false;
  bool _showNew = false;
  bool _showConfirm = false;

  String _errMsg = "";

  Future<void> _changePassword() async {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validOldPass = UtilValidator.validate(data: _oldPassController.text);
      _validNewPass = UtilValidator.validate(data: _newPassController.text);
      _validConfirmNewPass =
          UtilValidator.validate(data: _confirmNewPassController.text);

      if (_newPassController.text != _confirmNewPassController.text) {
        _validConfirmNewPass = Translate.of(context)
            .translate('confirm_password_not_same_with_new_password');
      }
    });
    if (_validOldPass == null &&
        _validNewPass == null &&
        _validConfirmNewPass == null) {
      AppBloc.changePassBloc.add(OnChangePass(
        oldPass: _oldPassController.text,
        newPass: _newPassController.text,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // background image
          Container(
            decoration: BoxDecoration(
              color: const Color(0xff00439E),
              image: DecorationImage(
                image: AssetImage(Images.LoginBg),
                fit: BoxFit.cover,
              ),
            ),
          ),

          // card
          Scaffold(
            backgroundColor: Colors.transparent,
            body: Center(
              child: Container(
                width: 420,
                height: 550,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.2),
                  color: Colors.white,
                ),
                padding: EdgeInsets.symmetric(vertical: 30, horizontal: 40),
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    // logo
                    Image(image: AssetImage(Images.Logo)),
                    const SizedBox(height: 20),

                    // title: reset password
                    Text(
                      Translate.of(context).translate('change_password'),
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),

                    // err msg
                    if (_errMsg.isNotEmpty)
                      Container(
                        height: 40,
                        alignment: Alignment.bottomCenter,
                        child: Text(
                          Translate.of(context)
                              .translate(_errMsg.toLowerCase()),
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.redAccent),
                        ),
                      ),
                    SizedBox(height: _errMsg.isNotEmpty ? 20 : 40),

                    // input: old password
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Translate.of(context)
                                .translate('input_your_password'),
                            style: _bold12)),
                    const SizedBox(height: 8),
                    AppTextInput(
                      hintText: '',
                      errorText: Translate.of(context).translate(_validOldPass),
                      textInputAction: TextInputAction.done,
                      onChanged: (text) {
                        setState(() {
                          _validOldPass = UtilValidator.validate(
                            data: _oldPassController.text,
                          );
                        });
                      },
                      onSubmitted: (text) {
                        UtilOther.fieldFocusChange(
                            context, _focusOldPass, _focusNewPass);
                      },
                      onTapIcon: () {
                        setState(() {
                          _showOld = !_showOld;
                        });
                      },
                      obscureText: !_showOld,
                      icon: Icon(
                        _showOld ? Icons.visibility : Icons.visibility_off,
                      ),
                      controller: _oldPassController,
                      focusNode: _focusOldPass,
                    ),
                    const SizedBox(height: 14),

                    // input: new password
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Translate.of(context).translate('new_password'),
                            style: _bold12)),
                    const SizedBox(height: 8),
                    AppTextInput(
                      hintText: '',
                      errorText: Translate.of(context).translate(_validNewPass),
                      textInputAction: TextInputAction.done,
                      onChanged: (text) {
                        setState(() {
                          _validNewPass = UtilValidator.validate(
                            data: _newPassController.text,
                          );
                        });
                      },
                      onSubmitted: (text) {
                        UtilOther.fieldFocusChange(
                            context, _focusNewPass, _focusConfirmNewPass);
                      },
                      onTapIcon: () {
                        setState(() {
                          _showNew = !_showNew;
                        });
                      },
                      obscureText: !_showNew,
                      icon: Icon(
                        _showNew ? Icons.visibility : Icons.visibility_off,
                      ),
                      controller: _newPassController,
                      focusNode: _focusNewPass,
                    ),
                    const SizedBox(height: 14),

                    // input: confirm new password
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            Translate.of(context)
                                .translate('confirm_new_password'),
                            style: _bold12)),
                    const SizedBox(height: 8),
                    AppTextInput(
                      hintText: '',
                      errorText:
                          Translate.of(context).translate(_validConfirmNewPass),
                      textInputAction: TextInputAction.done,
                      onChanged: (text) {
                        setState(() {
                          _validConfirmNewPass = UtilValidator.validate(
                            data: _confirmNewPassController.text,
                          );
                        });
                      },
                      onSubmitted: (text) {
                        _changePassword();
                      },
                      onTapIcon: () {
                        setState(() {
                          _showConfirm = !_showConfirm;
                        });
                      },
                      obscureText: !_showConfirm,
                      icon: Icon(
                        _showConfirm ? Icons.visibility : Icons.visibility_off,
                      ),
                      controller: _confirmNewPassController,
                      focusNode: _focusConfirmNewPass,
                    ),
                    const SizedBox(height: 14),

                    BlocBuilder<ChangePassBloc, ChangePassState>(
                      builder: (context, change) {
                        return BlocListener<ChangePassBloc, ChangePassState>(
                          listener: (context, state) {
                            if (state is ChangePassFail) {
                              setState(() {
                                _errMsg = state.error;
                              });
                            }
                            if (state is ChangePassSuccess) {
                              AppBloc.authBloc.add(OnClear());
                              Navigator.pushNamedAndRemoveUntil(
                                  context, Routes.signIn, (route) => false);
                            }
                          },
                          child: AppButton(
                            Translate.of(context).translate('change_password'),
                            onPressed: _changePassword,
                            loading: change is ChangingPass,
                            disabled: change is ChangingPass,
                          ),
                        );
                      },
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    AppButton(
                      Translate.of(context).translate('back'),
                      type: ButtonType.outline,
                      onPressed: () {
                        Navigator.pushNamed(context, Routes.home);
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  get _bold12 => const TextStyle(fontSize: 12, fontWeight: FontWeight.bold);
}
