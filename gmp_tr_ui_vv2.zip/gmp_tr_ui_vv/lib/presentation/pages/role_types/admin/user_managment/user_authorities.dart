import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/user_role_view_types/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model_user_roles.dart';
import 'package:gmptr/presentation/widgets/app_dropdown_view_multiselect.dart';
import 'package:gmptr/presentation/widgets/dynamic_treeview_admin.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/repository/repository.dart';
import 'package:gmptr/utils/utils.dart';

class UserAuthorities extends StatefulWidget {
  final List<UserRolesModel> userRolesList;
  final int roleId;
  final multiRolesId;

  UserAuthorities({
    Key key,
    this.userRolesList,
    this.roleId,
    this.multiRolesId,
  }) : super(key: key);

  @override
  _UserAuthoritiesState createState() => _UserAuthoritiesState();
}

class _UserAuthoritiesState extends State<UserAuthorities> {
  List<String> taskDeptselected = [];
  List<String> docSelected = [];
  List<String> smallLeaderSelected = [];
  List<String> bigLeaderSelected = [];
  List<String> trainingTypesSelected = [];
  List<String> viewTypesSelected = [];

  List<String> selectedAdminDepartsItems = [];
  List<String> selectedAdminDepartMngmtItems = [];
  List<String> selectedViewDepartsItems = [];
  List<String> selectedViewTrainingDepartsItems = [];
  var showTask;
  var showLeaders;
  var showBigLeaders;
  var showAdmin;
  var showViewer;

  @override
  void initState() {
    super.initState();

    showAdmin = widget.userRolesList.where((element) => element.roleIdFk == 6).toList();

    showViewer = widget.userRolesList.where((element) => element.roleIdFk == 7).toList();
    showTask = widget.userRolesList
        .where(
          (element) => element.roleIdFk == 2,
        )
        .toList();

    showLeaders = widget.userRolesList
        .where(
          (element) => element.roleIdFk == 3,
        )
        .toList();

    showBigLeaders = widget.userRolesList
        .where(
          (element) => element.roleIdFk == 4,
        )
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Visibility(
          visible: showTask.length != 0 || widget.roleId == 2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                Translate.of(context).translate('authorities_for_task_creator'),
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 18,
              ),
              Container(
                width: 240,
                decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                padding: EdgeInsets.all(20),
                child: Container(
                  width: 230,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Translate.of(context).translate('department'),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      BlocListener<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                        listener: (context, state) {
                          if (state is UserRoleDepartmentSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text(Translate.of(context).translate('added_successfully')),
                            ));
                          }
                          if (state is UserRoleDepartmentDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text(Translate.of(context).translate('deleted_successfully')),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                            bloc: BlocProvider.of<UserRoleDepartmentsListBloc>(context),
                            builder: (context, userRoleDepartmentsList) {
                              if (userRoleDepartmentsList is UserRoleDepartmentsLoading) {
                                return Center(
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              } else if (userRoleDepartmentsList is UserRoleDepartmentsSuccess) {
                                taskDeptselected = userRoleDepartmentsList.userroleDepartment.map((element) => element.department.name).toList();
                                return MyDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      taskDeptselected = x;
                                    });
                                  },
                                  selectedValues: taskDeptselected,
                                  whenEmpty: 'Select Department',
                                );
                              } else {
                                return MyDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      taskDeptselected = x;
                                    });
                                  },
                                  selectedValues: taskDeptselected,
                                  whenEmpty: 'Select Department',
                                );
                              }
                            }),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        Translate.of(context).translate('document'),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      BlocListener<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                        listener: (context, docState) {
                          if (docState is UserRoleDocTypeSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: Colors.green,
                                content: Text(
                                  Translate.of(context).translate('added_successfully'),
                                ),
                              ),
                            );
                          }
                          if (docState is UserRoleDocTypeDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text(Translate.of(context).translate('deleted_successfully')),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                          bloc: BlocProvider.of<UserRoleDocTypesListBloc>(context),
                          builder: (context, userRoleDocsList) {
                            if (userRoleDocsList is UserRoleDocTypesLoading) {
                              return Center(
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            } else if (userRoleDocsList is UserRoleDocTypesSuccess) {
                              docSelected = userRoleDocsList.userroleDocType.map((element) => element.documentType.name).toList();
                              return Container(
                                height: 80,
                                child: MyDocDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      docSelected = x;
                                    });
                                  },
                                  selectedValues: docSelected,
                                  whenEmpty: 'Document Feature',
                                ),
                              );
                            } else {
                              return MyDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    docSelected = x;
                                  });
                                },
                                selectedValues: docSelected,
                                whenEmpty: 'Document Feature',
                              );
                            }
                          },
                        ),
                      ),
                      BlocListener<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                        listener: (context, docState) {
                          if (docState is UserRoleTrainingTypeSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: Colors.green,
                                content: Text(
                                  "Assigned Training Type to Task Creator User Successfully",
                                ),
                              ),
                            );
                          }
                          if (docState is UserRoleTrainingTypeDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text("Deleted Training Type to Task Creator User Successfully"),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                          bloc: BlocProvider.of<UserRoleTrainingTypesListBloc>(context),
                          builder: (context, userRoleTrainingList) {
                            if (userRoleTrainingList is UserRoleTrainingTypesLoading) {
                              return Center(
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            } else if (userRoleTrainingList is UserRoleTrainingTypesSuccess) {
                              trainingTypesSelected = userRoleTrainingList.userRoleTrainingType.map((element) => element.trainingType.name).toList();
                              return Container(
                                height: 80,
                                child: MyTrainingDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      trainingTypesSelected = x;
                                    });
                                  },
                                  selectedValues: trainingTypesSelected,
                                  whenEmpty: 'Select Training Type',
                                ),
                              );
                            } else {
                              return MyTrainingDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    trainingTypesSelected = x;
                                  });
                                },
                                selectedValues: trainingTypesSelected,
                                whenEmpty: 'Select Training Type',
                              );
                            }
                          },
                        ),
                      ),
                      BlocListener<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                        listener: (context, viewState) {
                          if (viewState is UserRoleViewTypeSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: Colors.green,
                                content: Text(
                                  "Assigned View Type to Task Creator User Successfully",
                                ),
                              ),
                            );
                          }
                          if (viewState is UserRoleViewTypeDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text("Deleted View Type to Task Creator User Successfully"),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                          bloc: BlocProvider.of<UserRoleViewTypesListBloc>(context),
                          builder: (context, userRoleViewList) {
                            if (userRoleViewList is UserRoleViewTypesLoading) {
                              return Center(
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            } else if (userRoleViewList is UserRoleViewTypesSuccess) {
                              viewTypesSelected = userRoleViewList.userroleTaskType.map((element) => element.name).toList();
                              return Container(
                                height: 80,
                                child: MyViewDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      viewTypesSelected = x;
                                    });
                                  },
                                  selectedValues: viewTypesSelected,
                                  whenEmpty: 'Select View Type',
                                ),
                              );
                            } else {
                              return MyViewDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    viewTypesSelected = x;
                                  });
                                },
                                selectedValues: viewTypesSelected,
                                whenEmpty: 'Select View Type',
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          width: 12,
        ),
        Visibility(
          visible: showLeaders.length != 0 || widget.roleId == 3,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                Translate.of(context).translate('authorities_for_small_leader'),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 18,
              ),
              Container(
                width: 240,
                decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                padding: EdgeInsets.all(20),
                child: Container(
                  width: 230,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Translate.of(context).translate('department'),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      BlocListener<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                        listener: (context, state) {
                          if (state is UserRoleDepartmentSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text(Translate.of(context).translate('added_successfully')),
                            ));
                          }
                          if (state is UserRoleDepartmentDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text(Translate.of(context).translate('deleted_successfully')),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                          bloc: BlocProvider.of<UserRoleDepartmentsListBloc>(context),
                          builder: (context, userRoleDepartmentsList) {
                            if (userRoleDepartmentsList is UserRoleDepartmentsLoading) {
                              return Text(
                                "Select Department",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 12,
                                ),
                              );
                            } else if (userRoleDepartmentsList is UserRoleDepartmentsSuccess) {
                              smallLeaderSelected = userRoleDepartmentsList.userroleDepartment.map((element) => element.department.name).toList();
                              return MyDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    smallLeaderSelected = x;
                                  });
                                },
                                selectedValues: smallLeaderSelected,
                                whenEmpty: 'Select Department',
                              );
                            } else {
                              return MyDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    smallLeaderSelected = x;
                                  });
                                },
                                selectedValues: smallLeaderSelected,
                                whenEmpty: 'Select Department',
                              );
                            }
                          },
                        ),
                      ),
                      BlocListener<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                        listener: (context, viewState) {
                          if (viewState is UserRoleViewTypeSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: Colors.green,
                                content: Text(
                                  "Assigned View Type to Task Creator User Successfully",
                                ),
                              ),
                            );
                          }
                          if (viewState is UserRoleViewTypeDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text("Deleted View Type to Task Creator User Successfully"),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                          bloc: BlocProvider.of<UserRoleViewTypesListBloc>(context),
                          builder: (context, userRoleViewList) {
                            if (userRoleViewList is UserRoleViewTypesLoading) {
                              return Center(
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            } else if (userRoleViewList is UserRoleViewTypesSuccess) {
                              viewTypesSelected = userRoleViewList.userroleTaskType.map((element) => element.name).toList();
                              return Container(
                                height: 80,
                                child: MyViewDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      viewTypesSelected = x;
                                    });
                                  },
                                  selectedValues: viewTypesSelected,
                                  whenEmpty: 'Select View Type',
                                ),
                              );
                            } else {
                              return MyViewDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    viewTypesSelected = x;
                                  });
                                },
                                selectedValues: viewTypesSelected,
                                whenEmpty: 'Select View Type',
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          width: 12,
        ),
        Visibility(
          visible: showBigLeaders.length != 0 || widget.roleId == 4,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                Translate.of(context).translate('authorities_for_big_leader'),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 18,
              ),
              Container(
                width: 240,
                decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                padding: EdgeInsets.all(20),
                child: Container(
                  width: 230,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Translate.of(context).translate('department'),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      BlocListener<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                        listener: (context, state) {
                          if (state is UserRoleDepartmentSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.green,
                              content: Text("Assigned User Role Department to Big Leader User Successfully"),
                            ));
                          }
                          if (state is UserRoleDepartmentDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text("Deleted User Role Department to Big Leader User Successfully"),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleDepartmentsListBloc, UserRoleDepartmentsListState>(
                            bloc: BlocProvider.of<UserRoleDepartmentsListBloc>(context),
                            builder: (context, userRoleDepartmentsList) {
                              if (userRoleDepartmentsList is UserRoleDepartmentsLoading) {
                                return Text(
                                  "Select Department",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                  ),
                                );
                              } else if (userRoleDepartmentsList is UserRoleDepartmentsSuccess) {
                                bigLeaderSelected = userRoleDepartmentsList.userroleDepartment.map((element) => element.department.name).toList();
                                return MyDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      bigLeaderSelected = x;
                                    });
                                  },
                                  selectedValues: bigLeaderSelected,
                                  whenEmpty: 'Select Department',
                                );
                              } else {
                                return MyDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      bigLeaderSelected = x;
                                    });
                                  },
                                  selectedValues: bigLeaderSelected,
                                  whenEmpty: 'Select Department',
                                );
                              }
                            }),
                      ),
                      BlocListener<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                        listener: (context, viewState) {
                          if (viewState is UserRoleViewTypeSaveSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: Colors.green,
                                content: Text(
                                  "Assigned View Type to Task Creator User Successfully",
                                ),
                              ),
                            );
                          }
                          if (viewState is UserRoleViewTypeDeleteSuccess) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              backgroundColor: Colors.red,
                              content: Text("Deleted View Type to Task Creator User Successfully"),
                            ));
                          }
                        },
                        child: BlocBuilder<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                          bloc: BlocProvider.of<UserRoleViewTypesListBloc>(context),
                          builder: (context, userRoleViewList) {
                            if (userRoleViewList is UserRoleViewTypesLoading) {
                              return Center(
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(),
                                ),
                              );
                            } else if (userRoleViewList is UserRoleViewTypesSuccess) {
                              viewTypesSelected = userRoleViewList.userroleTaskType.map((element) => element.name).toList();
                              return Container(
                                height: 80,
                                child: MyViewDropDownMultiSelect(
                                  onChanged: (List<String> x) {
                                    setState(() {
                                      viewTypesSelected = x;
                                    });
                                  },
                                  selectedValues: viewTypesSelected,
                                  whenEmpty: 'Select View Type',
                                ),
                              );
                            } else {
                              return MyViewDropDownMultiSelect(
                                onChanged: (List<String> x) {
                                  setState(() {
                                    viewTypesSelected = x;
                                  });
                                },
                                selectedValues: viewTypesSelected,
                                whenEmpty: 'Select View Type',
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          width: 12,
        ),
        Visibility(
          visible: widget.multiRolesId.contains("6") || showAdmin.length != 0,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                Translate.of(context).translate('authorities_for_admin'),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 18,
              ),
              BlocListener<UserAdminPageDepartmentsBloc, UserAdminPageDepartmentsState>(
                listener: (context, state) {
                  if (state is UserAdminPageDepartmentSaveSuccess) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      backgroundColor: Colors.green,
                      content: Text("Added User Admin Page Department Successfully"),
                    ));
                  }
                  if (state is UserAdminPageDepartmentDeleteSuccess) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      backgroundColor: Colors.red,
                      content: Text("Deleted User Admin Page Department Successfully"),
                    ));
                  }
                },
                child: BlocListener<UserAdminPagesBloc, UserAdminPagesState>(
                  listener: (context, state) {
                    if (state is UserAdminPageSaveSuccess) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        backgroundColor: Colors.green,
                        content: Text("Added User Admin Page Successfully"),
                      ));
                    }
                    if (state is UserAdminPageDeleteSuccess) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        backgroundColor: Colors.red,
                        content: Text("Deleted User Admin Page Successfully"),
                      ));
                    }
                  },
                  child: BlocBuilder<UserAdminPagesBloc, UserAdminPagesState>(
                    bloc: BlocProvider.of<UserAdminPagesBloc>(context),
                    builder: (context, userAdminPageDepartmentsList) {
                      if (userAdminPageDepartmentsList is UserAdminPagesLoading) {
                        return Container(
                          width: 240,
                          child: Center(
                            child: SizedBox(
                              width: 30,
                              height: 30,
                              child: CircularProgressIndicator(),
                            ),
                          ),
                        );
                      } else if (userAdminPageDepartmentsList is UserAdminPagesSuccess) {
                        return Container(
                          width: 240,
                          decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                          padding: EdgeInsets.all(20),
                          child: BlocBuilder<AdminPagesBloc, AdminPagesState>(
                            bloc: BlocProvider.of<AdminPagesBloc>(context),
                            builder: (context, adminPagesSt) {
                              if (adminPagesSt is AdminPagesLoading) {
                                return Center(
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              } else if (adminPagesSt is AdminPagesSuccess) {
                                return ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: adminPagesSt.adminPages.length,
                                  itemBuilder: (context, i) {
                                    // return AdminAuthorities(
                                    //     userAdminPageDepartmentsList:
                                    //         userAdminPageDepartmentsList
                                    //             .userAdminPages,
                                    //     adminPages: adminPages.adminPages[i]);
                                    final userAdminPagesRepository = UserAdminPagesRepository();
                                    int userAdminPageDepartmentId;
                                    int userAdminPageIdFk;
                                    String userRoleId;
                                    List<String> rolesId = UtilPreferences.getStringList(
                                      Preferences.multipleUserRoleId,
                                    );
                                    if (rolesId != null) {
                                      var map = rolesId.asMap();
                                      print("map $map");
                                      map.forEach((key, value) {
                                        if (value.contains("管理员"
                                            // Translate.of(context).translate('admin'),
                                            )) {
                                          List<String> record = value.replaceAll("{", " ").replaceAll("}", " ").split(",").toList();
                                          final rec = record.first.split(":").toList();
                                          userRoleId = rec.last;
                                        }
                                      });
                                    }
                                    userAdminPageDepartmentsList.userAdminPages.map((element) {
                                      if (element.adminPageIdFk == adminPagesSt.adminPages[i].id && element.userRoleIdFk == int.parse(userRoleId)) {
                                        adminPagesSt.adminPages[i].isChecked = true;
                                        userAdminPageIdFk = element.id;
                                      }
                                      if (adminPagesSt.adminPages[i].id == element.adminPageIdFk && element.userRoleIdFk == int.parse(userRoleId)) {
                                        userAdminPagesRepository.saveUserAdmingPageRecord(element.id, adminPagesSt.adminPages[i].name);
                                      }

                                      if (element.userAdminPageDepartments != null && element.userAdminPageDepartments.length > 0) {
                                        element.userAdminPageDepartments.map((e) {
                                          if (element.adminPageIdFk == adminPagesSt.adminPages[i].id && element.userRoleIdFk == int.parse(userRoleId)) {
                                            userAdminPageDepartmentId = e.id;
                                          }
                                        }).toList();

                                        if (adminPagesSt.adminPages[i].id == element.adminPageIdFk && adminPagesSt.adminPages[i].id == 6 && element.userRoleIdFk == int.parse(userRoleId)) selectedAdminDepartsItems = element.userAdminPageDepartments.map((e) => e.department.name).toList();

                                        if (adminPagesSt.adminPages[i].id == element.adminPageIdFk && adminPagesSt.adminPages[i].id == 7 && element.userRoleIdFk == int.parse(userRoleId)) selectedAdminDepartMngmtItems = element.userAdminPageDepartments.map((e) => e.department.name).toList();
                                      }
                                    }).toList();

                                    return adminPagesSt.adminPages[i].parentAdminPageIdFk == 1
                                        ? Column(
                                            children: [
                                              CheckboxListTile(
                                                activeColor: Color(0xff00A4E3),
                                                dense: true,
                                                contentPadding: EdgeInsets.zero,
                                                title: new Text(
                                                  adminPagesSt.adminPages[i].name,
                                                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                                ),
                                                value: adminPagesSt.adminPages[i].isChecked,
                                                onChanged: (value) {
                                                  setState(
                                                    () {
                                                      adminPagesSt.adminPages[i].isChecked = value;
                                                      if (value == true) {
                                                        AppBloc.userAdminPageBloc.add(
                                                          OnCreateUserAdminPage(
                                                            adminPageId: adminPagesSt.adminPages[i].id,
                                                            adminPageName: adminPagesSt.adminPages[i].name,
                                                            roleName: Translate.of(context).translate('admin'),
                                                          ),
                                                        );
                                                      } else {
                                                        AppBloc.userAdminPageBloc.add(
                                                          OnRemoveUserAdminPage(adminPageName: adminPagesSt.adminPages[i].name, userAdminPageIdFk: userAdminPageIdFk),
                                                        );
                                                      }
                                                    },
                                                  );
                                                },
                                              ),
                                              if (adminPagesSt.adminPages[i].departments == true && adminPagesSt.adminPages[i].id == 6 && adminPagesSt.adminPages[i].isChecked)
                                                MyAdminViewDropDownMultiSelect(
                                                    onChanged: (List<String> x) {
                                                      setState(() {
                                                        AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                                                        selectedAdminDepartsItems = x;
                                                      });
                                                    },
                                                    selectedValues: selectedAdminDepartsItems,
                                                    whenEmpty: 'Select Department',
                                                    adminPageName: adminPagesSt.adminPages[i].name,
                                                    userAdminPageDepartmentId: userAdminPageDepartmentId,
                                                    userAdminPageIdFk: userAdminPageIdFk),
                                              if (adminPagesSt.adminPages[i].departments == true && adminPagesSt.adminPages[i].id == 7 && adminPagesSt.adminPages[i].isChecked)
                                                BlocListener<UserAdminPageDepartmentsBloc, UserAdminPageDepartmentsState>(
                                                  listener: (context, state) {
                                                    if (state is UserAdminPageDepartmentSaveSuccess) {
                                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                                        backgroundColor: Colors.green,
                                                        content: Text("Added User Admin Page Department"),
                                                      ));
                                                    }
                                                    if (state is UserAdminPageSaveFail) {}
                                                  },
                                                  child: MyAdminViewDropDownMultiSelect(
                                                    onChanged: (List<String> x) {
                                                      setState(() {
                                                        AppBloc.userAdminPageBloc.add(OnLoadUserAdminPagesWithDepartment());
                                                        selectedAdminDepartMngmtItems = x;
                                                      });
                                                    },
                                                    selectedValues: selectedAdminDepartMngmtItems,
                                                    whenEmpty: 'Select Department',
                                                    adminPageName: adminPagesSt.adminPages[i].name,
                                                    userAdminPageDepartmentId: userAdminPageDepartmentId,
                                                    userAdminPageIdFk: userAdminPageIdFk,
                                                  ),
                                                ),
                                            ],
                                          )
                                        : Container();
                                  },
                                );
                              } else {
                                return Center(
                                  child: Container(
                                    child: Text("Some thing went wrong"),
                                  ),
                                );
                              }
                            },
                          ),
                        );
                      } else if (userAdminPageDepartmentsList is UserAdminPagesFail) {
                        return Container(
                          child: Text(userAdminPageDepartmentsList.code),
                        );
                      } else {
                        return Container(
                          width: 240,
                          decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                          padding: EdgeInsets.all(20),
                          child: BlocBuilder<AdminPagesBloc, AdminPagesState>(
                            bloc: BlocProvider.of<AdminPagesBloc>(context),
                            builder: (context, adminPages) {
                              if (adminPages is AdminPagesLoading) {
                                return Center(
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              } else if (adminPages is AdminPagesSuccess) {
                                return ListView.builder(
                                    shrinkWrap: true,
                                    itemCount: adminPages.adminPages.length,
                                    itemBuilder: (context, i) {
                                      return adminPages.adminPages[i].parentAdminPageIdFk == 1
                                          ? Column(
                                              children: [
                                                CheckboxListTile(
                                                  activeColor: Color(0xff00A4E3),
                                                  dense: true,
                                                  contentPadding: EdgeInsets.zero,
                                                  title: new Text(
                                                    adminPages.adminPages[i].name,
                                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                                  ),
                                                  value: adminPages.adminPages[i].isChecked,
                                                  onChanged: (value) {
                                                    setState(
                                                      () {
                                                        adminPages.adminPages[i].isChecked = value;
                                                        if (value == true) {
                                                          AppBloc.userAdminPageBloc.add(
                                                            OnCreateUserAdminPage(
                                                              adminPageId: adminPages.adminPages[i].id,
                                                              adminPageName: adminPages.adminPages[i].name,
                                                              roleName: Translate.of(context).translate('admin'),
                                                            ),
                                                          );
                                                        } else {
                                                          AppBloc.userAdminPageBloc.add(
                                                            OnRemoveUserAdminPage(
                                                              adminPageName: adminPages.adminPages[i].name,
                                                            ),
                                                          );
                                                        }
                                                      },
                                                    );
                                                  },
                                                ),
                                                if (adminPages.adminPages[i].departments == true && adminPages.adminPages[i].id == 6 && adminPages.adminPages[i].isChecked)
                                                  MyAdminViewDropDownMultiSelect(
                                                    onChanged: (List<String> x) {
                                                      setState(() {
                                                        selectedAdminDepartsItems = x;
                                                      });
                                                    },
                                                    selectedValues: selectedAdminDepartsItems,
                                                    whenEmpty: 'Select Something',
                                                    adminPageName: adminPages.adminPages[i].name,
                                                  ),
                                                if (adminPages.adminPages[i].departments == true && adminPages.adminPages[i].id == 7 && adminPages.adminPages[i].isChecked)
                                                  MyAdminViewDropDownMultiSelect(
                                                    onChanged: (List<String> x) {
                                                      setState(() {
                                                        selectedAdminDepartMngmtItems = x;
                                                      });
                                                    },
                                                    selectedValues: selectedAdminDepartMngmtItems,
                                                    whenEmpty: 'Select Department',
                                                    adminPageName: adminPages.adminPages[i].name,
                                                  ),
                                              ],
                                            )
                                          : Container();
                                    });
                              } else {
                                return Center(
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              }
                            },
                          ),
                        );
                      }
                    },
                  ),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          width: 12,
        ),
        Visibility(
          visible: widget.multiRolesId.contains("7") || showViewer.length != 0,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                Translate.of(context).translate('authorities_for_viewer'),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 18,
              ),
              BlocBuilder<UserAdminPagesBloc, UserAdminPagesState>(
                  bloc: BlocProvider.of<UserAdminPagesBloc>(context),
                  builder: (context, userAdminPageDepartmentsList) {
                    if (userAdminPageDepartmentsList is UserAdminPagesLoading) {
                      return Container(
                        width: 240,
                        child: Center(
                          child: SizedBox(
                            width: 30,
                            height: 30,
                            child: CircularProgressIndicator(),
                          ),
                        ),
                      );
                    } else if (userAdminPageDepartmentsList is UserAdminPagesSuccess) {
                      return Container(
                        width: 244,
                        decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                        padding: EdgeInsets.all(20),
                        child: BlocBuilder<AdminPagesBloc, AdminPagesState>(
                            bloc: BlocProvider.of<AdminPagesBloc>(context),
                            builder: (context, adminPages) {
                              print(adminPages);
                              if (adminPages is AdminPagesLoading) {
                                return Center(
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              } else if (adminPages is AdminPagesSuccess) {
                                return MyDynamicAdminTreeView(
                                  userData: userAdminPageDepartmentsList.userAdminPages,
                                  data: adminPages.adminPages,
                                  width: 200,
                                  config: AdminConfig(rootId: "2", parentPaddingEdgeInsets: EdgeInsets.only(left: 0, top: 0, bottom: 0)),
                                );
                              } else {
                                return Center(
                                  child: Container(
                                    width: 30,
                                    height: 30,
                                    child: CircularProgressIndicator(),
                                  ),
                                );
                              }
                            }),
                      );
                    } else {
                      return Container(
                        width: 244,
                        decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xffeeeeee))),
                        padding: EdgeInsets.all(20),
                        child: BlocBuilder<AdminPagesBloc, AdminPagesState>(
                            bloc: BlocProvider.of<AdminPagesBloc>(context),
                            builder: (context, adminPages) {
                              if (adminPages is AdminPagesLoading) {
                                return Container();
                              } else if (adminPages is AdminPagesSuccess) {
                                return MyDynamicAdminTreeView(
                                  contxt: context,
                                  data: adminPages.adminPages,
                                  width: 200,
                                  config: AdminConfig(rootId: "2", parentPaddingEdgeInsets: EdgeInsets.only(left: 0, top: 0, bottom: 0)),
                                );
                              } else {
                                return Container();
                              }
                            }),
                      );
                    }
                  }),
            ],
          ),
        ),
      ],
    );
  }
}
