import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

/// for creator dashboard
class UsersFilterBox extends StatefulWidget {
  const UsersFilterBox({
    Key key,
  }) : super(key: key);

  @override
  _FiltersBoxState createState() => _FiltersBoxState();
}

class _FiltersBoxState extends State<UsersFilterBox> {
  var departmentIdFk;
  List<UserAdminPageDepts> userAdminPageDepartments = [];
  List<UserRoles> userRoles;
  final _focusSearch = FocusNode();
  final _textSearchController = TextEditingController();

  @override
  void initState() {
    super.initState();

    AppBloc.departmentBlocs.add(OnLoadDepartments());
    userRoles = Application.user.userRoles;
    userRoles.forEach((e) {
      if (e.roleIdFk == 6) {
        e.userAdminPagees.forEach((e) {
          userAdminPageDepartments.addAll(e.userAdminPageDepartments);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(children: [
        Container(
            color: Colors.grey.withOpacity(.2),
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  Translate.of(context).translate("filters"),
                  textAlign: TextAlign.start,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                OutlinedButton(
                  child: Text(
                    Translate.of(context).translate('clear_filter'),
                  ),
                  onPressed: () {
                    setState(() {
                      departmentIdFk = null;
                      AppBloc.usersBloc
                          .add(OnLoadFilteredUsers(departmentIdFk: null));
                    });
                  },
                  style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.lightBlueAccent)),
                ),
              ],
            )),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              children: [
                const SizedBox(width: 10),
                userAdminPageDepartments.isNotEmpty
                    ? Container(
                        width: 120,
                        child: createDropdownButton(
                          hint: Translate.of(context).translate('department'),
                          value: departmentIdFk,
                          items: userAdminPageDepartments
                              .map((e) => DropdownMenuItem(
                                  child:
                                      Text(e.adminPageDept.name, style: text12),
                                  value: e.adminPageDept.id))
                              .toList(),
                          onChanged: (newValue) {
                            setState(() {
                              AppBloc.usersBloc.add(OnLoadFilteredUsers(
                                  departmentIdFk: [newValue]));
                            });
                          },
                        ),
                      )
                    : BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                        bloc: BlocProvider.of<DepartmentsListBloc>(context),
                        builder: (context, state) {
                          if (state is DepartmentsSuccess) {
                            return createDropdownButton(
                              hint:
                                  Translate.of(context).translate('department'),
                              value: departmentIdFk,
                              items: state.departments
                                  .map((e) => DropdownMenuItem(
                                      child: Text(e.name, style: text12),
                                      value: e.id))
                                  .toList(),
                              onChanged: (newValue) {
                                setState(() {
                                  AppBloc.usersBloc.add(OnLoadFilteredUsers(
                                      departmentIdFk: [newValue]));
                                });
                              },
                            );
                          } else if (state is DepartmentsLoading) {
                            return LoadingBox(
                              width: 20,
                              height: 20,
                            );
                          } else {
                            return Text("load departments failed.");
                          }
                        },
                      ),
                SizedBox(
                  width: 15,
                ),
                Container(
                  width: 200,
                  child: AppTextInput(
                    height: 36,
                    borderColor: Colors.black.withOpacity(.06),
                    controller: _textSearchController,
                    hintText:
                        Translate.of(context).translate('Search for User'),
                    textInputAction: TextInputAction.done,
                    onChanged: (text) {
                      setState(() {
                        AppBloc.usersBloc
                            .add(OnLoadFilteredUsers(username: text));
                      });
                    },
                    onTapIcon: () {
                      setState(() {
                        _textSearchController.clear();
                        AppBloc.usersBloc
                            .add(OnLoadFilteredUsers(departmentIdFk: null));
                      });
                    },
                    icon: Icon(
                      Icons.close,
                      size: 13,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  Widget createDropdownButton({
    String hint,
    dynamic value,
    List<DropdownMenuItem<dynamic>> items,
    Function(dynamic) onChanged,
  }) {
    return Container(
      height: 36,
      padding: const EdgeInsets.fromLTRB(7, 10, 7, 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black.withOpacity(.06), width: 1),
      ),
      child: DropdownButton(
        hint: Text(
          hint,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
        ),
        icon: const Icon(
          Icons.expand_more_outlined,
          color: Colors.blueAccent,
        ),
        elevation: 8,
        underline: Container(color: Colors.white),
        iconSize: 18,
        value: value,
        items: items,
        onChanged: onChanged,
      ),
    );
  }

  get text12 => const TextStyle(fontSize: 12);
}
