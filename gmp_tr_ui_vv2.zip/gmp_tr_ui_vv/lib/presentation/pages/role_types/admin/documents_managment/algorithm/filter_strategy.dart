import 'package:flutter/material.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/date_picker.dart';

enum FilterEnum {
  NONE,
  DocumentFeature,
  TrainingType,
  Department,
  Time,
}

class AfterFilterNotification extends Notification {}

abstract class FilterStrategy {
  dynamic value;

  List<DocumentsModel> doFilter(List<DocumentsModel> source) {
    print("dp $value");
    return source;
  }

  FilterEnum getFilterType();
}

class FilterByDocumentFeature extends FilterStrategy {
  @override
  List<DocumentsModel> doFilter(List<DocumentsModel> source) {
    return source.where((e) => e.documentTypeIdFk == value).toList();
  }

  @override
  FilterEnum getFilterType() {
    return FilterEnum.DocumentFeature;
  }
}

class FilterByTrainingType extends FilterStrategy {
  @override
  List<DocumentsModel> doFilter(List<DocumentsModel> source) {
    print(value);
    print("sss $source");
    return source.where((e) => e.trainingTypeIdFk == value).toList();
  }

  @override
  FilterEnum getFilterType() {
    return FilterEnum.TrainingType;
  }
}

class FilterByDepartment extends FilterStrategy {
  @override
  List<DocumentsModel> doFilter(List<DocumentsModel> source) {
    // FIXME: can not find department reference in task model.
    return source;
  }

  @override
  FilterEnum getFilterType() {
    return FilterEnum.Department;
  }
}

class FilterByTime extends FilterStrategy {
  final startTimeController = DatePickerController();
  final endTimeController = DatePickerController();

  final Map<String, int> kv = {
    "创建时间": 1,
    "审核时间": 2,
    "审批时间": 3,
  };

  @override
  List<DocumentsModel> doFilter(List<DocumentsModel> source) {
    // DateTime startTime = startTimeController.selectedDate;
    // DateTime endTime = endTimeController.selectedDate;

    // FIXME
    switch (value) {
      // Creator Sign Time
      case 1:
        break;
      // Small Leader Sign Time
      case 2:
        break;
      // Big Leader Sign Time
      case 3:
        break;
      // End Time
      case 4:
        break;
      // Finish Time
      case 5:
        break;
      default:
        return source;
    }
    return source;
  }

  @override
  FilterEnum getFilterType() {
    return FilterEnum.Time;
  }
}

class FilterByNothing extends FilterStrategy {
  @override
  FilterEnum getFilterType() {
    return FilterEnum.NONE;
  }
}
