import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/filters_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import '../../../../../global.dart';
import 'algorithm/documents_list_controller.dart';
import 'document_detail.dart';
import 'file_dialog.dart';

enum DocWidgetChange { documentsList, info }

/// DOCUMENTS MANAGEMENT
class DocumentManagementPage extends StatefulWidget {
  const DocumentManagementPage({Key key}) : super(key: key);

  @override
  _DocumentManagementPageState createState() => _DocumentManagementPageState();
}

///DATA TABLE VARIABLE DECLARATION

final int rowsPerPage = 10;
List<DocumentsModel> paginatedDocuments = [];

class _DocumentManagementPageState extends State<DocumentManagementPage> {
  DocWidgetChange selectedWidgetPage = DocWidgetChange.documentsList;
  DocumentsModel document;
  final documentsController = DocumentsListController();

  @override
  void initState() {
    super.initState();
    AppBloc.documentsBloc.add(OnLoadDocuments(taskDocuments: [
      ViewType.documents
    ]));
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case DocWidgetChange.documentsList:
        return documentsListWidget(context);
      case DocWidgetChange.info:
        return documentInfoWidget(context);
    }
    return documentsListWidget(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == DocWidgetChange.documentsList)
                    Text(
                      Translate.of(context).translate("document_managment"),
                      style: TextStyle(color: Color(0xff00439E), fontSize: widthOfScreen(context) * 0.025, fontWeight: FontWeight.bold),
                    ),
                  if (selectedWidgetPage == DocWidgetChange.info) Container(),
                  if (selectedWidgetPage == DocWidgetChange.info)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: AppButton(
                        Translate.of(context).translate('back'),
                        onPressed: () {
                          setState(() {
                            selectedWidgetPage = DocWidgetChange.documentsList;
                            // AppBloc.usersBloc.add(OnLoadUsers());
                          });
                        },
                        type: ButtonType.outline,
                        color: Color(0xff787E8C),
                      ),
                    ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Container(child: getCustomContainer(context))
            ],
          ),
        ),
      ],
    );
  }

  ///USER LISTS
  Widget documentsListWidget(context) {
    // int rowCount = 1;
    return Column(
      children: [
        AdminDocFiltersBox(),
        const SizedBox(height: 20),
        Container(
          width: double.infinity,
          child: BlocListener<DocumentsBloc, DocumentsState>(
            listener: (context, state) {
              if (state is OnUpdateDocumentStatusSuccess) {
                String status;
                Color color;
                if (state.docStatusId == 1) {
                  status = "Document Enabled";
                  color = Colors.green;
                } else if (state.docStatusId == 0) {
                  status = "Document Disabled";
                  color = Colors.red;
                }
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  backgroundColor: color,
                  content: Text(status),
                ));
              }
            },
            child: BlocBuilder<DocumentsBloc, DocumentsState>(
              bloc: BlocProvider.of<DocumentsBloc>(context),
              builder: (context, documentsList) {
                if (documentsList is DocumentsSuccess) {
                  // return buildDataTable(
                  //     context, buildDataRow(documentsList.documents));

                  DocDataSource docDataSource;
                  docDataSource = new DocDataSource(
                    documentsList.documents,
                    context,
                    onChanged: (List<int> x) {
                      setState(() {});
                    },
                  );

                  List<DocumentsModel> docCount = documentsList.documents;

                  return LayoutBuilder(builder: (context, constraints) {
                    return Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 360,
                              width: constraints.maxWidth,
                              child: SfDataGrid(
                                allowSorting: true,
                                source: docDataSource,
                                columnWidthMode: ColumnWidthMode.fill,
                                footerFrozenColumnsCount: 1,
                                columns: [
                                  GridColumn(
                                    columnName: 'title',
                                    width: 100,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('title'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'document',
                                    width: 100,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('document'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'description',
                                    width: 200,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('description'),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'createPerson',
                                    width: 200,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('create_person'),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'createdAt',
                                    minimumWidth: 150,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('created_time'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'department',
                                    minimumWidth: 150,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('department'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                      columnName: 'trainingType',
                                      minimumWidth: 150,
                                      label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('training_type'),
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                            softWrap: true,
                                          ))),
                                  GridColumn(
                                    columnName: 'documentFeature',
                                    minimumWidth: 150,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('document_feature'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'actions',
                                    width: 100,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        "",
                                      ),
                                    ),
                                  ),
                                ],
                                selectionMode: SelectionMode.single,
                                onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                  final index = docDataSource.rows.indexOf(addedRows.last);
                                  print("document >>>> $index");

                                  return true;
                                },
                                onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                  final index = docDataSource.rows.indexOf(addedRows.first);
                                  setState(() {
                                    selectedWidgetPage = DocWidgetChange.info;
                                    document = docCount[index];
                                  });
                                },
                              ),
                            ),
                            Container(
                              height: 52,
                              width: constraints.maxWidth,
                              child: SfDataPager(
                                delegate: docDataSource,
                                pageCount: docCount.length / rowsPerPage,
                                direction: Axis.horizontal,
                              ),
                            )
                          ],
                        ),
                      ],
                    );
                  });
                } else if (documentsList is DocumentsLoading) {
                  return LoadingBox(
                    height: 20,
                  );
                } else if (documentsList is DocumentsEmpty) {
                  return Center(child: Text("No Records"));
                } else {
                  return Text("load failed.");
                }
              },
            ),
          ),
        ),
      ],
    );
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }

  ///DOCUMENT INFO PAGE
  Widget documentInfoWidget(context) {
    return DocumentDetailPage(documentInfo: document);
  }
}

class DocDataSource extends DataGridSource {
  BuildContext contxt;

  int statusId;
  final Function(List<int>) onChanged;

  final Completer _completer = new Completer();
  DocDataSource(
    List<DocumentsModel> documentsData,
    context, {
    selectedIds,
    this.onChanged,
  }) {
    try {
      documents = documentsData;
      contxt = context;

      if (documents.length < rowsPerPage) {
        paginatedDocuments = documents.toList();
      } else {
        paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell(columnName: 'document', value: e.documentFiles),
              DataGridCell<String>(columnName: 'description', value: e.description),
              DataGridCell<String>(columnName: 'createPerson', value: e.docCreator.name),
              DataGridCell<String>(columnName: 'createdAt', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.createdAt)).toString()),
              DataGridCell<String>(columnName: 'department', value: e.department.name),
              DataGridCell<String>(columnName: 'trainingType', value: e.trainingType.name),
              DataGridCell<String>(
                columnName: 'documentFeature',
                value: e.documentType.name,
              ),
              DataGridCell(columnName: "actions", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[0].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          child: InkWell(
            onTap: () async {
              await showDialog(context: contxt, builder: (_) => FileDialog(documentFiles: row.getCells()[1].value));
            },
            child: Text(Translate.of(contxt).translate('view'),
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xff00A4E3),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[2].value),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[3].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[4].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[5].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[6].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[7].value.toString()),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Icon(
                Icons.history_outlined,
                color: Color(0xff00A4E3),
              ),
              // SizedBox(width: 15),
              // Tooltip(
              //   message: "Disable Document",
              //   child: InkWell(
              //     onTap: () {
              //       print(row.getCells()[8].value.status);
              //       if (row.getCells()[8].value.status == 1) {
              //         Api.updateDocumentStatus({
              //           "id": [row.getCells()[8].value.id],
              //           "document_status_id_fk": 0,
              //         });
              //         // AppBloc.documentsBloc.add(OnUpdateDocumentStatus(
              //         //     id: row.getCells()[8].value.id, status: 0));
              //         AppBloc.documentsBloc.add(
              //             OnLoadDocuments(taskDocuments: [ViewType.documents]));
              //       } else {
              //         Api.updateDocumentStatus({
              //           "id": [row.getCells()[8].value.id],
              //           "document_status_id_fk": 1,
              //         });
              //         // AppBloc.documentsBloc.add(OnUpdateDocumentStatus(
              //         //     id: row.getCells()[8].value.id, status: 1));
              //         AppBloc.documentsBloc.add(
              //             OnLoadDocuments(taskDocuments: [ViewType.documents]));
              //       }
              //       notifyListeners();
              //     },
              //     child: Icon(
              //       Icons.pan_tool_outlined,
              //       color: row.getCells()[8].value.status == 1
              //           ? Color(0xff00A4E3)
              //           : Colors.red,
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ],
    );
  }
}
