import 'dart:html';

import 'package:flutter/material.dart';
import 'dart:ui' as ui;

class ViewDocument extends StatefulWidget {
  final String path;
  const ViewDocument({Key key, this.path}) : super(key: key);

  @override
  _ViewDocumentState createState() => _ViewDocumentState();
}

class _ViewDocumentState extends State<ViewDocument>
    with AutomaticKeepAliveClientMixin {
  String src;
  final IFrameElement _iframeElement = IFrameElement();
  final ImageElement img = ImageElement();

  @override
  void initState() {
    super.initState();
    src =
        "http://139.9.146.31:3333${this.widget.path}#toolbar=0&navpanes=0&scrollbar=0";

    var splits = src.split('.');
    var parts = splits.last.split('#');
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'bmp'].contains(parts.first)) {
      img
        ..style.display = 'block'
        ..style.marginLeft = 'auto'
        ..style.marginRight = 'auto'
        ..style.objectFit = 'contain'
        ..src = src;
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        src,
        (int viewId) => img,
      );
    } else {
      _iframeElement
        ..src = src
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.border = 'none';
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        src,
        (int viewId) => _iframeElement,
      );
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          children: [
            Container(
              height: 40,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 20),
              child: Text(
                "This is document title",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              color: Colors.grey.withOpacity(.25),
            ),
          ],
        ),
        SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.75,
            padding: const EdgeInsets.all(20),
            child: HtmlElementView(
              viewType: src,
            ),
          ),
        ),
      ],
    );
  }
}
