import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/document_detail.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/heading_text.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/task_info.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/app_doc_status.dart';
import 'package:gmptr/presentation/widgets/app_task_status.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import '../../../../global.dart';

import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'widgets/filters_box.dart';

class VTHomePage extends StatefulWidget {
  const VTHomePage({Key key}) : super(key: key);

  @override
  _VTHomePageState createState() => _VTHomePageState();
}

///DATA TABLE VARIABLE DECLARATION
bool checkedBox = false;
List<int> selectedTaskIds = [];
List<int> selectedDocIds = [];
List<Task> paginatedTask = [];
final int rowsPerPage = 10;
List<DocumentsModel> paginatedDocuments = [];

class _VTHomePageState extends State<VTHomePage> {
  ViewTrainingWidgetChange selectedWidgetPage = ViewTrainingWidgetChange.dashboard;

  Task task;
  DocumentsModel document;
  int taskStatusId = 2;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  List<int> departIdFk = [];

  @override
  void initState() {
    super.initState();
    Application.user.userRoles
        .map((e) => e.userAdminPagees.map((e) {
              if (e.adminPageIdFk == UserAdminPageId.viewTraining) {
                e.userAdminPageDepartments.map((e) {
                  if (!departIdFk.contains(e.departmentIdfk)) departIdFk.add(e.departmentIdfk);
                }).toList();
              }
            }).toList())
        .toList();
    AppBloc.tasksDocBloc.add(
      OnLoadTaskDocEvent(viewType: [
        selectedViewTypeCommon
      ], taskDocStatusId: taskStatusId, multiDepartIdFk: departIdFk),
    );
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case ViewTrainingWidgetChange.dashboard:
        return taskController(context);

      case ViewTrainingWidgetChange.taskInfo:
        return taskInfo(context);
      case ViewTrainingWidgetChange.docInfo:
        return docInfo(context);
    }

    return taskController(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == ViewTrainingWidgetChange.dashboard) HeadingText(Translate.of(context).translate("signed_by_create_person")),
                  if (selectedWidgetPage == ViewTrainingWidgetChange.taskInfo || selectedWidgetPage == ViewTrainingWidgetChange.docInfo) Container(),
                  Row(
                    children: [
                      Wrap(
                        runSpacing: 20,
                        spacing: 40,
                        children: [
                          if (selectedWidgetPage == ViewTrainingWidgetChange.taskInfo)
                            Tooltip(
                              message: Translate.of(context).translate('close'),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    selectedWidgetPage = ViewTrainingWidgetChange.dashboard;
                                    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
                                      ViewType.regularTask
                                    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.close,
                                    color: Color(0xff00A4E3),
                                    size: 24,
                                  ),
                                ),
                              ),
                            ),
                          if (selectedWidgetPage == ViewTrainingWidgetChange.docInfo)
                            Tooltip(
                              message: Translate.of(context).translate('close'),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    selectedWidgetPage = ViewTrainingWidgetChange.dashboard;
                                    AppBloc.tasksDocBloc.add(
                                      OnLoadTaskDocEvent(viewType: [
                                        ViewType.documents
                                      ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId),
                                    );
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.close,
                                    color: Color(0xff00A4E3),
                                    size: 24,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),

              Container(child: getCustomContainer(context))
              // TaskTable(tasksController),
            ],
          ),
        ),
      ],
    );
  }

  Widget taskController(context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BlocBuilder<TaskDocBloc, TaskDocState>(
              bloc: BlocProvider.of<TaskDocBloc>(context),
              buildWhen: (previousState, currentState) {
                return previousState != currentState;
              },
              builder: (ctxt, state) {
                if (state is TaskDocSuccess) {
                  TaskDataSource taskDataSource;
                  DocDataSource docDataSource;
                  taskDataSource = new TaskDataSource(
                    state.tasks,
                    context,
                    taskStatusId,
                  );

                  List<Task> taskCount = state.tasks;
                  List<DocumentsModel> docCount = state.documents;

                  docDataSource = new DocDataSource(
                    state.documents,
                    context,
                    taskStatusId,
                    onChanged: (List<int> x) {
                      setState(() {
                        selectedDocIds = x;
                      });
                    },
                    selectedIds: selectedDocIds,
                  );

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ViewTrainingFiltersBox(
                        taskStatusId: taskStatusId,
                        departIdFk: departIdFk,
                        viewType: selectedViewTypeCommon,
                      ),
                      const SizedBox(height: 20),
                      LayoutBuilder(builder: (context, constraints) {
                        return Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 360,
                                  width: constraints.maxWidth,
                                  child: SfDataGrid(
                                    allowSorting: true,
                                    source: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                                    columnWidthMode: ColumnWidthMode.fill,
                                    footerFrozenColumnsCount: 1,
                                    columns: [
                                      GridColumn(
                                        columnName: 'title',
                                        width: 100,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('title'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'description',
                                        width: 200,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('description'),
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'version',
                                        width: 200,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('version'),
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                          ),
                                        ),
                                      ),
                                      // GridColumn(
                                      //   columnName: 'createdAt',
                                      //   minimumWidth: 150,
                                      //   label: Container(
                                      //     height: 50,
                                      //     color: Color(0xffEFF5FC),
                                      //     padding: EdgeInsets.all(16.0),
                                      //     alignment: Alignment.centerLeft,
                                      //     child: Text(
                                      //       Translate.of(context)
                                      //           .translate('created_time'),
                                      //     ),
                                      //   ),
                                      // ),
                                      GridColumn(
                                        columnName: 'beginTime',
                                        minimumWidth: 150,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('begin_time'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                          columnName: 'endTime',
                                          minimumWidth: 150,
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('end_time'),
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                softWrap: true,
                                              ))),
                                      GridColumn(
                                        columnName: 'createdDepWorker',
                                        minimumWidth: 150,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('created_dep_worker'),
                                          ),
                                        ),
                                      ),
                                      if (taskDataSource.rows.length > 0)
                                        GridColumn(
                                          columnName: 'students',
                                          minimumWidth: 150,
                                          label: Container(
                                            height: 50,
                                            color: Color(0xffEFF5FC),
                                            padding: EdgeInsets.all(16.0),
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              Translate.of(context).translate('students'),
                                            ),
                                          ),
                                        ),
                                      GridColumn(
                                        columnName: 'status',
                                        minimumWidth: 150,
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            "",
                                          ),
                                        ),
                                      ),
                                    ],
                                    selectionMode: SelectionMode.single,
                                    onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                      if (taskDataSource.rows.length > 0) {
                                        final index = taskDataSource.rows.indexOf(addedRows.last);
                                        print("task >>> $index");
                                      } else {
                                        final index = docDataSource.rows.indexOf(addedRows.last);
                                        print("document >>>> $index");
                                      }
                                      return true;
                                    },
                                    onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) async {
                                      if (taskDataSource.rows.length > 0) {
                                        final index = taskDataSource.rows.indexOf(addedRows.last);
                                        await showDialog(
                                            context: context,
                                            builder: (context) => CreatorTaskInfoWidget(
                                                  taskInfo: paginatedTask[index],
                                                ));
                                        // setState(() {
                                        //   selectedWidgetPage =
                                        //       ViewTrainingWidgetChange.taskInfo;
                                        //   task = taskCount[index];
                                        // });
                                      } else {
                                        final index = docDataSource.rows.indexOf(addedRows.first);
                                        print("document >>>> $index");
                                        await showDialog(
                                          context: context,
                                          builder: (context) => DocumentDetailPage(documentInfo: paginatedDocuments[index]),
                                        );
                                        // setState(() {
                                        //   selectedWidgetPage =
                                        //       ViewTrainingWidgetChange.docInfo;
                                        //   document = docCount[index];
                                        // });
                                      }
                                    },
                                  ),
                                ),
                                Container(
                                  height: 52,
                                  width: constraints.maxWidth,
                                  child: SfDataPager(
                                    delegate: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                                    pageCount: taskDataSource.rows.length > 0 ? (taskCount.length / 10).ceilToDouble() : docCount.length / 10,
                                    direction: Axis.horizontal,
                                  ),
                                )
                              ],
                            ),
                          ],
                        );
                      }),
                    ],
                  );
                } else if (state is TaskDocLoading) {
                  return LoadingBox(
                    height: 20,
                  );
                } else if (state is TaskDocEmpty) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ViewTrainingFiltersBox(
                        taskStatusId: taskStatusId,
                        departIdFk: departIdFk,
                        viewType: selectedViewTypeCommon,
                      ),
                      const SizedBox(height: 30),
                      Center(child: Text("No Records")),
                    ],
                  );
                } else {
                  return Text("load failed.");
                }
              },
            ),
          ],
        ),
      );

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }

  Widget taskInfo(context) {
    return TaskInfoWidget(taskInfo: task);
  }

  Widget docInfo(context) {
    return DocumentDetailPage(documentInfo: document);
  }
}

class TaskDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  TaskDataSource(List<Task> tasksData, context, int statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    try {
      if (tasks.length < 10) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              DataGridCell<String>(columnName: 'version', value: e.taskDocuments.first.document.version),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'beginTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.startDate)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'students',
                value: e.taskStudents.fold<String>("", (previousValue, element) => previousValue + element.taskUser.username + ', '),
              ),
              DataGridCell(columnName: "status", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[0].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[1].value.toString(),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value,
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                row.getCells()[1].value,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[2].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[3].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[4].value,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[5].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[6].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: TaskStatusWidget(taskStatusId: row.getCells()[7].value.taskStatusIdFk),
          ),
        ),
      ],
    );
  }
}

class DocDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int statusId;
  final Function(List<int>) onChanged;
  Task task;
  final Completer _completer = new Completer();
  DocDataSource(
    List<DocumentsModel> documentsData,
    context,
    int docStatusId, {
    selectedIds,
    this.onChanged,
  }) {
    try {
      documents = documentsData;
      contxt = context;
      statusId = docStatusId;

      if (documents.length < rowsPerPage) {
        paginatedDocuments = documents.toList();
      } else {
        paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              DataGridCell<String>(columnName: 'version', value: e.version),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'beginTime', value: ""),
              DataGridCell<String>(columnName: 'endTime', value: ""),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.docCreator.creatorDepartment.name + ", " + e.docCreator.name,
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> docIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[0].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[1].value),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[2].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[5].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: DocStatusWidget(docStatusId: row.getCells()[6].value.status),
          ),
        ),
      ],
    );
  }
}
