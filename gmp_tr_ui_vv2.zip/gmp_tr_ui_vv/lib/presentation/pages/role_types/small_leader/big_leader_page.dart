import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/document_detail.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/heading_text.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import '../../../../global.dart';
import 'widgets/filters_box.dart';

class SLBigLeaderPage extends StatefulWidget {
  const SLBigLeaderPage({Key key}) : super(key: key);

  @override
  _SLBigLeaderPageState createState() => _SLBigLeaderPageState();
}

List<int> selectedTaskIds = [];
List<int> selectedDocIds = [];
List<Task> paginatedTask = [];
final int rowsPerPage = 10;
List<DocumentsModel> paginatedDocuments = [];

class _SLBigLeaderPageState extends State<SLBigLeaderPage> {
  int taskStatusId = 6;
  SmallLeaderWidgets selectedWidget = SmallLeaderWidgets.dashboard;
  Task task;
  DocumentsModel document;
  @override
  void initState() {
    super.initState();
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], smallLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  Widget getCustomContainer(context) {
    switch (selectedWidget) {
      case SmallLeaderWidgets.dashboard:
        return dashboardController(context);
      case SmallLeaderWidgets.taskInfo:
        return taskInfo(context);
      case SmallLeaderWidgets.docInfo:
        return docInfo(context);
    }

    return dashboardController(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidget == SmallLeaderWidgets.dashboard) HeadingText(Translate.of(context).translate("signed_by_big_leader")),
                  if (selectedWidget == SmallLeaderWidgets.taskInfo) Container(),
                  if (selectedWidget == SmallLeaderWidgets.taskInfo || selectedWidget == SmallLeaderWidgets.docInfo)
                    Tooltip(
                      message: Translate.of(context).translate('close'),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedWidget = SmallLeaderWidgets.dashboard;

                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
                              ViewType.regularTask
                            ], smallLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
                          });
                        },
                        child: Icon(
                          Icons.close,
                          color: Color(0xff00A4E3),
                          size: 20,
                        ),
                      ),
                    ),
                  if (selectedWidget == SmallLeaderWidgets.docInfo)
                    Tooltip(
                      message: Translate.of(context).translate('close'),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selectedWidget = SmallLeaderWidgets.dashboard;

                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
                              3
                            ], smallLeaderIdFk: Application.user.id, taskDocStatusId: taskStatusId));
                          });
                        },
                        child: Icon(
                          Icons.close,
                          color: Color(0xff00A4E3),
                          size: 20,
                        ),
                      ),
                    ),
                ],
              ),
              // if (selectedWidget == SmallLeaderWidgets.dashboard)
              //   SizedBox(
              //     height: 20,
              //   ),
              if (selectedWidget == SmallLeaderWidgets.taskInfo || selectedWidget == SmallLeaderWidgets.docInfo)
                SizedBox(
                  height: 30,
                ),
              getCustomContainer(context)
            ],
          ),
        ),
      ],
    );
  }

  Widget dashboardController(context) {
    return Column(
      children: [
        SLFiltersBox(taskStatusId: taskStatusId),
        const SizedBox(height: 20),
        BlocBuilder<TaskDocBloc, TaskDocState>(
          bloc: BlocProvider.of<TaskDocBloc>(context),
          builder: (context, state) {
            if (state is TaskDocSuccess) {
              TaskDataSource taskDataSource;
              DocDataSource docDataSource;
              taskDataSource = new TaskDataSource(
                state.tasks,
                context,
                taskStatusId,
              );

              List<Task> taskCount = state.tasks;
              List<DocumentsModel> docCount = state.documents;

              docDataSource = new DocDataSource(
                state.documents,
                context,
                taskStatusId,
              );

              return LayoutBuilder(builder: (context, constraints) {
                return Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.5,
                          width: constraints.maxWidth,
                          child: SfDataGrid(
                            allowSorting: true,
                            source: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                            columnWidthMode: ColumnWidthMode.fill,
                            columns: [
                              GridColumn(
                                columnName: 'title',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('title'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'description',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('description'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'version',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('version'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                columnName: 'beginTime',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('begin_time'),
                                  ),
                                ),
                              ),
                              GridColumn(
                                  columnName: 'endTime',
                                  label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('end_time'),
                                      ))),
                              GridColumn(
                                columnName: 'createdDepWorker',
                                label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('created_dep_worker'),
                                  ),
                                ),
                              ),
                              if (taskDataSource.rows.length > 0)
                                GridColumn(
                                  columnName: 'students',
                                  minimumWidth: 150,
                                  label: Container(
                                    height: 50,
                                    color: Color(0xffEFF5FC),
                                    padding: EdgeInsets.all(16.0),
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      Translate.of(context).translate('students'),
                                    ),
                                  ),
                                ),
                            ],
                            selectionMode: SelectionMode.single,
                            onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                              if (taskDataSource.rows.length > 0) {
                                final index = taskDataSource.rows.indexOf(addedRows.last);
                                print("task >>> $index");
                              } else {
                                final index = docDataSource.rows.indexOf(addedRows.last);
                                print("document >>>> $index");
                              }
                              return true;
                            },
                            onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) async {
                              if (taskDataSource.rows.length > 0) {
                                final index = taskDataSource.rows.indexOf(addedRows.last);
                                await showDialog(
                                    context: context,
                                    builder: (context) => CreatorTaskInfoWidget(
                                          taskInfo: paginatedTask[index],
                                        ));
                                // setState(() {
                                //   selectedWidget = SmallLeaderWidgets.taskInfo;
                                //   task = taskCount[index];
                                // });
                              } else {
                                final index = docDataSource.rows.indexOf(addedRows.first);
                                print("document >>>> $index");
                                await showDialog(
                                  context: context,
                                  builder: (context) => DocumentDetailPage(documentInfo: paginatedDocuments[index]),
                                );
                                // setState(() {
                                //   selectedWidget = SmallLeaderWidgets.docInfo;
                                //   document = docCount[index];
                                // });
                              }
                            },
                          ),
                        ),
                        Container(
                          height: 52,
                          width: constraints.maxWidth,
                          child: SfDataPager(
                            delegate: taskDataSource.rows.length > 0 ? taskDataSource : docDataSource,
                            pageCount: taskDataSource.rows.length > 0 ? (taskCount.length / rowsPerPage).ceilToDouble() : docCount.length / rowsPerPage,
                            direction: Axis.horizontal,
                          ),
                        )
                      ],
                    ),
                  ],
                );
              });
            } else if (state is TaskDocLoading) {
              return LoadingBox();
            } else if (state is TaskDocEmpty) {
              return Center(child: Text("No Records"));
            } else {
              return Text("load failed.");
            }
          },
        ),
      ],
    );
  }

  Widget taskInfo(context) {
    return TaskInfoWidget(
      taskInfo: task,
    );
  }

  Widget docInfo(context) {
    return DocumentDetailPage(documentInfo: document);
  }
}

class TaskDataSource extends DataGridSource {
  BuildContext contxt;
  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  TaskDataSource(List<Task> tasksData, context, int statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    try {
      if (tasks.length < rowsPerPage) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.taskDocuments.first.document.version),
              DataGridCell<String>(columnName: 'beginTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.startDate)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'students',
                value: e.taskStudents.fold<String>("", (previousValue, element) => previousValue + element.taskUser.username + ', '),
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[0].value.toString(), child: Text(row.getCells()[0].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[1].value.toString(), child: Text(row.getCells()[1].value)),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[2].value.toString(), child: Text(row.getCells()[2].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[3].value.toString(), child: Text(row.getCells()[3].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[4].value.toString(), child: Text(row.getCells()[4].value)),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[5].value.toString(), child: Text(row.getCells()[5].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[6].value.toString(), child: Text(row.getCells()[6].value.toString())),
          ),
        ),
      ],
    );
  }
}

class DocDataSource extends DataGridSource {
  BuildContext contxt;
  int statusId;
  final Completer _completer = new Completer();
  DocDataSource(List<DocumentsModel> documentsData, context, int docStatusId) {
    try {
      documents = documentsData;
      contxt = context;
      statusId = docStatusId;

      if (documents.length < rowsPerPage) {
        paginatedDocuments = documents.toList();
      } else {
        paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.version),
              DataGridCell<String>(columnName: 'beginTime', value: ""),
              DataGridCell<String>(columnName: 'endTime', value: ""),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.docCreator.creatorDepartment.name + ", " + e.docCreator.name,
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[0].value.toString(), child: Text(row.getCells()[0].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[1].value.toString(), child: Text(row.getCells()[1].value)),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[2].value.toString(), child: Text(row.getCells()[2].value.toString())),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Tooltip(message: row.getCells()[5].value.toString(), child: Text(row.getCells()[5].value.toString())),
          ),
        ),
      ],
    );
  }
}
