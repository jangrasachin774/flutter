// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:gmptr/blocs/app_bloc.dart';
// import 'package:gmptr/blocs/bloc.dart';
// import 'package:gmptr/models/model.dart';
// import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
// import 'package:gmptr/presentation/pages/role_types/creator/widgets/selection_box.dart';
// import 'package:gmptr/utils/translate.dart';

// class SmallLeaderSignDialog extends StatefulWidget {
//   final int departmentId;

//   const SmallLeaderSignDialog(this.departmentId, {Key key}) : super(key: key);

//   @override
//   _SmallLeaderSignDialogState createState() => _SmallLeaderSignDialogState();
// }

// class _SmallLeaderSignDialogState extends State<SmallLeaderSignDialog> {
//   final bigLeaderSelection = SelectionBoxController();
//   final bigLeaderRoleId = 4;

//   @override
//   void initState() {
//     super.initState();
//     AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(
//         departmentId: widget.departmentId, roleId: bigLeaderRoleId));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Dialog(
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//       elevation: 16,
//       child: Stack(
//         children: [
//           Padding(
//             padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
//             child: Column(mainAxisSize: MainAxisSize.min, children: [
//               Text(
//                 Translate.of(context).translate("choose_big_leader"),
//                 style: TextStyle(
//                     fontSize: 24,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.lightBlueAccent),
//               ),
//               const SizedBox(height: 35),
//               // selection box, choose small leader
//               BlocBuilder<UsersListBloc, UsersListState>(
//                 bloc: BlocProvider.of<UsersListBloc>(context),
//                 builder: (context, state) {
//                   if (state is UsersSuccess) {
//                     return SelectionBox<UsersModel>(
//                       leading: null,
//                       hint: "choose big leader",
//                       controller: bigLeaderSelection,
//                       items: state.users,
//                       getText: (e) => e.name,
//                     );
//                   } else if (state is UsersLoading) {
//                     return LoadingBox(height: 20, width: 20);
//                   } else {
//                     return SelectionBox(
//                       leading: null,
//                       items: [],
//                       getText: (e) => "",
//                       controller: bigLeaderSelection,
//                       hint: "choose big leader",
//                     );
//                   }
//                 },
//               ),
//               const SizedBox(height: 30),
//               SizedBox(
//                 width: 300,
//                 height: 45,
//                 child: ElevatedButton(
//                     onPressed: () => _confirm(context),
//                     child: Text(Translate.of(context).translate("confirm"))),
//               )
//             ]),
//           ),
//           Positioned(
//             right: 0,
//             child: IconButton(
//               icon: Icon(Icons.close_outlined),
//               onPressed: () => Navigator.of(context).pop(),
//             ),
//           )
//         ],
//       ),
//     );
//   }

//   _confirm(BuildContext context) async {
//     if (bigLeaderSelection.value == null) {
//       Navigator.of(context).pop();
//       return;
//     }
//     Navigator.of(context).pop(bigLeaderSelection.value.id);
//   }
// }
