import 'package:flutter/material.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/creator_sign_dialog.dart';
import 'package:gmptr/utils/utils.dart';

class BigLeaderSignDialog extends StatelessWidget {
  const BigLeaderSignDialog({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CreatorSignDialog(
      text: Translate.of(context).translate('sign'),
    );
  }
}
