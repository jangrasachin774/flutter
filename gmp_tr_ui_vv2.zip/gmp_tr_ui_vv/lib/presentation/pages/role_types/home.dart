import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:gmptr/configs/application.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/presentation/layout/adaptive_scaffold.dart';
import 'package:gmptr/presentation/pages/role_types/big_leader/all_for_me.dart';
import 'package:gmptr/presentation/pages/role_types/creator/approve_holiday.dart';
import 'package:gmptr/presentation/pages/role_types/small_leader/all_for_me.dart';
import 'package:gmptr/presentation/pages/role_types/small_leader/tasks_for_me.dart';
import 'package:gmptr/presentation/pages/role_types/student/my_holiday.dart';
import 'package:gmptr/presentation/pages/role_types/types.dart';
import 'package:gmptr/presentation/pages/role_types/view_training/finished_by_students.dart';
import 'package:gmptr/presentation/pages/role_types/view_training/home.dart';
import 'package:gmptr/presentation/pages/role_types/view_training/signed_by_big_leader.dart';
import 'package:gmptr/presentation/pages/role_types/view_training/signed_by_small_leader.dart';
import 'package:gmptr/utils/utils.dart';

import 'admin/department_management.dart';
import 'admin/documents_feature_management.dart';
import 'admin/documents_managment/home.dart';
import 'admin/trainings_type_management.dart';
import 'big_leader/my_signed_task.dart';
import 'big_leader/students_page.dart';
import 'big_leader/tasks_for_me.dart';
import 'creator/all_for_me.dart';
import 'creator/finished_by_students.dart';
import 'creator/home.dart';
import 'creator/signed_by_big_leader.dart';
import 'creator/signed_by_small_leader.dart';
import 'small_leader/big_leader_page.dart';
import 'small_leader/my_signed_task.dart';
import 'small_leader/students_page.dart';
import 'student/my_finished_work.dart';
import 'student/signed_by_big_leader.dart';
import 'student/signed_by_create_person.dart';
import 'student/signed_by_small_leader.dart';
import 'view-admin/department_management.dart';
import 'view-admin/documents_feature_management.dart';
import 'view-admin/documents_managment/home.dart';
import 'view-admin/trainings_type_management.dart';
import 'view-admin/user_managment/home.dart';

class HomeNavigation extends StatefulWidget {
  final int roleId;
  const HomeNavigation({Key key, this.roleId}) : super(key: key);

  @override
  _HomeNavigationState createState() => _HomeNavigationState();
}

class _HomeNavigationState extends State<HomeNavigation> {
  int _pageIndex = 0;
  bool deptMngmtPage;
  bool documentMngmt;
  bool userMngmt;
  bool trainingTypeMngmt;
  bool documentTypeMngmt;
  var userPageRoleId;
  @override
  void initState() {
    super.initState();
    userPageRoleId = UtilPreferences.getString(Preferences.userRoleId);
    print(userPageRoleId);
    Application.user.userRoles
        .map((e) => e.userAdminPagees.map((e) {
              if (e.adminPageIdFk == UserAdminPageId.departmentManagment) {
                deptMngmtPage = true;
              }
              if (e.adminPageIdFk == UserAdminPageId.documentManagement) {
                documentMngmt = true;
              }
              if (e.adminPageIdFk == UserAdminPageId.userManagement) {
                userMngmt = true;
              }
              if (e.adminPageIdFk == UserAdminPageId.trainingTypeManagement) {
                trainingTypeMngmt = true;
              }
              if (e.adminPageIdFk == UserAdminPageId.documentTypeManagement) {
                documentTypeMngmt = true;
              }
            }).toList())
        .toList();
    print("documentMngmt >>> $documentMngmt");
    print("userMngmt >> $userMngmt");
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: AdaptiveScaffold(
        title: Text(userPageRoleId),
        destinations: [
          ///ADMIN
          if (int.parse(userPageRoleId) == UserRolesId.admin) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///STUDENT
          if (int.parse(userPageRoleId) == UserRolesId.student) ...[
            // AdaptiveScaffoldDestination(
            //     title:
            //         Translate.of(context).translate("signed_by_create_person")),
            // AdaptiveScaffoldDestination(
            //     title:
            //         Translate.of(context).translate("signed_by_small_leader")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("signed_by_big_leader")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("my_finished_work")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("my_holiday")),
          ],

          ///Task Creator
          if (int.parse(userPageRoleId) == UserRolesId.creator) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate("create_by_me_page_heading"),
            ),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("approve_holiday")),
            AdaptiveScaffoldDestination(
                title:
                    Translate.of(context).translate("signed_by_small_leader")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("signed_by_big_leader")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("finished_by_student")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("all_for_me")),
          ],

          ///SMALL LEADER
          if (int.parse(userPageRoleId) == UserRolesId.smallLeader) ...[
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("tasks_for_me")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("my_signed_task")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("signed_by_big_leader")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("finished_by_student")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("all_for_me")),
          ],

          ///BIG LEADER
          if (int.parse(userPageRoleId) == UserRolesId.bigLeader) ...[
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("tasks_for_me")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("my_signed_task")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("finished_by_student")),
            AdaptiveScaffoldDestination(
                title: Translate.of(context).translate("all_for_me")),
          ],

          ///VIEW - ADMIN - ALL TABS
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt != null &&
              userMngmt != null &&
              documentMngmt != null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT TRAINING TYPE MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt != null &&
              userMngmt != null &&
              documentMngmt != null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT DOCUMENT TYPE MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt == null &&
              userMngmt != null &&
              documentMngmt != null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT DOCUMENT TYPE MANAGEMENT, TRAINING TYPE MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt == null &&
              userMngmt != null &&
              documentMngmt != null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT USER MANAGEMENT MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt != null &&
              userMngmt == null &&
              documentMngmt != null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT DOCUMENT  MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt != null &&
              userMngmt != null &&
              documentMngmt == null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT DOCUMENT  MANAGEMENT, USER MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt != null &&
              userMngmt == null &&
              documentMngmt == null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - EXCEPT DEPARTMENT  MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt != null &&
              userMngmt != null &&
              documentMngmt != null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
          ],

          /// VIEW - ADMIN - EXCEPT TRAINING TYPE  MANAGEMENT & DEPARTMENT MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt != null &&
              userMngmt != null &&
              documentMngmt != null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - ONLY DOCUMENT MANAGEMENT & DEPARTMENT MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt == null &&
              userMngmt == null &&
              documentMngmt != null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - ONLY TRAINING TYPE & DEPARTMENT MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt == null &&
              userMngmt == null &&
              documentMngmt == null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - ADMIN -  ONLY TRAINING TYPE & DOCUMENT TYPE MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt != null &&
              userMngmt == null &&
              documentMngmt == null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
          ],

          ///VIEW - ADMIN - ONLY USER MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt == null &&
              userMngmt != null &&
              documentMngmt == null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('user_management'),
            ),
          ],

          ///VIEW - ADMIN - ONLY TRAINING TYPE MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt != null &&
              documentTypeMngmt == null &&
              userMngmt == null &&
              documentMngmt == null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title:
                  Translate.of(context).translate('training_type_management'),
            ),
          ],

          ///VIEW - ADMIN - ONLY DOCUMENT TYPE MANAGMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt != null &&
              userMngmt == null &&
              documentMngmt == null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context)
                  .translate('document_feature_management'),
            ),
          ],

          ///VIEW - ADMIN - ONLY DOCUMENT MANAGMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt == null &&
              userMngmt == null &&
              documentMngmt != null &&
              deptMngmtPage == null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('document_mngmt'),
            ),
          ],

          ///VIEW - ADMIN - ONLY DEPARTMENT MANAGEMENT
          if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
              trainingTypeMngmt == null &&
              documentTypeMngmt == null &&
              userMngmt == null &&
              documentMngmt == null &&
              deptMngmtPage != null) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('department_mngmt'),
            ),
          ],

          ///VIEW - TRAINING
          if (int.parse(userPageRoleId) == UserRolesId.viewTraining) ...[
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('signed_by_create_person'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('signed_by_small_leader'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('signed_by_big_leader'),
            ),
            AdaptiveScaffoldDestination(
              title: Translate.of(context).translate('finished_by_student'),
            ),
          ]
        ],
        username: Application.user.name,
        userRole: int.parse(userPageRoleId),
        currentIndex: _pageIndex,
        body: _pageAtIndex(_pageIndex),
        onNavigationIndexChange: (newIndex) {
          setState(() {
            _pageIndex = newIndex;
          });
        },
      ),
    );
  }

  Widget _pageAtIndex(int index) {
    ///ADMIN
    if (index == 0 && int.parse(userPageRoleId) == UserRolesId.admin) {
      return TrainingTypeManagementPage();
    }
    if (index == 1 && int.parse(userPageRoleId) == UserRolesId.admin) {
      return DocumentFeatureManagementPage();
    }
    if (index == 2 && int.parse(userPageRoleId) == UserRolesId.admin) {
      return UserManagementPage();
    }

    if (index == 3 && int.parse(userPageRoleId) == UserRolesId.admin) {
      return DocumentManagementPage();
    }
    if (index == 4 && int.parse(userPageRoleId) == UserRolesId.admin) {
      return DepartmentManagementPage();
    }

    ///TASK CREATOR
    if (index == 0 && int.parse(userPageRoleId) == UserRolesId.creator) {
      return CreatorHomePage();
    }
    if (index == 1 && int.parse(userPageRoleId) == UserRolesId.creator) {
      return ApproveHolidayPage();
    }
    if (index == 2 && int.parse(userPageRoleId) == UserRolesId.creator) {
      return SmallLeaderPage();
    }
    if (index == 3 && int.parse(userPageRoleId) == UserRolesId.creator) {
      return BigLeaderPage();
    }
    if (index == 4 && int.parse(userPageRoleId) == UserRolesId.creator) {
      return FinishedByStudentPage();
    }
    if (index == 5 && int.parse(userPageRoleId) == UserRolesId.creator) {
      return AllForMePage();
    }

    ///SMALL LEADER
    if (index == 0 && int.parse(userPageRoleId) == UserRolesId.smallLeader) {
      return SmallLeaderHomePage();
    }
    if (index == 1 && int.parse(userPageRoleId) == UserRolesId.smallLeader) {
      return SLMySignedTask();
    }
    if (index == 2 && int.parse(userPageRoleId) == UserRolesId.smallLeader) {
      return SLBigLeaderPage();
    }

    if (index == 3 && int.parse(userPageRoleId) == UserRolesId.smallLeader) {
      return SLFinishedByStudentPage();
    }

    if (index == 4 && int.parse(userPageRoleId) == UserRolesId.smallLeader) {
      return SLAllForMePage();
    }

    ///BIG LEADER
    if (index == 0 && int.parse(userPageRoleId) == UserRolesId.bigLeader) {
      return BigLeaderHomePage();
    }
    if (index == 1 && int.parse(userPageRoleId) == UserRolesId.bigLeader) {
      return BLMySignedTask();
    }

    if (index == 2 && int.parse(userPageRoleId) == UserRolesId.bigLeader) {
      return BLFinishedByStudentPage();
    }

    if (index == 3 && int.parse(userPageRoleId) == UserRolesId.bigLeader) {
      return BLAllForMePage();
    }

    ///STUDENT
    // if (index == 0 && int.parse(userPageRoleId) == UserRolesId.student) {
    //   return SignedByCpDashboardPage();
    // }
    // if (index == 1 && int.parse(userPageRoleId) == UserRolesId.student) {
    //   return SignedBySLDashboardPage();
    // }
    if (index == 0 && int.parse(userPageRoleId) == UserRolesId.student) {
      return SignedByBLDashboardPage();
    }
    if (index == 1 && int.parse(userPageRoleId) == UserRolesId.student) {
      return StudentDashboardPage();
    }
    if (index == 2 && int.parse(userPageRoleId) == UserRolesId.student) {
      return MyHolidayPage();
    }

    ///VIEW -ADMIN
    ///VIEW - ADMIN - ALL TABS
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt != null &&
        userMngmt != null &&
        documentMngmt != null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }
      if (index == 2) {
        return VAUserManagementPage();
      }
      if (index == 3) {
        return VADocumentManagementPage();
      }
      if (index == 4) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT TRAINING TYPE MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt != null &&
        userMngmt != null &&
        documentMngmt != null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VADocumentFeatureManagementPage();
      }
      if (index == 1) {
        return VAUserManagementPage();
      }
      if (index == 2) {
        return VADocumentManagementPage();
      }
      if (index == 3) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT DOCUMENT TYPE MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt == null &&
        userMngmt != null &&
        documentMngmt != null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VAUserManagementPage();
      }
      if (index == 2) {
        return VADocumentManagementPage();
      }
      if (index == 3) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT DOCUMENT TYPE MANAGEMENT, TRAINING TYPE MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt == null &&
        userMngmt != null &&
        documentMngmt != null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VAUserManagementPage();
      }
      if (index == 1) {
        return VADocumentManagementPage();
      }
      if (index == 2) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT USER MANAGEMENT MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt != null &&
        userMngmt == null &&
        documentMngmt != null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }

      if (index == 2) {
        return VADocumentManagementPage();
      }
      if (index == 3) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT DOCUMENT  MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt != null &&
        userMngmt != null &&
        documentMngmt == null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }
      if (index == 2) {
        return VAUserManagementPage();
      }

      if (index == 3) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT DOCUMENT  MANAGEMENT, USER MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt != null &&
        userMngmt == null &&
        documentMngmt == null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }

      if (index == 2) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - EXCEPT DEPARTMENT  MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt != null &&
        userMngmt != null &&
        documentMngmt != null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }
      if (index == 2) {
        return VAUserManagementPage();
      }
      if (index == 3) {
        return VADocumentManagementPage();
      }
    }

    ///VIEW - ADMIN - DOCUMENT MANAGEMENT & DEPARTMENT MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt == null &&
        userMngmt == null &&
        documentMngmt != null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }
      if (index == 2) {
        return VAUserManagementPage();
      }
    }

    ///VIEW - ADMIN - TRAINING TYPE & DEPARTMENT MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt == null &&
        userMngmt == null &&
        documentMngmt == null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - ADMIN - TRAINING TYPE & DOCUMENT TYPE MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt != null &&
        userMngmt == null &&
        documentMngmt == null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
      if (index == 1) {
        return VADocumentFeatureManagementPage();
      }
    }

    /// VIEW - ADMIN - EXCEPT TRAINING TYPE  MANAGEMENT & DEPARTMENT MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt != null &&
        userMngmt != null &&
        documentMngmt != null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VADocumentFeatureManagementPage();
      }
      if (index == 1) {
        return VAUserManagementPage();
      }
      if (index == 2) {
        return VADocumentManagementPage();
      }
    }

    ///VIEW - ADMIN - ONLY USER MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt == null &&
        userMngmt != null &&
        documentMngmt == null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VAUserManagementPage();
      }
    }

    ///VIEW - ADMIN - ONLY TRAINING TYPE MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt != null &&
        documentTypeMngmt == null &&
        userMngmt == null &&
        documentMngmt == null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VATrainingTypeManagementPage();
      }
    }

    ///VIEW - ADMIN - ONLY DOCUMENT TYPE MANAGMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt != null &&
        userMngmt == null &&
        documentMngmt == null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VADocumentFeatureManagementPage();
      }
    }

    ///VIEW - ADMIN - ONLY DOCUMENT MANAGMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt == null &&
        userMngmt == null &&
        documentMngmt != null &&
        deptMngmtPage == null) {
      if (index == 0) {
        return VADocumentManagementPage();
      }
    }

    ///VIEW - ADMIN - ONLY DEPARTMENT MANAGEMENT
    if (int.parse(userPageRoleId) == UserRolesId.viewAdmin &&
        trainingTypeMngmt == null &&
        documentTypeMngmt == null &&
        userMngmt == null &&
        documentMngmt == null &&
        deptMngmtPage != null) {
      if (index == 0) {
        return VADepartmentManagementPage();
      }
    }

    ///VIEW - TRAINING
    if (index == 0 && int.parse(userPageRoleId) == UserRolesId.viewTraining) {
      return VTHomePage();
    }
    if (index == 1 && int.parse(userPageRoleId) == UserRolesId.viewTraining) {
      return VTSmallLeaderPage();
    }
    if (index == 2 && int.parse(userPageRoleId) == UserRolesId.viewTraining) {
      return VTBigLeaderPage();
    }
    if (index == 3 && int.parse(userPageRoleId) == UserRolesId.viewTraining) {
      return VTFinishedByStudentPage();
    }

    return const Center(child: Text(''));
  }
}
