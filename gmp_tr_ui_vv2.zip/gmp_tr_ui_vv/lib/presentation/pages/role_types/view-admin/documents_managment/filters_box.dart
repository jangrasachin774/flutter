import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/algorithm/filter_strategy.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/algorithm/filter_strategy_factory.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/date_picker.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

/// for creator dashboard
class AdminDocFiltersBox extends StatefulWidget {
  const AdminDocFiltersBox({Key key}) : super(key: key);

  @override
  _AdminDocFiltersBoxState createState() => _AdminDocFiltersBoxState();
}

class _AdminDocFiltersBoxState extends State<AdminDocFiltersBox> {
  final startTimeController = DatePickerController();
  final endTimeController = DatePickerController();
  final filterByNothing = FilterStrategyFactory().getStrategy(FilterEnum.NONE);
  final FilterByTime filterByTime =
      FilterStrategyFactory().getStrategy(FilterEnum.Time);
  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';
  var selectedValue;
  var selectedDepartmentValue;
  var selectedTrainingTypeValue;

  @override
  void initState() {
    super.initState();
    initializeDateFormatting();
    AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    setState(() {
      if (args.value is PickerDateRange) {
        _startDate =
            DateFormat('dd/MM/yyyy').format(args.value.startDate).toString();
        _endDate = DateFormat('dd/MM/yyyy')
            .format(args.value.endDate ?? args.value.startDate)
            .toString();
      } else if (args.value is DateTime) {
        _selectedDate = args.value.toString();
      } else if (args.value is List<DateTime>) {
        _dateCount = args.value.length.toString();
      } else {
        _rangeCount = args.value.length.toString();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(children: [
        Container(
            color: Colors.grey.withOpacity(.2),
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  Translate.of(context).translate("filters"),
                  textAlign: TextAlign.start,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                OutlinedButton(
                  child: Text(
                    Translate.of(context).translate('clear_filter'),
                  ),
                  onPressed: () {
                    setState(() {
                      selectedValue = null;
                      selectedTrainingTypeValue = null;
                      selectedDepartmentValue = null;
                      AppBloc.documentsBloc.add(OnLoadDocuments());
                    });
                  },
                  style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.lightBlueAccent)),
                ),
              ],
            )),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              children: [
                const SizedBox(width: 10),
                BlocBuilder<DocumentsFeatureListBloc,
                    DocumentsFeatureListState>(
                  bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
                  builder: (context, state) {
                    if (state is DocumentsFeatureSuccess) {
                      return createDropdownButton(
                        hint:
                            Translate.of(context).translate("document_feature"),
                        value: selectedValue,
                        items: state.documentsFeature
                            .map((e) => DropdownMenuItem(
                                child: Text(e.name, style: text12),
                                value: e.id))
                            .toList(),
                        onChanged: (newValue) {
                          setState(() {
                            selectedValue = newValue;
                            AppBloc.documentsBloc.add(OnLoadDocuments(
                                documentFeature: selectedValue,
                                trainingTypeIdFk: selectedTrainingTypeValue,
                                departmentIdFk: selectedDepartmentValue));
                          });
                        },
                      );
                    } else if (state is DocumentsFeatureLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load document features failed.");
                    }
                  },
                ),
                const SizedBox(width: 10),
                BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                  bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                  builder: (context, state) {
                    if (state is TrainingsTypeSuccess) {
                      return createDropdownButton(
                        hint: Translate.of(context).translate("training_type"),
                        value: selectedTrainingTypeValue,
                        items: state.trainingTypes
                            .map((e) => DropdownMenuItem(
                                child: Text(e.name, style: text12),
                                value: e.id))
                            .toList(),
                        onChanged: (newValue) {
                          setState(() {
                            selectedTrainingTypeValue = newValue;
                            AppBloc.documentsBloc.add(OnLoadDocuments(
                                documentFeature: selectedValue,
                                trainingTypeIdFk: selectedTrainingTypeValue,
                                departmentIdFk: selectedDepartmentValue));
                          });
                        },
                      );
                    } else if (state is DocumentsFeatureLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load training types failed.");
                    }
                  },
                ),
                const SizedBox(width: 10),
                BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                  bloc: BlocProvider.of<DepartmentsListBloc>(context),
                  builder: (context, state) {
                    if (state is DepartmentsSuccess) {
                      return createDropdownButton(
                        hint: Translate.of(context).translate("department"),
                        value: selectedDepartmentValue,
                        items: state.departments
                            .map((e) => DropdownMenuItem(
                                child: Text(e.name, style: text12),
                                value: e.id))
                            .toList(),
                        onChanged: (newValue) {
                          setState(() {
                            selectedDepartmentValue = newValue;
                            AppBloc.documentsBloc.add(OnLoadDocuments(
                                documentFeature: selectedValue,
                                trainingTypeIdFk: selectedTrainingTypeValue,
                                departmentIdFk: selectedDepartmentValue));
                          });
                        },
                      );
                    } else if (state is DepartmentsLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load departments failed.");
                    }
                  },
                ),
                const SizedBox(width: 10),
                createDropdownButton(
                  hint: Translate.of(context).translate("time"),
                  value: filterByTime.value,
                  items: [
                    DropdownMenuItem(
                      child: Container(
                        width: 280,
                        child: SfDateRangePicker(
                          onSelectionChanged: _onSelectionChanged,
                          selectionMode: DateRangePickerSelectionMode.range,
                          initialSelectedRange: PickerDateRange(
                              DateTime.now().subtract(const Duration(days: 4)),
                              DateTime.now().add(const Duration(days: 3))),
                        ),
                      ),
                      value: -1,
                    ),
                  ]..addAll(filterByTime.kv.entries
                      .map(
                        (entry) => DropdownMenuItem(
                            child: Text(entry.key, style: text12),
                            value: entry.value),
                      )
                      .toList()),
                  onChanged: (newValue) {
                    setState(() {
                      if (newValue != -1) {
                        AppBloc.documentsBloc.add(OnLoadDocuments(
                          documentFeature: selectedValue,
                          trainingTypeIdFk: selectedTrainingTypeValue,
                          departmentIdFk: selectedDepartmentValue,
                          criteria: newValue,
                          startDate: _startDate,
                          endDate: _endDate,
                        ));
                      }
                    });
                  },
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  Widget createDropdownButton({
    String hint,
    dynamic value,
    List<DropdownMenuItem<dynamic>> items,
    Function(dynamic) onChanged,
  }) {
    return Container(
      height: 36,
      padding: const EdgeInsets.fromLTRB(7, 10, 7, 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black.withOpacity(.06), width: 1),
      ),
      child: DropdownButton(
        hint: Text(
          hint,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
        ),
        icon: const Icon(
          Icons.expand_more_outlined,
          color: Colors.blueAccent,
        ),
        elevation: 8,
        underline: Container(color: Colors.white),
        iconSize: 18,
        value: value,
        items: items,
        onChanged: onChanged,
      ),
    );
  }

  get text12 => const TextStyle(fontSize: 12);
}
