import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/change_student_time_dialog.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/view_document_dialog.dart';
import 'package:gmptr/utils/utils.dart';

class DocumentDetailPage extends StatefulWidget {
  final DocumentsModel documentInfo;
  const DocumentDetailPage({Key key, this.documentInfo}) : super(key: key);

  @override
  _DocumentDetailPageState createState() => _DocumentDetailPageState();
}

class _DocumentDetailPageState extends State<DocumentDetailPage> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // training type and training title
              Wrap(
                spacing: 100,
                runSpacing: 20,
                children: [
                  _keyValueText(
                      Translate.of(context).translate("training_type"),
                      widget.documentInfo.trainingType.name),
                  _keyValueText(
                      Translate.of(context).translate("training_title"),
                      widget.documentInfo.title)
                ],
              ),
              const SizedBox(height: 20),
              // document feature type
              _keyValueText(
                  Translate.of(context).translate("document_feature_type"),
                  widget.documentInfo.documentType.name),
              const SizedBox(height: 20),
              // training description
              _trainingDescription(widget.documentInfo.description),
              const SizedBox(height: 20),

              // training documents buttons
              _trainingDocuments(widget.documentInfo.documentFiles),
              const SizedBox(height: 20),

              // display tests
              _testsDisplayTable(widget.documentInfo.documentTests),
              const SizedBox(height: 20),
              // FIXME: use correct datasource blow.
              // create info card
              _createAndSignInfoCard(
                isSign: false,
                title: Translate.of(context).translate("create_task_person"),
                dept: widget.documentInfo.docCreator.creatorDepartment.name,
                worker: widget.documentInfo.docCreator.name,
                time: widget.documentInfo.createdAt,
              ),
              const SizedBox(height: 20),
              // small leader sign info card
              _createAndSignInfoCard(
                isSign: true,
                title: Translate.of(context).translate("small_leader"),
                dept: "",
                worker: "",
                time: "",
                // isSigned: true,
              ),
              const SizedBox(height: 20),
              // big leader sign info card
              _createAndSignInfoCard(
                isSign: true,
                title: Translate.of(context).translate("big_leader"),
                dept: "",
                worker: "",
                time: "",
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ],
    );
  }

  Widget _keyValueText(String key, String value) {
    return Wrap(
      children: [
        Container(width: 200, child: Text(key, style: _bold14)),
        Text(value, style: _text12),
      ],
    );
  }

  Widget _trainingDescription(String description) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(Translate.of(context).translate("document_description"),
            style: _bold14),
        const SizedBox(height: 5),
        ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 500),
          child: Text(
            description,
            textAlign: TextAlign.justify,
          ),
        )
      ],
    );
  }

  Widget _trainingDocuments(List<DocumentFiles> documentFiles) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(Translate.of(context).translate("training_documents"),
            style: _bold14),
        const SizedBox(height: 7),
        ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 700),
          child: Wrap(
            spacing: 10,
            runSpacing: 10,
            // FIXME: use correct documents source and re-implement onPressed
            children: List.generate(documentFiles.length,
                (index) => _viewDocumentButton(documentFiles[index])),
          ),
        )
      ],
    );
  }

  Widget _viewDocumentButton(DocumentFiles documentFile) {
    return Container(
        height: 40,
        width: 200,
        child: OutlinedButton(
          onPressed: () {
            showDialog(
                context: context,
                builder: (context) => ViewDocumentDialog(
                    path: documentFile.path, isNeedConfirm: false));
          },
          child: Text("Training Document"),
        ));
  }

  Widget _testsDisplayTable(List<DocumentTests> test) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(Translate.of(context).translate("test"), style: _bold14),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          direction: Axis.vertical,
          children: List.generate(
              test.length, (index) => _singleTestRecorde(index, test[index])),
        )
      ],
    );
  }

  Widget _singleTestRecorde(int index, DocumentTests tests) {
    index++;
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text("0" + '$index'),
      const SizedBox(width: 10),
      ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 820),
          child: Text(tests.question))
    ]);
  }

  Widget _createAndSignInfoCard({
    bool isSign,
    String title,
    String dept,
    String worker,
    String time,
    bool isSigned = false,
  }) {
    Widget twoLineText(
            {String line1, String line2, Color line2Color = Colors.black}) =>
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(line1, style: _bold14),
            Text(line2, style: TextStyle(fontSize: 12, color: line2Color))
          ],
        );

    return Container(
      width: double.infinity,
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(
        children: [
          Container(
            height: 40,
            padding: const EdgeInsets.only(left: 30),
            alignment: Alignment.centerLeft,
            color: Colors.grey.withOpacity(.2),
            child: Text(title, style: _bold14),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 30),
            alignment: Alignment.centerLeft,
            child: Wrap(spacing: 160, runSpacing: 20, children: [
              twoLineText(
                line1: Translate.of(context).translate("department"),
                line2: dept,
              ),
              twoLineText(
                line1: Translate.of(context)
                    .translate(isSign ? "sign_worker" : "create_worker"),
                line2: worker,
              ),
              twoLineText(
                line1: Translate.of(context)
                    .translate(isSign ? "sign_time" : "create_time"),
                line2: time,
              ),
              if (isSign)
                twoLineText(
                  line1: Translate.of(context).translate("sign_result"),
                  line2: Translate.of(context)
                      .translate(isSigned ? "agree" : "disagree"),
                  line2Color: isSigned ? Colors.lightGreen : Colors.redAccent,
                )
            ]),
          )
        ],
      ),
    );
  }

  get _bold14 => const TextStyle(fontSize: 14, fontWeight: FontWeight.bold);

  get _text12 => const TextStyle(fontSize: 12);
}

class StudentsInfoTable extends StatefulWidget {
  final bool isCreator;

  const StudentsInfoTable(this.isCreator, {Key key}) : super(key: key);

  @override
  _StudentsInfoTableState createState() => _StudentsInfoTableState();
}

class _StudentsInfoTableState extends State<StudentsInfoTable> {
  String _studentSortBy = "All";

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(
        children: [
          Container(
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            alignment: Alignment.centerLeft,
            color: Colors.grey.withOpacity(.2),
            child: Row(
              children: [
                Text(Translate.of(context).translate("students"),
                    style: _bold14),
                Spacer(),
                Text(Translate.of(context).translate("sort_by")),
                SizedBox(width: 10),
                DropdownButton(
                  value: _studentSortBy,
                  items: [
                    DropdownMenuItem(
                        child: Text("All", style: _text12), value: "All"),
                    DropdownMenuItem(
                        child: Text("Pass", style: _text12), value: "Pass"),
                    DropdownMenuItem(
                        child: Text("Fail", style: _text12), value: "Fail"),
                  ],
                  onChanged: (newValue) =>
                      setState(() => _studentSortBy = newValue),
                )
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowHeight: 40,
              columnSpacing: 20,
              columns: _header(),
              // ignore: todo
              // TODO: filter rows according to _studentSortedBy
              rows: List.generate(3, (index) => _singleRecorde()),
            ),
          )
        ],
      ),
    );
  }

  List<DataColumn> _header() {
    return [
      DataColumn(
          label: Text(Translate.of(context).translate("student_name"),
              style: _bold14)),
      DataColumn(
          label: Text(Translate.of(context).translate("work_number"),
              style: _bold14)),
      DataColumn(
          label:
              Text(Translate.of(context).translate("gender"), style: _bold14)),
      DataColumn(
        label: Text(Translate.of(context).translate("student_department"),
            style: _bold14),
      ),
      DataColumn(
        label: Text(Translate.of(context).translate("training_department"),
            style: _bold14),
      ),
      DataColumn(
          label: Text(Translate.of(context).translate("start_time"),
              style: _bold14)),
      DataColumn(
          label: Text(Translate.of(context).translate("end_time"),
              style: _bold14)),
      DataColumn(
          label: Text(Translate.of(context).translate("student_finish_time"),
              style: _bold14)),
      DataColumn(
          label: Text(Translate.of(context).translate("type"), style: _bold14)),
      DataColumn(
          label:
              Text(Translate.of(context).translate("result"), style: _bold14)),
      if (widget.isCreator)
        DataColumn(
            label: Text(Translate.of(context).translate("action"),
                style: _bold14)),
    ];
  }

  // FIXME: use correct datasource
  DataRow _singleRecorde() {
    return DataRow(cells: [
      DataCell(Text(
        "Feng wenyi",
        style: TextStyle(color: Colors.lightBlueAccent),
      )),
      DataCell(Text("W12345")),
      DataCell(Text("Male")),
      DataCell(Text("2nd Grade Department-1")),
      DataCell(Text("2nd Grade Department-1")),
      DataCell(Text("2021/8/8 22:27:23")),
      DataCell(Text("2021/8/8 22:27:23")),
      DataCell(Text("2021/8/8 22:27:23")),
      DataCell(Text("Normal")),
      DataCell(Text(
        "Pass",
        style: TextStyle(color: Colors.lightGreen),
      )),
      if (widget.isCreator)
        DataCell(Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            OutlinedButton(
              onPressed: () {},
              child: Text(Translate.of(context).translate('cancel')),
              style: outlinedButtonStyle,
            ),
            const SizedBox(width: 10),
            // FIXME: show this only after big leader sign
            OutlinedButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (context) => ChangeStudentTimeDialog());
                setState(() {});
              },
              child: Text(Translate.of(context).translate('change')),
              style: outlinedButtonStyle,
            ),
          ],
        ))
    ]);
  }

  get _bold14 => const TextStyle(fontSize: 14, fontWeight: FontWeight.bold);

  get _text12 => const TextStyle(fontSize: 12);

  get outlinedButtonStyle => OutlinedButton.styleFrom(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
      side: BorderSide(color: Colors.lightBlueAccent));
}
