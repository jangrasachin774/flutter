import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/filters_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'algorithm/documents_list_controller.dart';
import 'document_detail.dart';
import 'file_dialog.dart';

enum DocWidgetChange { documentsList, info }

/// DOCUMENTS MANAGEMENT
class VADocumentManagementPage extends StatefulWidget {
  const VADocumentManagementPage({Key key}) : super(key: key);

  @override
  _VADocumentManagementPageState createState() => _VADocumentManagementPageState();
}

List<DocumentsModel> paginatedDocuments = [];
final int rowsPerPage = 10;

class _VADocumentManagementPageState extends State<VADocumentManagementPage> {
  DocWidgetChange selectedWidgetPage = DocWidgetChange.documentsList;
  DocumentsModel document;
  final documentsController = DocumentsListController();

  @override
  void initState() {
    super.initState();
    AppBloc.documentsBloc.add(OnLoadDocuments());
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case DocWidgetChange.documentsList:
        return documentsListWidget(context);
      case DocWidgetChange.info:
        return documentInfoWidget(context);
    }
    return documentsListWidget(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == DocWidgetChange.documentsList)
                    Text(
                      Translate.of(context).translate("document_managment"),
                      style: TextStyle(color: Color(0xff00439E), fontSize: widthOfScreen(context) * 0.025, fontWeight: FontWeight.bold),
                    ),
                  if (selectedWidgetPage == DocWidgetChange.info) Container(),
                  if (selectedWidgetPage == DocWidgetChange.info)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: AppButton(
                        Translate.of(context).translate('back'),
                        onPressed: () {
                          setState(() {
                            selectedWidgetPage = DocWidgetChange.documentsList;
                            // AppBloc.usersBloc.add(OnLoadUsers());
                          });
                        },
                        type: ButtonType.outline,
                        color: Color(0xff787E8C),
                      ),
                    ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Container(child: getCustomContainer(context))
            ],
          ),
        ),
      ],
    );
  }

  ///USER LISTS
  Widget documentsListWidget(context) {
    // int rowCount = 1;
    return Column(
      children: [
        AdminDocFiltersBox(),
        const SizedBox(height: 20),
        Container(
          width: double.infinity,
          child: BlocListener<DocumentsBloc, DocumentsState>(
            listener: (context, state) {
              if (state is OnUpdateDocumentStatusSuccess) {
                String status;
                Color color;
                if (state.docStatusId == 1) {
                  status = "Document Enabled";
                  color = Colors.green;
                } else if (state.docStatusId == 0) {
                  status = "Document Disabled";
                  color = Colors.red;
                }
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  backgroundColor: color,
                  content: Text(status),
                ));
              }
            },
            child: BlocBuilder<DocumentsBloc, DocumentsState>(
              bloc: BlocProvider.of<DocumentsBloc>(context),
              builder: (context, documentsList) {
                if (documentsList is DocumentsSuccess) {
                  // return buildDataTable(
                  //     context, buildDataRow(documentsList.documents));
                  DocumentsDataSource documentsDataSource;
                  documentsDataSource = new DocumentsDataSource(documentsList.documents, context);

                  List<DocumentsModel> docCount = documentsList.documents;

                  return LayoutBuilder(builder: (context, constraints) {
                    return Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 360,
                              width: constraints.maxWidth,
                              child: SfDataGrid(
                                allowSorting: true,
                                source: documentsDataSource,
                                columnWidthMode: ColumnWidthMode.fill,
                                isScrollbarAlwaysShown: true,
                                columns: [
                                  GridColumn(
                                    columnName: 'title',
                                    width: 150,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('title'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'document',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('document'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'description',
                                    width: 150,
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('description'),
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'createPerson',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('create_person'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'createTime',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('create_time'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'department',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('department'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'trainingType',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('training_type'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                  GridColumn(
                                    columnName: 'documentFeature',
                                    label: Container(
                                      height: 50,
                                      color: Color(0xffEFF5FC),
                                      padding: EdgeInsets.all(16.0),
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Translate.of(context).translate('document_feature'),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                                selectionMode: SelectionMode.single,
                                onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                  if (documentsDataSource.rows.length > 0) {
                                    final index = documentsDataSource.rows.indexOf(addedRows.last);
                                    print("DOC >>> $index");
                                  }
                                  return true;
                                },
                                onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                  if (documentsDataSource.rows.length > 0) {
                                    final index = documentsDataSource.rows.indexOf(addedRows.last);
                                    setState(() {
                                      selectedWidgetPage = DocWidgetChange.info;
                                      document = docCount[index];
                                    });
                                  }
                                },
                              ),
                            ),
                            Container(
                              height: 52,
                              width: constraints.maxWidth,
                              child: SfDataPager(
                                delegate: documentsDataSource,
                                pageCount: (docCount.length / rowsPerPage).ceilToDouble(),
                                direction: Axis.horizontal,
                              ),
                            )
                          ],
                        ),
                      ],
                    );
                  });
                } else if (documentsList is DocumentsLoading) {
                  return LoadingBox(
                    height: 20,
                  );
                } else if (documentsList is DocumentsFail) {
                  return Container(
                    child: Text(documentsList.code),
                  );
                } else {
                  return Container();
                }
              },
            ),
          ),
        ),
      ],
    );
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }

  ///DOCUMENT INFO PAGE
  Widget documentInfoWidget(context) {
    return DocumentDetailPage(documentInfo: document);
  }
}

class DocumentsDataSource extends DataGridSource {
  BuildContext contxt;

  final Completer _completer = new Completer();
  DocumentsDataSource(List<DocumentsModel> documentData, context) {
    documents = documentData;
    contxt = context;
    try {
      if (documents.length < rowsPerPage) {
        paginatedDocuments = documents.toList();
      } else {
        paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];

  @override
  List<DataGridRow> get rows => _documents;

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell(columnName: 'document', value: e.documentFiles),
              DataGridCell<String>(
                columnName: 'description',
                value: e.description,
              ),
              DataGridCell(
                columnName: 'createPerson',
                value: e.docCreator.name,
              ),
              DataGridCell(
                columnName: 'createTime',
                value: e.createdAt,
              ),
              DataGridCell<String>(columnName: 'department', value: e.department.name),
              DataGridCell<String>(columnName: 'trainingType', value: e.trainingType.name),
              DataGridCell(columnName: 'documentFeature', value: e.documentType.name),
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[0].value.toString(),
              child: Text(
                row.getCells()[0].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: InkWell(
            onTap: () async {
              await showDialog(context: contxt, builder: (_) => FileDialog(documentFiles: row.getCells()[1].value));
            },
            child: Text(Translate.of(contxt).translate('view'),
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xff00A4E3),
                )),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Text(
              row.getCells()[2].value != null ? row.getCells()[2].value : "",
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[3].value.toString(),
            child: Text(
              row.getCells()[3].value != null ? row.getCells()[3].value : "",
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            row.getCells()[4].value.toString(),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[5].value.toString(),
            child: Text(
              row.getCells()[5].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
            message: row.getCells()[6].value.toString(),
            child: Text(
              row.getCells()[6].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(vertical: 15),
          child: Tooltip(
            message: row.getCells()[7].value,
            child: Text(
              row.getCells()[7].value.toString(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ],
    );
  }
}
