import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class VATrainingTypeManagementPage extends StatefulWidget {
  const VATrainingTypeManagementPage({Key key}) : super(key: key);

  @override
  _VATrainingTypeManagementPageState createState() =>
      _VATrainingTypeManagementPageState();
}

class _VATrainingTypeManagementPageState
    extends State<VATrainingTypeManagementPage> {
  final _textIDController = TextEditingController();

  String _validID;
  var _focusID = FocusNode();

  @override
  void initState() {
    super.initState();
    AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Translate.of(context)
                        .translate('trainings_type_page_heading'),
                    style: TextStyle(
                        color: Color(0xff00439E),
                        fontSize: widthOfScreen(context) * 0.025,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                child:
                    BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
                        bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
                        builder: (context, trainingsTypeList) {
                          if (trainingsTypeList is TrainingsTypeLoading) {
                            return Center(child: CircularProgressIndicator());
                          } else if (trainingsTypeList
                              is TrainingsTypeSuccess) {
                            return Container(
                              decoration: BoxDecoration(
                                border: Border(
                                  top: BorderSide(color: Color(0xffD4E5F9)),
                                  left: BorderSide(color: Color(0xffD4E5F9)),
                                  right: BorderSide(color: Color(0xffD4E5F9)),
                                ),
                              ),
                              child: MyTrainingsTypeDynamicTreeView(
                                actionVisible: false,
                                data: trainingsTypeList.trainingTypes,
                                width: screenWidth * 0.7,
                                config: TrainingsConfig(
                                    rootId: "null",
                                    parentPaddingEdgeInsets: EdgeInsets.only(
                                        left: 16, top: 0, bottom: 0)),
                              ),
                            );
                          } else if (trainingsTypeList is TrainingsTypeFail) {
                            return Container(
                              child: Text(trainingsTypeList.code),
                            );
                          } else {
                            return Container(
                              child: Text(""),
                            );
                          }
                        }),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
