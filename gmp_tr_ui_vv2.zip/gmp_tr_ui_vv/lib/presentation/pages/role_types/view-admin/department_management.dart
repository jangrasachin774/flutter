import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

class VADepartmentManagementPage extends StatefulWidget {
  const VADepartmentManagementPage({Key key}) : super(key: key);

  @override
  _VADepartmentManagementPageState createState() =>
      _VADepartmentManagementPageState();
}

class _VADepartmentManagementPageState
    extends State<VADepartmentManagementPage> {
  @override
  void initState() {
    super.initState();
    AppBloc.departmentBlocs.add(OnLoadDepartments());
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = widthOfScreen(context);

    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    Translate.of(context).translate('department_mngmt'),
                    style: TextStyle(
                        color: Color(0xff00439E),
                        fontSize: widthOfScreen(context) * 0.025,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                child: BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                    bloc: BlocProvider.of<DepartmentsListBloc>(context),
                    builder: (context, departmentsList) {
                      if (departmentsList is DepartmentsLoading) {
                        return Center(child: CircularProgressIndicator());
                      } else if (departmentsList is DepartmentsSuccess) {
                        return Container(
                          decoration: BoxDecoration(
                            border: Border(
                              top: BorderSide(color: Color(0xffD4E5F9)),
                              left: BorderSide(color: Color(0xffD4E5F9)),
                              right: BorderSide(color: Color(0xffD4E5F9)),
                            ),
                          ),
                          child: MyDynamicTreeView(
                            actionVisible: false,
                            data: departmentsList.departments,
                            width: screenWidth * 0.7,
                            config: Config(
                              rootId: "null",
                            ),
                          ),
                        );
                      } else if (departmentsList is DepartmentsFail) {
                        return Container(
                          child: Text(departmentsList.code),
                        );
                      } else {
                        return Container(
                          child: Text(""),
                        );
                      }
                    }),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
