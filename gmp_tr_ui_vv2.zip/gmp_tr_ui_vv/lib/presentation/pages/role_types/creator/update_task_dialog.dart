import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/input_box.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

// ignore: must_be_immutable
class UpdateTaskDialog extends StatefulWidget {
  final Task task;

  UpdateTaskDialog({
    Key key,
    this.task,
  }) : super(key: key);

  @override
  _UpdateTaskDialogState createState() => _UpdateTaskDialogState();
}

class _UpdateTaskDialogState extends State<UpdateTaskDialog> {
  bool isRegularTask = false;
  List<TextEditingController> _dateController = [];
  final _textTitleController = TextEditingController();

  final documentTitleController = MyTextEditingController();
  final documentDescriptionController = MyTextEditingController();

  int departmentIdFk;
  int smallLeaderIdFk;
  int trainingTypeIdFk;
  int traininTypeIdFk;
  int documentTypeIdFk;

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  List<int> showAllUsersListWhen = [
    1,
    3,
    5,
    7
  ];

  DocumentsModel selectedDocument;

  GlobalKey key = new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
  final List<UpdateSingleTaskTestController> testControllers = [];
  List<DocumentTests> selectedDocumentTests = [];
  final List<PlatformFile> choseDocuments = [];

  List<DocumentFiles> selectedDocuments = [];

  List<DocumentTests> selectedDocumentTest = [];

  final int smallLeaderRoleId = 3;

  final int studentsRoleId = 5;

  int documentIdFk;
  String selectedPath;
  String selectedName;
  String selectedIdentifier;
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  int studentIdFk;
  List<String> selectedStudents = [];
  final documentVersionsSelection = SelectionBoxController();
  final documentTestVersionsSelection = SelectionBoxController();

  List<TaskStudents> taskUsers;

  List<int> selectedStudentsIds = [];
  final viewTypeSelection = SelectionBoxController();
  List<ViewTypeModel> views = [];
  List<int> taskTypeDocuments = [];
  List<ViewTypeModel> documentType = [];
  int documentFileIdFk;
  int documentTestIdFk;
  int taskTypeView;

  @override
  void initState() {
    super.initState();
    // AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.documentsBloc.add(OnLoadDocuments());
    AppBloc.studentsBloc.add(OnLoadStudents());
    AppBloc.tasksBloc.add(OnLoadTasksEvent(taskId: widget.task.id));
    AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: widget.task.departmentIdFk, roleId: smallLeaderRoleId));
    AppBloc.studentsBloc.add(OnLoadStudents(departmentIdFk: widget.task.departmentIdFk, roleIdFk: studentsRoleId));

    if (selectedDocument != null) _textTitleController.text = selectedDocument.title;
    _startDate = widget.task.startDate;
    _endDate = widget.task.endDate;
  }

  @override
  void didChangeDependencies() {
    setState(() {
      AppBloc.tasksBloc.add(OnLoadTasksEvent(taskId: widget.task.id));
      widget.task.taskStudents.forEach((ele) {
        selectedStudentsIds.add(ele.id);
        selectedStudents.add(ele.taskUser.username);
      });
      widget.task.taskDocuments.forEach((doc) => doc.document.documentTests.forEach(
            (e) => testControllers.add(
              new UpdateSingleTaskTestController(
                doRemove: onDelete,
                correctAnswers: e.rightAnswers,
                questionInputController: TextEditingController(text: e.question),
                selectedAnswers: e.totalAnswers,
                documentIdFk: e.documentTestIdFk,
                documentTestIdFk: e.documentTestIdFk,
                id: e.id,
              ),
            ),
          ));

      taskTypeView = widget.task.viewTypeIdFk;
      widget.task.taskDocuments.forEach((element) {
        documentVersionsSelection.value = element.document.version;
      });
      documentTitleController.text = widget.task.title;
      documentDescriptionController.text = widget.task.description;
      departmentIdFk = widget.task.departmentIdFk;
      trainingTypeIdFk = widget.task.trainingTypeIdFk;
      documentTypeIdFk = widget.task.documentTypeIdFk;
      smallLeaderIdFk = widget.task.smallLeaderIdFk;
      widget.task.taskDocuments.forEach((element) => selectedDocuments = element.document.documentFiles);

      taskUsers = widget.task.taskStudents;
      _dateController.clear();
      taskUsers.forEach((element) {
        var duration = DateFormat('yyyy/MM/dd').format(DateTime.parse(element.startDate ?? '2012-02-27')).toString() + "-" + DateFormat('yyyy/MM/dd').format(DateTime.parse(element.endDate ?? '2012-02-27')).toString();

        _dateController.add(TextEditingController(text: duration));
      });
    });

    super.didChangeDependencies();
  }

  void _showCalender(_startDate, _endDate, int index) {
    var started = DateFormat('yyyy-MM-dd 00:00:00.000').format(DateTime.parse(_startDate));
    var end = DateFormat('yyyy-MM-dd 00:00:00.000').format(DateTime.parse(_endDate));
    showDialog<void>(
        context: context,
        builder: (BuildContext buildContext) {
          return AlertDialog(
            content: Container(
              width: 280,
              height: 400,
              child: SfDateRangePicker(
                onSelectionChanged: (args) => _onSelectionChanged(args, index),
                selectionMode: DateRangePickerSelectionMode.range,
                // initialSelectedDates: [
                //   DateTime.parse(started),
                //   DateTime.parse(end),
                // ],
              ),
            ),
            actions: <Widget>[
              AppButton(
                Translate.of(context).translate('ok'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
                type: ButtonType.normal,
              ),
            ],
          );
        });
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args, int index) {
    setState(() {
      if (args.value is PickerDateRange) {
        _startDate = (args.value.startDate).toString();
        _endDate = (args.value.endDate).toString();
        _dateController.elementAt(index).text = DateFormat('dd/MM/yyyy').format(DateTime.parse(_startDate)) + "-" + DateFormat('dd/MM/yyyy').format(DateTime.parse(_endDate));
      } else if (args.value is DateTime) {
        _selectedDate = args.value.toString();
      } else if (args.value is List<DateTime>) {
        _dateCount = args.value.length.toString();
      } else {
        _rangeCount = args.value.length.toString();
      }
    });
    AppBloc.tasksBloc.add(OnLoadTasksEvent(taskId: widget.task.id));
  }

  Future<void> doUpdate() async {
    // check if all test been confirmed.
    if (selectedDocuments == null)
      for (var controller in testControllers) {
        if (controller.onFocus) {
          if (controller.changeFocus(context)) {
            setState(() {});
          } else {
            // save failed. suspend create task
            return;
          }
          return;
        }

        if (controller.totalAnswers == [] || controller.correctAnswers == []) {
          return;
        }
      }

    // check task title
    if (documentTitleController.text == null || documentTitleController.text.isEmpty) {
      SnackBarUtil.warn(context, "document title empty");
      return;
    }

    // check training type
    if (trainingTypeIdFk == null) {
      SnackBarUtil.warn(context, "training type not select");
      return;
    }

    // check document feature
    if (documentTypeIdFk == null) {
      SnackBarUtil.warn(context, "document feature not select");
      return;
    }

    // check department id
    if (departmentIdFk == null) {
      SnackBarUtil.warn(context, "department not select");
      return;
    }

    // check small leader id
    if (smallLeaderIdFk == null) {
      SnackBarUtil.warn(context, "small leader not select");
      return;
    }

    String title = documentTitleController.text;
    String description = documentDescriptionController.text;

    int creatorIdFk = Application.user.id;

    String fromDate = _startDate;
    String endDate = _endDate;

    final task = Task.create(
      isReadonly: isRegularTask,
      departmentIdFk: departmentIdFk,
      title: title,
      description: description,
      trainingTypeIdFk: trainingTypeIdFk,
      documentTypeIdFk: documentTypeIdFk,
      creatorIdFk: creatorIdFk,
      smallLeaderIdFk: smallLeaderIdFk,
      startDate: fromDate,
      endDate: endDate,
    );
    try {
      await Api.updateTask(task, widget.task.id);

      // do update task tests

      testControllers.forEach((e) {
        if (e.id != null) {
          Api.updateTaskTest(
            e.genTaskTest(widget.task.id),
          );
        } else {
          Api.createTaskTest(
            e.genTaskTest(widget.task.id),
          );
        }
      });

      selectedStudentsIds.forEach((element) {
        var dates = _dateController.elementAt(selectedStudentsIds.indexOf(element)).text.split('-').map((e) => DateFormat('dd/MM/yyyy').parse(e).toString()).toList();

        return Api.updateTaskDateToUsers(
          element,
          dates.first,
          dates.last,
        );
      });

      // do upload new files
      if (choseDocuments.isNotEmpty || choseDocuments.length > 0) {
        await Api.uploadTaskDocumentFiles(widget.task.id, choseDocuments);
      }

      /// DO UPLOAD EXISTS FILES
      if (documentIdFk != null) {
        selectedDocuments.forEach(
          (element) => Api.uploadExistsTaskDocumentFiles(
            widget.task.id,
            element.path,
            element.name,
            documentIdFk,
            selectedIdentifier,
          ),
        );
      }

      setState(() {});

      SnackBarUtil.info(context, "Updated Task Success.");
    } catch (error) {
      SnackBarUtil.info(context, error.toString());
    }
    // do create task
  }

  Future<void> uploadFile() async {
    if (widget.task.taskDocuments[0].document.documentFiles.isNotEmpty || widget.task.taskDocuments[0].document.documentFiles == []) {
      widget.task.taskDocuments[0].document.documentFiles.forEach((element) => Api.deleteTaskDocumentFile(element.id));
    }
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;

      print(choseDocuments);
      DocumentFiles documentFiles = new DocumentFiles.fromJson({
        "id": null,
        "name": file.name,
        "path": ""
      });
      setState(() {
        documentIdFk = null;
        choseDocuments.add(file);
        selectedDocuments.clear();
        selectedDocuments.add(documentFiles);
      });
      // print(file.name);
      // print(file.bytes);
      // print(file.size);
      // print(file.extension);
      // print(file.path);
    } else {
      // User canceled the picker
    }
  }

  @override
  Widget build(BuildContext context) {
    rebuildAllChildren(context);
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 0,
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    // AppButton(
                    //   Translate.of(context).translate('update'),
                    //   onPressed: () {
                    //     setState(() {
                    //       doUpdate()
                    //           .then((value) => Navigator.of(context).pop());
                    //     });
                    //   },
                    //   type: ButtonType.normal,
                    //   color: Color(0xff787E8C),
                    //   icon: Icon(Icons.save_outlined),
                    // ),
                    // SizedBox(
                    //   width: 15,
                    // ),
                    IconButton(
                      icon: Icon(Icons.close_outlined),
                      onPressed: () => Navigator.of(context).pop(),
                    )
                  ],
                ),
                SizedBox(
                  height: 12,
                ),
                //  regular or read only
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      runSpacing: 10,
                      spacing: 40,
                      children: [
                        // BlocBuilder<ViewTypeListBloc, ViewTypeListState>(
                        //   bloc: BlocProvider.of<ViewTypeListBloc>(context),
                        //   builder: (context, state) {
                        //     if (state is ViewTypeSuccess) {
                        //       views.clear();
                        //       if (views.isEmpty) {
                        //         for (var v in state.views) {
                        //           if (v.type == "T") {
                        //             views.add(v);
                        //           }
                        //         }
                        //       }

                        //       return SelectionBox<ViewTypeModel>(
                        //         leading: Translate.of(context)
                        //             .translate("task_type"),
                        //         hint: Translate.of(context)
                        //             .translate("task_type"),
                        //         controller: viewTypeSelection,
                        //         items: views,
                        //         getText: (view) => view.name,
                        //         onChanged: (value) {
                        //           setState(() {
                        //             taskTypeView = value.id;
                        //           });
                        //         },
                        //       );
                        //     } else if (state is ViewTypeLoading) {
                        //       return LoadingBox(
                        //         width: 10,
                        //         height: 10,
                        //       );
                        //     } else if (state is ViewTypeFail) {
                        //       return Text(state.code);
                        //     } else {
                        //       return Text("load task types failed.");
                        //     }
                        //   },
                        // ),
                        // selection box, choose dept
                        if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
                          BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
                            bloc: BlocProvider.of<DepartmentsListBloc>(context),
                            builder: (context, state) {
                              if (state is DepartmentsSuccess) {
                                return Wrap(
                                  children: [
                                    SizedBox(
                                      width: 162,
                                      height: 40,
                                      child: Container(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          Translate.of(context).translate("choose_department"),
                                          style: TextStyle(fontSize: 14),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 40,
                                      width: 200,
                                      child: Container(
                                        alignment: Alignment.center,
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 0,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          border: Border.all(width: 1, color: Colors.grey),
                                          borderRadius: BorderRadius.circular(2.2),
                                        ),
                                        child: DropdownButton(
                                          value: departmentIdFk,
                                          underline: SizedBox(),
                                          icon: Icon(Icons.keyboard_arrow_down_outlined),
                                          items: state.departments
                                              .map((e) => DropdownMenuItem(
                                                    child: Text(e.name, style: TextStyle(fontSize: 12)),
                                                    value: e.id,
                                                  ))
                                              .toList(),
                                          hint: Text(
                                            Translate.of(context).translate("choose_department"),
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 12,
                                            ),
                                          ),
                                          onChanged: (int value) {
                                            setState(() {
                                              departmentIdFk = value;
                                              AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(departmentId: value, roleId: smallLeaderRoleId));
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              } else if (state is DepartmentsLoading) {
                                return Text("loading");
                              } else {
                                return Text("load department data failed.");
                              }
                            },
                          ),
                      ],
                    ),
                  ],
                ),
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk)) const SizedBox(height: 12),

                // two selection box, train type and document feature
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
                  Wrap(
                    runSpacing: 12,
                    spacing: 40,
                    children: [
                      // selection box of training types
                      BlocBuilder<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                        bloc: BlocProvider.of<UserRoleTrainingTypesListBloc>(context),
                        builder: (context, state) {
                          if (state is UserRoleTrainingTypesSuccess) {
                            return Wrap(
                              children: [
                                SizedBox(
                                  width: 162,
                                  height: 40,
                                  child: Container(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      Translate.of(context).translate("training_type"),
                                      style: TextStyle(fontSize: 14),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 40,
                                  width: 200,
                                  child: Container(
                                    alignment: Alignment.center,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 0,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(width: 1, color: Colors.grey),
                                      borderRadius: BorderRadius.circular(2.2),
                                    ),
                                    child: DropdownButton(
                                      value: trainingTypeIdFk,
                                      underline: SizedBox(),
                                      icon: Icon(Icons.keyboard_arrow_down_outlined),
                                      items: state.userRoleTrainingType
                                          .map((e) => e.trainingType)
                                          .map((e) => DropdownMenuItem(
                                                child: Text(e.name, style: TextStyle(fontSize: 12)),
                                                value: e.id,
                                              ))
                                          .toList(),
                                      hint: Text(
                                        "Please choose a status",
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                      onChanged: (int value) {
                                        setState(() {
                                          traininTypeIdFk = value;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            );
                          } else if (state is UserRoleTrainingTypesLoading) {
                            return Text("loading");
                          } else {
                            return Text("load trainings type failed.");
                          }
                        },
                      ),

                      // selection box of training types
                      BlocBuilder<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                        bloc: BlocProvider.of<UserRoleDocTypesListBloc>(context),
                        builder: (context, state) {
                          if (state is UserRoleDocTypesSuccess) {
                            return Wrap(
                              children: [
                                SizedBox(
                                  width: 162,
                                  height: 40,
                                  child: Container(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      Translate.of(context).translate("document_feature"),
                                      style: TextStyle(fontSize: 14),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 40,
                                  width: 200,
                                  child: Container(
                                    alignment: Alignment.center,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 0,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(width: 1, color: Colors.grey),
                                      borderRadius: BorderRadius.circular(2.2),
                                    ),
                                    child: DropdownButton(
                                      value: documentTypeIdFk,
                                      underline: SizedBox(),
                                      icon: Icon(Icons.keyboard_arrow_down_outlined),
                                      items: state.userroleDocType
                                          .map((e) => e.documentType)
                                          .map((e) => DropdownMenuItem(
                                                child: Text(e.name, style: TextStyle(fontSize: 12)),
                                                value: e.id,
                                              ))
                                          .toList(),
                                      hint: Text(
                                        Translate.of(context).translate("document_feature"),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                      onChanged: (int value) {
                                        setState(() {
                                          documentTypeIdFk = value;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            );
                          } else if (state is UserRoleDocTypesLoading) {
                            return Text("loading");
                          } else {
                            return Text("load document features failed.");
                          }
                        },
                      ),
                    ],
                  ),
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk)) const SizedBox(height: 12),
                // taskTypeView == 1
                //     ? Wrap(
                //         runSpacing: 12,
                //         spacing: 40,
                //         children: [
                //           ///TAKS DOCUMENT TYPE ITEMS
                //           SizedBox(
                //             width: 162,
                //             height: 40,
                //             child: Container(
                //               alignment: Alignment.centerLeft,
                //               child: Text(
                //                 Translate.of(context)
                //                     .translate("select_document_type"),
                //                 style: TextStyle(fontSize: 14),
                //               ),
                //             ),
                //           ),
                //           Container(
                //             width: 190,
                //             height: 50,
                //             child: BlocBuilder<ViewTypeListBloc,
                //                 ViewTypeListState>(
                //               bloc: BlocProvider.of<ViewTypeListBloc>(context),
                //               builder: (context, state) {
                //                 if (state is ViewTypeSuccess) {
                //                   views.clear();
                //                   if (views.isEmpty) {
                //                     for (var v in state.views) {
                //                       if (v.type == "D") {
                //                         views.add(v);
                //                       }
                //                     }
                //                   }

                //                   return Container(
                //                     width: 100,
                //                     height: 60,
                //                     margin: EdgeInsets.only(right: 60),
                //                     child: CheckboxListTile(
                //                       activeColor: Color(0xff00A4E3),
                //                       dense: true,
                //                       contentPadding: EdgeInsets.zero,
                //                       title: Container(
                //                           width: 50,
                //                           child: Text(views[0].name)),
                //                       value: taskTypeDocuments
                //                           .contains(views[0].id),
                //                       onChanged: (value) {
                //                         setState(
                //                           () {
                //                             if (value == true) {
                //                               documentFileIdFk = views[0].id;
                //                               taskTypeDocuments
                //                                   .add(views[0].id);
                //                             } else {
                //                               taskTypeDocuments
                //                                   .remove(views[0].id);
                //                             }
                //                             AppBloc.documentsBloc.add(
                //                               OnLoadDocuments(
                //                                   viewTypeIdFk:
                //                                       documentFileIdFk,
                //                                   trainingTypeIdFk:
                //                                       trainingTypeIdFk,
                //                                   departmentIdFk:
                //                                       departmentIdFk,
                //                                   documentFeature:
                //                                       documentTypeIdFk),
                //                             );
                //                           },
                //                         );
                //                       },
                //                     ),
                //                   );
                //                 } else if (state is ViewTypeLoading) {
                //                   return LoadingBox(
                //                     width: 10,
                //                     height: 10,
                //                   );
                //                 } else if (state is ViewTypeFail) {
                //                   return Text(state.code);
                //                 } else {
                //                   return Text("load training types failed.");
                //                 }
                //               },
                //             ),
                //           ),
                //         ],
                //       )
                //     : Container(),
                // two input box, document title and document description
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
                  Wrap(
                    runSpacing: 12,
                    spacing: 40,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: 162,
                            height: 40,
                            child: Container(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate("document_title"),
                                style: TextStyle(fontSize: 14),
                              ),
                            ),
                          ),
                          BlocBuilder<DocumentsBloc, DocumentsState>(
                            bloc: BlocProvider.of<DocumentsBloc>(context),
                            builder: (context, documentsList) {
                              if (documentsList is DocumentsLoading) {
                                return Container(
                                  child: LoadingBox(
                                    height: 30,
                                  ),
                                );
                              } else if (documentsList is DocumentsSuccess) {
                                return Container(
                                  width: 200,
                                  height: 38,
                                  child: CustomAutoCompleteTextField<DocumentsModel>(
                                    controller: documentTitleController,
                                    suggestions: documentsList.documents,
                                    key: key,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                    ),
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(3)),
                                        borderSide: BorderSide(color: Colors.red, width: 1.0),
                                      ),
                                      contentPadding: EdgeInsets.fromLTRB(10, 4, 10, 4),
                                      hintText: Translate.of(context).translate('document_title'),
                                      hintStyle: TextStyle(color: Colors.black),
                                    ),
                                    itemBuilder: (context, query) {
                                      return new Padding(
                                          child: new ListTile(
                                            title: new Text(query.title),
                                          ),
                                          padding: EdgeInsets.all(2.0));
                                    },
                                    textChanged: (text) {
                                      print(text);
                                    },
                                    itemSorter: (a, b) => a.title.compareTo(b.title),
                                    itemFilter: (suggestion, input) => suggestion.title.toLowerCase().startsWith(input.toLowerCase()),
                                    itemSubmitted: (item) {
                                      setState(
                                        () {
                                          selectedDocument = item;
                                          documentTitleController.text = item.title;
                                          documentIdFk = item.id;
                                          selectedIdentifier = item.identifier;
                                          selectedName = item.documentFiles[0].name;
                                          selectedPath = item.documentFiles[0].path;
                                          selectedDocuments = item.documentFiles;
                                          selectedDocumentTest = item.documentTests;
                                          var documentTestIdFk = item.documentTests.first.id;
                                          item.documentTests.forEach(
                                            (e) => testControllers.add(
                                              new UpdateSingleTaskTestController(doRemove: onDelete, correctAnswers: e.rightAnswers, questionInputController: TextEditingController(text: e.question), selectedAnswers: e.totalAnswers, documentIdFk: documentIdFk, documentTestIdFk: documentTestIdFk),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                    clearOnSubmit: false,
                                  ),
                                );
                              } else {
                                return Container();
                              }
                            },
                          ),
                          // BlocBuilder<DocumentVersionsBloc,
                          //     DocumentVersionsState>(
                          //   bloc:
                          //       BlocProvider.of<DocumentVersionsBloc>(context),
                          //   builder: (context, state) {
                          //     if (state is DocumentVersionFetchSuccess) {
                          //       List<DocVersionsModel> fileVersioning = [];
                          //       for (var file in state.versions) {
                          //         if (file.viewIdFk == 3) {
                          //           fileVersioning.add(file);
                          //           print("fileVersioning $fileVersioning");
                          //         }
                          //       }
                          //       return SelectionBox<DocVersionsModel>(
                          //         leading: Translate.of(context)
                          //             .translate("file_version"),
                          //         hint: Translate.of(context)
                          //             .translate("file_version"),
                          //         controller: documentVersionsSelection,
                          //         items: fileVersioning,
                          //         getText: (e) => e.version.toString(),
                          //         onChanged: (value) {
                          //           setState(() {
                          //             // taskDocuments.add(value.documentId);
                          //             documentIdFk = value.documentId;
                          //             selectedIdentifier = value.identifier;
                          //             selectedName =
                          //                 value.documentFiles[0].name;
                          //             selectedPath =
                          //                 value.documentFiles[0].path;
                          //             selectedDocuments = value.documentFiles;
                          //           });
                          //         },
                          //       );
                          //     } else if (state is DepartmentsLoading) {
                          //       return LoadingBox(
                          //         width: 10,
                          //         height: 10,
                          //       );
                          //     } else {
                          //       return Text("");
                          //     }
                          //   },
                          // ),
                        ],
                      ),
                      InputBox(
                        label: Translate.of(context).translate("document_description"),
                        controller: documentDescriptionController,
                      ),
                    ],
                  ),
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk)) const SizedBox(height: 12),

                // button, upload file;
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk)) UpdateUploadTaskFileButton(uploadFile),
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk)) const SizedBox(height: 23),

                // data table, files
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk) && selectedDocuments.isNotEmpty) UpdateUploadedTaskFileTable(selectedDocuments: selectedDocuments),
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk)) const SizedBox(height: 20),

                // tests table
                if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk) && testControllers.isNotEmpty) UpdateTaskTestsTable(controllers: testControllers),
                const SizedBox(height: 30),

                // selection box, choose small leader

                Wrap(
                  runSpacing: 12,
                  spacing: 20,
                  children: [
                    if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Translate.of(context).translate("choose_small_leader"),
                            style: TextStyle(fontSize: 12),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
                            bloc: BlocProvider.of<DepartmentUsersBloc>(context),
                            builder: (context, state) {
                              if (state is DepartmentUsersSuccess) {
                                return SizedBox(
                                  height: 40,
                                  width: 200,
                                  child: Container(
                                    alignment: Alignment.center,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 0,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(width: 1, color: Colors.grey),
                                      borderRadius: BorderRadius.circular(2.2),
                                    ),
                                    child: DropdownButton(
                                      value: smallLeaderIdFk ?? widget.task.smallLeaderIdFk,
                                      underline: SizedBox(),
                                      icon: Icon(Icons.keyboard_arrow_down_outlined),
                                      items: state.departmentsUser
                                          .map((e) => DropdownMenuItem(
                                                child: Text(e.name, style: TextStyle(fontSize: 12)),
                                                value: e.id,
                                              ))
                                          .toList(),
                                      hint: Text(
                                        Translate.of(context).translate("choose_small_leader"),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                      onChanged: (int value) {
                                        setState(() {
                                          smallLeaderIdFk = value;
                                        });
                                      },
                                    ),
                                  ),
                                );
                              } else if (state is DepartmentUsersLoading) {
                                return LoadingBox(height: 20, width: 20);
                              } else {
                                return Container();
                              }
                            },
                          ),
                        ],
                      ),
                    // selection box, choose STUDENT
                    // Column(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //   children: [
                    //     Text(
                    //       Translate.of(context).translate("choose_student"),
                    //       style: TextStyle(fontSize: 12),
                    //     ),
                    //     SizedBox(
                    //       height: 5,
                    //     ),
                    //     SizedBox(
                    //       width: 162,
                    //       height: 40,
                    //       child: showAllUsersListWhen
                    //               .contains(widget.task.taskStatusIdFk)
                    //           ? UpdateStudentsDropDownMultiSelect(
                    //               onChanged:
                    //                   (List<String> names, List<int> ids) {
                    //                 setState(() {
                    //                   selectedStudents = names;
                    //                   selectedStudentsIds = ids;
                    //                 });
                    //               },
                    //               selectedValues: selectedStudents,
                    //               selectedIds: selectedStudentsIds,
                    //               whenEmpty: Translate.of(context)
                    //                   .translate("choose_student"),
                    //               departmentIdFk: departmentIdFk,
                    //               studentsRoleId: studentsRoleId,
                    //               taskId: widget.task.id,
                    //             )
                    //           : TaskUsersDropDownMultiSelect(
                    //               onChanged:
                    //                   (List<String> names, List<int> ids) {
                    //                 setState(() {
                    //                   selectedStudents = names;
                    //                   selectedStudentsIds = ids;
                    //                 });
                    //               },
                    //               selectedValues: selectedStudents,
                    //               selectedIds: selectedStudentsIds,
                    //               whenEmpty: Translate.of(context)
                    //                   .translate("choose_student"),
                    //               taskUsers: taskUsers,
                    //             ),
                    //     ),
                    //   ],
                    // ),
                    for (var student in selectedStudents)
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Container(
                                width: 200,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 14),
                                    Text('$student :'),
                                  ],
                                )),
                            Container(
                              width: 310,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    Translate.of(context).translate("choose_duration"),
                                    style: TextStyle(fontSize: 12),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Container(
                                    width: 300,
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _showCalender(_startDate, _endDate, selectedStudents.indexOf(student));
                                        });
                                      },
                                      child: AbsorbPointer(
                                        child: AppTextInput(
                                          controller: _dateController.elementAt(selectedStudents.indexOf(student)),
                                          hintText: Translate.of(context).translate("from_to_date"),
                                          keyboardType: TextInputType.datetime,
                                          icon: Icon(
                                            Icons.calendar_today_outlined,
                                            color: Colors.blue,
                                            size: 13,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            GestureDetector(
                                onTap: () {
                                  AppBloc.taskUsersBloc.add(OnDeleteTaskUser(taskId: widget.task.id, studentIdFk: selectedStudentsIds.elementAt(selectedStudents.indexOf(student))));
                                  selectedStudentsIds.removeAt(selectedStudents.indexOf(student));
                                  _dateController.removeAt(selectedStudents.indexOf(student));
                                  selectedStudents.remove(student);
                                  setState(() {});
                                },
                                child: Column(
                                  children: [
                                    SizedBox(height: 14),
                                    Icon(Icons.delete),
                                  ],
                                ))
                          ],
                        ),
                      ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        AppButton(
                          Translate.of(context).translate('update'),
                          onPressed: () {
                            doUpdate().then((value) => Navigator.of(context).pop());

                            setState(() {});
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(Icons.save_outlined),
                        ),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void onDelete(int index) => setState(() {
        testControllers.removeAt(index);
      });

  void rebuildAllChildren(BuildContext context) {
    void rebuild(Element el) {
      el.markNeedsBuild();
      el.visitChildren(rebuild);
    }

    (context as Element).visitChildren(rebuild);
  }
}
