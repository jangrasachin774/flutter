import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';

/// for create document/task page
class InputBox extends StatefulWidget {
  final String label;
  final MyTextEditingController controller;
  final TextInputType keyBoardType;
  final List<TextInputFormatter> inputFormatters;
  final Function(String) onChange;

  const InputBox(
      {Key key,
      this.label,
      this.controller,
      this.keyBoardType,
      this.inputFormatters,
      this.onChange})
      : super(key: key);

  @override
  _InputBoxState createState() => _InputBoxState();
}

class _InputBoxState extends State<InputBox> {
  @override
  Widget build(BuildContext context) {
    return Wrap(children: [
      SizedBox(
        width: 162,
        height: 40,
        child: Container(
          alignment: Alignment.centerLeft,
          child: Text(
            widget.label,
            style: TextStyle(fontSize: 14),
          ),
        ),
      ),
      SizedBox(
        height: 40,
        width: 200,
        child: AppTextInput(
          inputFormatters: widget.inputFormatters,
          keyboardType: widget.keyBoardType,
          controller: widget.controller,
          errorText:
              Translate.of(context).translate(widget.controller._validResult),
          onTapIcon: () async => widget.controller.clear(),
          icon: Icon(Icons.clear, size: 14),
          onChanged: (text) {
            widget.onChange(text);
            widget.controller.valid();
          },
        ),
      )
    ]);
  }
}

class InputSearchBox extends StatefulWidget {
  final String hint;
  final Function(String value) onChanged;
  final MyTextEditingController controller;

  const InputSearchBox(
      {Key key, this.hint, this.controller, @required this.onChanged})
      : super(key: key);

  @override
  _InputSearchBoxState createState() => _InputSearchBoxState();
}

class _InputSearchBoxState extends State<InputSearchBox> {
  @override
  Widget build(BuildContext context) {
    return Wrap(children: [
      // SizedBox(
      //   width: 162,
      //   height: 40,
      //   child: Container(
      //     alignment: Alignment.centerLeft,
      //     child: Text(
      //       widget.label,
      //       style: TextStyle(fontSize: 14),
      //     ),
      //   ),
      // ),
      SizedBox(
        height: 40,
        // width: 200,
        child: AppTextInput(
          controller: widget.controller,
          errorText:
              Translate.of(context).translate(widget.controller._validResult),
          onTapIcon: widget.controller.text.isNotEmpty
              ? () async => widget.controller.clear()
              : () {},
          icon: widget.controller.text.isNotEmpty
              ? Icon(Icons.clear, size: 14)
              : Icon(Icons.search, size: 14),
          onChanged: (text) =>
              {widget.controller.isValid(), widget.onChanged.call(text)},
          hintText: widget.hint,
          maxLines: 1,
        ),
      )
    ]);
  }
}

class MyTextEditingController extends TextEditingController {
  String _validResult;
  ValidateType validateType;
  bool allowEmpty;

  MyTextEditingController({
    this.validateType = ValidateType.normal,
    this.allowEmpty = false,
  });

  bool isValid() {
    return _validResult == null;
  }

  void valid() {
    _validResult = UtilValidator.validate(
      data: this.text,
      type: validateType,
      allowEmpty: allowEmpty,
    );
  }
}
