import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/user_role_view_types/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filter_strategy.dart';
import 'package:gmptr/presentation/pages/role_types/creator/algorithm/filter_strategy_factory.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/loading_box.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../../../../../global.dart';

/// for creator dashboard
class FiltersBox extends StatefulWidget {
  final int taskStatusId;
  final List<int> viewType;
  const FiltersBox({
    Key key,
    this.taskStatusId,
    this.viewType,
  }) : super(key: key);

  @override
  _FiltersBoxState createState() => _FiltersBoxState();
}

class _FiltersBoxState extends State<FiltersBox> {
  final filterByNothing = FilterStrategyFactory().getStrategy(FilterEnum.NONE);

  final FilterByResult filterByResult = FilterStrategyFactory().getStrategy(FilterEnum.Result);
  final FilterByTime filterByTime = FilterStrategyFactory().getStrategy(FilterEnum.Time);

  var documentFeatureIdFk;
  var trainingTypeIdFk;
  var roleTypeIdFk;
  var departmentIdFk;
  var workerIdFk;
  var viewTypeIdFk = 1;

  List<UserRoles> userRoles;
  List<UserRoleDept> userRoleDepartments = [];

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  // List<int> viewType = [1];

  @override
  void initState() {
    super.initState();
    // AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
    // AppBloc.viewTypesBloc.add(OnLoadViewType());
    // AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
    AppBloc.userRoleDocTypesBloc.add(OnLoadUserRoleDocTypes());
    AppBloc.userRoleViewTypesBloc.add(OnLoadUserRoleViewTypes());
    AppBloc.userRoleTrainingTypes.add(OnLoadUserRoleTrainingTypes());
    AppBloc.departmentBlocs.add(OnLoadDepartments());
    AppBloc.rolesBloc.add(OnLoadRoles());
    userRoles = Application.user.userRoles;
    viewTypeIdFk = widget.viewType.first;
    setState(() {
      userRoles.forEach((e) {
        print(" userRoleDept >>>>> ${e.role.name}");
        if (e.roleIdFk == 2) {
          userRoleDepartments.addAll(e.userRoleDept);
        }
      });
    });

    // if (widget.viewType != null) viewType = widget.viewType;
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    setState(() {
      if (args.value is PickerDateRange) {
        _startDate = DateFormat('dd/MM/yyyy').format(args.value.startDate).toString();
        _endDate = DateFormat('dd/MM/yyyy').format(args.value.endDate ?? args.value.startDate).toString();
      } else if (args.value is DateTime) {
        _selectedDate = args.value.toString();
      } else if (args.value is List<DateTime>) {
        _dateCount = args.value.length.toString();
      } else {
        _rangeCount = args.value.length.toString();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(children: [
        Container(
            color: Colors.grey.withOpacity(.2),
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  Translate.of(context).translate("filters"),
                  textAlign: TextAlign.start,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                OutlinedButton(
                  child: Text(
                    Translate.of(context).translate('clear_filter'),
                  ),
                  onPressed: () {
                    setState(() {
                      documentFeatureIdFk = null;
                      trainingTypeIdFk = null;
                      roleTypeIdFk = null;
                      departmentIdFk = null;
                      viewTypeIdFk = 1;

                      AppBloc.tasksDocBloc.add(
                        OnLoadTaskDocEvent(viewType: [
                          viewTypeIdFk
                        ], creatorIdFk: Application.user.id, taskDocStatusId: widget.taskStatusId),
                      );
                    });
                  },
                  style: OutlinedButton.styleFrom(side: BorderSide(color: Colors.lightBlueAccent)),
                ),
              ],
            )),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              children: [
                /// VIEW TYPES
                Container(
                  width: 120,
                  child: BlocBuilder<UserRoleViewTypesListBloc, UserRoleViewTypesListState>(
                    bloc: BlocProvider.of<UserRoleViewTypesListBloc>(context),
                    builder: (context, state) {
                      if (state is UserRoleViewTypesSuccess) {
                        return createDropdownButton(
                          hint: Translate.of(context).translate('view_type'),
                          value: viewTypeIdFk,
                          items: state.userroleTaskType.map((e) => DropdownMenuItem(child: Text(e.name, style: text12), value: e.id)).toList(),
                          onChanged: (newValue) {
                            selectedViewTypeCommon = viewTypeIdFk = newValue;
                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                              viewType: [
                                viewTypeIdFk
                              ],
                              documentFeatureIdFk: documentFeatureIdFk,
                              trainingTypeIdFk: trainingTypeIdFk,
                              roleTypeIdFk: roleTypeIdFk,
                              workerIdFk: workerIdFk,
                              departmentIdFk: departmentIdFk,
                              creatorIdFk: Application.user.id,
                              taskDocStatusId: widget.taskStatusId,
                            ));
                            // setState(() {});
                          },
                        );
                      } else if (state is UserRoleViewTypesLoading) {
                        return LoadingBox(
                          width: 10,
                          height: 10,
                        );
                      } else if (state is UserRoleViewTypesFail) {
                        return Text(state.code);
                      } else {
                        return Text("load view types failed.");
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),

                /// DEPARTMENT LIST
                Container(
                  width: 120,
                  child: createDropdownButton(
                    hint: Translate.of(context).translate('department'),
                    value: departmentIdFk,
                    items: userRoleDepartments.map((e) => DropdownMenuItem(child: Text(e.roleDept.name, style: text12), value: e.roleDept.id)).toList(),
                    onChanged: (newValue) {
                      setState(() {
                        departmentIdFk = newValue;
                        AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                          viewType: [
                            viewTypeIdFk
                          ],
                          documentFeatureIdFk: documentFeatureIdFk,
                          trainingTypeIdFk: trainingTypeIdFk,
                          roleTypeIdFk: roleTypeIdFk,
                          workerIdFk: workerIdFk,
                          departmentIdFk: newValue,
                          creatorIdFk: Application.user.id,
                          taskDocStatusId: widget.taskStatusId,
                        ));
                      });
                    },
                  ),
                ),

                const SizedBox(width: 10),

                /// TRAINING TYPE
                BlocBuilder<UserRoleTrainingTypesListBloc, UserRoleTrainingTypesListState>(
                  bloc: BlocProvider.of<UserRoleTrainingTypesListBloc>(context),
                  builder: (context, state) {
                    if (state is UserRoleTrainingTypesSuccess) {
                      return createDropdownButton(
                        hint: Translate.of(context).translate('training_type'),
                        value: trainingTypeIdFk,
                        items: state.userRoleTrainingType.map((e) => DropdownMenuItem(child: Text(e.trainingType.name, style: text12), value: e.trainingType.id)).toList(),
                        onChanged: (newValue) {
                          setState(() {
                            trainingTypeIdFk = newValue;
                            AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                              viewType: [
                                viewTypeIdFk
                              ],
                              documentFeatureIdFk: documentFeatureIdFk,
                              trainingTypeIdFk: trainingTypeIdFk,
                              roleTypeIdFk: roleTypeIdFk,
                              workerIdFk: workerIdFk,
                              departmentIdFk: departmentIdFk,
                              creatorIdFk: Application.user.id,
                              taskDocStatusId: widget.taskStatusId,
                            ));
                          });
                        },
                      );
                    } else if (state is UserRoleTrainingTypesLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load training types failed.");
                    }
                  },
                ),
                const SizedBox(width: 10),
                BlocBuilder<UserRoleDocTypesListBloc, UserRoleDocTypesListState>(
                  bloc: BlocProvider.of<UserRoleDocTypesListBloc>(context),
                  builder: (context, state) {
                    if (state is UserRoleDocTypesSuccess) {
                      return createDropdownButton(
                        hint: Translate.of(context).translate('document_feature'),
                        value: documentFeatureIdFk,
                        items: state.userroleDocType
                            .map(
                              (e) => DropdownMenuItem(
                                child: Text(e.documentType.name, style: text12),
                                value: e.documentType.id,
                              ),
                            )
                            .toList(),
                        onChanged: (newValue) {
                          setState(
                            () {
                              documentFeatureIdFk = newValue;
                              AppBloc.tasksDocBloc.add(
                                OnLoadTaskDocEvent(
                                  viewType: [
                                    viewTypeIdFk
                                  ],
                                  documentFeatureIdFk: documentFeatureIdFk,
                                  trainingTypeIdFk: trainingTypeIdFk,
                                  roleTypeIdFk: roleTypeIdFk,
                                  workerIdFk: workerIdFk,
                                  departmentIdFk: departmentIdFk,
                                  creatorIdFk: Application.user.id,
                                  taskDocStatusId: widget.taskStatusId,
                                ),
                              );
                            },
                          );
                        },
                      );
                    } else if (state is UserRoleDocTypesLoading) {
                      return LoadingBox(
                        width: 20,
                        height: 20,
                      );
                    } else {
                      return Text("load document features failed.");
                    }
                  },
                ),
                // const SizedBox(width: 10),
                // BlocBuilder<RolesListBloc, RolesListState>(
                //   bloc: BlocProvider.of<RolesListBloc>(context),
                //   builder: (context, state) {
                //     if (state is RolesSuccess) {
                //       return createDropdownButton(
                //         hint: "Role Type",
                //         value: FilterStrategyFactory()
                //             .getStrategy(FilterEnum.RoleType)
                //             .value,
                //         items: state.roles
                //             .map((e) => DropdownMenuItem(
                //                 child: Text(e.name, style: text12),
                //                 value: e.id))
                //             .toList(),
                //         onChanged: (newValue) {
                //           setState(() {
                //             roleTypeIdFk = newValue;
                //           });
                //         },
                //       );
                //     } else if (state is RolesLoading) {
                //       return LoadingBox(
                //         width: 20,
                //         height: 20,
                //       );
                //     } else {
                //       return Text("load role types failed.");
                //     }
                //   },
                // ),

                // const SizedBox(width: 10),
                // createDropdownButton(
                //   hint: "Worker",
                //   value: null,
                //   items: [],
                //   onChanged: (newValue) {},
                // ),
                const SizedBox(width: 10),
                viewTypeIdFk == 1
                    ? createDropdownButton(
                        hint: Translate.of(context).translate('result'),
                        value: filterByResult.value,
                        items: filterByResult.kv.entries.map((entry) => DropdownMenuItem(child: Text(entry.key, style: text12), value: entry.value)).toList(),
                        onChanged: (newValue) => setState(() {}),
                      )
                    : Container(),
                const SizedBox(width: 10),
                createDropdownButton(
                  hint: Translate.of(context).translate('time'),
                  value: filterByTime.value,
                  items: [
                    DropdownMenuItem(
                      child: Container(
                        width: 280,
                        child: SfDateRangePicker(
                          onSelectionChanged: _onSelectionChanged,
                          selectionMode: DateRangePickerSelectionMode.range,
                          initialSelectedRange: PickerDateRange(DateTime.now().subtract(const Duration(days: 4)), DateTime.now().add(const Duration(days: 3))),
                        ),
                      ),
                      value: -1,
                    ),
                  ]..addAll(filterByTime.kv.entries.map((entry) => DropdownMenuItem(child: Text(entry.key, style: text12), value: entry.value)).toList()),
                  onChanged: (newValue) {
                    if (newValue != -1)
                      setState(() {
                        AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(
                          viewType: [
                            viewTypeIdFk
                          ],
                          documentFeatureIdFk: documentFeatureIdFk,
                          trainingTypeIdFk: trainingTypeIdFk,
                          roleTypeIdFk: roleTypeIdFk,
                          workerIdFk: workerIdFk,
                          departmentIdFk: departmentIdFk,
                          criteria: newValue,
                          startDate: _startDate,
                          endDate: _endDate,
                          creatorIdFk: Application.user.id,
                          taskDocStatusId: widget.taskStatusId,
                        ));
                      });
                  },
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  Widget createDropdownButton({
    String hint,
    dynamic value,
    List<DropdownMenuItem<dynamic>> items,
    Function(dynamic) onChanged,
  }) {
    return Container(
      height: 36,
      padding: const EdgeInsets.fromLTRB(7, 10, 7, 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black.withOpacity(.06), width: 1),
      ),
      child: DropdownButton(
        hint: Text(
          hint,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
        ),
        icon: const Icon(
          Icons.expand_more_outlined,
          color: Colors.blueAccent,
        ),
        elevation: 8,
        underline: Container(color: Colors.white),
        iconSize: 18,
        value: value,
        items: items,
        onChanged: onChanged,
      ),
    );
  }

  get text12 => const TextStyle(fontSize: 12);
}
