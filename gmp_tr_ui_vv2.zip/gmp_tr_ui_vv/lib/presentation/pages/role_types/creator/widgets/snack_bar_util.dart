import 'package:flutter/material.dart';

class SnackBarUtil{


  static info(BuildContext context, String msg) {
    final bar = SnackBar(
      backgroundColor: Colors.green[300],
      content: Text(msg),
      action: SnackBarAction(
        label: 'X',
        textColor: Colors.white,
        onPressed: () {},
      ),
    );


    ScaffoldMessenger.of(context).showSnackBar(bar);
  }

  static warn(BuildContext context, String msg) {
    final bar = SnackBar(
      backgroundColor: Colors.yellow[300],
      content: Text(msg, style: TextStyle(color: Colors.black),),
      action: SnackBarAction(
        label: 'X',
        textColor: Colors.black,
        onPressed: () {},
      ),
    );


    ScaffoldMessenger.of(context).showSnackBar(bar);
  }


  static error(BuildContext context, String msg) {
    final bar = SnackBar(
      backgroundColor: Colors.red[300],
      content: Text(msg),
      action: SnackBarAction(
        label: 'X',
        textColor: Colors.white,
        onPressed: () {},
      ),
    );


    ScaffoldMessenger.of(context).showSnackBar(bar);
  }
}
