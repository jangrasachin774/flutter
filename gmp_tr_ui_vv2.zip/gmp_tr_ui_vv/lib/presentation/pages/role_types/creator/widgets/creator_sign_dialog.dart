import 'package:flutter/material.dart';
import 'package:gmptr/utils/utils.dart';

class CreatorSignDialog extends StatelessWidget {
  final String text;
  const CreatorSignDialog({Key key, this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(
                this.text,
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlueAccent),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 45,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: Text(Translate.of(context).translate("confirm")),
                ),
              )
            ]),
          ),
          Positioned(
            right: 0,
            child: IconButton(
              icon: Icon(Icons.close_outlined),
              onPressed: () => Navigator.of(context).pop(false),
            ),
          )
        ],
      ),
    );
  }
}
