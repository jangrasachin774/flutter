import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/date_picker.dart';
import 'package:gmptr/utils/translate.dart';

class ChangeStudentTimeDialog extends StatelessWidget {
  const ChangeStudentTimeDialog({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final startTime = DatePickerController();
    final endTime = DatePickerController();

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(
                Translate.of(context).translate("choose_time"),
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.lightBlueAccent),
              ),
              const SizedBox(height: 35),
              Row(mainAxisSize: MainAxisSize.min, children: [
                DatePicker(startTime, "start time"),
                const SizedBox(width: 10),
                DatePicker(endTime, "end time"),
              ]),
              const SizedBox(height: 30),
              SizedBox(
                width: 300,
                height: 45,
                child: ElevatedButton(
                    onPressed: () => _submit(context),
                    child: Text(Translate.of(context).translate("submit"))),
              )
            ]),
          ),
          Positioned(
            right: 0,
            child: IconButton(
              icon: Icon(Icons.close_outlined),
              onPressed: () => Navigator.of(context).pop(),
            ),
          )
        ],
      ),
    );
  }

  _submit(BuildContext context) async {
    // ignore: todo
    // TODO: submit the time change

    Navigator.of(context).pop();
  }
}
