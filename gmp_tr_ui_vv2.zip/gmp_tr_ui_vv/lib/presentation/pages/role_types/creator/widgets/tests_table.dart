import 'package:flutter/material.dart';
import 'package:gmptr/models/model_document_tests.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/responsive.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/translate.dart';

class TestsTable extends StatefulWidget {
  final List<SingleTestController> controllers;

  const TestsTable(this.controllers, {Key key}) : super(key: key);

  @override
  _TestsTableState createState() => _TestsTableState();
}

class _TestsTableState extends State<TestsTable> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // editable table, tests
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            Translate.of(context).translate("tests"),
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            // FIXME: text will overflow in mobile size
            child: Row(children: [
              // S.NO
              textOfTestsTable(1, Translate.of(context).translate("s_no")),
              const SizedBox(width: 10),

              // Question
              textOfTestsTable(12, Translate.of(context).translate("question")),
              const SizedBox(width: 10),

              // Total Answers
              textOfTestsTable(
                  3, Translate.of(context).translate("total_answers")),
              const SizedBox(width: 10),

              // Correct Answer
              textOfTestsTable(
                  2, Translate.of(context).translate("correct_answer")),
              const SizedBox(width: 10),

              Spacer(flex: 2),
            ]),
          ),
          const SizedBox(height: 20),
          Column(
            children: List.generate(widget.controllers.length,
                (i) => SingleTest(controller: widget.controllers[i], index: i)),
          )
        ]),
        const SizedBox(height: 10),

        // add new question button
        AppButton(
          Translate.of(context).translate("add_new_question_and_answer"),
          icon: Icon(Icons.question_answer_outlined),
          type: ButtonType.outline,
          color: Color(0xff787E8C),
          onPressed: () => setState(
              () => widget.controllers.add(new SingleTestController(onDelete))),
        ),
      ],
    );
  }

  Widget textOfTestsTable(int flex, String key) => Expanded(
        flex: flex,
        child: Container(
          child: Text(
            Translate.of(context).translate(key),
            style: TextStyle(
                fontSize: Responsive.isMobile(context) ? 10 : 14,
                fontWeight: FontWeight.bold),
          ),
        ),
      );

  void onDelete(int index) =>
      setState(() => widget.controllers.removeAt(index));
}

class SingleTestController {
  final _questionInputController = TextEditingController();

  List<String> _selectedAnswers = [];
  List<String> _correctAnswers = [];

  bool onFocus = true;

  final void Function(int) doRemove;

  SingleTestController(this.doRemove);

  void removeThis(int index) {
    doRemove(index);
  }

  bool changeFocus(BuildContext context) {
    if (onFocus == true) {
      // check user input here.

      if (_selectedAnswers.isEmpty || _correctAnswers.isEmpty) {
        SnackBarUtil.warn(context, "total answer or correct answer not select");
        return false;
      }

      if (_questionInputController.text == "") {
        SnackBarUtil.warn(context, "question can't be empty");
        return false;
      }
    }
    print(onFocus);
    onFocus = !onFocus;

    return true;
  }

  DocumentTestModel genDocumentTest(int documentId) {
    return DocumentTestModel.create(
      question: _questionInputController.text,
      documentIdFk: documentId,
      totalAnswers: _selectedAnswers,
      rightAnswers: _correctAnswers,
    );
  }

  get question => _questionInputController.text;

  get totalAnswers => _selectedAnswers;

  get correctAnswers => _correctAnswers;
}

class SingleTest extends StatefulWidget {
  final int index;
  final SingleTestController controller;

  const SingleTest({Key key, this.controller, this.index}) : super(key: key);

  @override
  _SingleTestState createState() => _SingleTestState();
}

class _SingleTestState extends State<SingleTest> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xffd4d4d4),
        border: Border.all(
          color: Colors.grey.withOpacity(.12),
          width: 1,
        ),
      ),
      constraints: BoxConstraints(minHeight: 50),
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
      // generated by a test recorde
      child: Row(children: [
        // S.NO.
        Expanded(
          flex: 1,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            alignment: Alignment.center,
            child: SizedBox(
              height: 45,
              child: Center(
                child: Text(
                  (widget.index + 1).toString(),
                  style: TextStyle(fontSize: 14),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),

        // question
        Expanded(
            flex: 12,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: focusColor,
              ),
              padding: EdgeInsets.symmetric(vertical: 10),
              alignment: Alignment.center,
              child: TextField(
                maxLines: null,
                keyboardType: TextInputType.multiline,
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                  border: OutlineInputBorder(borderSide: BorderSide.none),
                ),
                style: TextStyle(fontSize: 12),
                enabled: widget.controller.onFocus,
                controller: widget.controller._questionInputController,
              ),
            )),
        const SizedBox(width: 10),

        // total answers
        Expanded(
          flex: 3,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            alignment: Alignment.center,
            // FIXME: will overflow while choosing dropdown item in mobile size
            child: createDropdownMultiSelect(
              onChanged: (List<String> newValues) => setState(
                  () => widget.controller._selectedAnswers = newValues),
              options:
                  List.generate(26, (index) => String.fromCharCode(65 + index)),
              selectedValues: widget.controller._selectedAnswers,
              hint: "A ~ Z",
            ),
          ),
        ),
        const SizedBox(width: 10),

        // correct answer
        Expanded(
          flex: 2,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: focusColor,
            ),
            alignment: Alignment.center,
            child: createDropdownMultiSelect(
              hint: "answers",
              selectedValues: widget.controller._correctAnswers,
              options: widget.controller._selectedAnswers,
              onChanged: (newValues) =>
                  setState(() => widget.controller._correctAnswers = newValues),
            ),
          ),
        ),
        const SizedBox(width: 10),

        // edit/save & delete
        // FIXME: right side icon will overflow in mobile size
        Expanded(
            flex: 2,
            child: Container(
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    InkWell(
                      child: focusIcon,
                      onTap: () => setState(
                          () => widget.controller.changeFocus(context)),
                    ),
                    InkWell(
                      child: Icon(Icons.delete_outlined, color: Colors.grey),
                      onTap: () => widget.controller.doRemove(widget.index),
                    ),
                  ]),
            ))
      ]),
    );
  }

  Widget createDropdownMultiSelect({
    String hint,
    List<String> selectedValues,
    List<String> options,
    ValueChanged<List<String>> onChanged,
  }) {
    return IgnorePointer(
      ignoring: !widget.controller.onFocus,
      child: Container(
        width: double.infinity,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: 50, minHeight: 50),
          child: CustomDropDownMultiSelect(
            onChanged: onChanged,
            options: options,
            selectedValues: selectedValues,
            whenEmpty: hint,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 12),
            ),
          ),
        ),
      ),
    );
  }

  Color get focusColor =>
      widget.controller.onFocus ? Colors.white : Color(0xffe6e6e6);

  Icon get focusIcon => widget.controller.onFocus
      ? Icon(Icons.done_outlined, color: Colors.lightBlueAccent)
      : Icon(Icons.edit_outlined, color: Colors.lightBlueAccent);
}
