import 'package:flutter/material.dart';
import 'package:gmptr/presentation/layout/adaptive.dart';

class HeadingText extends StatelessWidget {
  final String text;
  final Color textColor;

  const HeadingText(this.text, {Key key, this.textColor}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widthOfScreen(context) < 520 ? 170 : 520,
      height: 50,
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        style: TextStyle(
            color: this.textColor ?? Color(0xff00439E),
            fontSize: (widthOfScreen(context) < 520 ? 14 : 24),
            fontWeight: FontWeight.bold),
      ),
    );
  }
}
