import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DatePicker extends StatefulWidget {
  final DatePickerController controller;
  final String label;

  const DatePicker(this.controller, this.label, {Key key}) : super(key: key);

  @override
  _DatePickerState createState() => _DatePickerState();
}

class _DatePickerState extends State<DatePicker> {
  TextEditingController _dateController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _dateController.text =
        DateFormat.yMd().format(widget.controller.selectedDate);
  }

  @override
  void didChangeDependencies() {
    _dateController.text =
        DateFormat.yMd().format(widget.controller.selectedDate);
    super.didChangeDependencies();
  }

  Future<Null> _selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: widget.controller.selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(2015),
        lastDate: DateTime(2101));
    if (picked != null)
      setState(() {
        widget.controller.selectedDate = picked;

        _dateController.text =
            DateFormat.yMd().format(widget.controller.selectedDate);
      });
  }

  void _formatDate(String str) {
    try {
      // print(str);
      var result = DateFormat.yMd().parse(str);
      widget.controller.selectedDate = result;
    } on FormatException catch (_) {
      // print(_ignore.message);
    } finally {
      setState(() => _dateController.text =
          DateFormat.yMd().format(widget.controller.selectedDate));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5),
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Colors.grey)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: Icon(
              Icons.date_range_outlined,
              color: Colors.lightBlueAccent,
            ),
            onPressed: () => _selectDate(context),
          ),
          Container(
              width: 150,
              height: 40,
              child: TextFormField(
                onChanged: (text) {
                  print(text);
                  _dateController.text = text;
                },
                style: TextStyle(fontSize: 14),
                textAlign: TextAlign.start,
                enabled: true,
                keyboardType: TextInputType.datetime,
                controller: _dateController,
                onFieldSubmitted: (String val) => _formatDate(val),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(top: 0),
                  border: UnderlineInputBorder(borderSide: BorderSide.none),
                  labelText: widget.label,
                  labelStyle: TextStyle(fontSize: 14, color: Colors.grey),
                ),
              )),
        ],
      ),
    );
  }
}

class DatePickerController {
  DateTime selectedDate = DateTime.now();
}
