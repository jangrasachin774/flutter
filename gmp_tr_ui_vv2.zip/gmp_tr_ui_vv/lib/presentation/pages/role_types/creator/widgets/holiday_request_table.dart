import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/models/model_leaves.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/creator_approve_leave_dialog.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'loading_box.dart';

class HolidayRequestTable extends StatefulWidget {
  const HolidayRequestTable({Key key}) : super(key: key);

  @override
  _HolidayRequestTableState createState() => _HolidayRequestTableState();
}

List<UserLeavesModel> paginatedUserLeaves = [];
final int rowsPerPage = 15;

class _HolidayRequestTableState extends State<HolidayRequestTable> {
  @override
  void initState() {
    super.initState();
    AppBloc.userLeavesBloc.add(OnLoadUserLeaves(departmentId: Application.user.departmentIdFk));
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<UserLeavesBloc, UserLeavesState>(
      bloc: BlocProvider.of<UserLeavesBloc>(context),
      builder: (contxt, state) {
        if (state is UserLeavesLoadedSuccess) {
          HolidayDataSource userLeavesDataSource;
          userLeavesDataSource = new HolidayDataSource(
            state.userLeaves,
            context,
          );

          List<UserLeavesModel> userLeavesCount = state.userLeaves;

          return LayoutBuilder(builder: (context, constraints) {
            return Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 500,
                      width: constraints.maxWidth,
                      child: SfDataGrid(
                        allowSorting: true,
                        source: userLeavesDataSource,
                        columnWidthMode: ColumnWidthMode.fill,
                        columns: [
                          GridColumn(
                            columnName: 'studentName',
                            width: 150,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('student_name'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'comment',
                            width: 150,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('comment'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'applyTime',
                            width: 180,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('apply_time'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'confirmTime',
                            width: 180,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('confirm_time'),
                              ),
                            ),
                          ),
                          GridColumn(
                              columnName: 'confirmPerson',
                              width: 150,
                              label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('confirm_person'),
                                  ))),
                          GridColumn(
                              columnName: 'approved',
                              width: 150,
                              label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('approved'),
                                  ))),
                          GridColumn(
                              columnName: 'returned',
                              width: 150,
                              label: Container(
                                  height: 50,
                                  color: Color(0xffEFF5FC),
                                  padding: EdgeInsets.all(16.0),
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    Translate.of(context).translate('returned'),
                                  ))),
                          GridColumn(
                            columnName: 'reason',
                            width: 150,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('reason'),
                              ),
                            ),
                          ),
                          GridColumn(
                            columnName: 'actions',
                            // columnWidthMode: ColumnWidthMode.lastColumnFill,
                            columnWidthMode: ColumnWidthMode.fitByCellValue,
                            label: Container(
                              height: 50,
                              color: Color(0xffEFF5FC),
                              padding: EdgeInsets.all(16.0),
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Translate.of(context).translate('actions'),
                              ),
                            ),
                          ),
                        ],
                        selectionMode: SelectionMode.none,
                      ),
                    ),
                    Container(
                      height: 52,
                      width: constraints.maxWidth,
                      child: SfDataPager(
                        delegate: userLeavesDataSource,
                        pageCount: (userLeavesCount.length / rowsPerPage).ceilToDouble(),
                        direction: Axis.horizontal,
                      ),
                    )
                  ],
                ),
              ],
            );
          });
        } else if (state is UserLeavesLoading) {
          return LoadingBox(
            height: 20,
          );
        } else if (state is UserLeavesEmpty) {
          return Container(child: Text("No Records Found"));
        } else if (state is UserLeavesLoadFail) {
          return Container(
            child: Text(state.error),
          );
        } else {
          return Container(
            child: Text("Something went wrong"),
          );
        }
      },
    );
  }
}

class HolidayDataSource extends DataGridSource {
  BuildContext contxt;

  final Completer _completer = new Completer();
  HolidayDataSource(
    List<UserLeavesModel> userLeave,
    context,
  ) {
    try {
      userLeaves = userLeave;
      contxt = context;

      if (userLeaves.length < rowsPerPage) {
        paginatedUserLeaves = userLeaves.toList();
      } else {
        paginatedUserLeaves = userLeaves.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.userLeaves.length) {
      endIndex = this.userLeaves.length;
    }
    paginatedUserLeaves = List.from(
      this.userLeaves.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  Future<void> _showApproveDialog(UserLeavesModel apply, bool isApprove) async {
    await showDialog(context: contxt, barrierDismissible: true, builder: (context) => CreatorApproveLeaveDialog(isApprove, apply.id));
    AppBloc.userLeavesBloc.add(OnLoadUserLeaves(departmentId: Application.user.departmentIdFk));
  }

  List<DataGridRow> _userLeaves = [];
  List<UserLeavesModel> userLeaves = [];
  @override
  List<DataGridRow> get rows => _userLeaves;

  void buildPaginatedDataGridRows() {
    _userLeaves = paginatedUserLeaves
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'studentName', value: e.user.username),
              DataGridCell<String>(columnName: 'comment', value: e.userDescription ?? ""),
              DataGridCell(columnName: 'applyTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.createdAt)).toString()),
              DataGridCell(columnName: 'confirmTime', value: e.confirmedDate != null ? DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.confirmedDate)).toString() : ""),
              DataGridCell<String>(columnName: 'confirmPerson', value: e.confirmedBy?.username ?? ""),
              DataGridCell<String>(columnName: 'approved', value: e.confirmedDate != null ? "Yes" : "No"),
              DataGridCell<String>(columnName: 'returned', value: e.returnDate != null ? 'Yes' : 'No'),
              DataGridCell<String>(
                columnName: 'reason',
                value: e.approverDescription ?? "",
              ),
              DataGridCell(
                columnName: 'actions',
                value: e,
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[0].value.toString(),
              child: Text(
                row.getCells()[0].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[1].value.toString(),
              child: Text(
                row.getCells()[1].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[2].value.toString(),
              child: Text(
                row.getCells()[2].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(row.getCells()[3].value.toString()),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[4].value.toString(),
              child: Text(
                row.getCells()[4].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[5].value.toString(),
              child: Text(
                row.getCells()[5].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[6].value.toString(),
              child: Text(
                row.getCells()[6].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Tooltip(
              message: row.getCells()[7].value.toString(),
              child: Text(
                row.getCells()[7].value.toString(),
                overflow: TextOverflow.ellipsis,
              )),
        ),
        Container(
            child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            OutlinedButton(
              onPressed: row.getCells()[8].value.status != null ? null : () async => _showApproveDialog(row.getCells()[8].value, true),
              child: Text(Translate.of(contxt).translate("approve")),
              style: outlinedButtonStyle(),
            ),
            SizedBox(width: 10),
            OutlinedButton(
              onPressed: row.getCells()[8].value.status != null ? null : () async => _showApproveDialog(row.getCells()[8].value, false),
              child: Text(Translate.of(contxt).translate("deny")),
              style: outlinedButtonStyle(),
            ),
          ],
        )),
      ],
    );
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }
}
