import 'package:flutter/material.dart';

/// for create document/task page
class SelectionBox<T> extends StatefulWidget {
  final String leading;
  final SelectionBoxController controller;
  final List<T> items;
  final String Function(T e) getText;
  final String hint;
  final void Function(T newValue) onChanged;

  const SelectionBox(
      {Key key,
      this.leading,
      this.items,
      this.controller,
      this.hint = "",
      this.getText,
      this.onChanged})
      : super(key: key);

  @override
  _SelectionBoxState<T> createState() => _SelectionBoxState<T>();
}

class _SelectionBoxState<T> extends State<SelectionBox<T>> {
  @override
  void initState() {
    super.initState();
    // widget.controller.value = widget.items.length > 0 ? widget.items[0] : null;
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(children: [
      if (widget.leading != null)
        SizedBox(
          width: 162,
          height: 40,
          child: Container(
            alignment: Alignment.centerLeft,
            child: Text(
              widget.leading,
              style: TextStyle(fontSize: 14),
            ),
          ),
        ),
      SizedBox(
        height: 40,
        width: 200,
        child: Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 0,
          ),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(width: 1, color: Colors.grey),
            borderRadius: BorderRadius.circular(2.2),
          ),
          child: DropdownButton(
              isExpanded: true,
              value: widget.controller.value,
              underline: SizedBox(),
              icon: Icon(Icons.keyboard_arrow_down_outlined),
              iconEnabledColor: Colors.lightBlueAccent,
              items: widget.items
                  .map((e) => DropdownMenuItem(
                        child: Text(widget.getText(e),
                            style: TextStyle(fontSize: 12)),
                        value: e,
                      ))
                  .toList(),
              hint: Text(
                widget.hint,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 12,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              onChanged: (value) {
                setState(() => widget.controller.value = value);
                if (widget.onChanged != null) widget.onChanged(value);
              }),
        ),
      ),
    ]);
  }
}

class SelectionBoxController {
  dynamic value;
}
