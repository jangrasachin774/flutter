import 'dart:html';

import 'package:flutter/material.dart';
import 'package:gmptr/utils/translate.dart';
import 'dart:ui' as ui;

// ignore: must_be_immutable
class ViewDocumentDialog extends StatefulWidget {
  final bool isNeedConfirm;
  final String path;
  final String name;
  int entryTime;
  ViewDocumentDialog(
      {Key key,
      this.isNeedConfirm = true,
      this.path,
      this.name,
      this.entryTime})
      : super(key: key);

  @override
  _ViewDocumentDialogState createState() => _ViewDocumentDialogState();
}

class _ViewDocumentDialogState extends State<ViewDocumentDialog>
    with AutomaticKeepAliveClientMixin {
  String src;
  final IFrameElement _iframeElement = IFrameElement();
  final ImageElement img = ImageElement();

  @override
  void initState() {
    super.initState();

    src =
        "http://139.9.146.31:3333${this.widget.path}#toolbar=0&navpanes=0&scrollbar=0";
    // "https://picsum.photos/id/1/5616/3744.jpg";
    // "https://www.youtube.com/embed/fnHr_rsQwDA";
    // "https://picsum.photos/id/1/200/300";
    // "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf";
    var splits = src.split('.');
    var parts = splits.last.split('#');
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'bmp'].contains(parts.first)) {
      img
        ..style.display = 'block'
        ..style.marginLeft = 'auto'
        ..style.marginRight = 'auto'
        ..style.objectFit = 'contain'
        ..src = src;
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        src,
        (int viewId) => img,
      );
    } else {
      _iframeElement
        ..src = src
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.border = 'none';
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        src,
        (int viewId) => _iframeElement,
      );
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
      return Dialog(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              children: [
                Container(
                  height: 40,
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    "This is document title",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  color: Colors.grey.withOpacity(.25),
                ),
                if (!widget.isNeedConfirm)
                  Positioned(
                    right: 0,
                    child: IconButton(
                      icon: Icon(Icons.close_outlined),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  )
              ],
            ),
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.75,
                padding: const EdgeInsets.all(20),
                child: HtmlElementView(
                  viewType: src,
                ),
              ),
            ),
            _confirmOrNot(context),
          ],
        ),
      );
    });
  }

  Widget _confirmOrNot(BuildContext context) {
    return Container(
      height: 66,
      alignment: Alignment.center,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: widget.isNeedConfirm
            ? [
                Container(
                  height: 36,
                  width: 150,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(context).pop(false);
                    },
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.close_outlined),
                      const SizedBox(width: 6),
                      Text(Translate.of(context).translate('cancel'))
                    ]),
                    style: _outlinedButtonStyle(),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  height: 36,
                  width: 150,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.done_outlined),
                      const SizedBox(width: 6),
                      Text(Translate.of(context).translate('confirm'))
                    ]),
                    style: _elevatedButtonStyle(),
                  ),
                )
              ]
            : [],
      ),
    );
  }

  ButtonStyle _outlinedButtonStyle() {
    return OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        side: BorderSide(color: Colors.lightBlueAccent));
  }

  ButtonStyle _elevatedButtonStyle() {
    return ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)));
  }
}
