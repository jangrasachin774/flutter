import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/tasks_and_documents/bloc.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_tasks.dart';
import 'package:gmptr/presentation/pages/role_types/creator/home.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/creator_sign_dialog.dart';
import 'package:gmptr/utils/utils.dart';

/// for creator dashboard
class TaskTable extends StatefulWidget {
  final List<DocumentsModel> documents;
  final List<Task> tasks;

  TaskTable({Key key, this.documents, this.tasks}) : super(key: key);

  @override
  _TaskTableState createState() => _TaskTableState();
}

class _TaskTableState extends State<TaskTable> {
  VoidCallback listener;
  Task task;
  @override
  void initState() {
    super.initState();
    // listener = () => setState(() {});
    // widget.controller.addListener(listener);
  }

  @override
  void dispose() {
    // widget.controller.removeListener(listener);
    super.dispose();
  }

  _cancelDoc(List<int> docIds) async {
    // ignore: todo
    // TODO: implement
    // bool confirm = await showDialog(
    //     context: context,
    //     builder: (context) => CreatorSignDialog(text: "Confirm to Cancel"));

    // if (confirm) {
    //   AppBloc.tasksDocBloc
    //       .add(CancelCreatedDoc(taskStatusId: 3, taskIds: docIds));
    // }
    // AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent());
  }

  _cancelTask(List<int> taskIds) async {
    bool confirm = await showDialog(
        context: context,
        builder: (context) => CreatorSignDialog(text: "Confirm to Cancel"));

    if (confirm) {
      AppBloc.tasksDocBloc
          .add(CancelCreatedTask(taskStatusId: 3, taskIds: taskIds));
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent());
  }

  _changeDoc(int docId) async {
    // ignore: todo
    // TODO: implement
  }

  _changeTask(int taskId) async {
    // ignore: todo
    // TODO: implement
  }

  _signDoc(List<int> docIds) async {
    bool confirm = await showDialog(
        context: context,
        builder: (context) => CreatorSignDialog(
            text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignDoc(docIds);
    }
  }

  _signTask(List<int> taskIds) async {
    // ignore: todo
    // TODO: implement
    bool confirm = await showDialog(
        context: context,
        builder: (context) => CreatorSignDialog(
            text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignTask(taskIds);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: buildDataTable(
        context,
        widget.tasks.isNotEmpty
            ? buildDataRowByTask(widget.tasks)
            : buildDataRowByDocument(widget.documents),
      ),
    );
  }

  Widget buildDataTable(BuildContext context, List<DataRow> rows) {
    // makes DataTable full width
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: BoxConstraints(minWidth: constraints.minWidth),
          child: DataTable(
            headingRowHeight: 50,
            columnSpacing: 25,
            decoration: BoxDecoration(
              border: Border.all(width: 1, color: Color(0xffD4E5F9)),
            ),
            headingRowColor: MaterialStateColor.resolveWith(
              (states) => Color(0xffEFF5FC),
            ),
            headingTextStyle: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
            columns: buildTasksTableHeader(context),
            rows: rows,
          ),
        ),
      ),
    );
  }

  dynamic buildTasksTableHeader(BuildContext context) {
    return <DataColumn>[
      DataColumn(
        label: Text(
          Translate.of(context).translate('s_no'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('title'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('description'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('created_time'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('begin_time'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('end_time'),
        ),
      ),
      DataColumn(
        label: Text(
          Translate.of(context).translate('created_dep_worker'),
        ),
      ),

      // Bulk actions
      DataColumn(
        label: Expanded(
          child: Container(
            height: 36,
            width: 130,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black12, width: 1),
              borderRadius: BorderRadius.all(Radius.circular(4)),
            ),
            child: DropdownButton(
                onChanged: (val) {
                  List<int> ids = widget.tasks.isNotEmpty
                      ? widget.tasks
                          .where((e) => e.selected)
                          .map((e) => e.id)
                          .toList()
                      : widget.documents
                          .where((e) => e.selected)
                          .map((e) => e.id)
                          .toList();
                  setState(() {
                    if (val == 1) {
                      widget.tasks.isNotEmpty
                          ? _cancelTask(ids)
                          : _cancelDoc(ids);
                    } else if (val == 2) {
                      widget.tasks.isNotEmpty ? _signTask(ids) : _signDoc(ids);
                    }
                  });
                },
                icon: const Icon(Icons.expand_more_outlined),
                underline: Container(color: Colors.white),
                hint: Text(Translate.of(context).translate("bulk_actions"),
                    style: TextStyle(fontSize: 12)),
                items: [
                  DropdownMenuItem(
                    value: 1,
                    child: Text(Translate.of(context).translate('cancel'),
                        style: TextStyle(fontSize: 12)),
                  ),
                  DropdownMenuItem(
                    value: 2,
                    child: Text(Translate.of(context).translate('sign'),
                        style: TextStyle(fontSize: 12)),
                  ),
                ]),
          ),
        ),
      )
    ];
  }

  List<DataRow> buildDataRowByTask(List<Task> tasks) {
    int rowCount = 1;
    return tasks
        .map((e) => DataRow(
              color: MaterialStateProperty.resolveWith<Color>(
                  (Set<MaterialState> states) => states
                          .contains(MaterialState.selected)
                      ? Theme.of(context).colorScheme.primary.withOpacity(0.08)
                      : null),
              selected: e.selected,
              onSelectChanged: (bool value) =>
                  setState(() => e.selected = value),
              cells: [
                // fixme
                DataCell(Text((rowCount++).toString())),
                DataCell(Text(e.title)),
                DataCell(Text(e.description)),
                DataCell(Text(e.createdAt)),
                DataCell(Text(e.startDate)),
                DataCell(Text(e.endDate)),
                DataCell(Text(
                    e.taskCreator.department.name + ", " + e.taskCreator.name)),

                DataCell(
                  e.taskStatusIdFk == 3
                      ? Text(
                          "Cancelled",
                          style: TextStyle(color: Colors.red),
                        )
                      : Row(
                          children: [
                            InkWell(
                              onTap: () {
                                setState(() {
                                  task = e;
                                });
                              },
                              child: Icon(
                                Icons.info_outline,
                                color: Color(0xff00A4E3),
                              ),
                            ),
                            SizedBox(width: 10),
                            OutlinedButton(
                              onPressed: () => _cancelTask([e.id]),
                              child: Text(
                                  Translate.of(context).translate('cancel')),
                              style: outlinedButtonStyle(),
                            ),
                            SizedBox(width: 10),
                            OutlinedButton(
                              onPressed: () => _changeTask(e.id),
                              child: Text(
                                  Translate.of(context).translate('change')),
                              style: outlinedButtonStyle(),
                            ),
                            SizedBox(width: 10),
                            OutlinedButton(
                              onPressed: () => _signTask([e.id]),
                              child:
                                  Text(Translate.of(context).translate('sign')),
                              style: outlinedButtonStyle(),
                            )
                          ],
                        ),
                ),
              ],
            ))
        .toList();
  }

  List<DataRow> buildDataRowByDocument(List<DocumentsModel> documents) {
    int rowCount = 1;
    return documents
        .map((e) => DataRow(
              color: MaterialStateProperty.resolveWith<Color>(
                  (Set<MaterialState> states) => states
                          .contains(MaterialState.selected)
                      ? Theme.of(context).colorScheme.primary.withOpacity(0.08)
                      : null),
              selected: e.selected,
              onSelectChanged: (bool value) =>
                  setState(() => e.selected = value),
              cells: [
                DataCell(Text((rowCount++).toString())),
                DataCell(Text("${e.title}")),
                DataCell(Text("${e.description}")),
                DataCell(Text(e.createdAt)),
                DataCell(Text("")),
                DataCell(Text("")),
                DataCell(Row(
                  children: [
                    Text("${e.docCreator?.creatorDepartment?.name}, "),
                    Text(
                      "${e.docCreator?.name}",
                      style: TextStyle(color: Colors.lightBlueAccent),
                    )
                  ],
                )),
                // DataCell(Text("${e.department?.name}")),

                DataCell(Row(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {});
                      },
                      child: Icon(
                        Icons.info_outline,
                        color: Color(0xff00A4E3),
                      ),
                    ),
                    SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () => _cancelDoc([e.id]),
                      child: Text(Translate.of(context).translate('cancel')),
                      style: outlinedButtonStyle(),
                    ),
                    SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () => _changeDoc(e.id),
                      child: Text(Translate.of(context).translate('change')),
                      style: outlinedButtonStyle(),
                    ),
                    SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () => _signDoc([e.id]),
                      child: Text(Translate.of(context).translate('sign')),
                      style: outlinedButtonStyle(),
                    )
                  ],
                ))
              ],
            ))
        .toList();
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
        side: BorderSide(color: Colors.lightBlueAccent));
  }
}
