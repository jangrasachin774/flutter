import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/create_new_document.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/heading_text.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/holiday_request_table.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/translate.dart';
import 'package:intl/intl.dart';

import '../../../../global.dart';
import 'create_new_task.dart';
import 'widgets/input_box.dart';
import 'widgets/selection_box.dart';
import 'widgets/task_tests_table.dart';

class ApproveHolidayPage extends StatefulWidget {
  const ApproveHolidayPage({Key key}) : super(key: key);

  @override
  _ApproveHolidayPageState createState() => _ApproveHolidayPageState();
}

class _ApproveHolidayPageState extends State<ApproveHolidayPage> {
  ApproveHolidayWidgetChange selectedWidgetPage =
      ApproveHolidayWidgetChange.dashboard;

  /// CREATE TASK VARIABLES
  bool isRegularTask = false;
  final _dateController = TextEditingController();
  final _textTitleController = TextEditingController();
  final trainingTypeSelection = SelectionBoxController();
  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentVersionController = MyTextEditingController();

  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final studentsSelection = SelectionBoxController();
  final departmentSelection = SelectionBoxController();
  DocumentsModel selectedDocument;
  int departmentIdFk;
  int documentFeatureIdFk;
  int trainingTypeId;
  GlobalKey key =
      new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
  final List<SingleTaskTestController> testControllers = [];
  List<DocumentTests> selectedDocumentTests = [];

  final List<PlatformFile> choseDocuments = [];

  List<DocumentFiles> selectedDocuments = [];

  List<DocumentTests> selectedDocumentTest = [];

  final int smallLeaderRoleId = 3;

  final int studentsRoleId = 5;

  int documentIdFk;
  String selectedPath;
  String selectedName;
  String selectedIdentifier;
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  int studentIdFk;
  List<String> selectedStudents = [];
  List<int> selectedStudentsIds = [];

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  ///CREATE DOCUMENT VARIABLES
  final List<SingleTestController> doctestControllers = [];

  ///SWITCH WIDGETS
  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case ApproveHolidayWidgetChange.dashboard:
        return dashboard(context);
    }

    return dashboard(context);
  }

  

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // heading text
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage ==
                      ApproveHolidayWidgetChange.dashboard)
                    HeadingText(
                        Translate.of(context).translate("approve_holiday")),
                  Row(
                    children: [
                      if (selectedWidgetPage ==
                          ApproveHolidayWidgetChange.dashboard)
                        AppButton(
                          Translate.of(context)
                              .translate('create_new_document'),
                          onPressed: () => {
                            setState(() {
                              showDialog(
                                  context: context,
                                  builder: (context) => CreateDocument());
                              // selectedWidgetPage =
                              //     ApproveHolidayWidgetChange.createDoc;
                            })
                          },
                          // Navigator.pushNamed(context, Routes.createDocument),
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage ==
                          ApproveHolidayWidgetChange.dashboard)
                        SizedBox(width: 10),
                      if (selectedWidgetPage ==
                          ApproveHolidayWidgetChange.dashboard)
                        AppButton(
                          Translate.of(context).translate('create_new_task'),
                          onPressed: () {
                            setState(() {
                              showDialog(
                                  context: context,
                                  builder: (context) => CreateNewTask());
                              // selectedWidgetPage =
                              //     ApproveHolidayWidgetChange.createTask;
                            });
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      
                    ],
                  ),
                ],
              ),
               SizedBox(
                    height: 20,
                  ),
              Container(child: getCustomContainer(context)),
            ],
          ),
        ),
      ],
    );
  }

  Widget dashboard(context) {
    return HolidayRequestTable();
  }

  

  Widget _headingText() {
    return Container(
      width: double.infinity,
      child: Wrap(
        runSpacing: 10,
        alignment: WrapAlignment.spaceBetween,
        children: [
          HeadingText(Translate.of(context).translate("approve_holiday")),
        ],
      ),
    );
  }
}
