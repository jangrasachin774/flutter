import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/api/api.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/models/model_document.dart';
import 'package:gmptr/presentation/pages/role_types/admin/documents_managment/document_detail.dart';
import 'package:gmptr/presentation/pages/role_types/creator/create_new_task.dart';
import 'package:gmptr/presentation/pages/role_types/creator/update_document.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/sizes.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'create_new_document.dart';
import 'home.dart';
import 'update_task.dart';
import 'update_task_dialog.dart';
import 'widgets/snack_bar_util.dart';
import 'widgets/task_info.dart';

class BigLeaderPage extends StatefulWidget {
  const BigLeaderPage({Key key}) : super(key: key);

  @override
  _BigLeaderPageState createState() => _BigLeaderPageState();
}

List<int> selectedTaskIds = [];
List<int> selectedDocIds = [];
int rowsPerPage = 10;

class _BigLeaderPageState extends State<BigLeaderPage> {
  HomeWidgetChange selectedWidgetPage = HomeWidgetChange.taskDocController;
  int taskStatusId = 6;
  List<int> taskStatusIds = [
    2,
    3,
    4,
    6,
    8,
    9
  ];

  Task task;
  DocumentsModel document;
  List<int> selectedIds = [];

  /// CREATE TASK VARIABLES
  bool isRegularTask = false;
  final _dateController = TextEditingController();
  final _textTitleController = TextEditingController();
  final trainingTypeSelection = SelectionBoxController();
  final documentFeatureSelection = SelectionBoxController();
  final documentTitleController = MyTextEditingController();
  final documentVersionController = MyTextEditingController();
  final documentDescriptionController = MyTextEditingController();
  final smallLeaderSelection = SelectionBoxController();
  final studentsSelection = SelectionBoxController();
  final departmentSelection = SelectionBoxController();
  DocumentsModel selectedDocument;
  int departmentIdFk;
  int documentFeatureIdFk;
  int trainingTypeId;
  GlobalKey key = new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
  final List<SingleTaskTestController> testControllers = [];
  List<DocumentTests> selectedDocumentTests = [];

  final List<PlatformFile> choseDocuments = [];

  List<DocumentFiles> selectedDocuments = [];

  List<DocumentTests> selectedDocumentTest = [];

  final int smallLeaderRoleId = 3;

  final int studentsRoleId = 5;

  int documentIdFk;
  String selectedPath;
  String selectedName;
  String selectedIdentifier;
  DateTime selectedDate = DateTime.now();
  DateFormat formatter = DateFormat('dd/MM/yyyy');
  int studentIdFk;
  List<String> selectedStudents = [];
  List<int> selectedStudentsIds = [];

  String _selectedDate = '';
  String _dateCount = '';
  String _startDate = '';
  String _endDate = '';
  String _rangeCount = '';

  ///CREATE DOCUMENT VARIABLES
  final List<SingleTestController> doctestControllers = [];

  @override
  void initState() {
    super.initState();
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      selectedViewTypeCommon
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  _cancelDoc(List<int> docIds) async {
    AppBloc.documentsBloc.add(OnUpdateDocumentStatus(docIds: docIds, status: 3));
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      3
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  _cancelTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: context, builder: (context) => CreatorSignDialog(text: "Confirm to Cancel"));

    if (confirm) {
      AppBloc.tasksDocBloc.add(CancelCreatedTask(taskStatusId: 3, taskIds: taskIds));
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  _signDoc(List<int> docIds) async {
    bool confirm = await showDialog(context: context, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignDoc(docIds);
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      3
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  _signTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: context, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignTask(taskIds);
      AppBloc.tasksDocBloc.add(
        OnLoadTaskDocEvent(viewType: [
          ViewType.regularTask
        ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId),
      );
    }
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case HomeWidgetChange.taskDocController:
        return dashboard(context);
      // case HomeWidgetChange.createDoc:
      //   return createDoc(context);

      // case HomeWidgetChange.createTask:
      //   return createTask(context);
      case HomeWidgetChange.taskInfo:
        return taskInfo(context);
      case HomeWidgetChange.docInfo:
        return docInfo(context);
      // case HomeWidgetChange.updateTask:
      //   return updateTask(context);
      case HomeWidgetChange.updateDoc:
        return updateDoc(context);
    }

    return dashboard(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectedWidgetPage == HomeWidgetChange.taskDocController) HeadingText(Translate.of(context).translate("signed_by_big_leader")),
                  if (selectedWidgetPage == HomeWidgetChange.taskInfo || selectedWidgetPage == HomeWidgetChange.docInfo || selectedWidgetPage == HomeWidgetChange.updateDoc) Container(),
                  Row(
                    children: [
                      if (selectedWidgetPage == HomeWidgetChange.taskDocController)
                        AppButton(
                          Translate.of(context).translate('create_new_document'),
                          onPressed: () => {
                            setState(() {
                              showDialog(context: context, builder: (context) => CreateDocument(taskStatusId: taskStatusId));
                              // selectedWidgetPage = HomeWidgetChange.createDoc;
                            })
                          },
                          // Navigator.pushNamed(context, Routes.createDocument),
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage == HomeWidgetChange.taskDocController) SizedBox(width: 10),
                      if (selectedWidgetPage == HomeWidgetChange.taskDocController)
                        AppButton(
                          Translate.of(context).translate('create_new_task'),
                          onPressed: () {
                            setState(() {
                              showDialog(context: context, builder: (context) => CreateNewTask(taskStatusId: taskStatusId));
                              // selectedWidgetPage = HomeWidgetChange.createTask;
                            });
                          },
                          type: ButtonType.normal,
                          color: Color(0xff787E8C),
                          icon: Icon(
                            Icons.post_add_outlined,
                          ),
                        ),
                      if (selectedWidgetPage == HomeWidgetChange.taskInfo)
                        Tooltip(
                          message: Translate.of(context).translate('close'),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                selectedWidgetPage = HomeWidgetChange.taskDocController;
                                AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
                                  ViewType.regularTask
                                ], creatorIdFk: Application.user.id, taskStatusId: taskStatusId));
                              });
                            },
                            child: Icon(
                              Icons.close,
                              color: Color(0xff00A4E3),
                              size: 20,
                            ),
                          ),
                        ),
                      if (selectedWidgetPage == HomeWidgetChange.docInfo)
                        Tooltip(
                          message: Translate.of(context).translate('close'),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                selectedWidgetPage = HomeWidgetChange.taskDocController;
                                AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
                                  ViewType.documents
                                ], creatorIdFk: Application.user.id, taskStatusId: taskStatusId));
                              });
                            },
                            child: Icon(
                              Icons.close,
                              color: Color(0xff00A4E3),
                              size: 20,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
              Container(child: getCustomContainer(context))
            ],
          ),
        ),
      ],
    );
  }

  Widget dashboard(context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BlocBuilder<TaskDocBloc, TaskDocState>(
              bloc: BlocProvider.of<TaskDocBloc>(context),
              buildWhen: (previousState, currentState) {
                return previousState != currentState;
              },
              builder: (ctxt, state) {
                if (state is TaskDocSuccess) {
                  BLTaskDataSource blTaskDataSource;
                  DocDataSource docDataSource;
                  blTaskDataSource = new BLTaskDataSource(
                    state.tasks,
                    context,
                    taskStatusId,
                  );

                  List<Task> taskCounts = state.tasks;
                  List<DocumentsModel> docCount = state.documents;
                  docDataSource = new DocDataSource(state.documents, context, taskStatusId);
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FiltersBox(
                        taskStatusId: taskStatusId,
                        viewType: [
                          selectedViewTypeCommon
                        ],
                      ),
                      const SizedBox(height: 15),
                      LayoutBuilder(builder: (context, constraints) {
                        return Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: MediaQuery.of(context).size.height * 0.5,
                                  width: constraints.maxWidth,
                                  child: SfDataGrid(
                                    allowSorting: true,
                                    source: blTaskDataSource.rows.length > 0 ? blTaskDataSource : docDataSource,
                                    columnWidthMode: ColumnWidthMode.fill,
                                    columns: [
                                      GridColumn(
                                          columnName: 'title',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('title'),
                                              ))),
                                      GridColumn(
                                          columnName: 'description',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('description'),
                                              ))),
                                      GridColumn(
                                          columnName: 'version',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('version'),
                                              ))),
                                      GridColumn(
                                          columnName: 'beginTime',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('begin_time'),
                                              ))),
                                      GridColumn(
                                          columnName: 'endTime',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('end_time'),
                                              ))),
                                      GridColumn(
                                        columnName: 'createdDepWorker',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('created_dep_worker'),
                                          ),
                                        ),
                                      ),
                                      if (blTaskDataSource.rows.length > 0)
                                        GridColumn(
                                          columnName: 'students',
                                          label: Container(
                                            height: 50,
                                            color: Color(0xffEFF5FC),
                                            padding: EdgeInsets.all(16.0),
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              Translate.of(context).translate('students'),
                                            ),
                                          ),
                                        ),
                                      GridColumn(
                                        columnName: 'filters',
                                        label: Container(
                                          height: 26,
                                          color: Color(0xffEFF5FC),
                                          constraints: BoxConstraints(maxHeight: 30),
                                          alignment: Alignment.center,
                                          child: Text(""),
                                        ),
                                      )
                                    ],
                                    selectionMode: SelectionMode.single,
                                    onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                      if (blTaskDataSource.rows.length > 0) {
                                        final index = blTaskDataSource.rows.indexOf(addedRows.last);
                                        print("task >>> $index");
                                      } else {
                                        final index = docDataSource.rows.indexOf(addedRows.last);
                                        print("document >>>> $index");
                                      }
                                      return true;
                                    },
                                    onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) async {
                                      if (blTaskDataSource.rows.length > 0) {
                                        final index = blTaskDataSource.rows.indexOf(addedRows.last);
                                        await showDialog(
                                            context: context,
                                            builder: (context) => CreatorTaskInfoWidget(
                                                  taskInfo: paginatedTask[index],
                                                ));
                                        // setState(() {
                                        //   selectedWidgetPage =
                                        //       HomeWidgetChange.taskInfo;
                                        //   task = taskCounts[index];
                                        // });
                                      } else {
                                        final index = docDataSource.rows.indexOf(addedRows.first);
                                        print("document >>>> $index");
                                        await showDialog(
                                          context: context,
                                          builder: (context) => DocumentDetailPage(documentInfo: paginatedDocuments[index]),
                                        );
                                        // setState(() {
                                        //   selectedWidgetPage =
                                        //       HomeWidgetChange.docInfo;
                                        //   document = docCount[index];
                                        // });
                                      }
                                    },
                                  ),
                                ),
                                Container(
                                  height: 52,
                                  width: constraints.maxWidth,
                                  child: SfDataPager(
                                    delegate: blTaskDataSource.rows.length > 0 ? blTaskDataSource : docDataSource,
                                    pageCount: blTaskDataSource.rows.length > 0 ? (taskCounts.length / 10).ceilToDouble() : docCount.length / 10,
                                    direction: Axis.horizontal,
                                  ),
                                )
                              ],
                            ),
                          ],
                        );
                      }),
                    ],
                  );
                } else if (state is TaskDocLoading) {
                  return LoadingBox(
                    height: 20,
                  );
                } else if (state is TaskDocEmpty) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FiltersBox(
                        taskStatusId: taskStatusId,
                        viewType: [
                          selectedViewTypeCommon
                        ],
                      ),
                      const SizedBox(height: 20),
                      Center(child: Text("No Records")),
                    ],
                  );
                } else {
                  return Text("load failed.");
                }
              },
            ),
          ],
        ),
      );
  // Widget createDoc(context) {
  //   // return CreateDocument();
  //   return ListView(
  //     shrinkWrap: true,
  //     children: [
  //       Padding(
  //         padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
  //         child: Column(
  //           crossAxisAlignment: CrossAxisAlignment.start,
  //           children: [
  //             // header and two button

  //             Wrap(
  //               runSpacing: 12,
  //               spacing: 40,
  //               children: [
  //                 // selection box, choose dept
  //                 BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
  //                   bloc: BlocProvider.of<DepartmentsListBloc>(context),
  //                   builder: (context, state) {
  //                     if (state is DepartmentsSuccess) {
  //                       List<Departments> departments = state.departments;
  //                       return SelectionBox<Departments>(
  //                         leading: Translate.of(context)
  //                             .translate("choose_department"),
  //                         hint: "choose_department",
  //                         controller: departmentSelection,
  //                         items: departments,
  //                         getText: (department) => department.name,
  //                         onChanged: (value) => AppBloc.departmentUserBloc.add(
  //                             OnLoadDepartmentUsers(
  //                                 departmentId: value.id,
  //                                 roleId: smallLeaderRoleId)),
  //                       );
  //                     } else if (state is DepartmentsLoading) {
  //                       return Text("loading");
  //                     } else {
  //                       return Text("load department data failed.");
  //                     }
  //                   },
  //                 ),

  //                 // selection box, choose small leader
  //                 BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
  //                   bloc: BlocProvider.of<DepartmentUsersBloc>(context),
  //                   builder: (context, state) {
  //                     if (state is DepartmentUsersSuccess) {
  //                       return SelectionBox<ReadUsersByIdModel>(
  //                         leading: Translate.of(context)
  //                             .translate("choose_small_leader"),
  //                         hint: "choose small leader",
  //                         controller: smallLeaderSelection,
  //                         items: state.departmentsUser,
  //                         getText: (e) => e.name,
  //                       );
  //                     } else if (state is DepartmentUsersLoading) {
  //                       return LoadingBox(height: 20, width: 20);
  //                     } else {
  //                       return SelectionBox(
  //                         leading: Translate.of(context)
  //                             .translate("choose_small_leader"),
  //                         items: [],
  //                         getText: (e) => "",
  //                         controller: smallLeaderSelection,
  //                         hint: "Please choose a small leader",
  //                       );
  //                     }
  //                   },
  //                 ),
  //                 SizedBox(
  //                   width: 40,
  //                 ),
  //               ],
  //             ),
  //             const SizedBox(height: 12),

  //             // two selection box, train type and document feature
  //             Wrap(
  //               runSpacing: 12,
  //               spacing: 40,
  //               children: [
  //                 // selection box of training types
  //                 BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
  //                   bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
  //                   builder: (context, state) {
  //                     if (state is TrainingsTypeSuccess) {
  //                       return SelectionBox<TrainingsType>(
  //                         leading:
  //                             Translate.of(context).translate("training_type"),
  //                         hint: "choose training type",
  //                         controller: trainingTypeSelection,
  //                         items: state.trainingTypes,
  //                         getText: (e) => e.name,
  //                       );
  //                     } else if (state is TrainingsTypeLoading) {
  //                       return Text("loading");
  //                     } else {
  //                       return Text("load trainings type failed.");
  //                     }
  //                   },
  //                 ),

  //                 // selection box of training types
  //                 BlocBuilder<DocumentsFeatureListBloc,
  //                     DocumentsFeatureListState>(
  //                   bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
  //                   builder: (context, state) {
  //                     if (state is DocumentsFeatureSuccess) {
  //                       return SelectionBox<DocumentsFeature>(
  //                         leading: Translate.of(context)
  //                             .translate("document_feature"),
  //                         hint: "choose document feature",
  //                         controller: documentFeatureSelection,
  //                         items: state.documentsFeature,
  //                         getText: (e) => e.name,
  //                       );
  //                     } else if (state is DocumentsFeatureLoading) {
  //                       return Text("loading");
  //                     } else {
  //                       return Text("load document features failed.");
  //                     }
  //                   },
  //                 ),
  //               ],
  //             ),
  //             const SizedBox(height: 12),

  //             // two input box, document title and document description
  //             Wrap(runSpacing: 12, spacing: 40, children: [
  //               InputBox(
  //                 label: Translate.of(context).translate("document_title"),
  //                 controller: documentTitleController,
  //               ),
  //               InputBox(
  //                 label:
  //                     Translate.of(context).translate("document_description"),
  //                 controller: documentDescriptionController,
  //               )
  //             ]),
  //             const SizedBox(height: 12),

  //             // button, upload file;
  //             Row(
  //               children: [
  //                 UploadFileButton(uploadDocFile),
  //                 SizedBox(width: 60),
  //                 InputBox(
  //                   label: Translate.of(context).translate("file_version"),
  //                   controller: documentVersionController,
  //                   keyBoardType: TextInputType.number,
  //                   inputFormatters: <TextInputFormatter>[
  //                     FilteringTextInputFormatter.digitsOnly
  //                   ], // Only numbers can be entered
  //                 ),
  //               ],
  //             ),
  //             const SizedBox(height: 23),

  //             // data table, files
  //             UploadedFileTable(choseDocuments),
  //             const SizedBox(height: 20),

  //             // tests table
  //             TestsTable(doctestControllers),
  //             const SizedBox(height: 30),
  //           ],
  //         ),
  //       ),
  //     ],
  //   );
  // }

  // Widget createTask(context) {
  //   return ListView(
  //     shrinkWrap: true,
  //     children: [
  //       Padding(
  //         padding: const EdgeInsets.fromLTRB(8, 12, 12, 25),
  //         child: Column(
  //           crossAxisAlignment: CrossAxisAlignment.start,
  //           children: [
  //             // two radio, regular or read only
  //             Column(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               children: [
  //                 SizedBox(
  //                   width: 162,
  //                   height: 40,
  //                   child: Container(
  //                     alignment: Alignment.centerLeft,
  //                     child: Text(
  //                       Translate.of(context).translate("task_type"),
  //                       style: TextStyle(fontSize: 14),
  //                     ),
  //                   ),
  //                 ),
  //                 Wrap(
  //                   runSpacing: 10,
  //                   spacing: 210,
  //                   children: [
  //                     Wrap(
  //                       runSpacing: 10,
  //                       spacing: 5,
  //                       children: [
  //                         Radio(
  //                           value: false,
  //                           groupValue: isRegularTask,
  //                           onChanged: (newValue) =>
  //                               setState(() => isRegularTask = newValue),
  //                           activeColor: Colors.lightBlueAccent,
  //                         ),
  //                         Text(Translate.of(context).translate("regular_task")),
  //                         SizedBox(
  //                           width: 15,
  //                         ),
  //                         Radio(
  //                           value: true,
  //                           groupValue: isRegularTask,
  //                           onChanged: (newValue) =>
  //                               setState(() => isRegularTask = newValue),
  //                           activeColor: Colors.lightBlueAccent,
  //                         ),
  //                         Text(Translate.of(context)
  //                             .translate("read_only_task")),
  //                       ],
  //                     ),

  //                     // selection box, choose dept
  //                     BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
  //                       bloc: BlocProvider.of<DepartmentsListBloc>(context),
  //                       builder: (context, state) {
  //                         if (state is DepartmentsSuccess) {
  //                           List<Departments> departments = state.departments;
  //                           return SelectionBox<Departments>(
  //                             leading: Translate.of(context)
  //                                 .translate("choose_department"),
  //                             hint: Translate.of(context)
  //                                 .translate("choose_department"),
  //                             controller: departmentSelection,
  //                             items: departments,
  //                             getText: (department) => department.name,
  //                             onChanged: (value) {
  //                               setState(() {
  //                                 departmentIdFk = value.id;
  //                                 AppBloc.departmentUserBloc.add(
  //                                     OnLoadDepartmentUsers(
  //                                         departmentId: value.id,
  //                                         roleId: smallLeaderRoleId));
  //                                 AppBloc.studentsBloc.add(OnLoadStudents(
  //                                     departmentIdFk: value.id,
  //                                     roleIdFk: studentsRoleId));
  //                               });
  //                             },
  //                           );
  //                         } else if (state is DepartmentsLoading) {
  //                           return Text("loading");
  //                         } else {
  //                           return Text("load department data failed.");
  //                         }
  //                       },
  //                     ),
  //                   ],
  //                 ),
  //               ],
  //             ),
  //             const SizedBox(height: 12),

  //             // two selection box, train type and document feature
  //             Wrap(
  //               runSpacing: 12,
  //               spacing: 40,
  //               children: [
  //                 // selection box of training types
  //                 BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
  //                   bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
  //                   builder: (context, state) {
  //                     if (state is TrainingsTypeSuccess) {
  //                       return SelectionBox<TrainingsType>(
  //                         leading:
  //                             Translate.of(context).translate("train_type"),
  //                         hint: Translate.of(context).translate("train_type"),
  //                         controller: trainingTypeSelection,
  //                         items: state.trainingTypes,
  //                         getText: (e) => e.name,
  //                         onChanged: (value) {
  //                           setState(() {
  //                             trainingTypeId = value.id;
  //                             AppBloc.documentsBloc.add(OnLoadDocuments(
  //                                 trainingTypeIdFk: trainingTypeId,
  //                                 departmentIdFk: departmentIdFk,
  //                                 documentFeature: documentFeatureIdFk));
  //                           });
  //                         },
  //                       );
  //                     } else if (state is TrainingsTypeLoading) {
  //                       return Text("loading");
  //                     } else {
  //                       return Text("load trainings type failed.");
  //                     }
  //                   },
  //                 ),

  //                 // selection box of training types
  //                 BlocBuilder<DocumentsFeatureListBloc,
  //                     DocumentsFeatureListState>(
  //                   bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
  //                   builder: (context, state) {
  //                     if (state is DocumentsFeatureSuccess) {
  //                       return SelectionBox<DocumentsFeature>(
  //                         leading: Translate.of(context)
  //                             .translate("document_feature"),
  //                         hint: Translate.of(context)
  //                             .translate("document_feature"),
  //                         controller: documentFeatureSelection,
  //                         items: state.documentsFeature,
  //                         getText: (e) => e.name,
  //                         onChanged: (value) {
  //                           setState(() {
  //                             documentFeatureIdFk = value.id;
  //                             AppBloc.documentsBloc.add(OnLoadDocuments(
  //                                 trainingTypeIdFk: trainingTypeId,
  //                                 departmentIdFk: departmentIdFk,
  //                                 documentFeature: documentFeatureIdFk));
  //                           });
  //                         },
  //                       );
  //                     } else if (state is DocumentsFeatureLoading) {
  //                       return Text("loading");
  //                     } else {
  //                       return Text("load document features failed.");
  //                     }
  //                   },
  //                 ),
  //               ],
  //             ),
  //             const SizedBox(height: 12),

  //             // two input box, document title and document description
  //             Wrap(
  //               runSpacing: 12,
  //               spacing: 40,
  //               children: [
  //                 Row(
  //                   mainAxisSize: MainAxisSize.min,
  //                   children: [
  //                     SizedBox(
  //                       width: 162,
  //                       height: 40,
  //                       child: Container(
  //                         alignment: Alignment.centerLeft,
  //                         child: Text(
  //                           Translate.of(context).translate("document_title"),
  //                           style: TextStyle(fontSize: 14),
  //                         ),
  //                       ),
  //                     ),
  //                     BlocBuilder<DocumentsBloc, DocumentsState>(
  //                       bloc: BlocProvider.of<DocumentsBloc>(context),
  //                       builder: (context, documentsList) {
  //                         if (documentsList is DocumentsLoading) {
  //                           return Container(
  //                             child: LoadingBox(
  //                               height: 30,
  //                             ),
  //                           );
  //                         } else if (documentsList is DocumentsSuccess) {
  //                           return Container(
  //                             width: 200,
  //                             height: 38,
  //                             child:
  //                                 CustomAutoCompleteTextField<DocumentsModel>(
  //                               controller: documentTitleController,
  //                               suggestions: documentsList.documents,
  //                               key: key,
  //                               style: TextStyle(
  //                                 color: Colors.black,
  //                                 fontSize: 12,
  //                               ),
  //                               onFocusChanged: (focus) {
  //                                 if (focus == true) {
  //                                   print(documentsList.documents.length);
  //                                 }
  //                               },
  //                               decoration: InputDecoration(
  //                                 border: OutlineInputBorder(
  //                                   borderRadius:
  //                                       BorderRadius.all(Radius.circular(3)),
  //                                   borderSide: BorderSide(
  //                                       color: Colors.red, width: 1.0),
  //                                 ),
  //                                 contentPadding:
  //                                     EdgeInsets.fromLTRB(10, 4, 10, 4),
  //                                 hintText: Translate.of(context)
  //                                     .translate("document_title"),
  //                                 hintStyle: TextStyle(color: Colors.black),
  //                               ),
  //                               itemBuilder: (context, query) {
  //                                 return new Padding(
  //                                     child: new ListTile(
  //                                       title: new Text(query.title),
  //                                     ),
  //                                     padding: EdgeInsets.all(2.0));
  //                               },
  //                               textChanged: (text) {
  //                                 print(text);
  //                               },
  //                               itemSorter: (a, b) =>
  //                                   a.title.compareTo(b.title),
  //                               itemFilter: (suggestion, input) => suggestion
  //                                   .title
  //                                   .toLowerCase()
  //                                   .startsWith(input.toLowerCase()),
  //                               itemSubmitted: (item) {
  //                                 setState(
  //                                   () {
  //                                     selectedDocument = item;
  //                                     documentTitleController.text = item.title;
  //                                     documentIdFk = item.id;
  //                                     selectedIdentifier = item.identifier;
  //                                     selectedName = item.documentFiles[0].name;
  //                                     selectedPath = item.documentFiles[0].path;
  //                                     selectedDocuments = item.documentFiles;
  //                                     selectedDocumentTest = item.documentTests;
  //                                     var documentTestIdFk =
  //                                         item.documentTests.first.id;
  //                                     item.documentTests.forEach(
  //                                       (e) => testControllers.add(
  //                                         new SingleTaskTestController(
  //                                             doRemove: onDelete,
  //                                             correctAnswers: e.rightAnswers,
  //                                             questionInputController:
  //                                                 TextEditingController(
  //                                                     text: e.question),
  //                                             selectedAnswers: e.totalAnswers,
  //                                             documentIdFk: documentIdFk,
  //                                             documentTestIdFk:
  //                                                 documentTestIdFk),
  //                                       ),
  //                                     );
  //                                   },
  //                                 );
  //                               },
  //                               clearOnSubmit: false,
  //                             ),
  //                           );
  //                         } else {
  //                           return Container();
  //                         }
  //                       },
  //                     ),
  //                   ],
  //                 ),
  //                 InputBox(
  //                   label:
  //                       Translate.of(context).translate("document_description"),
  //                   controller: documentDescriptionController,
  //                 ),
  //               ],
  //             ),
  //             const SizedBox(height: 12),

  //             // button, upload file;

  //             UploadTaskFileButton(uploadFile),
  //             const SizedBox(height: 23),

  //             // data table, files

  //             UploadedTaskFileTable(selectedDocuments: selectedDocuments),
  //             const SizedBox(height: 20),

  //             // tests table
  //             TaskTestsTable(controllers: testControllers),
  //             const SizedBox(height: 30),

  //             // selection box, choose small leader
  //             Wrap(
  //               runSpacing: 12,
  //               spacing: 20,
  //               children: [
  //                 Column(
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: [
  //                     Text(
  //                       Translate.of(context).translate("choose_small_leader"),
  //                       style: TextStyle(fontSize: 12),
  //                     ),
  //                     SizedBox(
  //                       height: 5,
  //                     ),
  //                     BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
  //                       bloc: BlocProvider.of<DepartmentUsersBloc>(context),
  //                       builder: (context, state) {
  //                         if (state is DepartmentUsersSuccess) {
  //                           return SelectionBox<ReadUsersByIdModel>(
  //                             items: state.departmentsUser,
  //                             getText: (e) => e.name,
  //                             controller: smallLeaderSelection,
  //                             hint: Translate.of(context)
  //                                 .translate("choose_small_leader"),
  //                           );
  //                         } else if (state is DepartmentUsersLoading) {
  //                           return LoadingBox(height: 20, width: 20);
  //                         } else {
  //                           return SelectionBox(
  //                             items: [],
  //                             getText: (e) => "",
  //                             controller: smallLeaderSelection,
  //                             hint: Translate.of(context)
  //                                 .translate("choose_small_leader"),
  //                           );
  //                         }
  //                       },
  //                     ),
  //                   ],
  //                 ),
  //                 // selection box, choose STUDENT
  //                 Column(
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: [
  //                     Text(
  //                       Translate.of(context).translate("choose_student"),
  //                       style: TextStyle(fontSize: 12),
  //                     ),
  //                     SizedBox(
  //                       height: 5,
  //                     ),
  //                     SizedBox(
  //                       width: 162,
  //                       height: 40,
  //                       child: StudentsDropDownMultiSelect(
  //                           onChanged: (List<String> names, List<int> ids) {
  //                             print(selectedStudentsIds);
  //                             setState(() {
  //                               selectedStudents = names;
  //                               selectedStudentsIds = ids;
  //                             });
  //                           },
  //                           selectedValues: selectedStudents,
  //                           selectedIds: selectedStudentsIds,
  //                           whenEmpty: Translate.of(context)
  //                               .translate("choose_student"),
  //                           departmentIdFk: departmentIdFk,
  //                           studentsRoleId: studentsRoleId),
  //                     ),
  //                     // BlocBuilder<StudentsBloc, StudentsState>(
  //                     //   bloc: BlocProvider.of<StudentsBloc>(context),
  //                     //   builder: (context, state) {
  //                     //     if (state is StudentsSuccess) {
  //                     //       // return SelectionBox<ReadUsersByIdModel>(
  //                     //       //   items: state.students,
  //                     //       //   getText: (e) => e.name,
  //                     //       //   controller: studentsSelection,
  //                     //       //   hint: Translate.of(context)
  //                     //       //       .translate("choose_student"),
  //                     //       //   onChanged: (value) {
  //                     //       //     setState(() {
  //                     //       //       studentIdFk = value.id;
  //                     //       //     });
  //                     //       //   },
  //                     //       // );
  //                     //       return SizedBox(
  //                     //         width: 162,
  //                     //         height: 40,
  //                     //         child: StudentsDropDownMultiSelect(
  //                     //             onChanged: (List<String> x) {
  //                     //               setState(() {
  //                     //                 selectedStudents = x;
  //                     //               });
  //                     //             },
  //                     //             selectedValues: selectedStudents,
  //                     //             whenEmpty: 'Select Students',
  //                     //             departmentIdFk: departmentIdFk,
  //                     //             studentsRoleId: studentsRoleId),
  //                     //       );
  //                     //     } else if (state is StudentsLoading) {
  //                     //       return LoadingBox(height: 20, width: 20);
  //                     //     } else {
  //                     //       return SelectionBox(
  //                     //         items: [],
  //                     //         getText: (e) => "",
  //                     //         controller: studentsSelection,
  //                     //         hint: Translate.of(context)
  //                     //             .translate("choose_student"),
  //                     //       );
  //                     //     }
  //                     //   },
  //                     // ),
  //                   ],
  //                 ),
  //                 Container(
  //                   width: 400,
  //                   child: Column(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: [
  //                       Text(
  //                         Translate.of(context).translate("choose_duration"),
  //                         style: TextStyle(fontSize: 12),
  //                       ),
  //                       SizedBox(
  //                         height: 5,
  //                       ),
  //                       Container(
  //                         width: 300,
  //                         child: GestureDetector(
  //                           onTap: () {
  //                             setState(() {
  //                               _showCalender();
  //                             });
  //                           },
  //                           child: AbsorbPointer(
  //                             child: AppTextInput(
  //                               controller: _dateController,
  //                               hintText: Translate.of(context)
  //                                   .translate("from_to_date"),
  //                               keyboardType: TextInputType.datetime,
  //                               icon: Icon(
  //                                 Icons.calendar_today_outlined,
  //                                 color: Colors.blue,
  //                                 size: 13,
  //                               ),
  //                             ),
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 )
  //               ],
  //             )
  //           ],
  //         ),
  //       )
  //     ],
  //   );
  // }

  void onDelete(int index) => setState(() {
        testControllers.removeAt(index);
      });
  Widget taskInfo(context) {
    return TaskInfoWidget(taskInfo: task);
  }

  Widget docInfo(context) {
    return DocumentDetailPage(documentInfo: document);
  }

  // Widget updateTask(context) {
  //   return UpdateTask(
  //     task: task,
  //   );
  // }

  Widget updateDoc(context) {
    return UpdateDocument(document: document);
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }
}

class BLTaskDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  BLTaskDataSource(List<Task> tasksData, context, statusId) {
    tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;
    // print("initstate3 loadtasks.length >>>> ${tasks.length}");
    try {
      if (tasks.length < 10) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      print("paginatedTasks >>>>> ${paginatedTask.length}");
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  _cancelTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: contxt, builder: (context) => CreatorSignDialog(text: "Confirm to Cancel"));

    if (confirm) {
      AppBloc.tasksDocBloc.add(CancelCreatedTask(taskStatusId: 3, taskIds: taskIds));
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
  }

  _updateTask(Task task) async {
    bool confirm = await showDialog(
        context: contxt,
        builder: (context) => UpdateTaskDialog(
              task: task,
            ));

    if (confirm) {}
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    notifyListeners();
  }

  _signTask(List<int> taskIds) async {
    bool confirm = await showDialog(context: contxt, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignTask(taskIds);
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: taskStatusId));
    notifyListeners();
  }

  void buildPaginatedDataGridRows() {
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.taskDocuments.first.document.version),
              DataGridCell<String>(columnName: 'beginTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.startDate)).toString()),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'students',
                value: e.taskStudents.fold<String>("", (previousValue, element) => previousValue + element.taskUser.username + ', '),
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[0].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[0].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[1].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[2].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[3].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[3].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[4].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[4].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[5].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[5].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[6].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[6].value.toString()),
            ),
          ),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              if (showCancelSignButtonWhen.contains(row.getCells()[7].value.taskStatusIdFk))
                InkWell(
                  onTap: () {
                    _cancelTask([
                      row.getCells()[7].value.id
                    ]);
                  },
                  child: Icon(
                    Icons.cancel_presentation,
                    color: Color(0xff00A4E3),
                  ),
                ),
              if (showCancelSignButtonWhen.contains(row.getCells()[7].value.taskStatusIdFk)) SizedBox(width: 10),
              if (showChangeButtonWhen.contains(row.getCells()[7].value.taskStatusIdFk))
                InkWell(
                  autofocus: true,
                  onTap: () {
                    _updateTask(row.getCells()[7].value);
                  },
                  child: Icon(
                    Icons.edit_outlined,
                    color: Color(0xff00A4E3),
                  ),
                ),
              SizedBox(width: 10),
              if (showCancelSignButtonWhen.contains(row.getCells()[7].value.taskStatusIdFk))
                InkWell(
                  onTap: () => _signTask([
                    row.getCells()[7].value.id
                  ]),
                  child: Icon(
                    Icons.check_outlined,
                    color: Color(0xff00A4E3),
                  ),
                ),
              if (!showCancelSignButtonWhen.contains(row.getCells()[7].value.taskStatusIdFk) && !showChangeButtonWhen.contains(row.getCells()[7].value.taskStatusIdFk))
                Text(
                  row.getCells()[7].value.taskStatus.name,
                  style: TextStyle(color: Colors.black, fontSize: Sizes.TEXT_SIZE_12),
                )
            ],
          ),
        ),
      ],
    );
  }
}

class DocDataSource extends DataGridSource {
  BuildContext contxt;
  List<int> showCancelSignButtonWhen = [
    1,
    5,
    7
  ];
  List<int> showChangeButtonWhen = [
    1,
    5,
    6,
    7
  ];
  int statusId;
  final Function(List<int>) onChanged;
  Task task;
  final Completer _completer = new Completer();
  DocDataSource(
    List<DocumentsModel> documentsData,
    context,
    int docStatusId, {
    selectedIds,
    this.onChanged,
  }) {
    try {
      documents = documentsData;
      contxt = context;
      statusId = docStatusId;
      taskIds = selectedIds;

      if (documents != null) {
        if (documents.length < rowsPerPage) {
          paginatedDocuments = documents.toList();
        } else {
          paginatedDocuments = documents.getRange(0, rowsPerPage).toList();
        }
        buildPaginatedDataGridRows();
      }
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.documents.length) {
      endIndex = this.documents.length;
    }
    paginatedDocuments = List.from(
      this.documents.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _documents = [];
  List<DocumentsModel> documents = [];
  @override
  List<DataGridRow> get rows => _documents;

  _cancelDoc(List<int> docIds) async {
    AppBloc.documentsBloc.add(OnUpdateDocumentStatus(docIds: docIds, status: 3));
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      3
    ], creatorIdFk: Application.user.id, taskDocStatusId: statusId));
  }

  _updateTask(Task task, int statusId) async {
    bool confirm = await showDialog(
        context: contxt,
        builder: (context) => UpdateTaskDialog(
              task: task,
            ));

    if (confirm) {}
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent(viewType: [
      ViewType.regularTask
    ], creatorIdFk: Application.user.id, taskDocStatusId: statusId));
  }

  _signDoc(List<int> docIds) async {
    bool confirm = await showDialog(context: contxt, builder: (context) => CreatorSignDialog(text: Translate.of(context).translate("confirm_to_sign")));

    if (confirm) {
      await Api.creatorSignDoc(docIds);
    }
    AppBloc.tasksDocBloc.add(OnLoadTaskDocEvent());
  }

  void buildPaginatedDataGridRows() {
    _documents = paginatedDocuments
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell<String>(columnName: 'title', value: e.title),
              DataGridCell<String>(columnName: 'description', value: e.description),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell<String>(columnName: 'version', value: e.version),
              DataGridCell<String>(columnName: 'beginTime', value: ""),
              DataGridCell<String>(columnName: 'endTime', value: ""),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.docCreator.creatorDepartment.name + ", " + e.docCreator.name,
              ),
              DataGridCell(columnName: "filters", value: e)
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    // if (checkedBox == true) {
    //   taskIds.add(row.getCells()[7].value.id);
    // } else {
    //   taskIds = [];
    // }

    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[0].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[0].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[1].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[1].value),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[2].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[2].value.toString()),
            ),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(""),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Tooltip(
            message: row.getCells()[5].value.toString(),
            child: Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(row.getCells()[5].value.toString()),
            ),
          ),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              if (showCancelSignButtonWhen.contains(row.getCells()[6].value.status))
                InkWell(
                  onTap: () {
                    _cancelDoc([
                      row.getCells()[6].value.id
                    ]);
                  },
                  child: Icon(
                    Icons.cancel_presentation,
                    color: Color(0xff00A4E3),
                  ),
                ),
              if (showCancelSignButtonWhen.contains(row.getCells()[6].value.status)) SizedBox(width: 10),
              if (showChangeButtonWhen.contains(row.getCells()[6].value.status))
                InkWell(
                  autofocus: true,
                  onTap: () {
                    _updateTask(row.getCells()[6].value, statusId);
                  },
                  child: Icon(
                    Icons.edit_outlined,
                    color: Color(0xff00A4E3),
                  ),
                ),
              SizedBox(width: 10),
              if (showCancelSignButtonWhen.contains(row.getCells()[6].value.status))
                InkWell(
                  onTap: () => _signDoc([
                    row.getCells()[6].value.id
                  ]),
                  child: Icon(
                    Icons.check_outlined,
                    color: Color(0xff00A4E3),
                  ),
                ),
              if (!showCancelSignButtonWhen.contains(row.getCells()[6].value.status) && !showChangeButtonWhen.contains(row.getCells()[6].value.status))
                Text(
                  row.getCells()[6].value.docStatus.name,
                  style: TextStyle(color: Colors.black, fontSize: Sizes.TEXT_SIZE_12),
                )
            ],
          ),
        ),
      ],
    );
  }
}
