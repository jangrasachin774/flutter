// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:gmptr/api/api.dart';
// import 'package:gmptr/blocs/app_bloc.dart';
// import 'package:gmptr/blocs/bloc.dart';
// import 'package:gmptr/configs/config.dart';
// import 'package:gmptr/models/model.dart';
// import 'package:gmptr/presentation/pages/role_types/creator/widgets/input_box.dart';
// import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
// import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
// import 'package:gmptr/presentation/widgets/widget.dart';
// import 'package:gmptr/utils/utils.dart';
// import 'package:intl/intl.dart';
// import 'package:syncfusion_flutter_datepicker/datepicker.dart';

// // ignore: must_be_immutable
// class UpdateTask extends StatefulWidget {
//   final Task task;
//   UpdateTask({
//     Key key,
//     this.task,
//   }) : super(key: key);

//   @override
//   _UpdateTaskState createState() => _UpdateTaskState();
// }

// class _UpdateTaskState extends State<UpdateTask> {
//   bool isRegularTask = false;
//   final _dateController = TextEditingController();
//   final _textTitleController = TextEditingController();

//   final documentTitleController = MyTextEditingController();
//   final documentDescriptionController = MyTextEditingController();

//   int departmentIdFk;
//   int smallLeaderIdFk;
//   int trainingTypeIdFk;
//   int traininTypeIdFk;
//   int documentTypeIdFk;

//   String _selectedDate = '';
//   String _dateCount = '';
//   String _startDate = '';
//   String _endDate = '';
//   String _rangeCount = '';

//   List<int> showAllUsersListWhen = [1, 3, 5, 7];

//   DocumentsModel selectedDocument;

//   GlobalKey key =
//       new GlobalKey<CustomAutoCompleteTextFieldState<DocumentsModel>>();
//   final List<UpdateSingleTaskTestController> testControllers = [];
//   List<DocumentTests> selectedDocumentTests = [];
//   final List<PlatformFile> choseDocuments = [];

//   List<DocumentFiles> selectedDocuments = [];

//   List<DocumentTests> selectedDocumentTest = [];

//   final int smallLeaderRoleId = 3;

//   final int studentsRoleId = 5;

//   int documentIdFk;
//   String selectedPath;
//   String selectedName;
//   String selectedIdentifier;
//   DateTime selectedDate = DateTime.now();
//   DateFormat formatter = DateFormat('dd/MM/yyyy');
//   int studentIdFk;
//   List<String> selectedStudents = [];

//   List<TaskStudents> taskUsers;

//   List<int> selectedStudentsIds = [];
//   final viewTypeSelection = SelectionBoxController();
//   List<ViewTypeModel> views = [];
//   int taskTypeView;

//   @override
//   void initState() {
//     super.initState();
//     AppBloc.trainingsTypeBlocs.add(OnLoadTrainingsType());
//     AppBloc.documentFeatureBlocs.add(OnLoadDocumentsFeature());
//     AppBloc.departmentBlocs.add(OnLoadDepartments());
//     AppBloc.documentsBloc.add(OnLoadDocuments());
//     AppBloc.studentsBloc.add(OnLoadStudents());
//     AppBloc.tasksBloc.add(OnLoadTasksEvent(taskId: widget.task.id));
//     AppBloc.departmentUserBloc.add(OnLoadDepartmentUsers(
//         departmentId: widget.task.departmentIdFk, roleId: smallLeaderRoleId));
//     AppBloc.studentsBloc.add(OnLoadStudents(
//         departmentIdFk: widget.task.departmentIdFk, roleIdFk: studentsRoleId));

//     if (selectedDocument != null)
//       _textTitleController.text = selectedDocument.title;
//     _startDate = widget.task.startDate;
//     _endDate = widget.task.endDate;
//   }

//   @override
//   void didChangeDependencies() {
//     setState(() {
//       AppBloc.tasksBloc.add(OnLoadTasksEvent(taskId: widget.task.id));
//       widget.task.taskStudents.forEach((ele) {
//         selectedStudentsIds.add(ele.id);
//         selectedStudents.add(ele.taskUser.username);
//       });
//       widget.task.taskDocuments.map((doc) => doc.document.documentTests.forEach(
//             (e) => testControllers.add(
//               new UpdateSingleTaskTestController(
//                 doRemove: onDelete,
//                 correctAnswers: e.rightAnswers,
//                 questionInputController:
//                     TextEditingController(text: e.question),
//                 selectedAnswers: e.totalAnswers,
//                 documentIdFk: e.documentTestIdFk,
//                 documentTestIdFk: e.documentTestIdFk,
//                 id: e.id,
//               ),
//             ),
//           ));
//       viewTypeSelection.value = widget.task.viewTypeIdFk;
//       documentTitleController.text = widget.task.title;
//       documentDescriptionController.text = widget.task.description;
//       departmentIdFk = widget.task.departmentIdFk;
//       trainingTypeIdFk = widget.task.trainingTypeIdFk;
//       documentTypeIdFk = widget.task.documentTypeIdFk;
//       smallLeaderIdFk = widget.task.smallLeaderIdFk;
//       selectedDocuments = widget.task.taskDocuments[0].document.documentFiles;
//       taskUsers = widget.task.taskStudents;
//       _dateController.text = DateFormat('yyyy/MM/dd')
//               .format(DateTime.parse(widget.task.startDate))
//               .toString() +
//           "-" +
//           DateFormat('yyyy/MM/dd')
//               .format(DateTime.parse(widget.task.endDate))
//               .toString();
//     });

//     super.didChangeDependencies();
//   }

//   void _showCalender(_startDate, _endDate) {
//     var started = DateFormat('yyyy-MM-dd 00:00:00.000')
//         .format(DateTime.parse(_startDate));
//     var end =
//         DateFormat('yyyy-MM-dd 00:00:00.000').format(DateTime.parse(_endDate));
//     showDialog<void>(
//         context: context,
//         builder: (BuildContext buildContext) {
//           return AlertDialog(
//             content: Container(
//               width: 280,
//               height: 400,
//               child: SfDateRangePicker(
//                 onSelectionChanged: _onSelectionChanged,
//                 selectionMode: DateRangePickerSelectionMode.range,
//               ),
//             ),
//             actions: <Widget>[
//               AppButton(
//                 Translate.of(context).translate('ok'),
//                 onPressed: () {
//                   Navigator.of(context).pop();
//                 },
//                 type: ButtonType.normal,
//               ),
//             ],
//           );
//         });
//   }

//   void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
//     setState(() {
//       if (args.value is PickerDateRange) {
//         _startDate = (args.value.startDate).toString();
//         _endDate = (args.value.endDate).toString();
//         _dateController.text =
//             DateFormat('dd/MM/yyyy').format(DateTime.parse(_startDate)) +
//                 "-" +
//                 DateFormat('dd/MM/yyyy').format(DateTime.parse(_endDate));
//       } else if (args.value is DateTime) {
//         _selectedDate = args.value.toString();
//       } else if (args.value is List<DateTime>) {
//         _dateCount = args.value.length.toString();
//       } else {
//         _rangeCount = args.value.length.toString();
//       }
//     });
//     AppBloc.tasksBloc.add(OnLoadTasksEvent(taskId: widget.task.id));
//   }

//   Future<void> doUpdate() async {
//     // check if all test been confirmed.
//     if (selectedDocuments == null)
//       for (var controller in testControllers) {
//         if (controller.onFocus) {
//           if (controller.changeFocus(context)) {
//             setState(() {});
//           } else {
//             // save failed. suspend create task
//             return;
//           }
//           return;
//         }

//         if (controller.totalAnswers == [] || controller.correctAnswers == []) {
//           return;
//         }
//       }

//     // check task title
//     if (documentTitleController.text == null ||
//         documentTitleController.text.isEmpty) {
//       SnackBarUtil.warn(context, "document title empty");
//       return;
//     }

//     // check training type
//     if (trainingTypeIdFk == null) {
//       SnackBarUtil.warn(context, "training type not select");
//       return;
//     }

//     // check document feature
//     if (documentTypeIdFk == null) {
//       SnackBarUtil.warn(context, "document feature not select");
//       return;
//     }

//     // check department id
//     if (departmentIdFk == null) {
//       SnackBarUtil.warn(context, "department not select");
//       return;
//     }

//     // check small leader id
//     if (smallLeaderIdFk == null) {
//       SnackBarUtil.warn(context, "small leader not select");
//       return;
//     }

//     String title = documentTitleController.text;
//     String description = documentDescriptionController.text;

//     int creatorIdFk = Application.user.id;

//     String fromDate = _startDate;
//     String endDate = _endDate;

//     final task = Task.create(
//       isReadonly: isRegularTask,
//       departmentIdFk: departmentIdFk,
//       title: title,
//       description: description,
//       trainingTypeIdFk: trainingTypeIdFk,
//       documentTypeIdFk: documentTypeIdFk,
//       creatorIdFk: creatorIdFk,
//       smallLeaderIdFk: smallLeaderIdFk,
//       startDate: fromDate,
//       endDate: endDate,
//     );
//     try {
//       await Api.updateTask(task, widget.task.id);

//       // do update task tests

//       testControllers.forEach((e) {
//         if (e.id != null) {
//           Api.updateTaskTest(
//             e.genTaskTest(widget.task.id),
//           );
//         } else {
//           Api.createTaskTest(
//             e.genTaskTest(widget.task.id),
//           );
//         }
//       });

//       // do upload new files
//       if (choseDocuments.isNotEmpty || choseDocuments.length > 0) {
//         await Api.uploadTaskDocumentFiles(widget.task.id, choseDocuments);
//       }

//       /// DO UPLOAD EXISTS FILES
//       if (documentIdFk != null) {
//         selectedDocuments.forEach(
//           (element) => Api.uploadExistsTaskDocumentFiles(
//             widget.task.id,
//             element.path,
//             element.name,
//             documentIdFk,
//             selectedIdentifier,
//           ),
//         );
//       }

//       setState(() {});

//       SnackBarUtil.info(context, "Updated Task Success.");
//     } catch (error) {
//       SnackBarUtil.info(context, error.toString());
//     }
//     // do create task
//   }

//   Future<void> uploadFile() async {
//     if (widget.task.taskDocuments[0].document.documentFiles.isNotEmpty ||
//         widget.task.taskDocuments[0].document.documentFiles == []) {
//       widget.task.taskDocuments[0].document.documentFiles
//           .forEach((element) => Api.deleteTaskDocumentFile(element.id));
//     }
//     FilePickerResult result = await FilePicker.platform.pickFiles();

//     if (result != null) {
//       PlatformFile file = result.files.first;

//       print(choseDocuments);
//       DocumentFiles documentFiles = new DocumentFiles.fromJson(
//           {"id": null, "name": file.name, "path": ""});
//       setState(() {
//         documentIdFk = null;
//         choseDocuments.add(file);
//         selectedDocuments.clear();
//         selectedDocuments.add(documentFiles);
//       });
//       // print(file.name);
//       // print(file.bytes);
//       // print(file.size);
//       // print(file.extension);
//       // print(file.path);
//     } else {
//       // User canceled the picker
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     rebuildAllChildren(context);
//     return ListView(shrinkWrap: true, children: [
//       Padding(
//         padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // two radio, regular or read only

//             Wrap(
//               children: [
//                 if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//                   SizedBox(
//                     width: 162,
//                     height: 40,
//                     child: Container(
//                       alignment: Alignment.centerLeft,
//                       child: Text(
//                         Translate.of(context).translate("task_type"),
//                         style: TextStyle(fontSize: 14),
//                       ),
//                     ),
//                   ),
//                 BlocBuilder<ViewTypeListBloc, ViewTypeListState>(
//                   bloc: BlocProvider.of<ViewTypeListBloc>(context),
//                   builder: (context, state) {
//                     if (state is ViewTypeSuccess) {
//                       views.clear();
//                       if (views.isEmpty) {
//                         for (var v in state.views) {
//                           if (v.type == "T") {
//                             views.add(v);
//                           }
//                         }
//                       }
//                       return SelectionBox<ViewTypeModel>(
//                         leading: Translate.of(context).translate("task_type"),
//                         hint: Translate.of(context).translate("task_type"),
//                         controller: viewTypeSelection,
//                         items: views,
//                         getText: (view) => view.name,
//                         onChanged: (value) {
//                           setState(() {
//                             taskTypeView = value.id;
//                           });
//                         },
//                       );
//                     } else if (state is ViewTypeLoading) {
//                       return LoadingBox(
//                         width: 10,
//                         height: 10,
//                       );
//                     } else if (state is ViewTypeFail) {
//                       return Text(state.code);
//                     } else {
//                       return Text("load task types failed.");
//                     }
//                   },
//                 ),
//                 Wrap(
//                   runSpacing: 10,
//                   spacing: 210,
//                   children: [
//                     if (showAllUsersListWhen
//                         .contains(widget.task.taskStatusIdFk))

//                       // Wrap(
//                       //   runSpacing: 10,
//                       //   spacing: 5,
//                       //   children: [
//                       //     Radio(
//                       //       value: false,
//                       //       groupValue: isRegularTask,
//                       //       onChanged: (newValue) =>
//                       //           setState(() => isRegularTask = newValue),
//                       //       activeColor: Colors.lightBlueAccent,
//                       //     ),
//                       //     const SizedBox(width: 10),
//                       //     Text(Translate.of(context).translate("regular_task")),
//                       //     const SizedBox(width: 20),
//                       //     Radio(
//                       //       value: true,
//                       //       groupValue: isRegularTask,
//                       //       onChanged: (newValue) =>
//                       //           setState(() => isRegularTask = newValue),
//                       //       activeColor: Colors.lightBlueAccent,
//                       //     ),
//                       //     const SizedBox(width: 10),
//                       //     Text(Translate.of(context).translate("read_only_task")),
//                       //   ],
//                       // ),
//                       // selection box, choose dept
//                       if (showAllUsersListWhen
//                           .contains(widget.task.taskStatusIdFk))
//                         BlocBuilder<DepartmentsListBloc, DepartmentsListState>(
//                           bloc: BlocProvider.of<DepartmentsListBloc>(context),
//                           builder: (context, state) {
//                             if (state is DepartmentsSuccess) {
//                               return Wrap(
//                                 children: [
//                                   SizedBox(
//                                     width: 162,
//                                     height: 40,
//                                     child: Container(
//                                       alignment: Alignment.centerLeft,
//                                       child: Text(
//                                         Translate.of(context)
//                                             .translate("choose_department"),
//                                         style: TextStyle(fontSize: 14),
//                                       ),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: 40,
//                                     width: 200,
//                                     child: Container(
//                                       alignment: Alignment.center,
//                                       padding: EdgeInsets.symmetric(
//                                         horizontal: 10,
//                                         vertical: 0,
//                                       ),
//                                       decoration: BoxDecoration(
//                                         color: Colors.white,
//                                         border: Border.all(
//                                             width: 1, color: Colors.grey),
//                                         borderRadius:
//                                             BorderRadius.circular(2.2),
//                                       ),
//                                       child: DropdownButton(
//                                         value: departmentIdFk,
//                                         underline: SizedBox(),
//                                         icon: Icon(
//                                             Icons.keyboard_arrow_down_outlined),
//                                         items: state.departments
//                                             .map((e) => DropdownMenuItem(
//                                                   child: Text(e.name,
//                                                       style: TextStyle(
//                                                           fontSize: 12)),
//                                                   value: e.id,
//                                                 ))
//                                             .toList(),
//                                         hint: Text(
//                                           Translate.of(context)
//                                               .translate("choose_department"),
//                                           style: TextStyle(
//                                             color: Colors.black,
//                                             fontSize: 12,
//                                           ),
//                                         ),
//                                         onChanged: (int value) {
//                                           setState(() {
//                                             departmentIdFk = value;
//                                             AppBloc.departmentUserBloc.add(
//                                                 OnLoadDepartmentUsers(
//                                                     departmentId: value,
//                                                     roleId: smallLeaderRoleId));
//                                           });
//                                         },
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               );
//                             } else if (state is DepartmentsLoading) {
//                               return Text("loading");
//                             } else {
//                               return Text("load department data failed.");
//                             }
//                           },
//                         ),
//                     AppButton(
//                       Translate.of(context).translate('update'),
//                       onPressed: () {
//                         setState(() {
//                           doUpdate();
//                         });
//                       },
//                       type: ButtonType.normal,
//                       color: Color(0xff787E8C),
//                       icon: Icon(Icons.save_outlined),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//             const SizedBox(height: 12),

//             // two selection box, train type and document feature
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   Wrap(
//             //     runSpacing: 12,
//             //     spacing: 40,
//             //     children: [
//             //       // selection box of training types
//             //       BlocBuilder<TrainingsTypeListBloc, TrainingsTypeListState>(
//             //         bloc: BlocProvider.of<TrainingsTypeListBloc>(context),
//             //         builder: (context, state) {
//             //           if (state is TrainingsTypeSuccess) {
//             //             return Wrap(
//             //               children: [
//             //                 SizedBox(
//             //                   width: 162,
//             //                   height: 40,
//             //                   child: Container(
//             //                     alignment: Alignment.centerLeft,
//             //                     child: Text(
//             //                       Translate.of(context)
//             //                           .translate("training_type"),
//             //                       style: TextStyle(fontSize: 14),
//             //                     ),
//             //                   ),
//             //                 ),
//             //                 SizedBox(
//             //                   height: 40,
//             //                   width: 200,
//             //                   child: Container(
//             //                     alignment: Alignment.center,
//             //                     padding: EdgeInsets.symmetric(
//             //                       horizontal: 10,
//             //                       vertical: 0,
//             //                     ),
//             //                     decoration: BoxDecoration(
//             //                       color: Colors.white,
//             //                       border:
//             //                           Border.all(width: 1, color: Colors.grey),
//             //                       borderRadius: BorderRadius.circular(2.2),
//             //                     ),
//             //                     child: DropdownButton(
//             //                       value: trainingTypeIdFk,
//             //                       underline: SizedBox(),
//             //                       icon:
//             //                           Icon(Icons.keyboard_arrow_down_outlined),
//             //                       items: state.trainingTypes
//             //                           .map((e) => DropdownMenuItem(
//             //                                 child: Text(e.name,
//             //                                     style: TextStyle(fontSize: 12)),
//             //                                 value: e.id,
//             //                               ))
//             //                           .toList(),
//             //                       hint: Text(
//             //                         "Please choose a status",
//             //                         style: TextStyle(
//             //                           color: Colors.black,
//             //                           fontSize: 12,
//             //                         ),
//             //                       ),
//             //                       onChanged: (int value) {
//             //                         setState(() {
//             //                           traininTypeIdFk = value;
//             //                         });
//             //                       },
//             //                     ),
//             //                   ),
//             //                 ),
//             //               ],
//             //             );
//             //           } else if (state is TrainingsTypeLoading) {
//             //             return Text("loading");
//             //           } else {
//             //             return Text("load trainings type failed.");
//             //           }
//             //         },
//             //       ),

//             //       // selection box of training types
//             //       BlocBuilder<DocumentsFeatureListBloc,
//             //           DocumentsFeatureListState>(
//             //         bloc: BlocProvider.of<DocumentsFeatureListBloc>(context),
//             //         builder: (context, state) {
//             //           if (state is DocumentsFeatureSuccess) {
//             //             return Wrap(
//             //               children: [
//             //                 SizedBox(
//             //                   width: 162,
//             //                   height: 40,
//             //                   child: Container(
//             //                     alignment: Alignment.centerLeft,
//             //                     child: Text(
//             //                       Translate.of(context)
//             //                           .translate("document_feature"),
//             //                       style: TextStyle(fontSize: 14),
//             //                     ),
//             //                   ),
//             //                 ),
//             //                 SizedBox(
//             //                   height: 40,
//             //                   width: 200,
//             //                   child: Container(
//             //                     alignment: Alignment.center,
//             //                     padding: EdgeInsets.symmetric(
//             //                       horizontal: 10,
//             //                       vertical: 0,
//             //                     ),
//             //                     decoration: BoxDecoration(
//             //                       color: Colors.white,
//             //                       border:
//             //                           Border.all(width: 1, color: Colors.grey),
//             //                       borderRadius: BorderRadius.circular(2.2),
//             //                     ),
//             //                     child: DropdownButton(
//             //                       value: documentTypeIdFk,
//             //                       underline: SizedBox(),
//             //                       icon:
//             //                           Icon(Icons.keyboard_arrow_down_outlined),
//             //                       items: state.documentsFeature
//             //                           .map((e) => DropdownMenuItem(
//             //                                 child: Text(e.name,
//             //                                     style: TextStyle(fontSize: 12)),
//             //                                 value: e.id,
//             //                               ))
//             //                           .toList(),
//             //                       hint: Text(
//             //                         Translate.of(context)
//             //                             .translate("document_feature"),
//             //                         style: TextStyle(
//             //                           color: Colors.black,
//             //                           fontSize: 12,
//             //                         ),
//             //                       ),
//             //                       onChanged: (int value) {
//             //                         setState(() {
//             //                           documentTypeIdFk = value;
//             //                         });
//             //                       },
//             //                     ),
//             //                   ),
//             //                 ),
//             //               ],
//             //             );
//             //           } else if (state is DocumentsFeatureLoading) {
//             //             return Text("loading");
//             //           } else {
//             //             return Text("load document features failed.");
//             //           }
//             //         },
//             //       ),
//             //     ],
//             //   ),
//             // const SizedBox(height: 12),

//             // // two input box, document title and document description
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   Wrap(
//             //     runSpacing: 12,
//             //     spacing: 40,
//             //     children: [
//             //       Row(
//             //         mainAxisSize: MainAxisSize.min,
//             //         children: [
//             //           Text(Translate.of(context).translate("document_title")),
//             //           SizedBox(
//             //             width: 55,
//             //           ),
//             //           BlocBuilder<DocumentsBloc, DocumentsState>(
//             //             bloc: BlocProvider.of<DocumentsBloc>(context),
//             //             builder: (context, documentsList) {
//             //               if (documentsList is DocumentsLoading) {
//             //                 return Container(
//             //                   child: LoadingBox(
//             //                     height: 30,
//             //                   ),
//             //                 );
//             //               } else if (documentsList is DocumentsSuccess) {
//             //                 return Container(
//             //                   width: 220,
//             //                   height: 38,
//             //                   child:
//             //                       CustomAutoCompleteTextField<DocumentsModel>(
//             //                     controller: documentTitleController,
//             //                     suggestions: documentsList.documents,
//             //                     key: key,
//             //                     style: TextStyle(
//             //                       color: Colors.black,
//             //                       fontSize: 12,
//             //                     ),
//             //                     decoration: InputDecoration(
//             //                       border: OutlineInputBorder(
//             //                         borderRadius:
//             //                             BorderRadius.all(Radius.circular(3)),
//             //                         borderSide: BorderSide(
//             //                             color: Colors.red, width: 1.0),
//             //                       ),
//             //                       contentPadding:
//             //                           EdgeInsets.fromLTRB(10, 4, 10, 4),
//             //                       hintText: Translate.of(context)
//             //                           .translate('document_title'),
//             //                       hintStyle: TextStyle(color: Colors.black),
//             //                     ),
//             //                     itemBuilder: (context, query) {
//             //                       return new Padding(
//             //                           child: new ListTile(
//             //                             title: new Text(query.title),
//             //                           ),
//             //                           padding: EdgeInsets.all(2.0));
//             //                     },
//             //                     textChanged: (text) {
//             //                       print(text);
//             //                     },
//             //                     itemSorter: (a, b) =>
//             //                         a.title.compareTo(b.title),
//             //                     itemFilter: (suggestion, input) => suggestion
//             //                         .title
//             //                         .toLowerCase()
//             //                         .startsWith(input.toLowerCase()),
//             //                     itemSubmitted: (item) {
//             //                       setState(
//             //                         () {
//             //                           selectedDocument = item;
//             //                           documentTitleController.text = item.title;
//             //                           documentIdFk = item.id;
//             //                           selectedIdentifier = item.identifier;
//             //                           selectedName = item.documentFiles[0].name;
//             //                           selectedPath = item.documentFiles[0].path;
//             //                           selectedDocuments = item.documentFiles;
//             //                           selectedDocumentTest = item.documentTests;
//             //                           var documentTestIdFk =
//             //                               item.documentTests.first.id;
//             //                           item.documentTests.forEach(
//             //                             (e) => testControllers.add(
//             //                               new UpdateSingleTaskTestController(
//             //                                   doRemove: onDelete,
//             //                                   correctAnswers: e.rightAnswers,
//             //                                   questionInputController:
//             //                                       TextEditingController(
//             //                                           text: e.question),
//             //                                   selectedAnswers: e.totalAnswers,
//             //                                   documentIdFk: documentIdFk,
//             //                                   documentTestIdFk:
//             //                                       documentTestIdFk),
//             //                             ),
//             //                           );
//             //                         },
//             //                       );
//             //                     },
//             //                     clearOnSubmit: false,
//             //                   ),
//             //                 );
//             //               } else {
//             //                 return Container();
//             //               }
//             //             },
//             //           ),
//             //         ],
//             //       ),
//             //       InputBox(
//             //         label:
//             //             Translate.of(context).translate("document_description"),
//             //         controller: documentDescriptionController,
//             //       ),
//             //     ],
//             //   ),
//             // const SizedBox(height: 12),

//             // // button, upload file;
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   UpdateUploadTaskFileButton(uploadFile),
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   const SizedBox(height: 23),

//             // // data table, files
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   UpdateUploadedTaskFileTable(selectedDocuments: selectedDocuments),
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   const SizedBox(height: 20),

//             // // tests table
//             // if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //   UpdateTaskTestsTable(controllers: testControllers),
//             // const SizedBox(height: 30),

//             // // selection box, choose small leader

//             // Wrap(
//             //   runSpacing: 12,
//             //   spacing: 20,
//             //   children: [
//             //     if (showAllUsersListWhen.contains(widget.task.taskStatusIdFk))
//             //       Column(
//             //         crossAxisAlignment: CrossAxisAlignment.start,
//             //         children: [
//             //           Text(
//             //             Translate.of(context).translate("choose_small_leader"),
//             //             style: TextStyle(fontSize: 12),
//             //           ),
//             //           SizedBox(
//             //             height: 5,
//             //           ),
//             //           BlocBuilder<DepartmentUsersBloc, DepartmentUsersState>(
//             //             bloc: BlocProvider.of<DepartmentUsersBloc>(context),
//             //             builder: (context, state) {
//             //               if (state is DepartmentUsersSuccess) {
//             //                 return SizedBox(
//             //                   height: 40,
//             //                   width: 200,
//             //                   child: Container(
//             //                     alignment: Alignment.center,
//             //                     padding: EdgeInsets.symmetric(
//             //                       horizontal: 10,
//             //                       vertical: 0,
//             //                     ),
//             //                     decoration: BoxDecoration(
//             //                       color: Colors.white,
//             //                       border:
//             //                           Border.all(width: 1, color: Colors.grey),
//             //                       borderRadius: BorderRadius.circular(2.2),
//             //                     ),
//             //                     child: DropdownButton(
//             //                       value: smallLeaderIdFk ??
//             //                           widget.task.smallLeaderIdFk,
//             //                       underline: SizedBox(),
//             //                       icon:
//             //                           Icon(Icons.keyboard_arrow_down_outlined),
//             //                       items: state.departmentsUser
//             //                           .map((e) => DropdownMenuItem(
//             //                                 child: Text(e.name,
//             //                                     style: TextStyle(fontSize: 12)),
//             //                                 value: e.id,
//             //                               ))
//             //                           .toList(),
//             //                       hint: Text(
//             //                         Translate.of(context)
//             //                             .translate("choose_small_leader"),
//             //                         style: TextStyle(
//             //                           color: Colors.black,
//             //                           fontSize: 12,
//             //                         ),
//             //                       ),
//             //                       onChanged: (int value) {
//             //                         setState(() {
//             //                           smallLeaderIdFk = value;
//             //                         });
//             //                       },
//             //                     ),
//             //                   ),
//             //                 );
//             //               } else if (state is DepartmentUsersLoading) {
//             //                 return LoadingBox(height: 20, width: 20);
//             //               } else {
//             //                 return Container();
//             //               }
//             //             },
//             //           ),
//             //         ],
//             //       ),
//             //     // selection box, choose STUDENT
//             //     Column(
//             //       crossAxisAlignment: CrossAxisAlignment.start,
//             //       children: [
//             //         Text(
//             //           Translate.of(context).translate("choose_student"),
//             //           style: TextStyle(fontSize: 12),
//             //         ),
//             //         SizedBox(
//             //           height: 5,
//             //         ),
//             //         SizedBox(
//             //           width: 162,
//             //           height: 40,
//             //           child: showAllUsersListWhen
//             //                   .contains(widget.task.taskStatusIdFk)
//             //               ? UpdateStudentsDropDownMultiSelect(
//             //                   onChanged: (List<String> names, List<int> ids) {
//             //                     setState(() {
//             //                       selectedStudents = names;
//             //                       selectedStudentsIds = ids;
//             //                     });
//             //                   },
//             //                   selectedValues: selectedStudents,
//             //                   selectedIds: selectedStudentsIds,
//             //                   whenEmpty: Translate.of(context)
//             //                       .translate("choose_student"),
//             //                   departmentIdFk: departmentIdFk,
//             //                   studentsRoleId: studentsRoleId,
//             //                   taskId: widget.task.id,
//             //                 )
//             //               : TaskUsersDropDownMultiSelect(
//             //                   onChanged: (List<String> names, List<int> ids) {
//             //                     setState(() {
//             //                       selectedStudents = names;
//             //                       selectedStudentsIds = ids;
//             //                     });
//             //                   },
//             //                   selectedValues: selectedStudents,
//             //                   selectedIds: selectedStudentsIds,
//             //                   whenEmpty: Translate.of(context)
//             //                       .translate("choose_student"),
//             //                   taskUsers: taskUsers,
//             //                 ),
//             //         ),
//             //       ],
//             //     ),
//             //     Container(
//             //       width: 400,
//             //       child: Column(
//             //         crossAxisAlignment: CrossAxisAlignment.start,
//             //         children: [
//             //           Text(
//             //             Translate.of(context).translate("choose_duration"),
//             //             style: TextStyle(fontSize: 12),
//             //           ),
//             //           SizedBox(
//             //             height: 5,
//             //           ),
//             //           Container(
//             //             width: 300,
//             //             child: GestureDetector(
//             //               onTap: () {
//             //                 setState(() {
//             //                   _showCalender(_startDate, _endDate);
//             //                 });
//             //               },
//             //               child: AbsorbPointer(
//             //                 child: AppTextInput(
//             //                   controller: _dateController,
//             //                   hintText: Translate.of(context)
//             //                       .translate("from_to_date"),
//             //                   keyboardType: TextInputType.datetime,
//             //                   icon: Icon(
//             //                     Icons.calendar_today_outlined,
//             //                     color: Colors.blue,
//             //                     size: 13,
//             //                   ),
//             //                 ),
//             //               ),
//             //             ),
//             //           ),
//             //         ],
//             //       ),
//             //     )
//             //   ],
//             // )
//           ],
//         ),
//       )
//     ]);
//   }

//   void onDelete(int index) => setState(() {
//         testControllers.removeAt(index);
//       });

//   void rebuildAllChildren(BuildContext context) {
//     void rebuild(Element el) {
//       el.markNeedsBuild();
//       el.visitChildren(rebuild);
//     }

//     (context as Element).visitChildren(rebuild);
//   }
// }
