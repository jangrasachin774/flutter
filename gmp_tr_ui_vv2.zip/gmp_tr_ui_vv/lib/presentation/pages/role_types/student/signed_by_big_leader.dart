import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/blocs/tasks/bloc.dart';
import 'package:gmptr/configs/application.dart';
import 'package:gmptr/global.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/snack_bar_util.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:intl/intl.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'student_take_test_page.dart';
import 'widgets/bottom_filters_box.dart';
import 'widgets/key_value_text_horizontal.dart';
import 'widgets/key_value_text_vertical.dart';
import 'widgets/widgets.dart';

class SignedByBLDashboardPage extends StatefulWidget {
  const SignedByBLDashboardPage({
    Key key,
  }) : super(key: key);

  @override
  _SignedByBLDashboardPageState createState() => _SignedByBLDashboardPageState();
}

List<int> selectedTaskIds = [];
List<Task> paginatedTask = [];
final int rowsPerPage = 10;

class _SignedByBLDashboardPageState extends State<SignedByBLDashboardPage> {
  StudentsWidgets selectedWidgetPage = StudentsWidgets.dashboard;
  bool isConfirmed = false;
  DateTime enterTime;
  Task task;
  List<DocumentTests> tests;
  int taskStatusId = 6;
  var currentSecond;
  Timer timer;
  @override
  void initState() {
    super.initState();
    enterTime = DateTime.now();

    /// LOADS TASKS
    AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
      ViewType.regularTask
    ], studentIdFk: Application.user.id, taskStatusId: taskStatusId));
  }

  void _getTime() {
    final DateTime _now = DateTime.now().toUtc().toLocal();
    if (mounted) {
      setState(() {
        currentSecond = _now.second;
      });
    }
  }

  // /// VALIDATION TO TAKE EXAM PAGE - MORE THAN 2 MIN TO VIEW DOCUMENT
  Future<void> _go2TestPage() async {
    if (DateTime.now().difference(enterTime).abs().inMinutes < 2) {
      SnackBarUtil.warn(context, "please read at least 2 minutes.");

      return false;
    } else {
      selectedWidgetPage = StudentsWidgets.openTest;
      return true;
    }
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  Widget getCustomContainer(context) {
    switch (selectedWidgetPage) {
      case StudentsWidgets.dashboard:
        return dashboardController(context);
      case StudentsWidgets.openTest:
        return openTest(context);
      case StudentsWidgets.taskDetails:
        return taskDetails(context);
    }

    return dashboardController(context);
  }

  @override
  Widget build(BuildContext context) {
    return ResponsiveBuilder(
        refinedBreakpoints: RefinedBreakpoints(),
        builder: (context, sizingInformation) {
          double screenWidth = sizingInformation.screenSize.width;
          //Desktop
          if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
            return ListView(
              shrinkWrap: true,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(35, 18, 12, 25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // heading text and two button, create new document/task
                      Container(
                        width: double.infinity,
                        child: Wrap(
                          runSpacing: 10,
                          alignment: WrapAlignment.spaceBetween,
                          children: [
                            if (selectedWidgetPage == StudentsWidgets.dashboard) HeadingText(Translate.of(context).translate("signed_by_big_leader")),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails) HeadingText(Translate.of(context).translate("company_policy_training")),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails || selectedWidgetPage == StudentsWidgets.openTest)
                              SizedBox(
                                width: 1,
                              ),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails || selectedWidgetPage == StudentsWidgets.openTest)
                              Tooltip(
                                message: Translate.of(context).translate('close'),
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      selectedWidgetPage = StudentsWidgets.dashboard;
                                      AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
                                        ViewType.regularTask
                                      ], studentIdFk: Application.user.id, taskStatusId: taskStatusId));
                                    });
                                  },
                                  child: Icon(
                                    Icons.close,
                                    color: Color(0xff00A4E3),
                                    size: 20,
                                  ),
                                ),
                              ),
                            Container(
                              child: getCustomContainer(context),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          } else {
            return SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            if (selectedWidgetPage == StudentsWidgets.dashboard) HeadingText(Translate.of(context).translate("signed_by_big_leader")),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails) HeadingText(Translate.of(context).translate("company_policy_training")),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails) Container(),
                            if (selectedWidgetPage == StudentsWidgets.dashboard)
                              Row(
                                children: [
                                  AppButton(
                                    Translate.of(context).translate('filter'),
                                    onPressed: () {
                                      showModalBottomSheet<void>(
                                        shape: RoundedRectangleBorder(
                                          //setting a new shape
                                          borderRadius: BorderRadius.vertical(
                                            top: Radius.circular(0),
                                          ),
                                        ),
                                        isScrollControlled: true,
                                        backgroundColor: Colors.white,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return FractionallySizedBox(
                                            heightFactor: 0.8,
                                            child: BottomSheetFilters(taskStatusId: taskStatusId),
                                          );
                                        },
                                      );
                                    },
                                    type: ButtonType.outline,
                                    color: Color(0xff787E8C),
                                    icon: Icon(
                                      Icons.filter_alt,
                                    ),
                                  ),
                                ],
                              ),
                            if (selectedWidgetPage == StudentsWidgets.taskDetails)
                              Tooltip(
                                message: Translate.of(context).translate('close'),
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      selectedWidgetPage = StudentsWidgets.dashboard;
                                      AppBloc.tasksBloc.add(OnLoadTasksEvent(viewType: [
                                        ViewType.regularTask
                                      ], studentIdFk: Application.user.id, taskStatusId: taskStatusId));
                                    });
                                  },
                                  child: Icon(
                                    Icons.close,
                                    color: Color(0xff00A4E3),
                                    size: 20,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          child: getCustomContainer(context),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        });
  }

  Widget dashboardController(context) {
    return ResponsiveBuilder(
        refinedBreakpoints: RefinedBreakpoints(),
        builder: (context, sizingInformation) {
          double screenWidth = sizingInformation.screenSize.width;
          //Desktop
          if (screenWidth > (RefinedBreakpoints().mobileExtraLarge)) {
            return Column(
              children: [
                StudentsFiltersBox(taskStatusId: taskStatusId),
                const SizedBox(height: 20),
                BlocBuilder<TasksListBloc, TasksListState>(
                  bloc: BlocProvider.of<TasksListBloc>(context),
                  builder: (context, state) {
                    if (state is TasksSuccess) {
                      TaskDataSource taskDataSource;
                      taskDataSource = new TaskDataSource(
                        state.tasks,
                        context,
                        taskStatusId,
                      );

                      List<Task> taskCount = state.tasks;

                      return LayoutBuilder(builder: (context, constraints) {
                        return Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: MediaQuery.of(context).size.height * 0.5,
                                  width: constraints.maxWidth,
                                  child: SfDataGrid(
                                    allowSorting: true,
                                    source: taskDataSource,
                                    columnWidthMode: ColumnWidthMode.fill,
                                    columns: [
                                      GridColumn(
                                        columnName: 'title',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('title'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'trainingType',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('training_type'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'version',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('version'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                          columnName: 'endTime',
                                          label: Container(
                                              height: 50,
                                              color: Color(0xffEFF5FC),
                                              padding: EdgeInsets.all(16.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                Translate.of(context).translate('end_time'),
                                              ))),
                                      GridColumn(
                                        columnName: 'createdDepWorker',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('created_dep_worker'),
                                          ),
                                        ),
                                      ),
                                      GridColumn(
                                        columnName: 'finishDepWorker',
                                        label: Container(
                                          height: 50,
                                          color: Color(0xffEFF5FC),
                                          padding: EdgeInsets.all(16.0),
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            Translate.of(context).translate('finish_dep_worker'),
                                          ),
                                        ),
                                      ),
                                    ],
                                    selectionMode: SelectionMode.single,
                                    onSelectionChanging: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) {
                                      if (taskDataSource.rows.length > 0) {
                                        final index = taskDataSource.rows.indexOf(addedRows.last);
                                        print("task >>> $index");
                                      }
                                      return true;
                                    },
                                    onSelectionChanged: (List<DataGridRow> addedRows, List<DataGridRow> removedRows) async {
                                      if (taskDataSource.rows.length > 0) {
                                        // final index = taskDataSource.rows
                                        //     .indexOf(addedRows.last);
                                        // task = taskCount[index];
                                        task = taskCount.firstWhere((element) => element.id == (addedRows.last.getCells().first.value as Task).id);
                                        await showDialog(context: context, builder: (context) => Dialog(backgroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0, child: taskDetails(context))
                                            //     CreatorTaskInfoWidget(
                                            //   taskInfo: taskCount[index],
                                            // ),
                                            );
                                        // setState(() {
                                        //   selectedWidgetPage =
                                        //       StudentsWidgets.taskDetails;
                                        //   task = taskCount[index];
                                        // });
                                      }
                                    },
                                  ),
                                ),
                                Container(
                                  height: 51,
                                  width: constraints.maxWidth,
                                  child: SfDataPager(
                                    delegate: taskDataSource,
                                    pageCount: (taskCount.length / rowsPerPage).ceilToDouble(),
                                    direction: Axis.horizontal,
                                  ),
                                )
                              ],
                            ),
                          ],
                        );
                      });
                    } else if (state is TasksLoading) {
                      return LoadingBox(
                        height: 20,
                      );
                    } else if (state is TasksEmpty) {
                      return Center(child: Text("No Tests to show"));
                    } else {
                      return Text("load failed.");
                    }
                  },
                ),
              ],
            );
          } else {
            return BlocBuilder<TasksListBloc, TasksListState>(
                bloc: BlocProvider.of<TasksListBloc>(context),
                builder: (context, state) {
                  if (state is TasksSuccess) {
                    List<Task> showPendingTaskOnly = [];
                    print("state tasks ${state.tasks}");
                    state.tasks.forEach((e) {
                      e.taskStudents.forEach((el) {
                        if (el.result == null) {
                          showPendingTaskOnly.add(e);
                          print("showPendingTaskOnly $showPendingTaskOnly");
                        }
                      });
                    });
                    return ConstrainedBox(
                      constraints: BoxConstraints(maxHeight: 1000),
                      child: ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: showPendingTaskOnly.length,
                          itemBuilder: (BuildContext context, index) {
                            return Container(
                              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                              margin: EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(border: Border.all(width: 1, color: Color(0xFFD1D1D1))),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  KeyValueTextHorizontal(field: Translate.of(context).translate('title'), value: showPendingTaskOnly[index].title),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      KeyValueTextVertical(field: Translate.of(context).translate("created_time"), value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(showPendingTaskOnly[index].createdAt)).toString()),
                                      KeyValueTextVertical(field: Translate.of(context).translate("begin_time"), value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(showPendingTaskOnly[index].endDate)).toString()),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      KeyValueTextVertical(field: Translate.of(context).translate("created_dep_worker"), value: showPendingTaskOnly[index].taskCreator.department.name + ", " + showPendingTaskOnly[index].taskCreator.name),
                                      KeyValueTextVertical(field: Translate.of(context).translate("finish_dep_worker"), value: showPendingTaskOnly[index].dept.name),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  KeyValueTextHorizontal(field: Translate.of(context).translate('description'), value: showPendingTaskOnly[index].description),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  AppButton(
                                    Translate.of(context).translate('view_details'),
                                    onPressed: () {
                                      setState(() {
                                        selectedWidgetPage = StudentsWidgets.taskDetails;
                                        task = showPendingTaskOnly[index];
                                      });
                                    },
                                    type: ButtonType.normal,
                                    color: Color(0xff787E8C),
                                  ),
                                ],
                              ),
                            );
                          }),
                    );
                  } else if (state is TasksLoading) {
                    return LoadingBox();
                  } else if (state is TasksEmpty) {
                    return Center(child: Text("No Records"));
                  } else {
                    return Text("load failed.");
                  }
                });
          }
        });
  }

  /// TEST QUESTIONS
  Widget openTest(context) {
    return StudentTakeTestPage(tests: tests, task: task);
  }

  ///TASK DETAILS
  Widget taskDetails(context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // heading
            // _header(),
            // const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  icon: Icon(Icons.close_outlined),
                  onPressed: () => Navigator.of(context).pop(),
                )
              ],
            ),

            // training type and training title
            Wrap(spacing: 100, runSpacing: 20, children: [
              _keyValueText(Translate.of(context).translate("training_type"), task.taskTrainingType.name),
              _keyValueText(Translate.of(context).translate("training_title"), task.title),
              // document feature type
              _keyValueText(Translate.of(context).translate("document_feature_type"), task.taskDocumentType.name),
              // training description
              _trainingDescription(),
            ]),
            // const SizedBox(height: 20),

            // const SizedBox(height: 20),

            const SizedBox(height: 20),

            // training documents buttons
            _trainingDocuments(),
            const SizedBox(height: 20),

            // create info card
            _createInfoCard(
              dept: task.taskCreator.department.name,
              worker: task.taskCreator.name,
              time: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(task.creatorConfirmDate)).toString(),
            ),
            const SizedBox(height: 20),

            // students info card
            // FIXME: can not find student info in task model.
            _studentInfoCard(
              name: _fakeWorker,
              department: _fakeDept,
              beginTime: _fakeTime,
              endTime: _fakeTime,
              result: "",
            )
          ],
        ),
      ),
    );
  }

  // Widget _header() {
  //   return Container(
  //     width: double.infinity,
  //     child: Wrap(
  //       alignment: WrapAlignment.spaceBetween,
  //       children: [
  //         SizedBox(
  //           width: 1,
  //         ),
  //         Row(
  //           mainAxisSize: MainAxisSize.min,
  //           children: [
  //             SizedBox(width: 10),
  //             AppButton(
  //               Translate.of(context).translate('go_to_test_page'),
  //               onPressed: () {
  //                 setState(() {
  //                   _go2TestPage();
  //                   tests = task.taskDocumentTests;
  //                   task = task;
  //                 });
  //               },
  //               type: ButtonType.normal,
  //               color: Color(0xff787E8C),
  //               icon: Icon(Icons.history_edu_outlined),
  //             ),
  //           ],
  //         )
  //       ],
  //     ),
  //   );
  // }

  Widget _keyValueText(String key, String value) {
    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.end,
      children: [
        // Container(width: 150, child: Text(key, style: _bold14)),
        Text(key, style: _bold14),
        SizedBox(width: 8.0),
        Text(value, style: _text12),
      ],
    );
  }

  get _bold14 => const TextStyle(fontSize: 14, fontWeight: FontWeight.bold);

  get _text12 => const TextStyle(fontSize: 14);

  Widget _trainingDescription() {
    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.end,
      children: [
        Text(Translate.of(context).translate("document_description"), style: _bold14),
        const SizedBox(width: 8),
        ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 500),
          child: Text(
            task.description,
            textAlign: TextAlign.justify,
          ),
        )
      ],
    );
  }

  Widget _trainingDocuments() {
    if (task.taskDocuments.first.document.documentFiles.isNotEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(Translate.of(context).translate("training_documents"), style: _bold14),
          const SizedBox(height: 7),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: 700),
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: List.generate(task.taskDocuments[0].document.documentFiles.length, (index) => _viewDocumentButton(task.taskDocuments[0].document.documentFiles[index].name, task.taskDocuments[0].document.documentFiles[index].path)),
            ),
          )
        ],
      );
    } else if (task.taskDocuments.first.document.documentTests.isNotEmpty) {
      return OutlinedButton(
        onPressed: () async {
          isConfirmed = await showDialog<bool>(
              context: context,
              barrierDismissible: false, // user must tap button!
              builder: (context) => StudentTakeTestPage(tests: task.taskDocuments.first.document.documentTests, task: task));
        },
        child: Text(Translate.of(context).translate("take_test")),
      );
    } else {
      return Container();
    }
  }

  Widget _viewDocumentButton(String name, String path) {
    return Container(
        height: 40,
        width: 200,
        child: OutlinedButton(
          onPressed: () async {
            DateTime _now = DateTime.now();
            currentSecond = _now.second;
            timer = Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
            isConfirmed = await _showMyDialog(name, path);
          },
          child: Text(Translate.of(context).translate("training_document")),
        ));
  }

  Widget twoLineText({String line1, String line2, Color line2Color = Colors.black}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(line1, style: _bold14),
        Text(line2, style: TextStyle(fontSize: 12, color: line2Color))
      ],
    );
  }

  Widget _createInfoCard({
    String dept,
    String worker,
    String time,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(
        children: [
          Container(
            height: 40,
            padding: const EdgeInsets.only(left: 30),
            alignment: Alignment.centerLeft,
            color: Colors.grey.withOpacity(.2),
            child: Text(Translate.of(context).translate("create_department"), style: _bold14),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 30),
            alignment: Alignment.centerLeft,
            child: Wrap(spacing: 160, runSpacing: 20, children: [
              twoLineText(
                line1: Translate.of(context).translate("create_department"),
                line2: dept,
              ),
              twoLineText(
                line1: Translate.of(context).translate("create_worker"),
                line2: worker,
              ),
              twoLineText(
                line1: Translate.of(context).translate("create_time"),
                line2: time,
              ),
            ]),
          )
        ],
      ),
    );
  }

  Widget _studentInfoCard({
    String name,
    String department,
    String beginTime,
    String endTime,
    String result,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(border: Border.all(width: 1, color: Colors.black12)),
      child: Column(
        children: [
          Container(
            height: 40,
            padding: const EdgeInsets.only(left: 30),
            alignment: Alignment.centerLeft,
            color: Colors.grey.withOpacity(.2),
            child: Text(Translate.of(context).translate("student"), style: _bold14),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 30),
            alignment: Alignment.centerLeft,
            child: Wrap(
              spacing: 160,
              runSpacing: 20,
              children: [
                twoLineText(
                  line1: Translate.of(context).translate("student_name"),
                  line2: name,
                ),
                twoLineText(
                  line1: Translate.of(context).translate("student_department"),
                  line2: department,
                ),
                twoLineText(
                  line1: Translate.of(context).translate("begin_time"),
                  line2: beginTime,
                ),
                twoLineText(
                  line1: Translate.of(context).translate("end_time"),
                  line2: endTime,
                ),
                twoLineText(
                  line1: Translate.of(context).translate("test_result"),
                  line2: result,
                  line2Color: result == "Pass" ? Colors.green : Colors.redAccent,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  get _fakeDept => "TODO";

  get _fakeWorker => "TODO";

  get _fakeTime => "TODO";

  Future<bool> _showMyDialog(String name, String path) async {
    print('currentSecond $currentSecond');
    timer = Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
    var tests;
    for (var taskdocs in task.taskDocuments) {
      if (taskdocs.document.documentTests.isNotEmpty) {
        tests = taskdocs.document.documentTests;
        break;
      }
    }

    return showDialog<bool>(
        context: context,
        barrierDismissible: false, // user must tap button!
        builder: (context) => StudentViewDocumentDialog(
              isNeedConfirm: true,
              name: name,
              path: path,
              task: task,
              tests: tests,
            ));
  }

  ButtonStyle outlinedButtonStyle() {
    return OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)), side: BorderSide(color: Colors.lightBlueAccent));
  }
}

class TaskDataSource extends DataGridSource {
  BuildContext contxt;
  int taskStatusId;
  Task task;
  final Completer _completer = new Completer();
  TaskDataSource(List<Task> tasksData, context, int statusId) {
    // tasks = tasksData;
    contxt = context;
    taskStatusId = statusId;

    ///PENDING TASKS
    tasksData.forEach((e) {
      e.taskStudents.forEach((el) {
        if (el.result == null) {
          tasks.add(e);
        }
      });
    });
    try {
      if (tasks.length < rowsPerPage) {
        paginatedTask = tasks.toList();
      } else {
        paginatedTask = tasks.getRange(0, rowsPerPage).toList();
      }
      buildPaginatedDataGridRows();
    } catch (e, stackTrace) {
      _completer.completeError(e, stackTrace);
    }
  }

  @override
  Future<bool> handlePageChange(
    int oldPageIndex,
    int newPageIndex,
  ) async {
    int startIndex = newPageIndex * rowsPerPage;
    int endIndex = startIndex + rowsPerPage;
    if (endIndex > this.tasks.length) {
      endIndex = this.tasks.length;
    }
    paginatedTask = List.from(
      this.tasks.getRange(startIndex, endIndex).toList(growable: false),
    );
    buildPaginatedDataGridRows();
    notifyListeners();
    return true;
  }

  List<DataGridRow> _tasks = [];
  List<Task> tasks = [];

  @override
  List<DataGridRow> get rows => _tasks;

  void buildPaginatedDataGridRows() {
    // ///PENDING TASKS
    // List<Task> pendingTasks = [];
    // paginatedTask.forEach((e) {
    //   e.taskStudents.forEach((el) {
    //     if (el.result == null) {
    //       pendingTasks.add(e);
    //     }
    //   });
    // });
    _tasks = paginatedTask
        .map<DataGridRow>(
          (e) => DataGridRow(
            cells: [
              DataGridCell(columnName: 'title', value: e),
              DataGridCell<String>(columnName: 'trainingType', value: e.taskTrainingType.name),
              // DataGridCell<String>(
              //     columnName: 'createdAt',
              //     value: DateFormat('yyyy/MM/dd hh:mm:ss')
              //         .format(DateTime.parse(e.createdAt))
              //         .toString()),
              DataGridCell(columnName: 'version', value: e.taskDocuments.first.document.version),
              DataGridCell<String>(columnName: 'endTime', value: DateFormat('yyyy/MM/dd hh:mm:ss').format(DateTime.parse(e.endDate)).toString()),
              DataGridCell<String>(
                columnName: 'createdDepWorker',
                value: e.taskCreator.department.name + ", " + e.taskCreator.name,
              ),
              DataGridCell<String>(
                columnName: 'finishDepWorker',
                value: e.dept.name,
              ),
            ],
          ),
        )
        .toList(growable: false);
  }

  List<int> taskIds = [];

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
      cells: [
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[0].value.title.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[1].value),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[2].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[3].value.toString()),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(row.getCells()[4].value),
          ),
        ),
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              row.getCells()[5].value.toString(),
            ),
          ),
        ),
      ],
    );
  }
}
