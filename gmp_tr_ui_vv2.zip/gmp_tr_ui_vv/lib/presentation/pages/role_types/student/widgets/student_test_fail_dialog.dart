import 'package:flutter/material.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/utils/utils.dart';

import '../../../../../global.dart';
import '../signed_by_big_leader.dart';
import '../student_take_test_page.dart';

class StudentTestFailDialog extends StatefulWidget {
  final int attempts;
  const StudentTestFailDialog({Key key, this.attempts}) : super(key: key);

  @override
  _StudentTestFailDialogState createState() => _StudentTestFailDialogState();
}

class _StudentTestFailDialogState extends State<StudentTestFailDialog> {
  Task task;
  int taskStatusId = 6;
  List<DocumentTests> tests;
  @override
  void initState() {
    super.initState();

    /// LOADS TASKS
    AppBloc.tasksBloc.add(OnLoadTasksEvent(
        viewType: [ViewType.regularTask],
        studentIdFk: Application.user.id,
        taskStatusId: taskStatusId));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 16,
      child: Stack(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(65, 100, 65, 75),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                Translate.of(context).translate("better_luck_next_time"),
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.redAccent),
              ),
              Text(
                Translate.of(context).translate("you_have_failed_your_exam"),
                style: TextStyle(
                    fontSize: 14,
                    color: Colors.black.withOpacity(.54),
                    fontWeight: FontWeight.w500),
              ),
              const SizedBox(
                height: 10,
              ),
              Text('${widget.attempts} out of 3 attempts completed.'),
              const SizedBox(height: 50),
              SizedBox(
                width: 300,
                height: 45,
                child: widget.attempts == 3
                    ? ElevatedButton(
                        onPressed: () => _gotoDashboard(context),
                        child: Text(
                            Translate.of(context).translate("go_to_dashboard")))
                    : ElevatedButton(
                        onPressed: () => _close(context),
                        child: Text(Translate.of(context)
                            .translate("retake_the_test"))),
              )
            ],
          ),
        ),
        Positioned(
          right: 0,
          child: IconButton(
              onPressed: () => _close(context),
              icon: Icon(Icons.close_outlined, size: 20)),
        )
      ]),
    );
  }

  void _close(BuildContext context) {
    Navigator.of(context).pop();
  }

  void _gotoDashboard(BuildContext context) {
    // StudentTakeTestPage(tests: tests);
    Navigator.of(context).pop();
    Navigator.of(context).pop();
    Navigator.of(context).pop();
  }
}
