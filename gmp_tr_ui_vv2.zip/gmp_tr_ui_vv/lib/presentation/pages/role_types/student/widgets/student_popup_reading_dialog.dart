import 'package:flutter/material.dart';

class StudentPopupReadingDialog extends StatefulWidget {
  const StudentPopupReadingDialog({Key key}) : super(key: key);

  @override
  _StudentPopupReadingDialogState createState() => _StudentPopupReadingDialogState();
}

class _StudentPopupReadingDialogState extends State<StudentPopupReadingDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog();
  }
}
