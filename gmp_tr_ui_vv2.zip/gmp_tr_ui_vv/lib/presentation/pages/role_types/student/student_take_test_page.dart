import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gmptr/blocs/app_bloc.dart';
import 'package:gmptr/blocs/bloc.dart';
import 'package:gmptr/configs/config.dart';
import 'package:gmptr/models/model.dart';
import 'package:gmptr/presentation/pages/role_types/creator/widgets/widgets.dart';
import 'package:gmptr/presentation/pages/role_types/student/widgets/student_task_fail_dialog.dart';
import 'package:gmptr/presentation/pages/role_types/student/widgets/student_test_fail_dialog.dart';
import 'package:gmptr/presentation/pages/role_types/student/widgets/student_test_pass_dialog.dart';
import 'package:gmptr/presentation/widgets/widget.dart';
import 'package:gmptr/utils/sizes.dart';
import 'package:gmptr/utils/utils.dart';
import 'package:responsive_builder/responsive_builder.dart';

class StudentTakeTestPage extends StatefulWidget {
  final List<DocumentTests> tests;
  final Task task;
  const StudentTakeTestPage({Key key, this.tests, this.task}) : super(key: key);

  @override
  _StudentTakeTestPageState createState() => _StudentTakeTestPageState();
}

class _StudentTakeTestPageState extends State<StudentTakeTestPage> {
  List<List<_TestOption>> selected;

  Future<void> _submit() async {
    List<bool> isPassed = [];
    List<dynamic> testData = [];
    for (int i = 0; i < widget.tests.length; i++) {
      // got true, if a test all right
      var chose = selected[i].where((e) => e.selected).toList();
      var selectedOption;
      for (int i = 0; i < chose.length; i++) {
        selectedOption = chose[i].text;
      }
      if (_isCorrect(widget.tests[i].rightAnswers, selected[i]) == true) {
        isPassed.add(true);
        testData.add({
          "${widget.tests[i].id}": ['$selectedOption']
        });
      } else {
        testData.add({
          "${widget.tests[i].id}": ['$selectedOption']
        });
        isPassed.add(false);
      }
    }

    if (!isPassed.contains(null)) {
      AppBloc.testsBloc.add(OnSaveTest(
        testIdFk: widget.task.id,
        studentIdFk: Application.user.id,
        selectedAnswers: testData,
      ));
    }
    setState(() {
      isPassed.clear();
    });
    // Navigator.of(context).pop();
  }

  bool _isCorrect(List<String> rightAnswers, List<_TestOption> options) {
    var chose = options.where((e) => e.selected).toList();
    if (chose.length != rightAnswers.length) {
      return false;
    }

    for (int i = 0; i < chose.length; i++) {
      if (chose[i].text != rightAnswers[i]) {
        print("${chose[i].text} != ${rightAnswers[i]}");
        return false;
      }
    }

    return true;
  }

  @override
  void initState() {
    super.initState();
    selected = List.generate(
        widget.tests.length,
        (i) => List.generate(widget.tests[i].totalAnswers.length,
            (j) => _TestOption(widget.tests[i].totalAnswers[j])));
  }

  Future<void> showTestPassDialog() async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => StudentTestPassDialog());
  }

  Future<void> showTestFailDialog(attempts) async {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) => StudentTestFailDialog(attempts: attempts));
  }

  Future<void> showTaskFailDialog() async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => StudentTaskFailDialog());
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      child: ListView(
        shrinkWrap: true,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 12, 25),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // heading text and two button, close / confirm
                Container(
                  width: double.infinity,
                  child: Wrap(
                    runSpacing: 10,
                    alignment: WrapAlignment.spaceBetween,
                    children: [
                      HeadingText(Translate.of(context).translate("test")),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          BlocBuilder<TestsBloc, TestsState>(
                            builder: (context, submit) {
                              return BlocListener<TestsBloc, TestsState>(
                                  listener: (context, state) {
                                    if (state is TestsaveFail) {
                                      showTaskFailDialog();
                                    }
                                    if (state is TestsaveSuccess) {
                                      showTestPassDialog();
                                    }
                                    if (state is TestAttemptsFailed) {
                                      showTestFailDialog(state.attempts);
                                    }
                                  },
                                  child: AppButton(
                                    Translate.of(context).translate('submit'),
                                    onPressed: () {
                                      // Navigator.of(context).pop();
                                      _submit();
                                    },
                                    loading: submit is Testsaving,
                                    disabled: submit is Testsaving ||
                                        selected.isEmpty,
                                    type: ButtonType.normal,
                                    color: Color(0xff787E8C),
                                    icon: Icon(
                                      Icons.done_outlined,
                                    ),
                                  ));
                            },
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                // tests
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: widget.tests.length,
                    itemBuilder: (context, index) {
                      return ResponsiveBuilder(
                          refinedBreakpoints: RefinedBreakpoints(),
                          builder: (context, sizingInformation) {
                            double screenWidth =
                                sizingInformation.screenSize.width;
                            //Desktop
                            if (screenWidth >
                                (RefinedBreakpoints().mobileExtraLarge)) {
                              return Card(
                                margin: EdgeInsets.all(10),
                                color: Colors.white,
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      vertical: 20, horizontal: 10),
                                  child: _StudentSingleTest(
                                    index,
                                    widget.tests[index].question,
                                    selected[index],
                                  ),
                                ),
                              );
                            } else {
                              return Container(
                                child: _StudentMobileSingleTest(
                                  index,
                                  widget.tests[index].question,
                                  selected[index],
                                ),
                              );
                            }
                          });
                    }),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StudentSingleTest extends StatefulWidget {
  final int index;
  final String question;
  final List<_TestOption> options;

  const _StudentSingleTest(this.index, this.question, this.options, {Key key})
      : super(key: key);

  @override
  _StudentSingleTestState createState() => _StudentSingleTestState();
}

class _StudentSingleTestState extends State<_StudentSingleTest> {
  List<bool> selectedAnswers = [];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final len = widget.options.length;

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: 36,
          width: 36,
          alignment: Alignment.center,
          child: Text(
            "${widget.index + 1}",
            style: TextStyle(color: Color(0xff2A2D33)),
          ),
          color: Colors.grey.withOpacity(.15),
        ),
        SizedBox(width: 13),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.question,
                style: TextStyle(fontSize: Sizes.TEXT_SIZE_12),
                textAlign: TextAlign.justify,
                softWrap: true,
              ),
              Wrap(
                spacing: 13,
                children: List.generate(
                  len,
                  (index) => Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Checkbox(
                        activeColor: Colors.blueAccent,
                        value: widget.options[index].selected,
                        onChanged: (val) {
                          setState(() {
                            widget.options[index].selected = val;
                            selectedAnswers.add(val);
                          });
                        },
                      ),
                      Text(widget.options[index].text,
                          style: TextStyle(fontSize: Sizes.TEXT_SIZE_12))
                    ],
                  ),
                ),
              ),
            ],
          ),
        )
      ],
    );
  }
}

class _StudentMobileSingleTest extends StatefulWidget {
  final int index;
  final String question;
  final List<_TestOption> options;

  const _StudentMobileSingleTest(this.index, this.question, this.options,
      {Key key})
      : super(key: key);

  @override
  _StudentMobileSingleTestState createState() =>
      _StudentMobileSingleTestState();
}

class _StudentMobileSingleTestState extends State<_StudentMobileSingleTest> {
  List<bool> selectedAnswers = [];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final len = widget.options.length;

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: 36,
          width: 36,
          alignment: Alignment.center,
          child: Text(
            "${widget.index + 1}",
            style: TextStyle(color: Color(0xff2A2D33)),
          ),
          color: Colors.grey.withOpacity(.15),
        ),
        SizedBox(width: 13),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.question,
                style: TextStyle(fontSize: Sizes.TEXT_SIZE_12),
                textAlign: TextAlign.justify,
                softWrap: true,
              ),
              Wrap(
                spacing: 13,
                children: List.generate(
                  len,
                  (index) => Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Checkbox(
                        activeColor: Colors.blueAccent,
                        value: widget.options[index].selected,
                        onChanged: (val) {
                          print(val);
                          setState(() {
                            widget.options[index].selected = val;
                            selectedAnswers.add(val);
                          });
                        },
                      ),
                      Text(widget.options[index].text,
                          style: TextStyle(fontSize: Sizes.TEXT_SIZE_12))
                    ],
                  ),
                ),
              ),
            ],
          ),
        )
      ],
    );
  }
}

class _TestOption {
  bool selected = false;
  String text;

  _TestOption(this.text);
}
