import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gmptr/presentation/pages/auth/authpage.dart';
import 'package:gmptr/presentation/pages/change_password.dart';
import 'package:gmptr/presentation/pages/error_page.dart';
import 'package:gmptr/presentation/pages/forgot_password.dart';
import 'package:gmptr/presentation/pages/role_types/types.dart';
import 'package:gmptr/presentation/pages/roles/user_roles.dart';
import 'package:gmptr/presentation/pages/signin/signin.dart';

class Routes {
  static const String authPage = "/";
  static const String roles = "/your-roles";
  static const String home = "/home";
  static const String studentRole = "/student";
  static const String account = "/account";
  static const String signIn = "/signIn";
  static const String forgotPassword = "/forgotPassword";
  static const String editProfile = "/editProfile";
  static const String changePassword = "/changePassword";
  static const String changeLanguage = "/changeLanguage";
  static const String userManagement = "/user-management";
  static const String aboutUs = "/aboutUs";
  static const String filter = "/filter";
  static const String setting = "/setting";
  static const String createUser = "/create-user";
  static const String error = "/error";
  Route<dynamic> generateMobileRoute(RouteSettings settings) {
    switch (settings.name) {
      case authPage:
        return MaterialPageRoute(
          builder: (context) {
            return AuthPage();
          },
        );
      case error:
        return MaterialPageRoute(
          builder: (context) {
            return ErrorPage();
          },
        );
      case signIn:
        return MaterialPageRoute(
          builder: (context) {
            return SignIn();
          },
        );
      case roles:
        return MaterialPageRoute(
          builder: (context) {
            return UserRoleTypes();
          },
        );
      case home:
        return MaterialPageRoute(
          builder: (context) {
            return HomeNavigation(roleId: settings.arguments);
          },
        );
      case userManagement:
        return MaterialPageRoute(
          builder: (context) {
            return UserManagementPage();
          },
        );

      case changePassword:
        return MaterialPageRoute(
          builder: (context) {
            return ChangePassword();
          },
        );

      default:
        return MaterialPageRoute(
          builder: (context) {
            return Scaffold(
              appBar: AppBar(
                title: Text("Not Found"),
              ),
              body: Center(
                child: Text('No path for ${settings.name}'),
              ),
            );
          },
        );
    }
  }

  Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case authPage:
        return _MaterialPageRoute(widget: AuthPage(), routeName: settings.name);
      case signIn:
        return _MaterialPageRoute(widget: SignIn(), routeName: settings.name);
      case roles:
        return _MaterialPageRoute(
            widget: UserRoleTypes(), routeName: settings.name);
      // case studentRole:
      //   return _MaterialPageRoute(
      //       widget: StudentRoleType(), routeName: settings.name);
      case home:
        return _MaterialPageRoute(
            widget: HomeNavigation(roleId: settings.arguments),
            routeName: settings.name);

      case userManagement:
        return _MaterialPageRoute(
            widget: UserManagementPage(), routeName: settings.name);

      case changePassword:
        return _MaterialPageRoute(
            widget: ChangePassword(), routeName: settings.name);

      case forgotPassword:
        return _MaterialPageRoute(
            widget: ForgotPassword(), routeName: settings.name);

      default:
        return _MaterialPageRoute(
            widget: Scaffold(
              appBar: AppBar(
                title: Text("Not Found"),
              ),
              body: Center(
                child: Text('No path for ${settings.name}'),
              ),
            ),
            routeName: settings.name);
    }
  }

  ///Singleton factory
  static final Routes _instance = Routes._internal();

  factory Routes() {
    return _instance;
  }

  Routes._internal();
}

class _MaterialPageRoute extends PageRouteBuilder {
  final Widget widget;
  final String routeName;
  _MaterialPageRoute({this.widget, this.routeName})
      : super(
            settings: RouteSettings(name: routeName),
            pageBuilder: (BuildContext context, Animation<double> animation,
                Animation<double> secondaryAnimation) {
              return widget;
            },
            transitionDuration: Duration(milliseconds: 300),
            transitionsBuilder: (BuildContext context,
                Animation<double> animation,
                Animation<double> secondaryAnimation,
                Widget child) {
              return SlideTransition(
                textDirection: TextDirection.rtl,
                position: Tween<Offset>(
                  begin: Offset(1.0, 0.0),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              );
            });
}
