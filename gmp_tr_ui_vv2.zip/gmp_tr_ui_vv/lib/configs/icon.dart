class CustomIcon {
  static const String begin = "assets/icons/begin.svg";
  static const String bigLeaderConfirmed =
      "assets/icons/big_leader_confirmed.svg";
  static const String bigLeaderSentBack =
      "assets/icons/big_leader_sent_back.svg";
  static const String created = "assets/icons/created.svg";
  static const String creatorCancelled = "assets/icons/creator_cancelled.svg";
  static const String creatorConfirmed = "assets/icons/creator_confirmed.svg";
  static const String expired = "assets/icons/expired.svg";
  static const String finished = "assets/icons/finished.svg";
  static const String smallLeaderConfirmed =
      "assets/icons/small_leader_confirmed.svg";
  static const String smallLeaderSentBack =
      "assets/icons/small_leader_sent_back.svg";

  ///Singleton factory
  static final CustomIcon _instance = CustomIcon._internal();

  factory CustomIcon() {
    return _instance;
  }

  CustomIcon._internal();
}
