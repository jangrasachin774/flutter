class Images {
  static const String LoginBg = "assets/images/bg.png";
  static const String Logo = "assets/images/logo.png";

  ///Singleton factory
  static final Images _instance = Images._internal();

  factory Images() {
    return _instance;
  }

  Images._internal();
}
